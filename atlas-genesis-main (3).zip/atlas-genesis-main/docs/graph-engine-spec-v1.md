# Atlas Kernel · Graph Engine Spec v2

> Motor de grafo operativo del metasistema ATLAS TRASCENDENCE (MD‑X4, RDM Digital, TAMV, Isabella).
> No es un knowledge graph informativo: es ejecutable, versionable, temporal y trazable.

---

## 1. Propósito

El Graph Engine de Atlas es la **capa de verdad operativa** del ecosistema civilizatorio: representa entidades, relaciones, eventos y gemelos digitales, y permite reconstruir y explicar la evolución del sistema en el tiempo.[file:426][file:427]

Objetivos principales:

- Reflejar en tiempo casi real la topología de **personas, organizaciones, territorios, sistemas, servicios, políticas, documentos, datasets, transacciones y gemelos**.[file:426][file:427]  
- Registrar cada acción relevante como **evento EOCT** y construir un grafo de trazas que permita auditoría, explicabilidad y cumplimiento (BookPI, MSR/ELITE, Kernel Isabella).[file:426][file:427]  
- Servir como backbone de **IA soberana y gemelos territoriales** (RDM Digital Nodo Cero y otros nodos MD‑X4) integrando estado actual + historial + políticas activas.[file:426][file:427][web:571]  

---

## 2. Ontología v2

### 2.1 EntityType

```text
PERSON
ORGANIZATION
TERRITORY
SYSTEM
SERVICE
DOCUMENT
POLICY
DATASET
REPO
EVENT
TWIN
PRODUCT
TRANSACTION
NODE
```

Atributos básicos de entidad:

```ts
Entity {
  id: UUID
  type: EntityType
  name: string
  slug: string
  federation: FederationType[]         // knowledge, identity, governance, economy, security, infrastructure, ai
  classification: Classification       // public, internal, sensitive, critical
  lifecycle_state: 'draft' | 'active' | 'deprecated' | 'archived'
  geo?: Geometry                       // Point / Polygon, para TERRITORY/TWIN/PRODUCT físico
  attributes: JSONB                    // Schema versionado por tipo
  created_at: timestamptz
  updated_at: timestamptz
  version: integer
}
```

### 2.2 RelationType

Relaciones dirigidas, con vigencia temporal y metadatos:

```text
BELONGS_TO
CONTAINS
DEPENDS_ON
AFFECTS
BACKED_BY
EXECUTES
MONETIZES
PRESERVES
FEDERATES
MIRRORS
EMITS
OBSERVES
```

Estructura general:

```ts
Relation {
  id: UUID
  source_id: UUID      // Entity.id
  target_id: UUID      // Entity.id
  type: RelationType
  federation_scope: FederationType[]
  classification: Classification
  valid_from: timestamptz
  valid_to?: timestamptz
  weight?: numeric      // scoring para IA/Isabella
  attributes: JSONB
  created_at: timestamptz
  updated_at: timestamptz
  version: integer
}
```

### 2.3 EventType (EOCT v2)

```text
OBSERVATION
DECISION
INCIDENT
STATE_TRANSITION
POLICY_CHANGE
RECONCILIATION
INGEST
PUBLISH
AUDIT
SECURITY_ALERT
```

Modelo de evento:

```ts
EoctEvent {
  id: UUID
  type: EventType
  timestamp: timestamptz
  subject_entity_id?: UUID        // entidad principal afectada
  actor_id: UUID | string         // persona, sistema, IA (Isabella/TAMVAI)
  federation: FederationType
  severity: 'info' | 'low' | 'medium' | 'high' | 'critical'
  payload: JSONB                  // datos específicos (schema-versioned)
  trace_id: UUID                  // grafo de trazas
  parent_event_id?: UUID          // para spans anidados
  created_at: timestamptz
}
```

Tablas auxiliares:

```ts
EoctRelatedEntity {
  event_id: UUID
  entity_id: UUID
  role: 'cause' | 'effect' | 'context'
}

EoctEvidenceLink {
  event_id: UUID
  kind: 'BOOKPI' | 'MSR' | 'ELITE' | 'LOG' | 'DOCUMENT' | 'DATASET'
  uri: string           // URL, DOI, hash, etc.
  hash?: string         // hash criptográfico opcional
}

EoctTrace {
  trace_id: UUID
  root_event_id: UUID
  span_count: integer
  severity: 'info' | 'low' | 'medium' | 'high' | 'critical'
  federation: FederationType
  created_at: timestamptz
}
```

---

## 3. Persistencia (Postgres · Lovable Cloud)

### 3.1 Esquema Atlas Kernel

Tablas canónicas:

- `entities`  
- `relations`  
- `eoct_events`, `eoct_related_entities`, `eoct_evidence_links`, `eoct_traces`  
- `twins`, `twin_relations`, `telemetry_points` (GEMET / RDM Digital)[web:571]  
- `documents`, `document_versions`, `document_links` (BookPI)[file:426][file:427]  
- `datasets` (Zenodo/Figshare, exports, snapshots)[file:426][web:571]  
- `anchors`, `elite_certifications` (MSR/ELITE)[file:426][file:427]  
- `transactions` (economía Lucrum Prime / TAMV)[file:427]  
- `nodes` (Nodo Cero RDM, otros nodos territoriales MD‑X4)[file:426]  

Ejemplo SQL simplificado:

```sql
CREATE TABLE entities (
  id               uuid PRIMARY KEY,
  type             text NOT NULL,
  name             text NOT NULL,
  slug             text UNIQUE,
  federation       text[] NOT NULL,
  classification   text NOT NULL,
  lifecycle_state  text NOT NULL,
  geo              geometry,
  attributes       jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  version          integer NOT NULL DEFAULT 1
);

CREATE TABLE relations (
  id               uuid PRIMARY KEY,
  source_id        uuid NOT NULL REFERENCES entities(id),
  target_id        uuid NOT NULL REFERENCES entities(id),
  type             text NOT NULL,
  federation_scope text[] NOT NULL,
  classification   text NOT NULL,
  valid_from       timestamptz NOT NULL,
  valid_to         timestamptz,
  weight           numeric,
  attributes       jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  version          integer NOT NULL DEFAULT 1
);

CREATE INDEX idx_entities_type_classification
  ON entities(type, classification);

CREATE INDEX idx_relations_source
  ON relations(source_id);

CREATE INDEX idx_relations_target
  ON relations(target_id);

CREATE INDEX idx_entities_geo
  ON entities USING gist (geo);
```

### 3.2 EOCT y trazas

```sql
CREATE TABLE eoct_events (
  id                uuid PRIMARY KEY,
  type              text NOT NULL,
  timestamp         timestamptz NOT NULL,
  subject_entity_id uuid REFERENCES entities(id),
  actor_id          text NOT NULL,
  federation        text NOT NULL,
  severity          text NOT NULL,
  payload           jsonb NOT NULL,
  trace_id          uuid NOT NULL,
  parent_event_id   uuid,
  created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE eoct_related_entities (
  event_id uuid NOT NULL REFERENCES eoct_events(id),
  entity_id uuid NOT NULL REFERENCES entities(id),
  role      text NOT NULL,
  PRIMARY KEY (event_id, entity_id, role)
);

CREATE TABLE eoct_evidence_links (
  event_id uuid NOT NULL REFERENCES eoct_events(id),
  kind     text NOT NULL,
  uri      text NOT NULL,
  hash     text,
  PRIMARY KEY (event_id, kind, uri)
);

CREATE TABLE eoct_traces (
  trace_id       uuid PRIMARY KEY,
  root_event_id  uuid NOT NULL REFERENCES eoct_events(id),
  span_count     integer NOT NULL,
  severity       text NOT NULL,
  federation     text NOT NULL,
  created_at     timestamptz NOT NULL DEFAULT now()
);
```

### 3.3 Gemelos (GEMET) y telemetría

```sql
CREATE TABLE twins (
  id              uuid PRIMARY KEY,
  entity_id       uuid NOT NULL REFERENCES entities(id),
  twin_type       text NOT NULL,           -- TERRITORY, SYSTEM, PROCESS, etc.
  resolution      text NOT NULL,           -- spatial/temporal resolution
  attributes      jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE telemetry_points (
  id         bigserial PRIMARY KEY,
  twin_id    uuid NOT NULL REFERENCES twins(id),
  metric     text NOT NULL,
  value      jsonb NOT NULL,
  source     text NOT NULL,
  timestamp  timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
```

### 3.4 Seguridad en base de datos

- **RLS** habilitado en todas las tablas de negocio.  
- Roles: `anon`, `authenticated`, `service_role`, `guardian`.  
- Policies por `classification` y por `federation` (LOD por permisos).  

Ejemplo:

```sql
ALTER TABLE entities ENABLE ROW LEVEL SECURITY;

CREATE POLICY entities_public ON entities
  FOR SELECT
  TO anon
  USING (classification = 'public');

CREATE POLICY entities_internal ON entities
  FOR SELECT
  TO authenticated
  USING (classification IN ('public', 'internal'));
```

---

## 4. API de consulta y mutación

La capa de API expone funciones server‑side (TypeScript) y/o endpoints REST/GraphQL que entregan un **view‑model {nodes, edges}** y un DSL de consulta semántica sobre el grafo.[file:426][file:427][web:573]

### 4.1 Funciones existentes (v1, extendidas)

```ts
getAtlasGraph(params: {
  federation?: FederationType
  limit?: number
  entityTypes?: EntityType[]
  relationTypes?: RelationType[]
  classificationMax?: Classification
  timeRange?: { from: string; to?: string }
}): Promise<{ nodes: NodeVM[]; edges: EdgeVM[] }>

getEoctStream(params: {
  limit?: number
  type?: EventType
  severity?: 'info' | 'low' | 'medium' | 'high' | 'critical'
  federation?: FederationType
}): Promise<EoctEvent[]>

getFederationManifest(): Promise<FederationManifest>

recordEoctEvent(event: EoctEventInput): Promise<{ id: string }>
```

### 4.2 Nuevas funciones de consulta

```ts
getEntityGraph(params: {
  rootId: string
  depth: number
  direction?: 'out' | 'in' | 'both'
  relationTypes?: RelationType[]
  classificationMax?: Classification
}): Promise<{ nodes: NodeVM[]; edges: EdgeVM[] }>

findPath(params: {
  sourceId: string
  targetId: string
  maxDepth?: number
  relationTypes?: RelationType[]
}): Promise<{ nodes: NodeVM[]; edges: EdgeVM[] }>

getTwinState(params: {
  twinId: string
  at?: string   // ISO timestamp; si no, "now"
}): Promise<TwinStateVM>

queryGraph(params: {
  dsl: string   // DSL propia o subconjunto de Cypher/openCypher
}): Promise<QueryResult>
```

### 4.3 Mutación controlada

Todas las mutaciones sensibles pasan por Kernel Isabella.

```ts
mutateGraph(params: {
  operations: GraphOperation[]
  actor: ActorContext
}): Promise<{
  results: OperationResult[]
  eoctEvents: EoctEvent[]
}>
```

Ejemplo de operación:

```ts
type GraphOperation =
  | { op: 'createEntity'; entity: Partial<Entity> }
  | { op: 'updateEntity'; id: string; patch: Partial<Entity> }
  | { op: 'deleteEntity'; id: string }
  | { op: 'createRelation'; relation: Partial<Relation> }
  | { op: 'updateRelation'; id: string; patch: Partial<Relation> }
  | { op: 'deleteRelation'; id: string };
```

### 4.4 View‑model de visualización

```ts
type NodeVM = {
  id: string
  label: string
  type: EntityType
  federation: FederationType[]
  classification: Classification
  visual: {
    color: string
    size: number
    icon?: string
  }
  meta: {
    lifecycle_state?: string
    severity?: string
    geo?: { lat: number; lng: number }
  }
}

type EdgeVM = {
  id: string
  source: string
  target: string
  type: RelationType
  visual: {
    width: number
    dash?: boolean
  }
  meta: {
    valid_from?: string
    valid_to?: string
  }
}
```

Ejemplo de payload:

```json
{
  "nodes": [
    {
      "id": "uuid",
      "label": "Atlas Kernel",
      "type": "SYSTEM",
      "federation": ["knowledge"],
      "classification": "internal",
      "visual": { "color": "#7DD3FC", "size": 14, "icon": "system" },
      "meta": {
        "lifecycle_state": "active"
      }
    }
  ],
  "edges": [
    {
      "id": "uuid",
      "source": "uuid",
      "target": "uuid2",
      "type": "CONTAINS",
      "visual": { "width": 2 },
      "meta": {
        "valid_from": "2026-01-01T00:00:00Z"
      }
    }
  ]
}
```

---

## 5. Render y vistas

### 5.1 Motor de visualización

- WebGL/Canvas2D basado en layout **force‑directed** con soporte para:
  - Layout radial (por federación).  
  - Layout temporal (timeline por EOCT).  
  - Reclustering por territorio/twin para vistas de RDM Digital y nodos territoriales.[web:571]  

### 5.2 Capas

- **Federación**: colores por `knowledge`, `identity`, `governance`, `economy`, `security`, `infrastructure`, `ai`.  
- **Clasificación**: gradientes y filtros, con redacción automática para `sensitive` y `critical`.  
- **Tiempo**: slider que reconstruye el grafo a tiempo `t` usando `valid_from/valid_to` + EOCT.  
- **Severidad**: encoding visual para `INCIDENT`, `SECURITY_ALERT`, `POLICY_CHANGE`.  

### 5.3 Vistas predefinidas

- *Vista civilizatoria MD‑X4*: foco en federaciones y relaciones `FEDERATES`, `PRESERVES`, `MONETIZES`.[file:426]  
- *Vista Nodo Cero RDM Digital*: TERRITORY + TWIN + PRODUCT + TRANSACTION + EVENT, con telemetría agregada.[file:427][web:571]  
- *Vista BookPI/MSR/ELITE*: DOCUMENT ↔ EVENT ↔ TRANSACTION ↔ ANCHOR (`BACKED_BY`, `PRESERVES`).[file:426][file:427]  

---

## 6. Seguridad y Kernel Isabella

### 6.1 Separación de planos

- Plano **visual** (UI): solo consume view‑models y endpoints read‑only, sin acceso directo a las tablas base.  
- Plano **ejecutable** (orquestadores, CI/CD, servicios): usa endpoints internos firmados y con mTLS, sometidos a Zero Trust.[file:426][file:427]  

### 6.2 LOD (Level of Detail)

- `anon`: grafo macro agregando entidades y ocultando identificadores sensibles.  
- `authenticated`: vistas detalladas solo en federaciones autorizadas.  
- `guardian/admin`: acceso de bajo nivel guiado por políticas KORIMA y Kernel Isabella.  

LOD implementado vía vistas SQL y lógica en la capa de API.

### 6.3 Interfaz con Kernel Isabella

Antes de aplicar mutaciones sensibles o registrar EOCT críticos, se consulta al Kernel:

```http
POST /kernel-isabella/evaluate-graph-operation
Content-Type: application/json
Authorization: Bearer <service-token>

{
  "actor": { "id": "user-or-service-id", "role": "guardian" },
  "operations": [ /* GraphOperation[] */ ],
  "context": {
    "federation": "governance",
    "source": "atlas-graph-api",
    "request_id": "uuid"
  }
}
```

Respuesta:

```json
{
  "allow": true,
  "reason": "Policy KORIMA-SEC-01 satisfied",
  "policy_refs": ["KORIMA-SEC-01", "MDX4-GOV-03"],
  "eoct_to_emit": [
    {
      "type": "POLICY_CHANGE",
      "severity": "medium",
      "payload": { "delta": "..." }
    }
  ]
}
```

Solo si `allow = true` se persisten las operaciones y se emiten los EOCT asociados.

### 6.4 RLS y redacción

- RLS garantiza filtrado por fila; la capa de API aplica redacción de campos en `attributes` para entidades `sensitive` y `critical`.  
- Se auditan accesos de alta sensibilidad vía EOCT de tipo `AUDIT` y `SECURITY_ALERT`.  

---

## 7. Telemetría y observabilidad

Cada operación relevante del Graph Engine genera spans OpenTelemetry y métricas:

- Spans:
  - `graph.query`
  - `graph.mutate`
  - `graph.view`
  - `graph.eoct.emit`  

- Tags:
  - `federation`
  - `classification`
  - `entity_type`
  - `relation_type`
  - `latency_bucket`  

- Métricas:
  - QPS y latencia (p50/p95/p99) por tipo de operación.  
  - Número de nodos/aristas por federación y clasificación.  
  - Conteo de EOCT por tipo, severidad, territorio, nodo MD‑X4.[web:571][web:573]  

---

## 8. Latencia y modos de operación

### 8.1 Objetivos

- EOCT críticos (`SECURITY_ALERT`, `INCIDENT`): reflejo en UI < 3 s.  
- Cambios de estado normales (alta/baja de entidades y relaciones): < 30 s.  
- Manifest global/federation manifest: < 500 ms.  

### 8.2 Hot path / cold path

- **Hot path**: vistas precalculadas y caché en memoria/Redis para:
  - `graph_public`
  - `graph_mdX4_overview`
  - `graph_rdm_overview`  

- **Cold path**: queries analíticas (paths largos, comparaciones históricas, reconstrucción de estados pasados) sirviéndose de EOCT + snapshots.[web:574]  

---

## 9. Blueprint modular de implementación

### 9.1 Módulos

- `atlas-graph-core`  
  - Modelos de dominio, repositorios, funciones SQL, políticas de RLS.  

- `atlas-graph-api`  
  - HTTP/GraphQL gateway, serialización a view‑model, RBAC, LOD.  

- `atlas-graph-ingest`  
  - Suscripción a colas/event bus (EOCT, telemetría, BookPI/MSR/ELITE, RDM, TAMV).  

- `atlas-graph-render`  
  - Librería de front para visualización (layouts, capas, interacciones).  

- `atlas-graph-isabella-bridge`  
  - Cliente de Kernel Isabella y mapeo de políticas KORIMA/MD‑X4 a reglas operativas del grafo.[file:426][file:427]  

### 9.2 Diagrama lógico (descripción)

- **Centro**: Postgres (entities, relations, eoct_*, twins, telemetry_points) + módulo `atlas-graph-core`.  
- **Arriba**: `atlas-graph-api` exponiendo las funciones `getAtlasGraph`, `getEntityGraph`, `findPath`, `getTwinState`, `mutateGraph`.  
- **Izquierda**: UIs (Atlas, panel MD‑X4, RDM Digital Nodo Cero, dashboards territoriales) consumiendo la API.  
- **Derecha**: `kernel-isabella` recibiendo propuestas de mutación y EOCT, devolviendo decisiones, razones y referencias de política.  
- **Abajo**: sistemas de evidencia (BookPI, MSR, ELITE, Zenodo, Figshare, repositorios de código) conectados mediante `BACKED_BY`, `PRESERVES`, `EMITS`.  

---

## 10. Ejemplo de flujo completo

1. Un comercio en RDM Digital se registra y pasa el proceso de aprobación: se crean `ENTITY: ORGANIZATION` y `ENTITY: PRODUCT`, y se vinculan a `TERRITORY` (Real del Monte) vía `BELONGS_TO` y `MONETIZES`.[file:427]  
2. El operador municipal cambia una política de visibilidad comercial, generando un EOCT `POLICY_CHANGE` en federación `governance`.  
3. `atlas-graph-api` prepara las mutaciones y llama a `kernel-isabella/evaluate-graph-operation`.  
4. Kernel Isabella valida que la política respeta KORIMA/MD‑X4 (p.ej., no mostrar comercios no registrados/pagados), devuelve `allow: true` y un EOCT adicional de auditoría.[file:426][file:427]  
5. `atlas-graph-core` aplica las mutaciones, emite EOCT, actualiza vistas y cache hot path, y la UI de Atlas/RDM refleja el cambio en segundos.  
6. BookPI/MSR registra el cambio de política con anclas y documentos vinculados (`BACKED_BY`), cerrando el circuito de trazabilidad.[file:426][file:427]  

---
