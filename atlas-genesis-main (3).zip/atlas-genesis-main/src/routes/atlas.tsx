import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState, useRef, useEffect } from "react";
import { Shell } from "@/components/Shell";
import { Starfield } from "@/components/Starfield";
import { RealmontenseBadge } from "@/components/RealmontenseBadge";
import { useI18n } from "@/lib/i18n";
import {
  absorbAll,
  askIsabella,
  getGithubProfile,
} from "@/lib/atlas.functions";
import { ingestAll, getIngestStats } from "@/lib/atlas-ingest.functions";

export const Route = createFileRoute("/atlas")({
  head: () => ({
    meta: [
      { title: "Atlas Absorber — ATLAS TRASCENDENCE" },
      { name: "description", content: "Pipeline de absorción civilizatoria: GitHub · OpenAIRE · Zenodo · Figshare · ORCID · Isabella." },
    ],
  }),
  component: AtlasPage,
});

type ChatMsg = { role: "user" | "isabella"; text: string };

function AtlasPage() {
  const { lang } = useI18n();
  const absorb = useServerFn(absorbAll);
  const isabellaFn = useServerFn(askIsabella);
  const ghFn = useServerFn(getGithubProfile);
  const ingestFn = useServerFn(ingestAll);
  const statsFn = useServerFn(getIngestStats);

  const stats = useQuery({ queryKey: ["atlas", "ingest-stats"], queryFn: () => statsFn(), refetchInterval: 8000 });
  const ingestM = useMutation({
    mutationFn: (q: string) => ingestFn({ data: { q } }),
    onSuccess: () => stats.refetch(),
  });

  const [query, setQuery] = useState("memoria civilizatoria");

  const gh = useQuery({
    queryKey: ["atlas", "github", "OsoPanda1"],
    queryFn: () => ghFn(),
    staleTime: 1000 * 60 * 5,
  });

  const absorbQ = useQuery({
    queryKey: ["atlas", "absorb", query],
    queryFn: () => absorb({ data: { q: query } }),
    staleTime: 1000 * 60,
  });

  // Isabella chat
  const [messages, setMessages] = useState<ChatMsg[]>([
    {
      role: "isabella",
      text:
        lang === "es"
          ? "Soy ISABELLA. Núcleo cognitivo de Atlas. Pregúntame por el grafo, los axiomas, o el flujo de absorción."
          : "I am ISABELLA. Atlas cognitive core. Ask me about the graph, the axioms, or the absorption flow.",
    },
  ]);
  const [input, setInput] = useState("");
  const chatEnd = useRef<HTMLDivElement>(null);

  const ask = useMutation({
    mutationFn: async (msg: string) => {
      const ctx = absorbQ.data
        ? `Query=${absorbQ.data.query}\nGitHub user=${absorbQ.data.github?.user?.login ?? "n/a"} (${absorbQ.data.github?.user?.public_repos ?? 0} repos, ${absorbQ.data.github?.stats?.stars ?? 0} stars)\nOpenAIRE=${absorbQ.data.openaire?.total ?? 0}\nZenodo=${absorbQ.data.zenodo?.total ?? 0}\nFigshare=${absorbQ.data.figshare?.total ?? 0}\nORCID=${absorbQ.data.orcid?.total ?? 0}`
        : undefined;
      return isabellaFn({ data: { message: msg, context: ctx } });
    },
    onSuccess: (res) => {
      setMessages((m) => [
        ...m,
        { role: "isabella", text: res.ok ? res.reply : `⚠ ${res.error ?? "error"}` },
      ]);
    },
  });

  useEffect(() => {
    chatEnd.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, ask.isPending]);

  function send() {
    const m = input.trim();
    if (!m) return;
    setMessages((prev) => [...prev, { role: "user", text: m }]);
    setInput("");
    ask.mutate(m);
  }

  const sources = absorbQ.data;

  return (
    <Shell>
      <section className="relative border-b border-border overflow-hidden">
        <Starfield count={70} />
        <div className="relative mx-auto max-w-7xl px-6 py-16">
          <div className="flex flex-wrap items-center gap-3 mb-6">
            <div className="chip">ATLAS · ABSORBER</div>
            <RealmontenseBadge variant="compact" />
          </div>
          <h1 className="font-display text-5xl md:text-6xl leading-[0.95] max-w-4xl">
            {lang === "es" ? "Flujo de absorción civilizatoria" : "Civilizational absorption flow"}
            <span className="text-primary text-glow">.</span>
          </h1>
          <p className="mt-4 text-muted-foreground max-w-2xl">
            {lang === "es"
              ? "Conexiones activas: GitHub · OpenAIRE · Zenodo · Figshare · ORCID. Isabella interpreta y memoriza."
              : "Live connections: GitHub · OpenAIRE · Zenodo · Figshare · ORCID. Isabella interprets and remembers."}
          </p>

          <div className="mt-8 flex flex-wrap gap-2 items-center hairline rounded-sm p-2 max-w-2xl">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && absorbQ.refetch()}
              placeholder={lang === "es" ? "Consulta semántica…" : "Semantic query…"}
              className="flex-1 bg-transparent px-3 py-2 mono text-sm outline-none placeholder:text-muted-foreground/50"
            />
            <button
              onClick={() => absorbQ.refetch()}
              className="px-4 py-2 bg-primary text-primary-foreground mono text-[10px] tracking-[0.2em] uppercase rounded-sm hover:bg-primary/90"
            >
              {absorbQ.isFetching ? "…" : lang === "es" ? "Absorber" : "Absorb"}
            </button>
          </div>
        </div>
      </section>

      {/* INGESTA REAL → Lovable Cloud */}
      <section className="py-12 border-b border-border bg-card/20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="flex flex-wrap items-baseline justify-between gap-4 mb-6">
            <div>
              <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">INGESTA · PERSISTENCIA · EOCT</div>
              <h2 className="font-display text-3xl">{lang === "es" ? "Persistir en el Atlas" : "Persist into Atlas"}</h2>
              <p className="text-sm text-muted-foreground mt-1 max-w-2xl">
                {lang === "es"
                  ? "Escribe entidades reales (GitHub repos, ORCID, Zenodo, Figshare, OpenAIRE) en la base civilizatoria y emite eventos EOCT firmados."
                  : "Writes real entities (GitHub repos, ORCID, Zenodo, Figshare, OpenAIRE) into the civilizational ledger and emits signed EOCT events."}
              </p>
            </div>
            <button
              onClick={() => ingestM.mutate(query)}
              disabled={ingestM.isPending}
              className="px-5 py-2.5 bg-primary text-primary-foreground mono text-[10px] tracking-[0.22em] uppercase rounded-sm hover:bg-primary/90 disabled:opacity-50"
            >
              {ingestM.isPending ? (lang === "es" ? "Ingiriendo…" : "Ingesting…") : (lang === "es" ? "Ingerir Todo" : "Ingest All")}
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-px hairline rounded-sm overflow-hidden">
            {(["github","orcid","zenodo","figshare","openaire"] as const).map((k) => (
              <div key={k} className="bg-card/40 p-4">
                <div className="mono text-[9px] tracking-[0.22em] uppercase text-muted-foreground">{k}</div>
                <div className="font-display text-3xl text-primary mt-1">{stats.data?.bySource?.[k] ?? 0}</div>
                <div className="mono text-[9px] text-muted-foreground/70 mt-1">entidades</div>
              </div>
            ))}
          </div>

          <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-px hairline rounded-sm overflow-hidden">
            <div className="bg-card/40 p-4">
              <div className="mono text-[9px] tracking-[0.22em] uppercase text-muted-foreground">Entidades totales</div>
              <div className="font-display text-2xl">{stats.data?.totals?.entities ?? 0}</div>
            </div>
            <div className="bg-card/40 p-4">
              <div className="mono text-[9px] tracking-[0.22em] uppercase text-muted-foreground">Eventos INGEST</div>
              <div className="font-display text-2xl">{stats.data?.totals?.ingest_events ?? 0}</div>
            </div>
            <div className="bg-card/40 p-4">
              <div className="mono text-[9px] tracking-[0.22em] uppercase text-muted-foreground">Última corrida</div>
              <div className="mono text-xs mt-1">
                {ingestM.data ? `+${ingestM.data.entities} ent · +${ingestM.data.events} ev` : "—"}
              </div>
              {ingestM.data && ingestM.data.errors.length > 0 && (
                <div className="mono text-[9px] text-amber-300 mt-1 truncate" title={ingestM.data.errors.join("; ")}>
                  {ingestM.data.errors.length} warn
                </div>
              )}
            </div>
          </div>
        </div>
      </section>


      {/* GitHub absorbed panel */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-6">
          <div className="flex items-baseline justify-between mb-6">
            <div>
              <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">F-01 · KNOWLEDGE · IDENTITY</div>
              <h2 className="font-display text-3xl">GitHub · @OsoPanda1</h2>
            </div>
            <a
              href="https://github.com/OsoPanda1"
              target="_blank"
              rel="noreferrer"
              className="mono text-[10px] tracking-[0.2em] uppercase text-primary hover:text-glow"
            >
              github.com/OsoPanda1 ↗
            </a>
          </div>

          {gh.isLoading && <div className="mono text-xs text-muted-foreground">Absorbiendo perfil…</div>}
          {gh.data?.user && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="glass rounded-sm p-6 lg:col-span-1">
                <div className="flex items-center gap-4">
                  {gh.data.user.avatar && (
                    <img src={gh.data.user.avatar} alt={gh.data.user.login} className="w-16 h-16 rounded-sm border border-primary/40" />
                  )}
                  <div>
                    <div className="font-display text-xl">{gh.data.user.name ?? gh.data.user.login}</div>
                    <div className="mono text-[10px] text-muted-foreground">@{gh.data.user.login}</div>
                  </div>
                </div>
                {gh.data.user.bio && <p className="mt-4 text-sm text-foreground/80">{gh.data.user.bio}</p>}
                <div className="mt-6 grid grid-cols-3 gap-px hairline rounded-sm overflow-hidden">
                  {[
                    { l: "repos", v: gh.data.user.public_repos },
                    { l: "stars", v: gh.data.stats.stars },
                    { l: "forks", v: gh.data.stats.forks },
                  ].map((m) => (
                    <div key={m.l} className="bg-card/40 px-3 py-3 text-center">
                      <div className="font-display text-2xl text-primary">{m.v}</div>
                      <div className="mono text-[9px] tracking-[0.2em] uppercase text-muted-foreground">{m.l}</div>
                    </div>
                  ))}
                </div>
                {gh.data.stats.languages.length > 0 && (
                  <div className="mt-5">
                    <div className="mono text-[10px] tracking-[0.2em] text-muted-foreground mb-2">LANGUAGES</div>
                    <div className="flex flex-wrap gap-2">
                      {gh.data.stats.languages.slice(0, 8).map(([k, v]) => (
                        <span key={k} className="chip">{k} · {v}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="glass rounded-sm p-6 lg:col-span-2">
                <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-3">
                  {lang === "es" ? "Repositorios absorbidos" : "Absorbed repositories"}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-px hairline rounded-sm overflow-hidden">
                  {gh.data.repos.map((r) => (
                    <a key={r.full_name} href={r.url} target="_blank" rel="noreferrer" className="bg-card/40 p-4 hover:bg-card/70 transition block">
                      <div className="flex items-baseline justify-between gap-3">
                        <div className="font-display text-base text-foreground truncate">{r.name}</div>
                        <div className="mono text-[9px] text-muted-foreground shrink-0">★ {r.stars}</div>
                      </div>
                      {r.description && <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{r.description}</div>}
                      <div className="mt-2 mono text-[9px] tracking-[0.2em] uppercase text-primary/80">
                        {r.language ?? "—"}
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Federated knowledge sources */}
      <section className="py-12 border-t border-border">
        <div className="mx-auto max-w-7xl px-6">
          <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-2">F-01 · CONOCIMIENTO FEDERADO</div>
          <h2 className="font-display text-3xl mb-8">
            {lang === "es" ? "Cuatro repositorios. Una memoria." : "Four repositories. One memory."}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            <SourceCard
              title="OpenAIRE"
              code="OA"
              total={sources?.openaire?.total}
              ok={sources?.openaire?.ok}
              items={sources?.openaire?.items?.map((i: any) => ({ title: i.title, sub: i.date }))}
              color="var(--fed-knowledge)"
            />
            <SourceCard
              title="Zenodo"
              code="ZE"
              total={sources?.zenodo?.total}
              ok={sources?.zenodo?.ok}
              items={sources?.zenodo?.items?.map((i: any) => ({ title: i.title, sub: i.type, href: i.url }))}
              color="var(--plasma)"
            />
            <SourceCard
              title="Figshare"
              code="FS"
              total={sources?.figshare?.total}
              ok={sources?.figshare?.ok}
              items={sources?.figshare?.items?.map((i: any) => ({ title: i.title, sub: i.published, href: i.url }))}
              color="var(--aurora)"
            />
            <SourceCard
              title="ORCID"
              code="OC"
              total={sources?.orcid?.total}
              ok={sources?.orcid?.ok}
              items={sources?.orcid?.items?.map((i: any) => ({
                title: `${i.given ?? ""} ${i.family ?? ""}`.trim() || i.orcid,
                sub: i.institutions?.[0],
                href: `https://orcid.org/${i.orcid}`,
              }))}
              color="var(--gold)"
            />
          </div>
        </div>
      </section>

      {/* Isabella console */}
      <section className="py-16 border-t border-border">
        <div className="mx-auto max-w-7xl px-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <div className="chip mb-4">F-07 · IA</div>
            <h2 className="font-display text-4xl mb-3">ISABELLA</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              {lang === "es"
                ? "Núcleo cognitivo asistido del metasistema. Opera bajo guardrails, lee el contexto absorbido y responde con doctrina."
                : "Assisted cognitive core. Operates under guardrails, reads the absorbed context, answers with doctrine."}
            </p>
            <div className="mt-6"><RealmontenseBadge variant="ribbon" /></div>
            <div className="mt-6 mono text-[10px] tracking-[0.2em] uppercase text-aurora flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-aurora shadow-[0_0_8px_var(--aurora)] animate-pulse" />
              {lang === "es" ? "Gateway activo · gemini-3-flash" : "Gateway live · gemini-3-flash"}
            </div>
          </div>

          <div className="lg:col-span-2 glass rounded-sm p-4 flex flex-col h-[520px]">
            <div className="flex-1 overflow-y-auto space-y-3 px-2 py-2">
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] px-4 py-2.5 rounded-sm text-sm whitespace-pre-wrap ${
                      m.role === "user"
                        ? "bg-primary/15 border border-primary/30"
                        : "bg-card/60 border border-border"
                    }`}
                  >
                    <div className="mono text-[9px] tracking-[0.22em] uppercase mb-1 opacity-70">
                      {m.role === "user" ? (lang === "es" ? "Tú" : "You") : "ISABELLA"}
                    </div>
                    {m.text}
                  </div>
                </div>
              ))}
              {ask.isPending && (
                <div className="mono text-[10px] text-muted-foreground px-2">ISABELLA · pensando…</div>
              )}
              <div ref={chatEnd} />
            </div>
            <div className="mt-3 flex gap-2 hairline rounded-sm p-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && send()}
                placeholder={lang === "es" ? "Pregunta a Isabella…" : "Ask Isabella…"}
                className="flex-1 bg-transparent px-3 py-2 text-sm outline-none placeholder:text-muted-foreground/50"
              />
              <button
                onClick={send}
                disabled={ask.isPending || !input.trim()}
                className="px-4 py-2 bg-primary text-primary-foreground mono text-[10px] tracking-[0.2em] uppercase rounded-sm hover:bg-primary/90 disabled:opacity-40"
              >
                {lang === "es" ? "Enviar" : "Send"}
              </button>
            </div>
          </div>
        </div>
      </section>
    </Shell>
  );
}

function SourceCard({
  title,
  code,
  total,
  ok,
  items,
  color,
}: {
  title: string;
  code: string;
  total?: number;
  ok?: boolean;
  items?: { title?: string; sub?: string; href?: string }[];
  color: string;
}) {
  return (
    <div className="glass rounded-sm p-5 relative overflow-hidden">
      <div className="absolute -right-8 -top-8 w-28 h-28 rounded-full opacity-30" style={{ background: `radial-gradient(circle, ${color}, transparent 70%)` }} />
      <div className="relative flex items-baseline justify-between mb-3">
        <div>
          <div className="mono text-[9px] tracking-[0.24em] uppercase text-muted-foreground">{code}</div>
          <div className="font-display text-xl" style={{ color }}>{title}</div>
        </div>
        <div className="text-right">
          <div className="font-display text-2xl" style={{ color }}>{total ?? "—"}</div>
          <div className="mono text-[8px] tracking-[0.2em] uppercase text-muted-foreground">{ok === false ? "offline" : "items"}</div>
        </div>
      </div>
      <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
        {(items ?? []).slice(0, 6).map((it, i) => {
          const body = (
            <>
              <div className="text-xs text-foreground/90 line-clamp-2">{it.title || "—"}</div>
              {it.sub && <div className="mono text-[9px] text-muted-foreground mt-0.5">{it.sub}</div>}
            </>
          );
          return it.href ? (
            <a key={i} href={it.href} target="_blank" rel="noreferrer" className="block py-1.5 border-b border-border/60 hover:bg-foreground/5 px-1 -mx-1">
              {body}
            </a>
          ) : (
            <div key={i} className="py-1.5 border-b border-border/60">{body}</div>
          );
        })}
        {(!items || items.length === 0) && (
          <div className="mono text-[10px] text-muted-foreground py-2">— sin datos —</div>
        )}
      </div>
    </div>
  );
}
