import type { ReactNode } from "react";
import { useEffect } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { I18nProvider } from "../lib/i18n";

// Si tienes un ThemeProvider o similar, impórtalo aquí
// import { ThemeProvider } from "../lib/theme";

/* 404 — anclada a tu propia narrativa de grafo civilizatorio */
function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl text-primary text-glow">404</h1>
        <p className="mt-2 mono text-xs tracking-[0.2em] uppercase text-muted-foreground">
          Entity not found in the civilizational graph
        </p>
        <p className="mt-3 text-xs text-muted-foreground">
          The requested node is not part of the current MD‑X4 heptafederated atlas.
        </p>
        <div className="mt-6 flex flex-col items-center gap-3">
          <Link
            to="/"
            className="mono text-xs tracking-[0.2em] uppercase border border-primary/40 px-4 py-2 rounded-sm hover:bg-primary/10 transition"
          >
            ← Return to Atlas
          </Link>
        </div>
      </div>
    </div>
  );
}

/* Error boundary — habla en lenguaje de kernel y transición de estados */
function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  const router = useRouter();

  useEffect(() => {
    // Enviar el error a tu canal de observabilidad
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-2xl">State transition failed</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          An anomaly was caught by the MD‑X4 boundary and did not corrupt the session.
        </p>
        <p className="mt-2 text-xs text-muted-foreground">
          The kernel has rolled back to a safe state. You can request a fresh evaluation.
        </p>
        <button
          onClick={() => {
            router.invalidate();
            reset();
          }}
          className="mt-6 mono text-xs tracking-[0.2em] uppercase border border-primary/40 px-4 py-2 rounded-sm hover:bg-primary/10 transition"
        >
          Retry
        </button>
      </div>
    </div>
  );
}

/**
 * Root route — aquí vive el “documento constitucional” del front:
 * meta, OG, layout base y providers globales.
 */
export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      {
        title:
          "ATLAS TRASCENDENCE — Metasistema civilizatorio heptafederado · TAMV ONLINE",
      },
      {
        name: "description",
        content:
          "Primer metasistema civilizatorio heptafederado originado en LATAM. Preservando todo aquello que la humanidad considera digno de ser recordado.",
      },
      { name: "author", content: "TAMV ONLINE · ORCID 0009-0008-5050-1539" },
      { name: "theme-color", content: "#020617" }, // obsidian-dark
      // Open Graph
      { property: "og:title", content: "ATLAS TRASCENDENCE · TAMV MD‑X4" },
      {
        property: "og:description",
        content:
          "Metasistema civilizatorio heptafederado desde Real del Monte, Hidalgo. Kernel MD‑X4, RDM Digital, IA soberana Isabella.",
      },
      { property: "og:type", content: "website" },
      { property: "og:locale", content: "es_MX" },
      // Puedes actualizarla a una imagen real cuando la tengas
      { property: "og:image", content: "/og/atlas-trascendence.png" },
      // Twitter
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "ATLAS TRASCENDENCE · TAMV ONLINE" },
      {
        name: "twitter:description",
        content:
          "Infraestructura civilizatoria MD‑X4 · IA soberana · RDM Digital · LATAM first.",
      },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      {
        rel: "preconnect",
        href: "https://fonts.gstatic.com",
        crossOrigin: "anonymous",
      },
      {
        rel: "stylesheet",
        href:
          "https://fonts.googleapis.com/css2?" +
          "family=Cormorant+Garamond:wght@300;400;500;600&" +
          "family=Inter+Tight:wght@300;400;500;600&" +
          "family=JetBrains+Mono:wght@300;400;500&display=swap",
      },
      // Canon del proyecto (ajusta la URL al DOI público cuando esté)
      {
        rel: "canonical",
        href: "https://tamv.online/atlas-trascendence",
      },
    ],
    // Si en el futuro quieres inyectar scripts globales, usa la key scripts aquí
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

/**
 * RootShell — documento HTML base que TanStack Start hidrata.
 * Sigue la recomendación oficial: <HeadContent /> + <Scripts />. [web:656][web:659]
 */
function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="es" data-mdx4-node="NODO_CERO_RDM">
      <head>
        <HeadContent />
      </head>
      <body className="min-h-screen bg-background text-foreground antialiased">
        {/* Puedes enganchar aquí un <div id="mdx4-debug" /> si lo necesitas */}
        {children}
        <Scripts />
      </body>
    </html>
  );
}

/**
 * RootComponent — capa de providers globales.
 * Es el equivalente a tu “MD‑X4 Frontend Kernel”:
 * - React Query
 * - I18n
 * - (Theme / Auth / Telemetría futura)
 */
function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      {/* ThemeProvider, si lo usas:
      <ThemeProvider defaultTheme="dark" attribute="class"> */}
      <I18nProvider>
        <Outlet />
      </I18nProvider>
      {/* </ThemeProvider> */}
    </QueryClientProvider>
  );
}
