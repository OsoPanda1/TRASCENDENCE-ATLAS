import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  getAtlasGraph,
  getEoctStream,
  getFederationManifest,
} from "@/lib/atlas-graph.functions";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type Node = {
  id: string;
  label: string;
  type: string;
  federation: string;
  visual: { color: string; size: number };
};

type Edge = {
  id: string;
  source: string;
  target: string;
  type: string;
  visual: { width: number };
};

type GraphPayload = { nodes: Node[]; edges: Edge[] };

export const Route = createFileRoute("/graph")({
  head: () => ({
    meta: [
      { title: "Atlas Kernel · Grafo Civilizatorio Heptafederado" },
      {
        name: "description",
        content:
          "Motor de grafo en vivo de ATLAS TRASCENDENCE — entidades, relaciones y eventos EOCT desde Lovable Cloud.",
      },
    ],
  }),
  component: GraphView,
});

const FEDS = [
  "knowledge",
  "identity",
  "governance",
  "economy",
  "security",
  "infrastructure",
  "ai",
] as const;

function GraphView() {
  const [graph, setGraph] = useState<GraphPayload | null>(null);
  const [manifest, setManifest] = useState<any>(null);
  const [events, setEvents] = useState<any[]>([]);
  const [filter, setFilter] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement>(null);

  async function refresh(f?: string) {
    setLoading(true);
    setError(null);
    try {
      const [g, m, e] = await Promise.all([
        getAtlasGraph({ data: { federation: f, limit: 500 } }),
        getFederationManifest(),
        getEoctStream({ data: { limit: 30 } }),
      ]);

      setGraph({
        nodes: (g.nodes ?? []) as Node[],
        edges: (g.edges ?? []) as Edge[],
      });
      setManifest(m);
      setEvents(e.events ?? []);
    } catch (err) {
      console.error("Atlas Graph refresh failed", err);
      setError("No se pudo sincronizar el grafo. Intenta de nuevo en unos segundos.");
    } finally {
      setLoading(false);
    }
  }

  // Carga inicial + cuando cambia la federación
  useEffect(() => {
    void refresh(filter);
  }, [filter]);

  // Layout forzado en anillo con radios escalonados (simple pero estable)
  const positions = useMemo(() => {
    const map = new Map<string, { x: number; y: number }>();
    if (!graph || graph.nodes.length === 0) return map;

    const width = 800;
    const height = 600;
    const cx = width / 2;
    const cy = height / 2;
    const N = graph.nodes.length;

    graph.nodes.forEach((n, i) => {
      const angle = (i / N) * Math.PI * 2;
      const ring = i % 5;
      const radius = 180 + ring * 40;
      map.set(n.id, {
        x: cx + Math.cos(angle) * radius,
        y: cy + Math.sin(angle) * radius,
      });
    });

    return map;
  }, [graph]);

  // Renderizado en canvas (idempotente / seguro ante rerenders)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !graph) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = 800;
    const height = 600;
    const dpr = window.devicePixelRatio || 1;

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = "100%";
    canvas.style.height = `${height}px`;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Fondo
    ctx.fillStyle = "#020617";
    ctx.fillRect(0, 0, width, height);

    // Aristas
    ctx.strokeStyle = "rgba(125,211,252,0.18)";
    graph.edges.forEach((e) => {
      const a = positions.get(e.source);
      const b = positions.get(e.target);
      if (!a || !b) return;
      ctx.lineWidth = e.visual?.width ?? 0.5;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    });

    // Nodos
    graph.nodes.forEach((n) => {
      const p = positions.get(n.id);
      if (!p) return;
      const radius = n.visual?.size ?? 4;

      ctx.fillStyle = n.visual?.color ?? "#22d3ee";
      ctx.shadowColor = ctx.fillStyle;
      ctx.shadowBlur = 14;
      ctx.beginPath();
      ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.fillStyle = "#E2E8F0";
      ctx.font = "10px ui-sans-serif";
      ctx.fillText(n.label.slice(0, 22), p.x + radius + 4, p.y + 3);
    });
  }, [graph, positions]);

  const hasData = !!graph && graph.nodes.length > 0;

  return (
    <div className="container mx-auto py-10 space-y-6">
      <header className="space-y-2">
        <Badge
          variant="outline"
          className="border-cyan-400/40 text-cyan-300"
        >
          ATLAS KERNEL · GRAPH ENGINE
        </Badge>
        <h1 className="text-4xl font-light tracking-tight">
          Grafo civilizatorio heptafederado
        </h1>
        <p className="text-muted-foreground max-w-3xl">
          Motor de grafo operativo (no solo informativo): cada nodo es una
          entidad real del metasistema, cada arista una relación semántica. Datos
          en vivo desde Lovable Cloud (Atlas Kernel + EOCT). Orgullosamente
          realmontense.
        </p>
      </header>

      {manifest && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {(
            [
              ["Entities", manifest.entities],
              ["Relations", manifest.relations],
              ["Documents", manifest.documents],
              ["EOCT events", manifest.events],
              ["Integrity", manifest.integrity ? `${manifest.integrity}%` : "—"],
            ] as const
          ).map(([k, v]) => (
            <Card
              key={k}
              className="p-4 bg-slate-900/40 border-slate-800"
            >
              <div className="text-xs uppercase text-slate-400">{k}</div>
              <div className="text-2xl font-light text-cyan-200">
                {v ?? "—"}
              </div>
            </Card>
          ))}
        </div>
      )}

      <div className="flex flex-wrap gap-2 items-center">
        <Button
          size="sm"
          variant={!filter ? "default" : "outline"}
          onClick={() => setFilter(undefined)}
        >
          Todas las federaciones
        </Button>
        {FEDS.map((f) => (
          <Button
            key={f}
            size="sm"
            variant={filter === f ? "default" : "outline"}
            onClick={() => setFilter(f)}
          >
            {f}
          </Button>
        ))}
        <Button
          size="sm"
          variant="secondary"
          onClick={() => refresh(filter)}
          disabled={loading}
        >
          {loading ? "Sincronizando…" : "↻ Refrescar"}
        </Button>
        {error && (
          <span className="text-xs text-red-400 ml-2">
            {error}
          </span>
        )}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-2 bg-slate-950 border-cyan-900/40 overflow-hidden">
          {hasData ? (
            <canvas ref={canvasRef} />
          ) : (
            <div className="flex h-[600px] items-center justify-center text-sm text-slate-500">
              {loading
                ? "Sincronizando grafo civilizatorio…"
                : "No hay nodos cargados todavía. Emite entidades desde Atlas Kernel."}
            </div>
          )}
        </Card>
        <Card className="p-4 bg-slate-900/40 border-slate-800 max-h-[600px] overflow-auto">
          <h3 className="text-sm uppercase text-cyan-300 mb-3">
            EOCT — Stream
          </h3>
          <ol className="space-y-2 text-xs">
            {events.map((e) => (
              <li
                key={e.id ?? `${e.event_type}_${e.ts}`}
                className="border-l-2 border-cyan-700/40 pl-2"
              >
                <div className="text-cyan-200">
                  {e.event_type}{" "}
                  <span className="text-slate-500">
                    · {e.severity ?? "info"}
                  </span>
                </div>
                <div className="text-slate-400">
                  {e.source_federation ?? "—"} →{" "}
                  {e.target_federation ?? "—"}
                </div>
                <div className="text-slate-600">
                  {e.ts
                    ? new Date(e.ts).toLocaleString()
                    : "—"}
                </div>
              </li>
            ))}
            {events.length === 0 && !loading && (
              <li className="text-slate-500">
                Sin eventos. Emite uno desde /console o vía API.
              </li>
            )}
          </ol>
        </Card>
      </div>
    </div>
  );
}
