import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { Starfield } from "@/components/Starfield";
import { useI18n } from "@/lib/i18n";
import { ATLAS_LAYERS } from "@/lib/layers";

export const Route = createFileRoute("/layers")({
  head: () => ({
    meta: [
      { title: "Capas — ATLAS TRASCENDENCE" },
      { name: "description", content: "Las 8 capas funcionales del metasistema civilizatorio ATLAS TRASCENDENCE." },
      { property: "og:title", content: "Capas — ATLAS TRASCENDENCE" },
      { property: "og:description", content: "Observabilidad, telemetría, seguridad, gobernanza, conocimiento, automatización, IA, interfaces." },
    ],
  }),
  component: LayersPage,
});

function LayersPage() {
  const { lang } = useI18n();
  return (
    <Shell>
      <section className="relative border-b border-border overflow-hidden">
        <Starfield count={70} />
        <div className="relative mx-auto max-w-7xl px-6 py-20">
          <div className="chip mb-6">{lang === "es" ? "Arquitectura funcional" : "Functional architecture"}</div>
          <h1 className="font-display text-5xl md:text-7xl leading-[0.95] max-w-4xl">
            {lang === "es" ? "Ocho capas." : "Eight layers."}<br />
            <span className="text-primary text-glow">{lang === "es" ? "Una infraestructura cognitiva." : "One cognitive infrastructure."}</span>
          </h1>
          <p className="mt-6 max-w-2xl text-muted-foreground">
            {lang === "es"
              ? "De la observabilidad a las interfaces. Cada capa expone estado, métricas y políticas, y se conecta con las demás bajo EOCT."
              : "From observability to interfaces. Each layer exposes state, metrics and policies, connected to the others under EOCT."}
          </p>
        </div>
      </section>

      <section className="py-12">
        <div className="mx-auto max-w-7xl px-6 space-y-px hairline rounded-sm overflow-hidden">
          {ATLAS_LAYERS.map((l) => (
            <div key={l.id} className="grid grid-cols-12 gap-6 bg-card/40 hover:bg-card/70 transition p-6 md:p-8 items-start">
              <div className="col-span-12 md:col-span-2">
                <div className="mono text-[10px] tracking-[0.25em] text-muted-foreground">{l.index}</div>
                <div className="font-display text-3xl mt-1" style={{ color: l.color, textShadow: `0 0 18px ${l.color}` }}>{l.code}</div>
              </div>
              <div className="col-span-12 md:col-span-6">
                <div className="font-display text-2xl">{l.name[lang]}</div>
                <p className="text-sm text-foreground/80 mt-2 leading-relaxed">{l.essence[lang]}</p>
                <ul className="mt-3 space-y-1">
                  {l.pillars.map((p, i) => (
                    <li key={i} className="mono text-[11px] text-muted-foreground flex gap-2">
                      <span style={{ color: l.color }}>▸</span>{p[lang]}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="col-span-12 md:col-span-4 flex flex-wrap gap-2 md:justify-end">
                {l.routes.map((r) => (
                  <Link
                    key={r.to}
                    to={r.to}
                    className="mono text-[10px] tracking-[0.2em] uppercase border border-primary/30 hover:border-primary/70 px-3 py-1.5 rounded-sm text-foreground/80 hover:text-primary transition"
                  >
                    {r.label} →
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </Shell>
  );
}
