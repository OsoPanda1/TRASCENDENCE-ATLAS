"use client";

import * as React from "react";

type ParticleFieldProps = {
  count?: number;
  color?: string;
  /**
   * 0–1: intensidad visual (opacidad, velocidad).
   */
  intensity?: number;
  /**
   * Si true, aplica un ligero flow direccional en vez de movimiento totalmente aleatorio.
   */
  directional?: boolean;
  /**
   * Semilla opcional para reproducibilidad.
   */
  seed?: number;
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
};

function seededRandom(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export function ParticleField({
  count = 80,
  color = "var(--glow)",
  intensity = 0.8,
  directional = false,
  seed,
}: ParticleFieldProps) {
  const ref = React.useRef<HTMLCanvasElement | null>(null);

  React.useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let destroyed = false;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const prng = seed !== undefined ? seededRandom(seed) : Math.random;

    const particles: Particle[] = [];

    const resize = () => {
      const { clientWidth, clientHeight } = canvas;
      canvas.width = clientWidth * dpr;
      canvas.height = clientHeight * dpr;

      // Re‑inicializa partículas con el nuevo tamaño
      particles.splice(0, particles.length);
      for (let i = 0; i < count; i++) {
        const baseSpeed = (0.15 + prng() * 0.25) * dpr * (0.5 + intensity);
        const angle = directional
          ? // flujo suave hacia arriba/diagonal
            (-Math.PI / 2) + (prng() - 0.5) * (Math.PI / 6)
          : prng() * Math.PI * 2;

        particles.push({
          x: prng() * canvas.width,
          y: prng() * canvas.height,
          vx: Math.cos(angle) * baseSpeed,
          vy: Math.sin(angle) * baseSpeed,
          r: (0.4 + prng() * 1.6) * dpr,
        });
      }
    };

    resize();
    window.addEventListener("resize", resize);

    const draw = () => {
      if (destroyed) return;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const mixOpacity = 0.3 + intensity * 0.5;
      ctx.fillStyle = `color-mix(in oklch, ${color} ${
        mixOpacity * 100
      }%, transparent)`;

      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;

        // Rebote suave en bordes
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }

      raf = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      destroyed = true;
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [count, color, intensity, directional, seed]);

  return (
    <canvas
      ref={ref}
      className="absolute inset-0 w-full h-full pointer-events-none opacity-50"
    />
  );
}
