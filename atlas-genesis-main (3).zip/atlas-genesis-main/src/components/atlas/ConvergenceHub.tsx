"use client";

import * as React from "react";
import { FEDERATIONS } from "@/lib/federations";

type FederationStatus = "ok" | "degraded" | "down";

type ConvergenceFederation = {
  id: string;
  index: string | number;
  name: string;
  domain: string;
  glyph: string;
  color: string;
  status: FederationStatus;
  load: number;              // 0–1
  activePolicies?: number;   // p.ej. # de políticas vigentes
  lastEventTs?: number;      // timestamp del último EOCT
};

type ConvergenceHubProps = {
  data?: ConvergenceFederation[];
};

const buildDefaultFederations = (): ConvergenceFederation[] =>
  FEDERATIONS.map((f, i) => ({
    id: f.id,
    index: f.index ?? i + 1,
    name: f.name?.es ?? f.name?.en ?? f.id.toUpperCase(),
    domain: f.domain?.es ?? f.domain?.en ?? "",
    glyph: f.glyph,
    color: f.color,
    status: "ok" as FederationStatus,
    load: 0.2,
    activePolicies: 0,
    lastEventTs: Date.now(),
  }));

const statusLabel = (status: FederationStatus): string => {
  switch (status) {
    case "ok":
      return "OPERATIVA";
    case "degraded":
      return "DEGRADADA";
    case "down":
      return "FUERA DE SERVICIO";
  }
};

const statusClass = (status: FederationStatus): string => {
  switch (status) {
    case "ok":
      return "text-emerald-300";
    case "degraded":
      return "text-amber-300";
    case "down":
      return "text-red-400";
  }
};

const formatAgo = (ts?: number): string => {
  if (!ts) return "—";
  const delta = Date.now() - ts;
  if (delta < 60_000) return "hace instantes";
  const min = Math.round(delta / 60_000);
  if (min < 60) return `hace ${min} min`;
  const h = Math.round(min / 60);
  return `hace ${h} h`;
};

export function ConvergenceHub({ data }: ConvergenceHubProps) {
  const [federations, setFederations] = React.useState<
    ConvergenceFederation[]
  >(() => buildDefaultFederations());

  React.useEffect(() => {
    if (!data || data.length === 0) return;
    setFederations((prev) =>
      prev.map((f) => data.find((d) => d.id === f.id) ?? f),
    );
  }, [data]);

  return (
    <div className="glass rounded-sm p-6">
      <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-2 flex items-center justify-between">
        <span>Convergence Hub</span>
        <span className="text-[9px] text-muted-foreground/80">
          MD-X4 · HEPTAFEDERACIÓN
        </span>
      </div>

      <h3 className="font-display text-2xl mb-1">
        Las 7 federaciones convergen en el KERNEL
      </h3>
      <p className="text-[11px] text-muted-foreground mb-4 max-w-xl">
        Cada federación es un pilar del ecosistema civilizatorio MD‑X4.
        Aquí se observa su estado operativo, carga de trabajo y la
        actividad reciente sobre el Kernel Atlas/Isabella.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {federations.map((f) => (
          <article
            key={f.id}
            className="hairline rounded-sm p-3 relative overflow-hidden group"
          >
            {/* Halo de color de federación */}
            <div
              className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-200"
              style={{
                background: `radial-gradient(circle at top left, ${f.color}33, transparent 55%)`,
              }}
            />

            <header className="flex items-center justify-between mb-1 relative">
              <span className="mono text-[10px] text-muted-foreground">
                {f.index}
              </span>
              <span
                className="text-lg"
                style={{ color: f.color }}
                aria-hidden
              >
                {f.glyph}
              </span>
            </header>

            <h4 className="font-display text-sm relative">
              {f.name}
            </h4>
            <p className="text-[10px] text-muted-foreground mt-1 leading-tight relative">
              {f.domain}
            </p>

            {/* Estado + carga */}
            <div className="mt-2 flex items-center justify-between relative">
              <div className="flex flex-col gap-0.5">
                <span
                  className={`mono text-[9px] ${statusClass(
                    f.status,
                  )}`}
                >
                  {statusLabel(f.status)}
                </span>
                <span className="mono text-[9px] text-muted-foreground/80">
                  Último evento {formatAgo(f.lastEventTs)}
                </span>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className="mono text-[9px] text-muted-foreground/80">
                  CARGA {Math.round(f.load * 100)}%
                </span>
                <div className="w-16 h-[5px] bg-black/20 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-[width]"
                    style={{
                      width: `${Math.max(
                        0,
                        Math.min(1, f.load),
                      ) * 100}%`,
                      backgroundColor: f.color,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Métricas rápidas / políticas */}
            <footer className="mt-2 flex items-center justify-between text-[9px] text-muted-foreground/90 relative">
              <span className="mono">
                POL: {f.activePolicies ?? 0}
              </span>
              <span className="mono uppercase tracking-[0.16em]">
                F{f.index}
              </span>
            </footer>
          </article>
        ))}
      </div>
    </div>
  );
}
