"use client";

import * as React from "react";
import { FEDERATIONS } from "@/lib/federations";

type FederationStatus = "ok" | "degraded" | "down";

type AtlasConstellationProps = {
  size?: number;
  rotationSpeedDegPerSec?: number;    // velocidad de rotación lenta del anillo
  data?: {
    id: string;
    status?: FederationStatus;
    load?: number;                    // 0–1
    pulse?: boolean;                  // resaltar federación
  }[];
};

type FederationNode = {
  id: string;
  index: string | number;
  name: string;
  glyph: string;
  color: string;
  status: FederationStatus;
  load: number;
  pulse: boolean;
};

const buildDefaultNodes = (): FederationNode[] =>
  FEDERATIONS.map((f, idx) => ({
    id: f.id,
    index: f.index ?? idx + 1,
    name: f.name?.es ?? f.id.toUpperCase(),
    glyph: f.glyph,
    color: f.color,
    status: "ok" as FederationStatus,
    load: 0.15,
    pulse: false,
  }));

const statusRingOpacity = (status: FederationStatus) => {
  switch (status) {
    case "ok":
      return 0.35;
    case "degraded":
      return 0.7;
    case "down":
      return 1;
  }
};

const statusStrokeWidth = (status: FederationStatus) => {
  switch (status) {
    case "ok":
      return 0.5;
    case "degraded":
      return 0.9;
    case "down":
      return 1.4;
  }
};

export function AtlasConstellation({
  size = 280,
  rotationSpeedDegPerSec = 2,
  data,
}: AtlasConstellationProps) {
  const [nodes, setNodes] = React.useState<FederationNode[]>(() =>
    buildDefaultNodes(),
  );
  const [hoveredId, setHoveredId] = React.useState<string | null>(null);
  const [angleOffset, setAngleOffset] = React.useState(0);

  // Sincroniza datos externos (estado, load, pulse)
  React.useEffect(() => {
    if (!data || data.length === 0) return;
    setNodes((prev) =>
      prev.map((n) => {
        const override = data.find((d) => d.id === n.id);
        if (!override) return n;
        return {
          ...n,
          status: override.status ?? n.status,
          load:
            typeof override.load === "number"
              ? Math.max(0, Math.min(1, override.load))
              : n.load,
          pulse: override.pulse ?? n.pulse,
        };
      }),
    );
  }, [data]);

  // Rotación suave del anillo
  React.useEffect(() => {
    if (!rotationSpeedDegPerSec) return;
    let frame: number;
    const start = performance.now();

    const loop = (now: number) => {
      const elapsedSec = (now - start) / 1000;
      const angle = (elapsedSec * rotationSpeedDegPerSec * Math.PI) / 180;
      setAngleOffset(angle);
      frame = requestAnimationFrame(loop);
    };

    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, [rotationSpeedDegPerSec]);

  const r = size * 0.36;
  const cx = size / 2;
  const cy = size / 2;

  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      className="w-full h-auto drop-shadow-[0_0_12px_rgba(0,0,0,0.55)]"
      aria-hidden
    >
      <defs>
        {/* Glow del núcleo */}
        <radialGradient id="core-glow">
          <stop offset="0%" stopColor="var(--glow)" stopOpacity="0.95" />
          <stop offset="60%" stopColor="var(--glow)" stopOpacity="0.3" />
          <stop offset="100%" stopColor="var(--glow)" stopOpacity="0" />
        </radialGradient>

        {/* Halo exterior dinámico */}
        <radialGradient id="outer-halo">
          <stop offset="0%" stopColor="var(--glow)" stopOpacity="0" />
          <stop offset="65%" stopColor="var(--glow)" stopOpacity="0.08" />
          <stop offset="100%" stopColor="var(--glow)" stopOpacity="0.0" />
        </radialGradient>

        {/* Pulso para nodos activos */}
        <radialGradient id="pulse-glow">
          <stop offset="0%" stopColor="white" stopOpacity="0.9" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* Halo general */}
      <circle
        cx={cx}
        cy={cy}
        r={r * 1.55}
        fill="url(#outer-halo)"
        opacity={0.45}
      />

      {/* Anillos de referencia */}
      <circle
        cx={cx}
        cy={cy}
        r={r * 0.6}
        fill="none"
        stroke="var(--border-color, rgba(148,163,184,0.4))"
        strokeWidth={0.5}
        strokeDasharray="2 6"
        strokeOpacity={0.6}
      />
      <circle
        cx={cx}
        cy={cy}
        r={r}
        fill="none"
        stroke="var(--border-color, rgba(148,163,184,0.5))"
        strokeWidth={0.6}
        strokeDasharray="1.5 4"
        strokeOpacity={0.7}
      />

      {/* Glow central */}
      <circle
        cx={cx}
        cy={cy}
        r={r * 1.3}
        fill="url(#core-glow)"
        opacity={0.18}
      />

      {/* Nodos de federación */}
      {nodes.map((f, i) => {
        const angle =
          angleOffset + (i / nodes.length) * Math.PI * 2 - Math.PI / 2;

        const x = cx + Math.cos(angle) * r;
        const y = cy + Math.sin(angle) * r;

        const isHovered = hoveredId === f.id;
        const lineOpacityBase = 0.25 + f.load * 0.4;
        const nodeGlowSize = 6 + f.load * 6;

        return (
          <g
            key={f.id}
            onMouseEnter={() => setHoveredId(f.id)}
            onMouseLeave={() => setHoveredId(null)}
            className="transition-all duration-200"
          >
            {/* Línea núcleo -> federación (intensidad ~ load) */}
            <line
              x1={cx}
              y1={cy}
              x2={x}
              y2={y}
              stroke={f.color}
              strokeOpacity={lineOpacityBase}
              strokeWidth={statusStrokeWidth(f.status)}
            />

            {/* Anillo de estado alrededor del nodo */}
            <circle
              cx={x}
              cy={y}
              r={nodeGlowSize}
              fill={f.color}
              opacity={statusRingOpacity(f.status) * 0.3}
            />

            {/* Pulso externo (solo si pulse=true o hover) */}
            {(f.pulse || isHovered) && (
              <circle
                cx={x}
                cy={y}
                r={nodeGlowSize + 5}
                fill="url(#pulse-glow)"
                opacity={0.45}
              >
                <animate
                  attributeName="r"
                  values={`${nodeGlowSize + 3}; ${nodeGlowSize + 8}; ${
                    nodeGlowSize + 3
                  }`}
                  dur="2600ms"
                  repeatCount="indefinite"
                />
                <animate
                  attributeName="opacity"
                  values="0.4; 0.9; 0.2; 0.4"
                  dur="2600ms"
                  repeatCount="indefinite"
                />
              </circle>
            )}

            {/* Núcleo del nodo */}
            <circle
              cx={x}
              cy={y}
              r={4}
              fill={f.color}
              style={{
                filter: `drop-shadow(0 0 8px ${f.color})`,
              }}
              opacity={0.85}
            />

            {/* Índice F1..F7 */}
            <text
              x={x}
              y={y - 11}
              fontSize={7}
              textAnchor="middle"
              fill="currentColor"
              className="font-mono text-foreground/70"
            >
              {f.index}
            </text>

            {/* Glyph de la federación */}
            <text
              x={x}
              y={y + 13}
              fontSize={8}
              textAnchor="middle"
              fill={f.color}
              className="font-display"
            >
              {f.glyph}
            </text>
          </g>
        );
      })}

      {/* Núcleo Atlas/MD-X4 */}
      <circle
        cx={cx}
        cy={cy}
        r={4}
        fill="var(--glow)"
        style={{ filter: "drop-shadow(0 0 10px var(--glow))" }}
      />
      <circle
        cx={cx}
        cy={cy}
        r={8}
        fill="none"
        stroke="var(--glow)"
        strokeWidth={0.8}
        strokeOpacity={0.6}
      >
        <animate
          attributeName="r"
          values="7; 10; 7"
          dur="2200ms"
          repeatCount="indefinite"
        />
        <animate
          attributeName="stroke-opacity"
          values="0.4; 0.9; 0.4"
          dur="2200ms"
          repeatCount="indefinite"
        />
      </circle>

      {/* Etiqueta central MD-X4 */}
      <text
        x={cx}
        y={cy + 22}
        fontSize={8}
        textAnchor="middle"
        className="font-mono"
        fill="currentColor"
      >
        MD-X4 · ATLAS CORE
      </text>
    </svg>
  );
}
