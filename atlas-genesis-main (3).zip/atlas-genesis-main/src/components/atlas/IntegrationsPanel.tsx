"use client";

import * as React from "react";

type IntegrationStatus = "ok" | "degraded" | "down" | "pending";

type IntegrationSide = "ingest" | "emit" | "bidirectional";

type Integration = {
  key: string;
  label: string;
  desc: string;
  color: string;
  status: IntegrationStatus;
  depth: 1 | 2 | 3;          // 1 = superficial, 3 = núcleo
  side: IntegrationSide;     // cómo fluye la integración
  eventsPerHour?: number;
  lastSyncTs?: number;
};

type IntegrationsPanelProps = {
  data?: Partial<Integration>[]; // override dinámico por clave
};

const BASE_INTEGRATIONS: Integration[] = [
  {
    key: "GITHUB",
    label: "GitHub",
    desc: "Repos, CI/CD, webhooks de código civilizatorio",
    color: "var(--glow)",
    status: "ok",
    depth: 3,
    side: "bidirectional",
    eventsPerHour: 42,
  },
  {
    key: "OPENAIRE",
    label: "OpenAIRE",
    desc: "Indexación de ciencia abierta MD‑X4",
    color: "var(--plasma)",
    status: "ok",
    depth: 2,
    side: "emit",
    eventsPerHour: 3,
  },
  {
    key: "ZENODO",
    label: "Zenodo",
    desc: "Repositorio FAIR / DOI del canon TAMV",
    color: "var(--aurora)",
    status: "ok",
    depth: 3,
    side: "bidirectional",
    eventsPerHour: 5,
  },
  {
    key: "FIGSHARE",
    label: "Figshare",
    desc: "Datasets, artefactos y evidencias GEMET",
    color: "var(--gold)",
    status: "ok",
    depth: 2,
    side: "emit",
    eventsPerHour: 2,
  },
  {
    key: "ORCID",
    label: "ORCID",
    desc: "Identidad investigadora del Kernel (MD‑X4)",
    color: "var(--fed-identity)",
    status: "ok",
    depth: 3,
    side: "bidirectional",
    eventsPerHour: 1,
  },
  {
    key: "ELEVENLABS",
    label: "ElevenLabs",
    desc: "Capa vocal de Isabella / TAMVAI",
    color: "var(--fed-ai)",
    status: "degraded",
    depth: 1,
    side: "emit",
    eventsPerHour: 18,
  },
  {
    key: "IPFS",
    label: "IPFS / BookPI",
    desc: "Anclaje inmutable de documentos y ledger civilizatorio",
    color: "var(--fed-knowledge)",
    status: "ok",
    depth: 3,
    side: "bidirectional",
    eventsPerHour: 9,
  },
];

const statusLabel = (s: IntegrationStatus): string => {
  switch (s) {
    case "ok":
      return "OPERATIVA";
    case "degraded":
      return "DEGRADADA";
    case "down":
      return "FUERA DE SERVICIO";
    case "pending":
      return "EN NEGOCIACIÓN";
  }
};

const statusClass = (s: IntegrationStatus): string => {
  switch (s) {
    case "ok":
      return "text-emerald-300";
    case "degraded":
      return "text-amber-300";
    case "down":
      return "text-red-400";
    case "pending":
      return "text-sky-300";
  }
};

const sideLabel = (side: IntegrationSide): string => {
  switch (side) {
    case "ingest":
      return "INGESTA → ATLAS";
    case "emit":
      return "ATLAS → EMISIÓN";
    case "bidirectional":
      return "FLUJO BIDIRECCIONAL";
  }
};

const sideGlyph = (side: IntegrationSide): string => {
  switch (side) {
    case "ingest":
      return "↙";
    case "emit":
      return "↗";
    case "bidirectional":
      return "⇄";
  }
};

const depthLabel = (d: Integration["depth"]): string => {
  switch (d) {
    case 1:
      return "PERIFÉRICA";
    case 2:
      return "ESTRATÉGICA";
    case 3:
      return "NUCLEAR";
  }
};

const depthDots = (d: Integration["depth"], color: string) =>
  Array.from({ length: 3 }, (_, i) => {
    const active = i < d;
    return (
      <span
        key={i}
        className={`w-0.5 h-2 rounded-full ${
          active ? "" : "bg-border/40"
        }`}
        style={active ? { background: color } : {}}
      />
    );
  });

const formatEventsRate = (n?: number): string =>
  typeof n === "number" ? `${n.toFixed(0)} ev/h` : "—";

const formatAgo = (ts?: number): string => {
  if (!ts) return "—";
  const delta = Date.now() - ts;
  if (delta < 60_000) return "instante";
  const min = Math.round(delta / 60_000);
  if (min < 60) return `${min} min`;
  const h = Math.round(min / 60);
  return `${h} h`;
};

export function IntegrationsPanel({ data }: IntegrationsPanelProps) {
  const [integrations, setIntegrations] = React.useState<Integration[]>(
    BASE_INTEGRATIONS,
  );

  React.useEffect(() => {
    if (!data || data.length === 0) return;
    setIntegrations((prev) =>
      prev.map((base) => {
        const override = data.find((d) => d.key === base.key);
        if (!override) return base;
        return { ...base, ...override };
      }),
    );
  }, [data]);

  return (
    <div className="glass rounded-sm p-6">
      <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-2 flex items-center justify-between">
        <span>Integraciones federadas</span>
        <span className="text-[9px] text-muted-foreground/80">
          ATLAS · MD-X4 · NODO CERO
        </span>
      </div>

      <p className="text-[11px] text-muted-foreground mb-4 max-w-xl">
        Atlas no se limita a consumir APIs externas: las integra en un
        tejido civilizatorio trazable. Cada conector aporta evidencia,
        identidad o capacidad de ejecución al Kernel.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        {integrations.map((i) => (
          <article
            key={i.key}
            className="hairline rounded-sm p-3 relative overflow-hidden group"
          >
            {/* Halo de integración */}
            <div
              className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-15 transition-opacity duration-200"
              style={{
                background: `radial-gradient(circle at top left, ${i.color}33, transparent 55%)`,
              }}
            />

            {/* Cabecera */}
            <header className="flex items-center justify-between mb-1 relative">
              <div className="flex items-center gap-2">
                <span
                  className="w-1.5 h-1.5 rounded-full"
                  style={{
                    background: i.color,
                    boxShadow: `0 0 8px ${i.color}`,
                  }}
                />
                <div
                  className="mono text-[10px] tracking-[0.2em]"
                  style={{ color: i.color }}
                >
                  {i.label}
                </div>
              </div>
              <span
                className={`mono text-[9px] ${statusClass(i.status)}`}
              >
                {statusLabel(i.status)}
              </span>
            </header>

            {/* Descripción */}
            <p className="text-[11px] text-muted-foreground leading-tight mb-2 relative">
              {i.desc}
            </p>

            {/* Línea de flujo y profundidad */}
            <div className="flex items-center justify-between text-[9px] mono relative">
              <div className="flex flex-col gap-0.5">
                <span className="text-muted-foreground/80 flex items-center gap-1">
                  <span>{sideGlyph(i.side)}</span>
                  <span>{sideLabel(i.side)}</span>
                </span>
                <span className="text-muted-foreground/70">
                  Profundidad: {depthLabel(i.depth)}
                </span>
              </div>

              <div className="flex flex-col items-end gap-1">
                <span className="text-muted-foreground/80">
                  {formatEventsRate(i.eventsPerHour)}
                </span>
                <div className="flex items-center gap-1">
                  {depthDots(i.depth, i.color)}
                </div>
              </div>
            </div>

            {/* Footer de sincronización */}
            <footer className="mt-2 flex items-center justify-between text-[9px] text-muted-foreground/80 relative">
              <span className="mono">
                Última sync: {formatAgo(i.lastSyncTs)}
              </span>
              <span className="mono uppercase tracking-[0.16em]">
                {i.key}
              </span>
            </footer>
          </article>
        ))}
      </div>
    </div>
  );
}
