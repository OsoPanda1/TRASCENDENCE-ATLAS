"use client";

import * as React from "react";
import { FEDERATIONS } from "@/lib/federations";

type EoctType =
  | "INGEST"
  | "PUBLISH"
  | "DECISION"
  | "OBSERVATION"
  | "AUDIT"
  | "STATE_TRANSITION"
  | "RECONCILIATION"
  | "INCIDENT"
  | "SECURITY_ALERT";

type Severity = "info" | "low" | "medium" | "high" | "critical";

type CivilizationStreamItem = {
  id: string;
  type: EoctType;
  severity: Severity;
  entity: string;
  federation: (typeof FEDERATIONS)[number];
  ts: number;
  source?: string; // opcional: sistema emisor
};

type CivilizationStreamProps = {
  limit?: number;
  /** Si true, genera datos simulados (útil en demos / sin backend) */
  simulate?: boolean;
  /** Endpoint opcional para EOCT (SSE/WebSocket/REST polling) */
  endpointUrl?: string;
};

const SIM_ACTIONS: EoctType[] = [
  "INGEST",
  "PUBLISH",
  "DECISION",
  "OBSERVATION",
  "AUDIT",
  "STATE_TRANSITION",
  "RECONCILIATION",
  "INCIDENT",
  "SECURITY_ALERT",
];

const SIM_ENTS = [
  "entity:atlas",
  "entity:isabella",
  "entity:anubis",
  "entity:bookpi",
  "entity:utamv",
  "entity:cattleya",
];

const severityForType = (type: EoctType): Severity => {
  switch (type) {
    case "SECURITY_ALERT":
      return "critical";
    case "INCIDENT":
      return "high";
    case "DECISION":
    case "STATE_TRANSITION":
    case "RECONCILIATION":
      return "medium";
    case "AUDIT":
      return "low";
    default:
      return "info";
  }
};

const severityColorClass = (sev: Severity): string => {
  switch (sev) {
    case "critical":
      return "text-red-400";
    case "high":
      return "text-orange-400";
    case "medium":
      return "text-amber-300";
    case "low":
      return "text-emerald-300";
    case "info":
    default:
      return "text-sky-300";
  }
};

const severityLabel = (sev: Severity): string => {
  switch (sev) {
    case "critical":
      return "CRIT";
    case "high":
      return "HIGH";
    case "medium":
      return "MED";
    case "low":
      return "LOW";
    case "info":
    default:
      return "INFO";
  }
};

const formatTime = (ts: number): string =>
  new Date(ts).toISOString().split("T")[1]!.slice(0, 8);

/**
 * Genera un evento EOCT simulado coherente con el ecosistema ATLAS/MD-X4.
 */
const generateSimulatedItem = (): CivilizationStreamItem => {
  const type =
    SIM_ACTIONS[Math.floor(Math.random() * SIM_ACTIONS.length)];
  const federation =
    FEDERATIONS[Math.floor(Math.random() * FEDERATIONS.length)];
  const entity =
    SIM_ENTS[Math.floor(Math.random() * SIM_ENTS.length)];
  return {
    id: "ev_" + Math.random().toString(36).slice(2, 10),
    type,
    severity: severityForType(type),
    entity,
    federation,
    ts: Date.now(),
    source:
      type === "SECURITY_ALERT" || type === "INCIDENT"
        ? "kernel:isabella"
        : "system:atlas-graph",
  };
};

export function CivilizationStream({
  limit = 16,
  simulate = true,
  endpointUrl,
}: CivilizationStreamProps) {
  const [rows, setRows] = React.useState<CivilizationStreamItem[]>([]);
  const [isLive, setIsLive] = React.useState(true);
  const [hasError, setHasError] = React.useState<string | null>(null);

  // Semilla inicial
  React.useEffect(() => {
    const seed = Array.from({ length: limit }, (_, i) => {
      const item = generateSimulatedItem();
      // desplaza el tiempo hacia atrás para que se vea “historial”
      return {
        ...item,
        ts: Date.now() - i * 5000,
      };
    });
    setRows(seed);
  }, [limit]);

  // Modo simulado (fallback o demo)
  React.useEffect(() => {
    if (!simulate || !isLive) return;
    const id = setInterval(() => {
      setRows((current) => {
        const next = [generateSimulatedItem(), ...current];
        return next.slice(0, limit);
      });
    }, 2200);
    return () => clearInterval(id);
  }, [simulate, isLive, limit]);

  // Modo “real”: puedes adaptar esto a SSE/WebSocket
  React.useEffect(() => {
    if (!endpointUrl || simulate || !isLive) return;

    let cancelled = false;

    async function poll() {
      try {
        const res = await fetch(endpointUrl as string);
        if (!res.ok) throw new Error("Bad response " + res.status);
        const events: CivilizationStreamItem[] = await res.json();
        if (cancelled) return;
        setRows((current) => {
          // naive merge: prepend nuevos, mantener tamaño
          const merged = [...events, ...current];
          return merged
            .sort((a, b) => b.ts - a.ts)
            .slice(0, limit);
        });
        setHasError(null);
      } catch (err: any) {
        if (!cancelled) {
          setHasError(err?.message ?? "Stream error");
        }
      } finally {
        if (!cancelled) {
          // Polling básico; en producción podrías usar SSE
          setTimeout(poll, 3000);
        }
      }
    }

    poll();
    return () => {
      cancelled = true;
    };
  }, [endpointUrl, simulate, isLive, limit]);

  const toggleLive = () => setIsLive((x) => !x);

  return (
    <div className="glass rounded-sm p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">
          Civilizational stream
        </div>
        <div className="flex items-center gap-3">
          {hasError && (
            <span className="mono text-[9px] text-red-400/80">
              {hasError}
            </span>
          )}
          <button
            type="button"
            onClick={toggleLive}
            className="mono text-[10px] flex items-center gap-2 text-aurora"
          >
            <span
              className={[
                "w-1.5 h-1.5 rounded-full shadow-[0_0_8px_var(--aurora)]",
                isLive ? "bg-aurora animate-pulse" : "bg-muted",
              ].join(" ")}
            />
            {isLive ? "LIVE" : "PAUSED"}
          </button>
        </div>
      </div>

      <div className="space-y-px">
        {rows.map((r) => (
          <div
            key={r.id}
            className={[
              "grid grid-cols-12 gap-2 py-1.5 border-b border-border/40 last:border-0 items-center text-[11px]",
              r.type === "SECURITY_ALERT" || r.type === "INCIDENT"
                ? "bg-red-500/5"
                : "",
            ].join(" ")}
          >
            {/* Timestamp */}
            <span className="col-span-2 mono text-[10px] text-muted-foreground/80">
              {formatTime(r.ts)}
            </span>

            {/* ID corto */}
            <span className="col-span-3 mono text-primary truncate">
              {r.id}
            </span>

            {/* Tipo de EOCT + severidad */}
            <span className="col-span-3 mono flex items-center gap-1 text-muted-foreground">
              <span className={severityColorClass(r.severity)}>
                {severityLabel(r.severity)}
              </span>
              <span className="uppercase tracking-[0.12em]">
                {r.type}
              </span>
            </span>

            {/* Entidad / origen */}
            <span className="col-span-2 mono text-foreground/70 truncate">
              {r.entity}
              {r.source && (
                <span className="text-[9px] text-muted-foreground/70 ml-1">
                  ({r.source})
                </span>
              )}
            </span>

            {/* Federación */}
            <span
              className="col-span-2 mono flex items-center gap-1.5 justify-end"
              style={{ color: r.federation.color }}
            >
              <span>{r.federation.glyph}</span>
              <span>{r.federation.index}</span>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
