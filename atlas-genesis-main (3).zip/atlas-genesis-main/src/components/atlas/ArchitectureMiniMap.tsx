"use client";

import * as React from "react";
import { FEDERATIONS } from "@/lib/federations";

type FederationStatus = "ok" | "degraded" | "down";

type FederationNode = {
  id: string;
  name: string;
  glyph: string;
  color: string;
  status: FederationStatus;
  load: number; // 0–1, p.ej. 0.72 = 72%
  tooltip?: string;
};

type ArchitectureMiniMapProps = {
  data?: FederationNode[];                // override dinámico desde API/graph
  compact?: boolean;                      // versión mini para sidebars
  onSelectFederation?: (id: string) => void;
};

function buildDefaultData(): FederationNode[] {
  // FEDERATIONS: [{ id, name, glyph, color, ... }]
  return FEDERATIONS.map((f) => ({
    id: f.id,
    name: f.name?.es ?? f.id.toUpperCase(),
    glyph: f.glyph,
    color: f.color,
    status: "ok" as FederationStatus,
    load: 0.1,
    tooltip: f.essence?.es ?? "",
  }));
}

function statusBorder(status: FederationStatus, baseColor: string) {
  switch (status) {
    case "ok":
      return baseColor;
    case "degraded":
      return "color-mix(in oklch, orange 55%, transparent)";
    case "down":
      return "color-mix(in oklch, red 65%, transparent)";
  }
}

function statusDotColor(status: FederationStatus) {
  switch (status) {
    case "ok":
      return "oklch(0.7 0.15 150)";
    case "degraded":
      return "oklch(0.7 0.2 80)";
    case "down":
      return "oklch(0.7 0.25 30)";
  }
}

export function ArchitectureMiniMap(props: ArchitectureMiniMapProps) {
  const { compact = false, onSelectFederation } = props;
  const [nodes, setNodes] = React.useState<FederationNode[]>(() =>
    props.data && props.data.length > 0 ? props.data : buildDefaultData(),
  );
  const [hoveredId, setHoveredId] = React.useState<string | null>(null);
  const isInteractive = typeof onSelectFederation === "function";

  // Si llegan props.data nuevas, sincroniza
  React.useEffect(() => {
    if (props.data && props.data.length > 0) {
      setNodes(props.data);
    }
  }, [props.data]);

  const handleClick = (node: FederationNode) => {
    if (!onSelectFederation) return;
    onSelectFederation(node.id);
  };

  const hoveredNode = hoveredId
    ? nodes.find((n) => n.id === hoveredId) ?? null
    : null;

  const containerPadding = compact ? "p-2" : "p-4";
  const titleSize = compact ? "text-[9px]" : "text-[10px]";
  const footerSize = compact ? "text-[8px]" : "text-[9px]";
  const glyphSize = compact ? "text-xs" : "text-sm";
  const gridCols = compact ? "grid-cols-4" : "grid-cols-7";

  return (
    <div
      className={`hairline rounded-sm ${containerPadding} relative overflow-hidden`}
      aria-label="MD-X4 architecture mini-map"
    >
      <div
        className={`mono ${titleSize} tracking-[0.22em] uppercase text-muted-foreground mb-2 flex items-center justify-between`}
      >
        <span>Architecture mini-map</span>
        <span className="text-[8px] opacity-70">
          F1–F7 · MD-X4 KERNEL
        </span>
      </div>

      {/* Grid principal */}
      <div className={`grid ${gridCols} gap-1`}>
        {nodes.map((f) => {
          const background = `color-mix(in oklch, ${f.color} 18%, transparent)`;
          const border = statusBorder(f.status, f.color);
          const ringClass =
            hoveredId === f.id ? "ring-1 ring-current/80" : "";

          return (
            <button
              key={f.id}
              type="button"
              className={[
                "aspect-square rounded-[3px] flex items-center justify-center relative group transition-all",
                "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-offset-1 focus-visible:ring-offset-background",
                isInteractive ? "cursor-pointer" : "cursor-default",
                ringClass,
              ].join(" ")}
              style={{ background, border: `1px solid ${border}` }}
              onMouseEnter={() => setHoveredId(f.id)}
              onMouseLeave={() => setHoveredId(null)}
              onClick={() => handleClick(f)}
            >
              {/* Círculo de estado (esquina superior derecha) */}
              <span
                className="absolute top-[2px] right-[2px] w-[6px] h-[6px] rounded-full shadow-sm"
                style={{ backgroundColor: statusDotColor(f.status) }}
              />

              {/* Glyph central */}
              <span
                className={`font-display ${glyphSize} leading-none`}
                style={{ color: f.color }}
              >
                {f.glyph}
              </span>

              {/* Barra de carga (inferior) */}
              <div className="absolute left-[2px] right-[2px] bottom-[2px] h-[3px] rounded-[2px] bg-black/10 overflow-hidden">
                <div
                  className="h-full rounded-[2px] transition-[width]"
                  style={{
                    width: `${Math.max(
                      0,
                      Math.min(1, f.load),
                    ) * 100}%`,
                    backgroundColor: f.color,
                  }}
                />
              </div>
            </button>
          );
        })}
      </div>

      {/* Pie de estado resumido */}
      <div
        className={`mono ${footerSize} text-muted-foreground mt-2 tracking-[0.18em] flex items-center justify-between`}
      >
        <span>MD-X4 · HEPTA-FEDERATION</span>
        <span>
          {nodes.filter((n) => n.status === "ok").length} OK ·{" "}
          {nodes.filter((n) => n.status === "degraded").length} DEG ·{" "}
          {nodes.filter((n) => n.status === "down").length} DOWN
        </span>
      </div>

      {/* Tooltip flotante (simple, sin portal) */}
      {hoveredNode && !compact && (
        <div className="pointer-events-none absolute left-0 right-0 -bottom-[2.1rem] mono text-[9px] tracking-[0.16em] text-muted-foreground bg-background/80 backdrop-blur-sm border-t border-border pt-1.5">
          <div className="flex items-center justify-between">
            <span className="truncate">
              {hoveredNode.name.toUpperCase()}
            </span>
            <span className="opacity-70">
              LOAD {Math.round(hoveredNode.load * 100)}%
            </span>
          </div>
          {hoveredNode.tooltip && (
            <div className="text-[8px] mt-[1px] line-clamp-1 opacity-80">
              {hoveredNode.tooltip}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
