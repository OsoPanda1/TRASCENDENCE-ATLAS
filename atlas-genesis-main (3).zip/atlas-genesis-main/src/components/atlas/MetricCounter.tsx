"use client";

import * as React from "react";

type Severity = "info" | "low" | "medium" | "high" | "critical";

type MetricSource =
  | "atlas_graph"
  | "mdx4_kernel"
  | "rdm_nodo_cero"
  | "github"
  | "zenodo"
  | "openaire"
  | "orcid"
  | "ipfs_bookpi"
  | "custom";

type MetricCounterProps = {
  label: string;
  value: number;              // valor actual
  unit?: string;
  color?: string;
  /**
   * Valor anterior para calcular delta (% o absoluto)
   */
  previousValue?: number;
  /**
   * Si true, muestra un indicador de “en vivo”
   */
  live?: boolean;
  /**
   * Severidad (para color/glow contextual)
   */
  severity?: Severity;
  /**
   * Fuente lógica del dato, para mostrar origen
   */
  source?: MetricSource;
  /**
   * Si se pasa, el componente no anima, solo muestra el valor
   */
  disableAnimation?: boolean;
  /**
   * (opcional) representación amigable de la métrica:
   * ej. "EOCT/s", "consultas/min", "usuarios activos"
   */
  hint?: string;
};

const severityGlow = (sev: Severity | undefined, baseColor: string) => {
  if (!sev) return `0 0 10px ${baseColor}`;
  switch (sev) {
    case "critical":
      return `0 0 24px ${baseColor}`;
    case "high":
      return `0 0 18px ${baseColor}`;
    case "medium":
      return `0 0 14px ${baseColor}`;
    case "low":
      return `0 0 10px ${baseColor}`;
    case "info":
    default:
      return `0 0 8px ${baseColor}`;
  }
};

const severityBadgeClass = (sev: Severity | undefined) => {
  switch (sev) {
    case "critical":
      return "bg-red-500/10 text-red-300 border-red-500/40";
    case "high":
      return "bg-amber-500/10 text-amber-300 border-amber-500/40";
    case "medium":
      return "bg-emerald-500/10 text-emerald-300 border-emerald-500/40";
    case "low":
      return "bg-sky-500/10 text-sky-300 border-sky-500/40";
    case "info":
    default:
      return "bg-slate-500/5 text-slate-200 border-slate-500/40";
  }
};

const sourceLabel = (src?: MetricSource): string => {
  switch (src) {
    case "atlas_graph":
      return "Atlas Graph";
    case "mdx4_kernel":
      return "MD-X4 Kernel";
    case "rdm_nodo_cero":
      return "Nodo Cero RDM";
    case "github":
      return "GitHub";
    case "zenodo":
      return "Zenodo";
    case "openaire":
      return "OpenAIRE";
    case "orcid":
      return "ORCID";
    case "ipfs_bookpi":
      return "IPFS / BookPI";
    case "custom":
    default:
      return "Sistema";
  }
};

export function MetricCounter({
  label,
  value,
  unit,
  color = "var(--glow)",
  previousValue,
  live = false,
  severity,
  source,
  disableAnimation = false,
  hint,
}: MetricCounterProps) {
  const [n, setN] = React.useState(0);

  // Animación suave hacia el nuevo valor
  React.useEffect(() => {
    if (disableAnimation) {
      setN(value);
      return;
    }

    let raf = 0;
    const start = performance.now();
    const dur = 1400;
    const startValue = n;

    const step = (t: number) => {
      const k = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - k, 3); // easeOutCubic
      setN(startValue + (value - startValue) * eased);
      if (k < 1) raf = requestAnimationFrame(step);
    };

    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, disableAnimation]);

  // Display formateado
  const display =
    Math.abs(value) >= 1000
      ? n.toLocaleString(undefined, {
          maximumFractionDigits: 0,
        })
      : n.toFixed(value % 1 === 0 ? 0 : 2);

  // Delta
  const hasPrevious =
    typeof previousValue === "number" && !Number.isNaN(previousValue);
  const rawDelta = hasPrevious ? value - (previousValue as number) : 0;
  const deltaSign = rawDelta > 0 ? "+" : rawDelta < 0 ? "−" : "";
  const deltaAbs = Math.abs(rawDelta);
  const deltaColor =
    rawDelta > 0
      ? "text-emerald-300"
      : rawDelta < 0
      ? "text-red-400"
      : "text-muted-foreground/70";

  const deltaPercent =
    hasPrevious && previousValue !== 0
      ? (rawDelta / (previousValue as number)) * 100
      : 0;

  return (
    <div className="glass rounded-sm p-5 flex flex-col gap-2">
      {/* Cabecera: etiqueta + fuente + severidad */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex flex-col gap-1">
          <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">
            {label}
          </div>
          {hint && (
            <div className="mono text-[9px] text-muted-foreground/80">
              {hint}
            </div>
          )}
        </div>
        <div className="flex flex-col items-end gap-1">
          {severity && (
            <span
              className={`mono text-[9px] px-1.5 py-[1px] rounded-full border ${severityBadgeClass(
                severity,
              )}`}
            >
              {severity.toUpperCase()}
            </span>
          )}
          <span className="mono text-[9px] text-muted-foreground/70">
            {sourceLabel(source)}
          </span>
        </div>
      </div>

      {/* Valor principal */}
      <div
        className="font-display text-3xl mt-1 flex items-baseline gap-1"
        style={{
          color,
          textShadow: severityGlow(severity, color),
        }}
      >
        <span>{display}</span>
        {unit && (
          <span className="text-base text-muted-foreground">
            {unit}
          </span>
        )}
      </div>

      {/* Delta + estado en vivo */}
      <div className="flex items-center justify-between mt-1">
        {hasPrevious ? (
          <div className="flex flex-col gap-[1px]">
            <span className={`mono text-[9px] ${deltaColor}`}>
              {deltaSign}
              {deltaAbs.toFixed(1)}
              {unit ? ` ${unit}` : ""} · Δ
            </span>
            <span className="mono text-[9px] text-muted-foreground/70">
              {deltaPercent > 0 ? "+" : ""}
              {deltaPercent.toFixed(1)}%
            </span>
          </div>
        ) : (
          <span className="mono text-[9px] text-muted-foreground/70">
            Sin histórico
          </span>
        )}

        {live && (
          <span className="flex items-center gap-1 mono text-[9px] text-aurora">
            <span className="w-1.5 h-1.5 rounded-full bg-aurora shadow-[0_0_8px_var(--aurora)] animate-pulse" />
            LIVE
          </span>
        )}
      </div>
    </div>
  );
}
