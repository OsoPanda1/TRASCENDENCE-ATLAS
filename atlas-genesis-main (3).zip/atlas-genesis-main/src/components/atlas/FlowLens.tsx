"use client";

import * as React from "react";

type Severity = "info" | "low" | "medium" | "high" | "critical";

type FlowLensProps = {
  label: string;
  value: number;
  max?: number;
  color?: string;
  unit?: string;              // p.ej. "ev/s", "%", "ms"
  hint?: string;              // descripción breve del métrico
  compact?: boolean;
  delta?: number;             // cambio reciente (positivo/negativo)
  thresholds?: {
    low?: number;
    medium?: number;
    high?: number;
    critical?: number;
  };
};

function computeSeverity(
  pct: number,
  thresholds?: FlowLensProps["thresholds"],
): Severity {
  if (!thresholds) return "info";
  const { low = 25, medium = 60, high = 85, critical = 95 } = thresholds;
  if (pct >= critical) return "critical";
  if (pct >= high) return "high";
  if (pct >= medium) return "medium";
  if (pct >= low) return "low";
  return "info";
}

function severityGlow(sev: Severity, baseColor: string): string {
  switch (sev) {
    case "critical":
      return `0 0 18px ${baseColor}`;
    case "high":
      return `0 0 14px ${baseColor}`;
    case "medium":
      return `0 0 10px ${baseColor}`;
    case "low":
      return `0 0 6px ${baseColor}`;
    case "info":
    default:
      return `0 0 4px ${baseColor}`;
  }
}

function severityOverlayClass(sev: Severity): string {
  switch (sev) {
    case "critical":
      return "bg-red-500/10";
    case "high":
      return "bg-amber-500/5";
    case "medium":
      return "bg-emerald-400/5";
    case "low":
      return "bg-sky-400/5";
    case "info":
    default:
      return "";
  }
}

export function FlowLens({
  label,
  value,
  max = 100,
  color = "var(--glow)",
  unit,
  hint,
  compact = false,
  delta,
  thresholds,
}: FlowLensProps) {
  const safeMax = max <= 0 ? 1 : max;
  const pct = Math.max(0, Math.min(100, (value / safeMax) * 100));
  const severity = computeSeverity(pct, thresholds);
  const glow = severityGlow(severity, color);
  const containerPadding = compact ? "p-2.5" : "p-3";
  const labelSize = compact ? "text-[9px]" : "text-[10px]";
  const valueSize = compact ? "text-[10px]" : "text-[11px]";
  const barHeight = compact ? "h-[3px]" : "h-[4px]";

  const hasDelta = typeof delta === "number" && !Number.isNaN(delta);
  const deltaSign = hasDelta ? (delta! > 0 ? "+" : delta! < 0 ? "−" : "") : "";
  const deltaAbs = hasDelta ? Math.abs(delta!).toFixed(1) : "";
  const deltaColor =
    delta && delta > 0
      ? "text-emerald-300"
      : delta && delta < 0
      ? "text-red-400"
      : "text-muted-foreground/70";

  return (
    <div
      className={[
        "hairline rounded-sm relative",
        containerPadding,
        severityOverlayClass(severity),
      ].join(" ")}
    >
      {/* Cabecera */}
      <div className="flex items-baseline justify-between mb-1.5">
        <div className="flex flex-col">
          <span
            className={`mono ${labelSize} tracking-[0.2em] uppercase text-muted-foreground`}
          >
            {label}
          </span>
          {hint && !compact && (
            <span className="mono text-[9px] text-muted-foreground/70 mt-[2px]">
              {hint}
            </span>
          )}
        </div>

        <div className="flex flex-col items-end">
          <span
            className={`mono ${valueSize}`}
            style={{ color }}
          >
            {value.toFixed(1)} / {safeMax}
            {unit ? ` ${unit}` : ""}
          </span>
          {hasDelta && (
            <span className={`mono text-[9px] ${deltaColor}`}>
              {deltaSign}
              {deltaAbs}
              {unit ? ` ${unit}` : ""} · Δ
            </span>
          )}
        </div>
      </div>

      {/* Barra principal */}
      <div className={`${barHeight} bg-border/70 rounded-full overflow-hidden`}>
        <div
          className="h-full transition-[width] duration-300"
          style={{
            width: `${pct}%`,
            background: `linear-gradient(90deg, ${color}, transparent)`,
            boxShadow: glow,
          }}
        />
      </div>

      {/* Marca de porcentaje y estado, opcionalmente visible en modo no compacto */}
      {!compact && (
        <div className="flex items-center justify-between mt-1">
          <span className="mono text-[9px] text-muted-foreground/80">
            {pct.toFixed(1)}%
          </span>
          <span className="mono text-[9px] text-muted-foreground/70">
            {severity.toUpperCase()}
          </span>
        </div>
      )}
    </div>
  );
}
