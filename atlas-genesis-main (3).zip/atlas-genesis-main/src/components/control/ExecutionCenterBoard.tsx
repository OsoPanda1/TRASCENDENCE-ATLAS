"use client";

import * as React from "react";
import { FEDERATIONS } from "@/lib/federations";
import { FlowLens } from "@/components/atlas/FlowLens";

type Severity = "info" | "low" | "medium" | "high" | "critical";

type FederationMetric = {
  id: string;
  label: string;
  value: number;
  max: number;
  severity: Severity;
  hint?: string;
};

type FederationBoardRow = {
  id: string;
  name: string;
  color: string;
  glyph: string;
  index: string | number;
  metrics: FederationMetric[];
};

function computeSeverity(pct: number): Severity {
  if (pct >= 95) return "critical";
  if (pct >= 80) return "high";
  if (pct >= 60) return "medium";
  if (pct >= 40) return "low";
  return "info";
}

function buildSimRow(
  fed: (typeof FEDERATIONS)[number],
  tick: number,
  i: number,
): FederationBoardRow {
  // simulaciones deterministas basadas en índice + tick
  const base = 60 + ((i * 11 + tick * 13) % 40);
  const throughput = base;
  const latency = 40 + ((i * 17 + tick * 7) % 140); // ms
  const eoctRate = 10 + ((i * 5 + tick * 3) % 90);

  const tpPct = (throughput / 100) * 100;
  const latPct = (latency / 200) * 100;
  const eoctPct = (eoctRate / 120) * 100;

  return {
    id: fed.id,
    name: fed.name?.es ?? fed.name?.en ?? fed.id.toUpperCase(),
    color: fed.color,
    glyph: fed.glyph,
    index: fed.index ?? i + 1,
    metrics: [
      {
        id: `${fed.id}-tp`,
        label: "throughput",
        value: throughput,
        max: 100,
        severity: computeSeverity(tpPct),
        hint: "Flujo EOCT/s normalizado",
      },
      {
        id: `${fed.id}-lat`,
        label: "latencia",
        value: latency,
        max: 200,
        severity: computeSeverity(100 - latPct),
        hint: "Latencia media de queries (ms)",
      },
      {
        id: `${fed.id}-eoct`,
        label: "eoct/min",
        value: eoctRate,
        max: 120,
        severity: computeSeverity(eoctPct),
        hint: "Eventos civilizatorios por minuto",
      },
    ],
  };
}

export function ExecutionCenterBoard() {
  const [tick, setTick] = React.useState(0);

  const rows: FederationBoardRow[] = React.useMemo(
    () => FEDERATIONS.map((f, i) => buildSimRow(f, tick, i)),
    [tick],
  );

  const handleRefresh = () => {
    setTick((t) => t + 1);
    // futuro: disparar refetch desde Graph Engine / MD-X4
  };

  return (
    <div className="glass rounded-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">
            Centro de Ejecución
          </div>
          <h3 className="font-display text-2xl">
            Tablero operativo · MD-X4
          </h3>
          <p className="text-[11px] text-muted-foreground mt-1 max-w-xl">
            Estado en tiempo casi real del Kernel heptafederado. Cada
            tarjeta refleja throughput, latencia y densidad EOCT de su
            federación.
          </p>
        </div>
        <button
          onClick={handleRefresh}
          className="hairline rounded-sm px-3 py-1.5 mono text-[10px] tracking-[0.2em] text-foreground hover:text-primary"
        >
          REFRESH
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        {rows.map((row) => (
          <section
            key={row.id}
            className="hairline rounded-sm p-3 relative overflow-hidden"
          >
            {/* halo de federación */}
            <div
              className="pointer-events-none absolute inset-0 opacity-10"
              style={{
                background: `radial-gradient(circle at top left, ${row.color}22, transparent 60%)`,
              }}
            />

            <header className="flex items-center justify-between mb-2 relative">
              <div className="flex flex-col gap-0.5">
                <span
                  className="mono text-[10px]"
                  style={{ color: row.color }}
                >
                  {row.glyph} {row.index}
                </span>
                <span className="mono text-[9px] text-muted-foreground">
                  {row.name}
                </span>
              </div>
              <span className="mono text-[9px] text-muted-foreground/80">
                F{row.index} · FEDERACIÓN
              </span>
            </header>

            <div className="grid grid-cols-1 gap-2 relative">
              {row.metrics.map((m) => (
                <FlowLens
                  key={m.id}
                  label={m.label}
                  value={m.value}
                  max={m.max}
                  color={row.color}
                  hint={m.hint}
                  thresholds={{
                    low: 35,
                    medium: 60,
                    high: 80,
                    critical: 95,
                  }}
                  // puedes mapear severidad en futuros usos
                />
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
