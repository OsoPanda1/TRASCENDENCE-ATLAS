"use client";

import * as React from "react";
import { FEDERATIONS } from "@/lib/federations";

type NexusGraphProps = {
  height?: number;
};

type Layer = "idVida" | "federaciones" | "matriz";

type NexusNodeType = "core" | "isabella" | "idVida" | "federation" | "problem" | "solution";

type NexusNode = {
  id: string;
  label: string;
  layer: Layer | "core" | "isabella";
  angle?: number; // radianes, solo para nodos concéntricos
  size: number;
  color: string;
  type: NexusNodeType;
  description: string;
  targetProblemId?: string; // para soluciones
};

type NexusLink = {
  from: string;
  to: string;
  kind?: "structural" | "problem" | "solution";
};

const colors = {
  bg: "#020617",
  human: "#F59E0B",
  isabella: "#00F2FE",
  idVida: "#3B82F6",
  federation: "#F9FAFB",
  problem: "#EF4444",
  solution: "#10B981",
  line: "rgba(148, 163, 184, 0.18)",
};

const BASE_NODES: NexusNode[] = [
  // Núcleo humano
  {
    id: "HUMAN",
    label: "NÚCLEO: SER HUMANO",
    layer: "core",
    size: 16,
    color: colors.human,
    type: "core",
    description:
      "Origen y fin último de la arquitectura TAMV. Toda decisión de sistema responde a la dignidad y conciencia humana.",
  },
  // ID en Vida
  {
    id: "ID_VIDA",
    label: "ID EN VIDA (SOBERANÍA)",
    layer: "idVida",
    angle: Math.PI * 0.5,
    size: 6,
    color: colors.idVida,
    type: "idVida",
    description:
      "Soberanía de identidad biológica y digital. Blindaje contra extractivismo de datos y capitalismo de vigilancia.",
  },
  {
    id: "SYS_4L",
    label: "SISTEMA 4L GOBERNANZA",
    layer: "idVida",
    angle: Math.PI * 1.5,
    size: 6,
    color: colors.idVida,
    type: "idVida",
    description:
      "Modelo normativo de capas L0-L7 que asegura transparencia total y control humano del Kernel.",
  },
];

function buildFederationNodes(): NexusNode[] {
  const n = 7;
  const baseAngle = -Math.PI / 2;
  const step = (2 * Math.PI) / n;

  const fedDescriptions = [
    "L0-L2: Infraestructura mesh física fijada en territorio.",
    "L3-L4: Kernels MD-X4 & MD-X5 redundantes para resiliencia.",
    "L5-L7: Omnikernel de red sincronizado globalmente.",
    "M0-M2: GEMET EOCT ético para regular inferencia.",
    "M3-M4: Campus UTAMV para transferencia de alta arquitectura.",
    "M5-M6: Foro RDM Digital para soberanía tecnológica territorial.",
    "M7: RDM LIVOS NextGen para comercio y turismo local.",
  ];

  return FEDERATIONS.slice(0, 7).map((f, i) => {
    const angle = baseAngle + step * i;
    return {
      id: `FED_${i + 1}`,
      label: f.name?.es ?? f.name?.en ?? f.id.toUpperCase(),
      layer: "federaciones" as Layer,
      angle,
      size: 8,
      color: f.color ?? colors.federation,
      type: "federation" as const,
      description: fedDescriptions[i] ?? "Federación heptafederada del ecosistema TAMV.",
    };
  });
}

const PROBLEM_SOLUTION_NODES: NexusNode[] = (() => {
  const baseAngle = -Math.PI / 2;
  const step = (2 * Math.PI) / 7;

  return [
    // CENSURA / CLOUD
    {
      id: "P_CENSURA",
      label: "VULN: CENSURA / APAGÓN CLOUD",
      layer: "matriz",
      angle: baseAngle + step * 0 - 0.14,
      size: 5,
      color: colors.problem,
      type: "problem",
      description:
        "Bloqueos perimetrales y censura corporativa que intentan aislar la infraestructura local.",
    },
    {
      id: "S_CENSURA",
      label: "SOL: REPOSITORIOS SOB_100",
      layer: "matriz",
      angle: baseAngle + step * 0 + 0.14,
      size: 6,
      color: colors.solution,
      type: "solution",
      targetProblemId: "P_CENSURA",
      description:
        "Despliegue P2P distribuido inmune a suspensiones y bloqueos centralizados.",
    },
    // DATOS
    {
      id: "P_DATA",
      label: "VULN: MONOPOLIO EXTRACTIVO DE DATOS",
      layer: "matriz",
      angle: baseAngle + step * 3 - 0.14,
      size: 5,
      color: colors.problem,
      type: "problem",
      description:
        "Modelos predictivos comerciales que mercantilizan el comportamiento ciudadano.",
    },
    {
      id: "S_DATA",
      label: "SOL: FILTRO DE INFERENCIA SOBERANO",
      layer: "matriz",
      angle: baseAngle + step * 3 + 0.14,
      size: 6,
      color: colors.solution,
      type: "solution",
      targetProblemId: "P_DATA",
      description:
        "Procesamiento local en Nodo Cero, destruyendo cualquier rastro de tracking externo.",
    },
    // COMERCIO
    {
      id: "P_COMERCIO",
      label: "VULN: CAPITALISMO DIGITAL EXTRACTIVO",
      layer: "matriz",
      angle: baseAngle + step * 6 - 0.14,
      size: 5,
      color: colors.problem,
      type: "problem",
      description:
        "Pasarelas multinacionales que extraen valor de los comercios locales vía comisiones abusivas.",
    },
    {
      id: "S_COMERCIO",
      label: "SOL: IMPULSO RDM LIVOS SIN COMISIÓN",
      layer: "matriz",
      angle: baseAngle + step * 6 + 0.14,
      size: 6,
      color: colors.solution,
      type: "solution",
      targetProblemId: "P_COMERCIO",
      description:
        "Directorio inteligente y pasarela soberana sin intermediarios para artesanos y restaurantes.",
    },
  ];
})();

// Enlaces tipo WEF
const BASE_LINKS: NexusLink[] = [
  // Núcleo a ID en Vida / Sistema 4L
  { from: "HUMAN", to: "ID_VIDA", kind: "structural" },
  { from: "HUMAN", to: "SYS_4L", kind: "structural" },
];

function buildFederationLinks(): NexusLink[] {
  const fedIds = Array.from({ length: 7 }, (_, i) => `FED_${i + 1}`);

  const ringLinks: NexusLink[] = fedIds.map((id, i) => ({
    from: id,
    to: fedIds[(i + 1) % fedIds.length],
    kind: "structural",
  }));

  // Ejemplo: vínculos ID_VIDA / SYS_4L a algunas federaciones
  const coreLinks: NexusLink[] = [
    { from: "ID_VIDA", to: "FED_1", kind: "structural" },
    { from: "ID_VIDA", to: "FED_4", kind: "structural" },
    { from: "SYS_4L", to: "FED_7", kind: "structural" },
  ];

  const problemLinks: NexusLink[] = [
    { from: "FED_1", to: "P_CENSURA", kind: "problem" },
    { from: "FED_4", to: "P_DATA", kind: "problem" },
    { from: "FED_7", to: "P_COMERCIO", kind: "problem" },
  ];

  return [...ringLinks, ...coreLinks, ...problemLinks];
}

function polarToCartesian(
  cx: number,
  cy: number,
  radius: number,
  angle: number,
) {
  return {
    x: cx + radius * Math.cos(angle),
    y: cy + radius * Math.sin(angle),
  };
}

export function NexusGraph({ height = 480 }: NexusGraphProps) {
  const wrapRef = React.useRef<HTMLDivElement | null>(null);
  const [width, setWidth] = React.useState(800);
  const [planeActive, setPlaneActive] = React.useState(false);
  const [visibleSolutions, setVisibleSolutions] = React.useState<string[]>([]);
  const [hoverId, setHoverId] = React.useState<string | null>(null);
  const [t, setT] = React.useState(0); // para animaciones suaves

  // ResizeObserver para ancho
  React.useEffect(() => {
    const r = wrapRef.current;
    if (!r) return;
    const obs = new ResizeObserver((entries) => {
      if (!entries[0]) return;
      setWidth(entries[0].contentRect.width);
    });
    obs.observe(r);
    return () => obs.disconnect();
  }, []);

  // Tick de animación
  React.useEffect(() => {
    let frame = 0;
    const loop = () => {
      setT((v) => v + 0.016);
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, []);

  // Construcción de nodos y enlaces
  const { nodes, links, radii } = React.useMemo(() => {
    const radiusBase = Math.min(width, height) * 0.16;
    const radii = {
      idVida: radiusBase * 1.0,
      federaciones: radiusBase * 1.85,
      matriz: radiusBase * 2.6,
      isabella: radiusBase * 0.65,
    };

    const federationNodes = buildFederationNodes();
    const nodes: NexusNode[] = [
      ...BASE_NODES,
      ...federationNodes,
      ...PROBLEM_SOLUTION_NODES,
      {
        id: "ISABELLA",
        label: "ISABELLA ENGINE AI",
        layer: "isabella",
        size: 7,
        color: colors.isabella,
        type: "isabella",
        description:
          "Puente cognitivo institucional. Media entre Kernel y humanos, filtrando inferencia según GEMET EOCT.",
      },
    ];

    const links: NexusLink[] = [...BASE_LINKS, ...buildFederationLinks()];

    return { nodes, links, radii };
  }, [width, height]);

  const cx = width / 2;
  const cy = height / 2;

  // Secuenciador de soluciones (plano de soluciones)
  React.useEffect(() => {
    if (!planeActive) {
      setVisibleSolutions([]);
      return;
    }
    const solutions = PROBLEM_SOLUTION_NODES.filter(
      (n) => n.type === "solution",
    );
    const timers: number[] = [];
    solutions.forEach((sol, index) => {
      const id = window.setTimeout(() => {
        setVisibleSolutions((prev) => [...prev, sol.id]);
      }, (index + 1) * 1200);
      timers.push(id);
    });
    return () => timers.forEach((id) => window.clearTimeout(id));
  }, [planeActive]);

  // Helpers de posición
  const getNodePosition = (node: NexusNode) => {
    if (node.type === "core") {
      return { x: cx, y: cy };
    }
    if (node.type === "isabella") {
      const angle = -Math.PI / 2 + t * 0.35;
      return polarToCartesian(cx, cy, radii.isabella, angle);
    }
    if (!node.angle) {
      return { x: cx, y: cy };
    }
    const radius =
      node.layer === "idVida"
        ? radii.idVida
        : node.layer === "federaciones"
        ? radii.federaciones
        : radii.matriz;
    return polarToCartesian(cx, cy, radius, node.angle);
  };

  const hoveredNode = hoverId
    ? nodes.find((n) => n.id === hoverId) ?? null
    : null;

  const handleTogglePlane = () => {
    setPlaneActive((v) => !v);
  };

  return (
    <div className="relative w-full">
      <div className="flex items-center justify-between mb-2">
        <div>
          <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">
            Mapa Concéntrico TAMV
          </div>
          <div className="font-display text-xs text-muted-foreground/80">
            Núcleo humano · 7 federaciones · Matriz de fricciones/soluciones
          </div>
        </div>
        {/* Switch plano soluciones */}
        <button
          type="button"
          onClick={handleTogglePlane}
          className={[
            "relative flex items-center gap-2 px-3 py-1.5 rounded-sm border",
            "mono text-[9px] tracking-[0.2em] uppercase",
            planeActive
              ? "border-emerald-400/60 text-emerald-400 bg-emerald-400/5 shadow-[0_0_18px_rgba(16,185,129,0.35)]"
              : "border-border text-muted-foreground hover:text-foreground bg-background/40",
          ].join(" ")}
        >
          <span
            className={[
              "inline-flex h-[14px] w-[26px] items-center rounded-full border border-border/60 bg-black/60 p-[1px] transition-colors",
              planeActive ? "border-emerald-400/60" : "",
            ].join(" ")}
          >
            <span
              className={[
                "h-[10px] w-[10px] rounded-full bg-slate-500 shadow-sm transform transition-transform duration-300",
                planeActive
                  ? "translate-x-[10px] bg-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.8)]"
                  : "",
              ].join(" ")}
            />
          </span>
          <span>{planeActive ? "SOLUCIONES" : "FRICCIONES"}</span>
        </button>
      </div>

      <div
        ref={wrapRef}
        className="relative w-full rounded-sm overflow-hidden glass bg-[radial-gradient(circle_at_top,_#020617_0,_#020617_40%,_black_100%)]"
        style={{ height }}
      >
        {/* halo / glow */}
        <div className="absolute inset-0 opacity-40 mix-blend-screen pointer-events-none">
          <div className="absolute inset-[18%] rounded-full bg-[radial-gradient(circle,_rgba(56,189,248,0.25),transparent_55%)] blur-3xl" />
        </div>

        <svg
          width={width}
          height={height}
          className="absolute inset-0 text-slate-300"
        >
          <defs>
            <radialGradient id="nexus-core" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="var(--glow)" stopOpacity="1" />
              <stop offset="100%" stopColor="var(--glow)" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* círculos concéntricos */}
          <circle
            cx={cx}
            cy={cy}
            r={radii.matriz}
            fill="none"
            stroke="rgba(148,163,184,0.12)"
            strokeWidth={0.7}
          />
          <circle
            cx={cx}
            cy={cy}
            r={radii.federaciones}
            fill="none"
            stroke="rgba(148,163,184,0.18)"
            strokeWidth={0.9}
          />
          <circle
            cx={cx}
            cy={cy}
            r={radii.idVida}
            fill="none"
            stroke="rgba(59,130,246,0.28)"
            strokeWidth={1}
          />
          {/* halo suave */}
          <circle
            cx={cx}
            cy={cy}
            r={radii.federaciones * 1.3}
            fill="url(#nexus-core)"
            opacity={0.08}
          />

          {/* enlaces estructurales curvados */}
          {links.map((link, idx) => {
            const fromNode = nodes.find((n) => n.id === link.from);
            const toNode = nodes.find((n) => n.id === link.to);
            if (!fromNode || !toNode) return null;
            const fromPos = getNodePosition(fromNode);
            const toPos = getNodePosition(toNode);

            const isProblemLink = link.kind === "problem";
            const isSolutionLink = link.kind === "solution";

            const stroke =
              isSolutionLink && planeActive
                ? colors.solution
                : isProblemLink
                ? colors.problem
                : colors.line;

            const opacity =
              isSolutionLink && planeActive
                ? 0.85
                : isProblemLink
                ? 0.5
                : 0.35;

            const dash =
              isSolutionLink && planeActive ? "2 4" : isProblemLink ? "3 5" : "";
            const widthStroke = isSolutionLink ? 1.4 : 0.9;

            const controlX = cx;
            const controlY = cy;

            return (
              <path
                key={`${link.from}-${link.to}-${idx}`}
                d={`M ${fromPos.x} ${fromPos.y} Q ${controlX} ${controlY} ${toPos.x} ${toPos.y}`}
                fill="none"
                stroke={stroke}
                strokeOpacity={opacity}
                strokeWidth={widthStroke}
                strokeDasharray={dash}
              />
            );
          })}

          {/* nodos */}
          {nodes.map((node) => {
            if (
              node.type === "solution" &&
              (!planeActive || !visibleSolutions.includes(node.id))
            ) {
              return null;
            }

            const { x, y } = getNodePosition(node);
            const hovered = hoveredNode?.id === node.id;

            const radius =
              node.type === "core"
                ? hovered
                  ? node.size + 4
                  : node.size
                : hovered
                ? node.size + 3
                : node.size;

            return (
              <g
                key={node.id}
                onMouseEnter={() => setHoverId(node.id)}
                onMouseLeave={() => setHoverId((current) => (current === node.id ? null : current))}
                style={{ cursor: "default" }}
              >
                {node.layer === "federaciones" && (
                  <circle
                    cx={x}
                    cy={y}
                    r={radius + 4}
                    fill="none"
                    stroke="rgba(248,250,252,0.18)"
                    strokeWidth={0.9}
                  />
                )}
                <circle cx={x} cy={y} r={radius} fill={node.color} opacity={0.9} />
                {node.type !== "core" && node.type !== "isabella" && (
                  <circle
                    cx={x}
                    cy={y}
                    r={radius + 8}
                    fill="none"
                    stroke={
                      node.type === "problem"
                        ? "rgba(248,113,113,0.4)"
                        : node.type === "solution"
                        ? "rgba(52,211,153,0.4)"
                        : "rgba(148,163,184,0.35)"
                    }
                    strokeWidth={hovered ? 1.1 : 0.7}
                    strokeDasharray={
                      node.type === "problem" || node.type === "solution" ? "3 4" : ""
                    }
                  />
                )}

                {/* etiquetas */}
                {node.type !== "core" && (
                  <text
                    x={x}
                    y={y - radius - 6}
                    fontSize={9}
                    textAnchor="middle"
                    fill="#E5E7EB"
                    className="font-mono"
                  >
                    {node.label}
                  </text>
                )}

                {node.type === "core" && (
                  <>
                    <circle
                      cx={cx}
                      cy={cy}
                      r={radius + 6}
                      fill="none"
                      stroke="#E5E7EB"
                      strokeWidth={1}
                    />
                    <text
                      x={cx}
                      y={cy + 3}
                      fontSize={9}
                      textAnchor="middle"
                      fill="#0B1120"
                      className="font-mono"
                    >
                      HUMANO
                    </text>
                  </>
                )}

                {node.type === "isabella" && (
                  <text
                    x={x}
                    y={y - radius - 4}
                    fontSize={8}
                    textAnchor="middle"
                    fill={colors.isabella}
                    className="font-mono"
                  >
                    ISABELLA AI
                  </text>
                )}
              </g>
            );
          })}
        </svg>

        {/* panel flotante de detalle */}
        {hoveredNode && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/90 border border-slate-800/80 rounded-sm px-4 py-3 max-w-md shadow-[0_0_40px_rgba(15,23,42,0.9)]">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-mono uppercase tracking-[0.18em] text-slate-400">
                {hoveredNode.type === "core"
                  ? "NÚCLEO HUMANO"
                  : hoveredNode.type === "isabella"
                  ? "SATÉLITE COGNITIVO"
                  : hoveredNode.type === "federation"
                  ? "FEDERACIÓN"
                  : hoveredNode.type === "problem"
                  ? "FRICCIÓN CRÍTICA"
                  : hoveredNode.type === "solution"
                  ? "SOLUCIÓN ACTIVA"
                  : "CAPA ID EN VIDA"}
              </span>
              <span
                className="w-2 h-2 rounded-full"
                style={{ backgroundColor: hoveredNode.color }}
              />
            </div>
            <div className="text-[11px] font-mono text-slate-50 mb-1">
              {hoveredNode.label}
            </div>
            <p className="text-[11px] text-slate-400 font-sans leading-snug">
              {hoveredNode.description}
            </p>
          </div>
        )}

        {/* texto fijo estilo leyenda inferior izquierda */}
        <div className="absolute bottom-4 left-4 bg-black/70 border border-slate-800/70 rounded-sm px-3 py-2 max-w-xs pointer-events-none">
          <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-[0.14em] text-slate-200 border-b border-slate-800 pb-1 mb-1">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            Topología Concéntrica Heptafederada
          </div>
          <ul className="space-y-[2px] text-[10px] text-slate-400 font-sans">
            <li>
              • <span className="font-mono text-amber-400">NÚCLEO:</span> Conciencia e integridad humana.
            </li>
            <li>
              • <span className="font-mono text-sky-400">ID EN VIDA:</span> Soberanía e inmunidad extractiva.
            </li>
            <li>
              • <span className="font-mono text-slate-100">FEDERACIONES:</span> Capas L0-L7 &amp; M0-M7.
            </li>
            <li>
              • <span className="font-mono text-emerald-400">SOLUCIONES:</span> Plano activo de mitigación ética.
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
