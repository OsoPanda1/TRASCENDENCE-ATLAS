"use client";

import * as React from "react";
import { Starfield } from "@/components/Starfield";
import { ParticleField } from "@/components/atlas/ParticleField";

function useParallaxLayers() {
  const [offset, setOffset] = React.useState(0);

  React.useEffect(() => {
    let frame = 0;
    const update = () => {
      setOffset((o) => (o + 0.15) % 360);
      frame = requestAnimationFrame(update);
    };
    frame = requestAnimationFrame(update);
    return () => cancelAnimationFrame(frame);
  }, []);

  return offset;
}

export function TAMVBackgroundScene() {
  const offset = useParallaxLayers();

  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Capa base: espacio profundo */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_#020617_0,_#020617_40%,_#020617_60%,_black_100%)]" />

      {/* Nebulosa aurora TAMV */}
      <div
        className="absolute inset-[-10%] opacity-70 mix-blend-screen"
        style={{
          background:
            "conic-gradient(from 220deg, rgba(56,189,248,0.0) 0deg, rgba(56,189,248,0.22) 40deg, rgba(129,140,248,0.45) 140deg, rgba(236,72,153,0.35) 230deg, rgba(56,189,248,0.0) 320deg)",
          transform: `translate3d(0, ${offset * 0.06}px, 0)`,
        }}
      />

      {/* Starfield lejano (capa lenta) */}
      <div
        className="absolute inset-0"
        style={{ transform: `translate3d(0, ${offset * 0.02}px, 0)` }}
      >
        <Starfield count={180} />
      </div>

      {/* Starfield cercano (puntos más grandes, ligero parallax inverso) */}
      <div
        className="absolute inset-0 opacity-70"
        style={{ transform: `translate3d(0, ${-offset * 0.03}px, 0)` }}
      >
        <Starfield count={60} />
      </div>

      {/* Campo de partículas plasmáticas envolviendo TAMV */}
      <div
        className="absolute inset-0"
        style={{ transform: `translate3d(0, ${offset * 0.04}px, 0)` }}
      >
        <ParticleField
          count={90}
          color="var(--plasma)"
          intensity={0.9}
          directional
          seed={42}
        />
      </div>

      {/* Halo central tipo “portal de datos” */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="relative w-[40rem] max-w-[80vw] aspect-[4/3]">
          {/* Disco luminoso */}
          <div
            className="absolute inset-[12%] rounded-full blur-3xl opacity-70"
            style={{
              background:
                "radial-gradient(circle, rgba(56,189,248,0.45), rgba(15,23,42,0.0) 65%)",
            }}
          />

          {/* Anillos concéntricos girando */}
          <div className="absolute inset-[18%] rounded-full border border-cyan-400/30 animate-[spin_38s_linear_infinite]" />
          <div className="absolute inset-[24%] rounded-full border border-fuchsia-400/25 animate-[spin_26s_linear_reverse_infinite]" />
          <div className="absolute inset-[30%] rounded-full border border-sky-300/30 opacity-70" />

          {/* Haz vertical TAMV */}
          <div className="absolute left-1/2 top-[-40%] bottom-[-40%] w-px -translate-x-1/2 bg-gradient-to-b from-transparent via-sky-300/60 to-transparent opacity-60" />

          {/* Retícula holográfica TAMV */}
          <div className="absolute inset-[22%] rounded-[30%] border border-cyan-300/15 bg-[radial-gradient(circle_at_top,_rgba(15,23,42,0.4),transparent_70%)]">
            <div className="absolute inset-0 grid-lines opacity-[0.35]" />
          </div>
        </div>
      </div>

      {/* Malla fina de grid general (muy sutil, por debajo del contenido) */}
      <div className="absolute inset-0 grid-lines opacity-20 mix-blend-soft-light" />

      {/* Ruido / grain para dar textura física */}
      <div className="absolute inset-0 opacity-[0.18] mix-blend-soft-light bg-[url('/noise.png')] bg-repeat pointer-events-none" />
    </div>
  );
}
