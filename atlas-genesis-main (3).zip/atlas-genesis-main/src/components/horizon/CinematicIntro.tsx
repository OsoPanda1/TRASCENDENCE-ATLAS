"use client";

import * as React from "react";

const LINES = [
  "BOOT · MD-X4 KERNEL ::: initializing 7 federations",
  "ANUBIS Sentinel™ : Dilithium5 + Kyber1024 handshake OK",
  "Isabella ACCS · triple bloqueo ontológico ACTIVE",
  "BookPI™ chain integrity : 100.000 %",
  "Atlas grafo civilizatorio : sync OK",
  "Phoenix V2 mesh ::: standby",
  "READY · Orgullosamente Realmontenses",
];

type CinematicIntroProps = {
  onDone?: () => void;
  /** Duración aproximada por línea en ms */
  lineDelay?: number;
  /** Si true, muestra botón de saltar */
  allowSkip?: boolean;
};

export function CinematicIntro({
  onDone,
  lineDelay = 420,
  allowSkip = true,
}: CinematicIntroProps) {
  const [lineIndex, setLineIndex] = React.useState(0);
  const [visibleChars, setVisibleChars] = React.useState(0);
  const [done, setDone] = React.useState(false);
  const [fadeOut, setFadeOut] = React.useState(false);

  // Avanza carácter a carácter para efecto typewriter
  React.useEffect(() => {
    if (done) return;
    const currentLine = LINES[lineIndex] ?? "";
    if (visibleChars < currentLine.length) {
      const t = setTimeout(
        () => setVisibleChars((c) => c + 1),
        22, // velocidad de typing
      );
      return () => clearTimeout(t);
    }

    // Cuando termina una línea, espera un poco y pasa a la siguiente
    if (lineIndex < LINES.length - 1) {
      const t = setTimeout(() => {
        setLineIndex((i) => i + 1);
        setVisibleChars(0);
      }, lineDelay);
      return () => clearTimeout(t);
    }

    // Última línea terminada → disparar fade out y cerrar
    const t = setTimeout(() => {
      setFadeOut(true);
      const t2 = setTimeout(() => {
        setDone(true);
        onDone?.();
      }, 600);
      return () => clearTimeout(t2);
    }, 900);
    return () => clearTimeout(t);
  }, [lineIndex, visibleChars, done, lineDelay, onDone]);

  const handleSkip = () => {
    setFadeOut(true);
    const t = setTimeout(() => {
      setDone(true);
      onDone?.();
    }, 400);
    return () => clearTimeout(t);
  };

  if (done) return null;

  return (
    <div
      className={[
        "fixed inset-0 z-[100] pointer-events-auto",
        "flex items-center justify-center",
        "bg-[radial-gradient(circle_at_top,_#020617_0,_#020617_35%,_#000000_100%)]",
        "backdrop-blur-[2px]",
        "transition-opacity duration-500",
        fadeOut ? "opacity-0" : "opacity-100",
      ].join(" ")}
    >
      {/* overlay de grano / scanlines */}
      <div className="pointer-events-none absolute inset-0 mix-blend-soft-light opacity-[0.22] bg-[url('/noise.png')] bg-repeat" />
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_bottom,rgba(15,23,42,0.6)_0,transparent_45%,rgba(0,0,0,0.9)_100%)]" />

      <div className="relative max-w-lg w-full px-6">
        <div className="flex items-center justify-between mb-4">
          <div className="mono text-[10px] tracking-[0.22em] uppercase text-aurora/80">
            MD-X4 · KERNEL BOOT
          </div>
          {allowSkip && (
            <button
              type="button"
              onClick={handleSkip}
              className="mono text-[9px] tracking-[0.18em] uppercase text-muted-foreground hover:text-foreground border border-border/50 rounded-sm px-2 py-[3px] bg-black/30"
            >
              SKIP
            </button>
          )}
        </div>

        <div className="font-mono text-[11px] leading-relaxed text-aurora space-y-[3px] relative">
          {LINES.slice(0, lineIndex + 1).map((line, idx) => {
            const isCurrent = idx === lineIndex;
            const text = isCurrent
              ? line.slice(0, visibleChars)
              : line;
            return (
              <div
                key={idx}
                className={`flex items-center gap-2 ${
                  isCurrent ? "opacity-100" : "opacity-70"
                }`}
              >
                <span className="text-glow text-[10px]">›</span>
                <span>{text}</span>
              </div>
            );
          })}
          {/* Cursor */}
          {lineIndex < LINES.length && (
            <div className="flex items-center gap-2 mt-[2px]">
              <span className="text-glow text-[10px]">›</span>
              <span className="text-glow animate-pulse">_</span>
            </div>
          )}
        </div>

        {/* Pie de pantalla estilo consola */}
        <div className="mt-5 flex items-center justify-between mono text-[9px] text-muted-foreground/80">
          <span>Atlas · Sistema nervioso civilizatorio</span>
          <span>Orgullosamente Realmontenses</span>
        </div>
      </div>
    </div>
  );
}
