// src/memory/event-log.ts

export interface KernelEventLogEntry {
  eventId: string;
  eventType: string;
  timestamp: string;
  actorId: string;
  nodeId: string | null;
  payload: unknown;
  prevHash?: string;
  hash?: string;
  traceId?: string;
}

const EVENTS: KernelEventLogEntry[] = [];

function computeHash(e: KernelEventLogEntry): string {
  // simplificación: usa JSON + crypto en tu entorno real
  return JSON.stringify({
    eventId: e.eventId,
    eventType: e.eventType,
    timestamp: e.timestamp,
    actorId: e.actorId,
    nodeId: e.nodeId,
    payload: e.payload,
    prevHash: e.prevHash ?? "",
  });
}

export function appendEvent(e: Omit<KernelEventLogEntry, "prevHash" | "hash">): KernelEventLogEntry {
  const prev = EVENTS[EVENTS.length - 1];
  const entry: KernelEventLogEntry = {
    ...e,
    prevHash: prev?.hash ?? undefined,
    hash: computeHash(e as KernelEventLogEntry),
  };
  EVENTS.push(entry);
  return entry;
}

export function eventCount(): number {
  return EVENTS.length;
}

export function listEvents(limit = 50): KernelEventLogEntry[] {
  return EVENTS.slice(-limit).reverse();
}

export function findEventsByTrace(traceId: string): KernelEventLogEntry[] {
  return EVENTS.filter((e) => (e.payload as any)?.traceId === traceId);
}

export function verifyChain(): { ok: boolean; brokenAt: number | null } {
  for (let i = 1; i < EVENTS.length; i++) {
    if (EVENTS[i].prevHash !== EVENTS[i - 1].hash) {
      return { ok: false, brokenAt: i };
    }
  }
  return { ok: true, brokenAt: null };
}
