// src/memory/graph-store.ts

import type { CanonicalNode } from "../canonical/types";

const NODES = new Map<string, CanonicalNode>();

export function upsertNode(raw: Partial<CanonicalNode> & { id: string; type: string; title: string; body: string }) {
  const existing = NODES.get(raw.id);
  const created = !existing;

  const node: CanonicalNode = {
    ...(existing ?? ({} as CanonicalNode)),
    ...raw,
  } as CanonicalNode;

  NODES.set(node.id, node);

  return {
    node,
    created,
    violations: [] as string[],
  };
}

export function nodeCount(): number {
  return NODES.size;
}

export function integrityReport() {
  return {
    ok: true,
    nodeCount: NODES.size,
  };
}
