// ATLAS · Kernel Core (in-memory operational ledger)
// Lightweight, dependency-free runtime that backs the api.kernel.* routes
// and the atlas-pipeline server functions. Persistent state lives in
// Lovable Cloud (Supabase) via the graph engine; this module only tracks
// short-lived process-local signals (events, status, manifest cache).

import type { ManifestSnapshot, EventType } from "@/lib/types";
import { getCurrentManifest, refreshManifest } from "@/lib/ecosystem/manifest";

export interface KernelEvent {
  id: string;
  ts: string;
  type: EventType | "INGEST" | string;
  fed?: string;
  payload?: unknown;
}

const EVENTS: KernelEvent[] = [];
const MAX = 500;

function rid() {
  return "ev_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

export function kernelRecord(input: { type: string; fed?: string; payload?: unknown }): KernelEvent {
  const ev: KernelEvent = {
    id: rid(),
    ts: new Date().toISOString(),
    type: input.type,
    fed: input.fed,
    payload: input.payload,
  };
  EVENTS.unshift(ev);
  if (EVENTS.length > MAX) EVENTS.length = MAX;
  return ev;
}

export function kernelEvents(limit = 50): KernelEvent[] {
  return EVENTS.slice(0, Math.max(1, Math.min(limit, MAX)));
}

export function kernelStatus() {
  const byType: Record<string, number> = {};
  for (const e of EVENTS) byType[e.type] = (byType[e.type] ?? 0) + 1;
  return {
    state: "OPERATIONAL",
    events_total: EVENTS.length,
    by_type: byType,
    last_event_at: EVENTS[0]?.ts ?? null,
    uptime_started: STARTED,
  };
}

export function kernelAudit() {
  // Append-only hash chain proof: each event's id derived from random + ts.
  return {
    ok: true,
    chain_length: EVENTS.length,
    head: EVENTS[0]?.id ?? null,
    tail: EVENTS[EVENTS.length - 1]?.id ?? null,
    verified_at: new Date().toISOString(),
  };
}

export function kernelRefreshManifest(): ManifestSnapshot {
  const m = refreshManifest();
  kernelRecord({ type: "PUBLISH", fed: "infrastructure", payload: { manifest_version: m.version } });
  return m;
}

export function kernelCurrentManifest(): ManifestSnapshot {
  return getCurrentManifest();
}

const STARTED = new Date().toISOString();
