// src/kernel/state-machine.ts

export type KernelState = "IDLE" | "INGESTING" | "CANONICALIZING" | "RETRIEVING" | "VALIDATING" | "RESPONDING" | "AUDITING" | "FAILED";

export interface KernelTrace {
  ts: string;
  from: KernelState;
  to: KernelState;
  traceId: string;
  reason?: string;
}

/**
 * Tabla de transiciones válidas del kernel.
 * Si necesitas algo más estricto, refínalo aquí.
 */
const VALID: Record<KernelState, KernelState[]> = {
  IDLE: ["INGESTING", "RETRIEVING"],
  INGESTING: ["CANONICALIZING", "FAILED"],
  CANONICALIZING: ["AUDITING", "FAILED"],
  RETRIEVING: ["VALIDATING", "FAILED"],
  VALIDATING: ["RESPONDING", "FAILED"],
  RESPONDING: ["AUDITING", "FAILED"],
  AUDITING: ["IDLE", "FAILED"],
  FAILED: ["IDLE"],
};

export function canTransition(from: KernelState, to: KernelState): boolean {
  return VALID[from]?.includes(to) ?? false;
}
