// Minimal CanonicalNode shape for the in-memory graph store.
export type NodeType = "ENTITY" | "DOCUMENT" | "POLICY" | "EVENT" | string;

export interface CanonicalNode {
  id: string;
  type: NodeType;
  title: string;
  body: string;
  meta?: Record<string, unknown>;
}
