// ATLAS · Real ingestion pipeline
// Pulls live data from GitHub / ORCID / Zenodo / Figshare / OpenAIRE
// and persists into Lovable Cloud (entities + eoct_events).
// Hardened: input validation, deterministic slugs (idempotent upserts),
// per-source try/catch so a single failure does not poison the batch.
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const GITHUB_USER = "OsoPanda1";
const AUTHOR_ORCID = "0009-0008-5050-1539";

const slug = (s: string) =>
  s.toLowerCase().normalize("NFKD").replace(/[^\w]+/g, "-").replace(/^-|-$/g, "").slice(0, 120);

async function safeJson(res: Response) {
  if (!res.ok) return null;
  try { return await res.json(); } catch { return null; }
}

type Counts = { entities: number; events: number; errors: string[] };

async function ingestGithub(admin: any, c: Counts) {
  try {
    const headers: Record<string, string> = {
      Accept: "application/vnd.github+json",
      "User-Agent": "atlas-trascendence",
    };
    if (process.env.GITHUB_TOKEN) headers.Authorization = `Bearer ${process.env.GITHUB_TOKEN}`;

    const [profileRes, reposRes] = await Promise.all([
      fetch(`https://api.github.com/users/${GITHUB_USER}`, { headers }),
      fetch(`https://api.github.com/users/${GITHUB_USER}/repos?per_page=100&sort=updated`, { headers }),
    ]);
    const profile = (await safeJson(profileRes)) as any;
    const repos = ((await safeJson(reposRes)) as any[]) ?? [];

    if (profile?.login) {
      const ent = {
        type: "PERSON" as const,
        name: profile.name ?? profile.login,
        slug: `gh-${slug(profile.login)}`,
        federation: "identity" as const,
        classification: "public" as const,
        summary: profile.bio ?? `GitHub @${profile.login}`,
        metadata: {
          source: "github",
          login: profile.login,
          avatar: profile.avatar_url,
          url: profile.html_url,
          public_repos: profile.public_repos,
          followers: profile.followers,
        },
      };
      const { error } = await admin.from("entities").upsert(ent, { onConflict: "slug" });
      if (error) c.errors.push(`gh-profile: ${error.message}`);
      else c.entities++;
    }

    for (const r of repos.slice(0, 60)) {
      const ent = {
        type: "REPO" as const,
        name: r.name,
        slug: `gh-repo-${slug(r.full_name)}`,
        federation: "knowledge" as const,
        classification: "public" as const,
        summary: r.description ?? "",
        metadata: {
          source: "github",
          full_name: r.full_name,
          url: r.html_url,
          stars: r.stargazers_count,
          forks: r.forks_count,
          language: r.language,
          topics: r.topics ?? [],
          updated_at: r.updated_at,
        },
      };
      const { error } = await admin.from("entities").upsert(ent, { onConflict: "slug" });
      if (error) c.errors.push(`gh-repo ${r.full_name}: ${error.message}`);
      else c.entities++;
    }

    const { error: eErr } = await admin.from("eoct_events").insert({
      event_type: "INGEST",
      source_federation: "knowledge",
      severity: "INFO",
      classification: "public",
      context: { source: "github", user: GITHUB_USER, repos: repos.length },
      trace_id: `ingest_gh_${Date.now()}`,
    });
    if (!eErr) c.events++;
  } catch (e: any) {
    c.errors.push(`github: ${e?.message ?? e}`);
  }
}

async function ingestOrcid(admin: any, c: Counts) {
  try {
    const res = await fetch(`https://pub.orcid.org/v3.0/${AUTHOR_ORCID}/record`, {
      headers: { Accept: "application/json" },
    });
    const j = (await safeJson(res)) as any;
    if (!j) return;
    const person = j?.person;
    const name = `${person?.name?.["given-names"]?.value ?? ""} ${person?.name?.["family-name"]?.value ?? ""}`.trim();
    const ent = {
      type: "PERSON" as const,
      name: name || `ORCID ${AUTHOR_ORCID}`,
      slug: `orcid-${AUTHOR_ORCID}`,
      federation: "identity" as const,
      classification: "public" as const,
      summary: `ORCID iD ${AUTHOR_ORCID}`,
      metadata: { source: "orcid", orcid: AUTHOR_ORCID, url: `https://orcid.org/${AUTHOR_ORCID}` },
    };
    const { error } = await admin.from("entities").upsert(ent, { onConflict: "slug" });
    if (error) c.errors.push(`orcid: ${error.message}`);
    else c.entities++;
    await admin.from("eoct_events").insert({
      event_type: "INGEST",
      source_federation: "identity",
      severity: "INFO",
      classification: "public",
      context: { source: "orcid", orcid: AUTHOR_ORCID },
      trace_id: `ingest_orcid_${Date.now()}`,
    });
    c.events++;
  } catch (e: any) {
    c.errors.push(`orcid: ${e?.message ?? e}`);
  }
}

async function ingestZenodo(admin: any, q: string, c: Counts) {
  try {
    const token = process.env.ZENODO_ACCESS_TOKEN ?? process.env.ZENODO_API_KEY;
    const url = `https://zenodo.org/api/records?q=${encodeURIComponent(q)}&size=10&sort=mostrecent${token ? `&access_token=${token}` : ""}`;
    const j = (await safeJson(await fetch(url, { headers: { Accept: "application/json" } }))) as any;
    const hits = j?.hits?.hits ?? [];
    for (const h of hits) {
      const ent = {
        type: "DOCUMENT" as const,
        name: (h?.metadata?.title ?? "Untitled").slice(0, 240),
        slug: `zenodo-${h.id}`,
        federation: "knowledge" as const,
        classification: "public" as const,
        summary: (h?.metadata?.description ?? "").replace(/<[^>]+>/g, "").slice(0, 400),
        metadata: {
          source: "zenodo",
          doi: h.doi,
          url: h.links?.html,
          date: h?.metadata?.publication_date,
          type: h?.metadata?.resource_type?.title,
        },
      };
      const { error } = await admin.from("entities").upsert(ent, { onConflict: "slug" });
      if (error) c.errors.push(`zenodo ${h.id}: ${error.message}`);
      else c.entities++;
    }
    await admin.from("eoct_events").insert({
      event_type: "INGEST", source_federation: "knowledge", severity: "INFO", classification: "public",
      context: { source: "zenodo", q, count: hits.length },
      trace_id: `ingest_zenodo_${Date.now()}`,
    });
    c.events++;
  } catch (e: any) { c.errors.push(`zenodo: ${e?.message ?? e}`); }
}

async function ingestFigshare(admin: any, q: string, c: Counts) {
  try {
    const headers: Record<string, string> = { Accept: "application/json", "Content-Type": "application/json" };
    if (process.env.FIGSHARE_TOKEN) headers.Authorization = `token ${process.env.FIGSHARE_TOKEN}`;
    const res = await fetch("https://api.figshare.com/v2/articles/search", {
      method: "POST", headers,
      body: JSON.stringify({ search_for: q, page_size: 10, order: "published_date", order_direction: "desc" }),
    });
    const arr = ((await safeJson(res)) as any[]) ?? [];
    for (const r of arr) {
      const ent = {
        type: "DOCUMENT" as const,
        name: (r.title ?? "Untitled").slice(0, 240),
        slug: `figshare-${r.id}`,
        federation: "knowledge" as const,
        classification: "public" as const,
        summary: "",
        metadata: { source: "figshare", doi: r.doi, url: r.url_public_html ?? r.url, published: r.published_date },
      };
      const { error } = await admin.from("entities").upsert(ent, { onConflict: "slug" });
      if (error) c.errors.push(`figshare ${r.id}: ${error.message}`);
      else c.entities++;
    }
    await admin.from("eoct_events").insert({
      event_type: "INGEST", source_federation: "knowledge", severity: "INFO", classification: "public",
      context: { source: "figshare", q, count: arr.length },
      trace_id: `ingest_figshare_${Date.now()}`,
    });
    c.events++;
  } catch (e: any) { c.errors.push(`figshare: ${e?.message ?? e}`); }
}

async function ingestOpenAire(admin: any, q: string, c: Counts) {
  try {
    const url = `https://api.openaire.eu/search/publications?title=${encodeURIComponent(q)}&format=json&size=10`;
    const j = (await safeJson(await fetch(url, { headers: { Accept: "application/json" } }))) as any;
    const results = j?.response?.results?.result ?? [];
    let i = 0;
    for (const r of results) {
      const meta = r?.metadata?.["oaf:entity"]?.["oaf:result"];
      const titleRaw = meta?.title?.$ ?? meta?.title?.[0]?.$ ?? "Untitled";
      const title = typeof titleRaw === "string" ? titleRaw : "Untitled";
      const id = meta?.["originalId"]?.$ ?? meta?.["originalId"]?.[0]?.$ ?? `oa-${Date.now()}-${i++}`;
      const ent = {
        type: "DOCUMENT" as const,
        name: title.slice(0, 240),
        slug: `openaire-${slug(String(id))}`,
        federation: "knowledge" as const,
        classification: "public" as const,
        summary: "",
        metadata: { source: "openaire", date: meta?.dateofacceptance?.$ },
      };
      const { error } = await admin.from("entities").upsert(ent, { onConflict: "slug" });
      if (error) c.errors.push(`openaire: ${error.message}`);
      else c.entities++;
    }
    await admin.from("eoct_events").insert({
      event_type: "INGEST", source_federation: "knowledge", severity: "INFO", classification: "public",
      context: { source: "openaire", q, count: results.length },
      trace_id: `ingest_openaire_${Date.now()}`,
    });
    c.events++;
  } catch (e: any) { c.errors.push(`openaire: ${e?.message ?? e}`); }
}

export const ingestAll = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({
      q: z.string().min(1).max(200).default("civilizational memory"),
      sources: z.array(z.enum(["github", "orcid", "zenodo", "figshare", "openaire"])).optional(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const c: Counts = { entities: 0, events: 0, errors: [] };
    const want = (s: string) => !data.sources || data.sources.includes(s as any);
    const tasks: Promise<unknown>[] = [];
    if (want("github")) tasks.push(ingestGithub(supabaseAdmin, c));
    if (want("orcid")) tasks.push(ingestOrcid(supabaseAdmin, c));
    if (want("zenodo")) tasks.push(ingestZenodo(supabaseAdmin, data.q, c));
    if (want("figshare")) tasks.push(ingestFigshare(supabaseAdmin, data.q, c));
    if (want("openaire")) tasks.push(ingestOpenAire(supabaseAdmin, data.q, c));
    await Promise.allSettled(tasks);
    return {
      ok: c.errors.length === 0,
      at: new Date().toISOString(),
      query: data.q,
      ...c,
    };
  });

export const getIngestStats = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const [github, orcid, zenodo, figshare, openaire, totalEnt, totalEv] = await Promise.all([
    supabaseAdmin.from("entities").select("*", { count: "exact", head: true }).like("slug", "gh-%"),
    supabaseAdmin.from("entities").select("*", { count: "exact", head: true }).like("slug", "orcid-%"),
    supabaseAdmin.from("entities").select("*", { count: "exact", head: true }).like("slug", "zenodo-%"),
    supabaseAdmin.from("entities").select("*", { count: "exact", head: true }).like("slug", "figshare-%"),
    supabaseAdmin.from("entities").select("*", { count: "exact", head: true }).like("slug", "openaire-%"),
    supabaseAdmin.from("entities").select("*", { count: "exact", head: true }),
    supabaseAdmin.from("eoct_events").select("*", { count: "exact", head: true }).eq("event_type", "INGEST"),
  ]);
  return {
    bySource: {
      github: github.count ?? 0,
      orcid: orcid.count ?? 0,
      zenodo: zenodo.count ?? 0,
      figshare: figshare.count ?? 0,
      openaire: openaire.count ?? 0,
    },
    totals: { entities: totalEnt.count ?? 0, ingest_events: totalEv.count ?? 0 },
  };
});
