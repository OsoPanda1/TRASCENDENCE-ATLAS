// ATLAS TRASCENDENCE — 8 capas funcionales (doctrina)
export type LayerId = "obs" | "tel" | "sec" | "gov" | "kno" | "aut" | "ai" | "ui";

export interface AtlasLayer {
  id: LayerId;
  index: string; // "Capa 0"
  code: string; // OBS, TEL, ...
  name: { es: string; en: string };
  essence: { es: string; en: string };
  pillars: { es: string; en: string }[];
  color: string;
  routes: { label: string; to: string }[];
}

export const ATLAS_LAYERS: AtlasLayer[] = [
  {
    id: "obs", index: "Capa 0", code: "OBS",
    name: { es: "Observabilidad", en: "Observability" },
    essence: {
      es: "Salud, métricas, eventos, logs, trazas, auditoría y dependencias. Lo que no se observa no se gobierna.",
      en: "Health, metrics, events, logs, traces, audits, dependencies. What is not observed cannot be governed.",
    },
    pillars: [
      { es: "Estado en vivo de cada componente", en: "Live state of every component" },
      { es: "EOCT — Event & Ontology Core Trace", en: "EOCT — Event & Ontology Core Trace" },
      { es: "Dependencias técnicas y causales", en: "Technical & causal dependencies" },
    ],
    color: "var(--aurora)",
    routes: [{ label: "Console", to: "/console" }, { label: "Kernel", to: "/kernel" }, { label: "Graph", to: "/graph" }],
  },
  {
    id: "tel", index: "Capa 1", code: "TEL",
    name: { es: "Telemetría", en: "Telemetry" },
    essence: {
      es: "Todo flujo produce señal: usuarios, agentes, APIs, workflows, documentos, decisiones, fallas.",
      en: "Every flow emits signal: users, agents, APIs, workflows, documents, decisions, failures.",
    },
    pillars: [
      { es: "Señales estructuradas con trace_id", en: "Structured signals with trace_id" },
      { es: "Métricas Prometheus / SLOs", en: "Prometheus metrics / SLOs" },
      { es: "Stream civilizatorio en tiempo real", en: "Real-time civilizational stream" },
    ],
    color: "var(--plasma)",
    routes: [{ label: "Atlas", to: "/atlas" }, { label: "Nexus", to: "/nexus" }],
  },
  {
    id: "sec", index: "Capa 2", code: "SEC",
    name: { es: "Seguridad", en: "Security" },
    essence: {
      es: "Identidad, autenticación, autorización, firma, integridad, secretos, políticas. Zero-trust + post-cuántico.",
      en: "Identity, auth, authorization, signing, integrity, secrets, policies. Zero-trust + post-quantum.",
    },
    pillars: [
      { es: "RLS estricta en Lovable Cloud", en: "Strict RLS on Lovable Cloud" },
      { es: "Roles separados (user_roles + has_role)", en: "Separated roles (user_roles + has_role)" },
      { es: "Dignity-by-design (DEKATEOTL)", en: "Dignity-by-design (DEKATEOTL)" },
    ],
    color: "#ff5577",
    routes: [{ label: "Auth", to: "/auth" }],
  },
  {
    id: "gov", index: "Capa 3", code: "GOV",
    name: { es: "Gobernanza", en: "Governance" },
    essence: {
      es: "Reglas, permisos, aprobación, rechazo, cumplimiento, excepciones, control humano. Korima Codex.",
      en: "Rules, permissions, approval, rejection, compliance, exceptions, human-in-the-loop. Korima Codex.",
    },
    pillars: [
      { es: "Tratados, manifiestos, políticas versionadas", en: "Treaties, manifestos, versioned policies" },
      { es: "Constitutional gate en CI", en: "Constitutional gate in CI" },
      { es: "Guardianías paralelas por federación", en: "Parallel guardianships per federation" },
    ],
    color: "var(--gold)",
    routes: [{ label: "Doctrine", to: "/doctrine" }, { label: "Federations", to: "/federations" }],
  },
  {
    id: "kno", index: "Capa 4", code: "KNO",
    name: { es: "Conocimiento", en: "Knowledge" },
    essence: {
      es: "Documentos, fuentes, ontologías, etiquetas, relaciones, evidencias, contexto. CITEMESH + GEMET.",
      en: "Documents, sources, ontologies, tags, relations, evidence, context. CITEMESH + GEMET.",
    },
    pillars: [
      { es: "Wikis canónicas TAMV", en: "Canonical TAMV wikis" },
      { es: "Ingesta científica (Zenodo, Figshare, OpenAIRE, ORCID)", en: "Scientific ingest (Zenodo, Figshare, OpenAIRE, ORCID)" },
      { es: "Grafo civilizatorio versionado", en: "Versioned civilizational graph" },
    ],
    color: "var(--glow)",
    routes: [{ label: "Wikis", to: "/wikis" }, { label: "Docs", to: "/docs" }, { label: "Nexus", to: "/nexus" }],
  },
  {
    id: "aut", index: "Capa 5", code: "AUT",
    name: { es: "Automatización", en: "Automation" },
    essence: {
      es: "Despliegues, sincronización, ingestión, clasificación, reconciliación, alertas. Pipeline hexagonal doble.",
      en: "Deploys, sync, ingestion, classification, reconciliation, alerts. Double hexagonal pipeline.",
    },
    pillars: [
      { es: "CI/CD + GitHub webhooks → EOCT", en: "CI/CD + GitHub webhooks → EOCT" },
      { es: "Cron de auditoría y reconciliación", en: "Audit & reconciliation cron" },
      { es: "Ingesta multi-fuente con allSettled", en: "Multi-source ingest with allSettled" },
    ],
    color: "var(--plasma)",
    routes: [{ label: "CSP", to: "/csp" }, { label: "Atlas", to: "/atlas" }],
  },
  {
    id: "ai", index: "Capa 6", code: "AI",
    name: { es: "Inteligencia Artificial", en: "Artificial Intelligence" },
    essence: {
      es: "Clasificación, recomendación, explicación, resumen, detección de anomalías, inferencia. Isabella Kernel + DEKATEOTL.",
      en: "Classification, recommendation, explanation, summary, anomaly detection, inference. Isabella Kernel + DEKATEOTL.",
    },
    pillars: [
      { es: "Hard-stop ético DEKATEOTL", en: "DEKATEOTL ethical hard-stop" },
      { es: "Validación THCF (4 reglas)", en: "THCF validation (4 rules)" },
      { es: "RAG estricto, alucinación cero", en: "Strict RAG, zero hallucination" },
    ],
    color: "var(--aurora)",
    routes: [{ label: "Console", to: "/console" }],
  },
  {
    id: "ui", index: "Capa 7", code: "UI",
    name: { es: "Interfaces", en: "Interfaces" },
    essence: {
      es: "Paneles, APIs, wikis, agentes, consolas, visualizaciones, experiencias. TAMV Console MD-X4.",
      en: "Dashboards, APIs, wikis, agents, consoles, visualizations, experiences. TAMV Console MD-X4.",
    },
    pillars: [
      { es: "Estética cósmica obsidiana/cian/platino", en: "Cosmic obsidian/cyan/platinum aesthetic" },
      { es: "ES + EN nativo", en: "Native ES + EN" },
      { es: "Acceso multi-lenguaje operativo", en: "Multi operational-language access" },
    ],
    color: "#9fc",
    routes: [{ label: "Atlas", to: "/atlas" }, { label: "Genesis", to: "/genesis" }],
  },
];
