import { Link, useLocation } from "@tanstack/react-router";
import { WIKI_CATEGORIES } from "@/lib/wikis";
import { useI18n } from "@/lib/i18n";

export function WikiSidebar() {
  const { lang } = useI18n();
  const loc = useLocation();
  const current = new URLSearchParams(loc.search as unknown as string).get("c");
  return (
    <aside className="hairline rounded-sm p-4 space-y-1 sticky top-20">
      <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-3">Categorías</div>
      <Link to="/wikis" className={`block px-2 py-1.5 rounded-sm mono text-[11px] ${!current ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>Todas</Link>
      {WIKI_CATEGORIES.map((c) => (
        <Link key={c.id} to="/wikis" search={{ c: c.id }} className={`block px-2 py-1.5 rounded-sm mono text-[11px] ${current === c.id ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
          {c.label[lang]}
        </Link>
      ))}
    </aside>
  );
}
