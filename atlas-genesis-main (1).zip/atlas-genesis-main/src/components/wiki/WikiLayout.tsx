import type { ReactNode } from "react";
import { WikiSidebar } from "./WikiSidebar";

export function WikiLayout({ children }: { children: ReactNode }) {
  return (
    <div className="mx-auto max-w-7xl px-6 py-12 grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-8">
      <WikiSidebar />
      <div>{children}</div>
    </div>
  );
}
