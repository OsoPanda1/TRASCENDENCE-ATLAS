import { Link } from "@tanstack/react-router";
import type { WikiArticle } from "@/lib/wikis";
import { useI18n } from "@/lib/i18n";

export function ArticleCard({ a }: { a: WikiArticle }) {
  const { lang } = useI18n();
  return (
    <Link to="/wikis/$slug" params={{ slug: a.slug }} className="glass rounded-sm p-5 hover:border-primary/50 transition block">
      <div className="flex items-center justify-between mb-2">
        <span className="chip">{a.category}</span>
        <span className="mono text-[9px] text-muted-foreground">{a.updated}</span>
      </div>
      <h3 className="font-display text-xl mb-2">{a.title[lang]}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed">{a.excerpt[lang]}</p>
      <div className="flex flex-wrap gap-1 mt-3">
        {a.tags.slice(0, 4).map((t) => <span key={t} className="mono text-[9px] text-muted-foreground">#{t}</span>)}
      </div>
    </Link>
  );
}
