export function PaginationBar({ page, total, onChange }: { page: number; total: number; onChange: (p: number) => void }) {
  if (total <= 1) return null;
  return (
    <div className="flex items-center justify-center gap-2 mt-8">
      {Array.from({ length: total }).map((_, i) => (
        <button key={i} onClick={() => onChange(i+1)} aria-current={page === i+1}
          className={`w-7 h-7 rounded-sm mono text-[10px] ${page === i+1 ? "bg-primary/20 text-primary border border-primary/60" : "hairline text-muted-foreground hover:text-foreground"}`}>
          {i+1}
        </button>
      ))}
    </div>
  );
}
