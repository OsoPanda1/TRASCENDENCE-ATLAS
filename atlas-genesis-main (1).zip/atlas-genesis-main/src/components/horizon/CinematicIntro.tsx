import { useEffect, useState } from "react";

const LINES = [
  "BOOT · MD-X4 KERNEL ::: initializing 7 federations",
  "ANUBIS Sentinel™ : Dilithium5 + Kyber1024 handshake OK",
  "Isabella ACCS · triple bloqueo ontológico ACTIVE",
  "BookPI™ chain integrity : 100.000 %",
  "Atlas grafo civilizatorio : sync OK",
  "Phoenix V2 mesh ::: standby",
  "READY · Orgullosamente Realmontenses",
];

export function CinematicIntro({ onDone }: { onDone?: () => void }) {
  const [i, setI] = useState(0);
  const [done, setDone] = useState(false);
  useEffect(() => {
    if (i >= LINES.length) { setDone(true); onDone?.(); return; }
    const t = setTimeout(() => setI(i + 1), 350);
    return () => clearTimeout(t);
  }, [i, onDone]);
  if (done) return null;
  return (
    <div className="fixed inset-0 z-[100] bg-void flex items-center justify-center pointer-events-none">
      <div className="font-mono text-xs text-aurora space-y-1 max-w-md">
        {LINES.slice(0, i).map((l, k) => (
          <div key={k} className="opacity-80"><span className="text-glow">›</span> {l}</div>
        ))}
        {i < LINES.length && <div className="text-glow animate-pulse">_</div>}
      </div>
    </div>
  );
}
