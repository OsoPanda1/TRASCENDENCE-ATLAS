import { useEffect, useRef } from "react";
export function MatrixRain({ density = 30 }: { density?: number }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext("2d"); if (!ctx) return;
    const chars = "アァカサタナハマヤラワTAMV01ATLΑΩ".split("");
    const fontSize = 14;
    let cols = 0, drops: number[] = [];
    const resize = () => {
      c.width = c.clientWidth; c.height = c.clientHeight;
      cols = Math.floor(c.width / fontSize);
      drops = Array.from({ length: cols }, () => Math.random() * c.height / fontSize);
    };
    resize(); window.addEventListener("resize", resize);
    let raf = 0;
    const draw = () => {
      ctx.fillStyle = "rgba(8,10,20,0.08)";
      ctx.fillRect(0, 0, c.width, c.height);
      ctx.fillStyle = "rgba(120,255,220,0.55)";
      ctx.font = `${fontSize}px JetBrains Mono, monospace`;
      for (let i = 0; i < cols; i++) {
        const ch = chars[Math.floor(Math.random() * chars.length)];
        ctx.fillText(ch, i * fontSize, drops[i] * fontSize);
        if (drops[i] * fontSize > c.height && Math.random() > 0.975) drops[i] = 0;
        drops[i] += 1;
      }
      raf = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, [density]);
  return <canvas ref={ref} className="absolute inset-0 w-full h-full opacity-30 pointer-events-none" />;
}
