import { Starfield } from "@/components/Starfield";
import { ParticleField } from "@/components/atlas/ParticleField";
export function TAMVBackgroundScene() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-void via-background to-background" />
      <Starfield count={120} />
      <ParticleField count={60} color="var(--plasma)" />
      <div className="absolute inset-0 grid-lines opacity-30" />
    </div>
  );
}
