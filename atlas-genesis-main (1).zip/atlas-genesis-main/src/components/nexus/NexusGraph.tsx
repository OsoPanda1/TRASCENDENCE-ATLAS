import { FEDERATIONS } from "@/lib/federations";
import { useEffect, useMemo, useRef, useState } from "react";

export function NexusGraph({ height = 480 }: { height?: number }) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [w, setW] = useState(800);
  useEffect(() => {
    const r = wrapRef.current; if (!r) return;
    const obs = new ResizeObserver((es) => setW(es[0].contentRect.width));
    obs.observe(r); return () => obs.disconnect();
  }, []);
  const nodes = useMemo(() => {
    const r = Math.min(w, height) * 0.35;
    return FEDERATIONS.map((f, i) => {
      const a = (i / FEDERATIONS.length) * Math.PI * 2 - Math.PI / 2;
      return { f, x: w/2 + Math.cos(a) * r, y: height/2 + Math.sin(a) * r };
    });
  }, [w, height]);
  return (
    <div ref={wrapRef} className="relative w-full grid-lines rounded-sm overflow-hidden glass" style={{ height }}>
      <svg width={w} height={height} className="absolute inset-0">
        <defs>
          <radialGradient id="nexus-core"><stop offset="0%" stopColor="var(--glow)" stopOpacity="1" /><stop offset="100%" stopColor="var(--glow)" stopOpacity="0" /></radialGradient>
        </defs>
        <circle cx={w/2} cy={height/2} r={Math.min(w, height) * 0.42} fill="url(#nexus-core)" opacity="0.08" />
        {nodes.map((a, i) => nodes.slice(i+1).map((b) => (
          <line key={`${a.f.id}-${b.f.id}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="currentColor" strokeOpacity="0.12" strokeWidth="0.6" className="text-foreground" />
        )))}
        {nodes.map((n) => (
          <g key={n.f.id}>
            <circle cx={n.x} cy={n.y} r="22" fill={n.f.color} opacity="0.1" />
            <circle cx={n.x} cy={n.y} r="9" fill={n.f.color} style={{ filter: `drop-shadow(0 0 14px ${n.f.color})` }} />
            <text x={n.x} y={n.y - 30} fontSize="11" textAnchor="middle" fill="currentColor" className="font-mono text-foreground/80">{n.f.index}</text>
            <text x={n.x} y={n.y + 36} fontSize="10" textAnchor="middle" fill="currentColor" className="font-display text-foreground/60">{n.f.name.es}</text>
          </g>
        ))}
        <circle cx={w/2} cy={height/2} r="14" fill="var(--glow)" style={{ filter: "drop-shadow(0 0 24px var(--glow))" }} />
        <text x={w/2} y={height/2 + 4} fontSize="10" textAnchor="middle" fill="var(--void)" className="font-mono">NEXUS</text>
      </svg>
    </div>
  );
}
