import { FEDERATIONS } from "@/lib/federations";
import { FlowLens } from "@/components/atlas/FlowLens";
import { useState } from "react";

export function ExecutionCenterBoard() {
  const [tick, setTick] = useState(0);
  return (
    <div className="glass rounded-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">Centro de Ejecución</div>
          <h3 className="font-display text-2xl">Tablero operativo · MD-X4</h3>
        </div>
        <button onClick={() => setTick(tick+1)} className="hairline rounded-sm px-3 py-1.5 mono text-[10px] tracking-[0.2em] text-foreground hover:text-primary">REFRESH</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {FEDERATIONS.map((f, i) => {
          const v = 70 + ((i * 13 + tick * 7) % 30);
          return (
            <div key={f.id} className="hairline rounded-sm p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="mono text-[10px]" style={{ color: f.color }}>{f.glyph} {f.index}</span>
                <span className="mono text-[9px] text-muted-foreground">{f.name.es}</span>
              </div>
              <FlowLens label="throughput" value={v} color={f.color} />
            </div>
          );
        })}
      </div>
    </div>
  );
}
