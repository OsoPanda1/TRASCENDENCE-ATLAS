import { FEDERATIONS } from "@/lib/federations";
export function ConvergenceHub() {
  return (
    <div className="glass rounded-sm p-6">
      <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-3">Convergence Hub</div>
      <h3 className="font-display text-2xl mb-4">Las 7 federaciones convergen en el KERNEL</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {FEDERATIONS.map((f) => (
          <div key={f.id} className="hairline rounded-sm p-3">
            <div className="flex items-center justify-between">
              <span className="mono text-[10px] text-muted-foreground">{f.index}</span>
              <span style={{ color: f.color }}>{f.glyph}</span>
            </div>
            <div className="font-display text-sm mt-2">{f.name.es}</div>
            <div className="text-[10px] text-muted-foreground mt-1 leading-tight">{f.domain.es}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
