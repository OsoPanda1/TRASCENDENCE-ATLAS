const INTEGRATIONS = [
  { key: "GITHUB", label: "GitHub", desc: "Webhooks, repos, eventos", color: "var(--glow)" },
  { key: "OPENAIRE", label: "OpenAIRE", desc: "Publicaciones científicas", color: "var(--plasma)" },
  { key: "ZENODO", label: "Zenodo", desc: "Repositorio FAIR / DOI", color: "var(--aurora)" },
  { key: "FIGSHARE", label: "Figshare", desc: "Datasets, artefactos", color: "var(--gold)" },
  { key: "ORCID", label: "ORCID", desc: "Identidad investigadora", color: "var(--fed-identity)" },
  { key: "ELEVENLABS", label: "ElevenLabs", desc: "Capa vocal Isabella", color: "var(--fed-ai)" },
  { key: "IPFS", label: "IPFS / BookPI", desc: "Anclaje inmutable", color: "var(--fed-knowledge)" },
];

export function IntegrationsPanel() {
  return (
    <div className="glass rounded-sm p-6">
      <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-3">Integraciones federadas</div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        {INTEGRATIONS.map((i) => (
          <div key={i.key} className="hairline rounded-sm p-3">
            <div className="flex items-center gap-2 mb-1">
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: i.color, boxShadow: `0 0 6px ${i.color}` }} />
              <div className="mono text-[10px] tracking-[0.2em]" style={{ color: i.color }}>{i.label}</div>
            </div>
            <div className="text-[11px] text-muted-foreground leading-tight">{i.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
