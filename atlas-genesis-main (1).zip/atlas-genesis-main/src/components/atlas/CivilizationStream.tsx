import { useEffect, useState } from "react";
import { FEDERATIONS } from "@/lib/federations";

const ACTIONS = ["INGEST","PUBLISH","DECISION","OBSERVATION","AUDIT","STATE_TRANSITION","RECONCILIATION"];
const ENTS = ["entity:atlas","entity:isabella","entity:anubis","entity:bookpi","entity:utamv","entity:cattleya"];

export function CivilizationStream({ limit = 12 }: { limit?: number }) {
  const [rows, setRows] = useState<{ id: string; t: string; e: string; f: typeof FEDERATIONS[number]; ts: number }[]>([]);
  useEffect(() => {
    const seed = Array.from({ length: limit }, (_, i) => ({
      id: "ev_" + Math.random().toString(36).slice(2, 8),
      t: ACTIONS[(i*3) % ACTIONS.length],
      e: ENTS[i % ENTS.length],
      f: FEDERATIONS[i % FEDERATIONS.length],
      ts: Date.now() - i * 4000,
    }));
    setRows(seed);
    const id = setInterval(() => {
      setRows((r) => [{
        id: "ev_" + Math.random().toString(36).slice(2, 8),
        t: ACTIONS[Math.floor(Math.random() * ACTIONS.length)],
        e: ENTS[Math.floor(Math.random() * ENTS.length)],
        f: FEDERATIONS[Math.floor(Math.random() * FEDERATIONS.length)],
        ts: Date.now(),
      }, ...r].slice(0, limit));
    }, 2200);
    return () => clearInterval(id);
  }, [limit]);
  return (
    <div className="glass rounded-sm p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">Civilizational stream</div>
        <span className="flex items-center gap-2 mono text-[10px] text-aurora">
          <span className="w-1.5 h-1.5 rounded-full bg-aurora shadow-[0_0_8px_var(--aurora)] animate-pulse" /> LIVE
        </span>
      </div>
      <div className="space-y-px">
        {rows.map((r) => (
          <div key={r.id} className="grid grid-cols-12 gap-2 py-1.5 border-b border-border/50 last:border-0 items-center text-[11px]">
            <span className="col-span-3 mono text-primary">{r.id}</span>
            <span className="col-span-3 mono text-muted-foreground">{r.t}</span>
            <span className="col-span-3 mono text-foreground/70">{r.e}</span>
            <span className="col-span-3 mono flex items-center gap-1.5 justify-end" style={{ color: r.f.color }}>
              <span>{r.f.glyph}</span>{r.f.index}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
