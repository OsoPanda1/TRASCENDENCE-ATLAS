export function FlowLens({ label, value, max = 100, color = "var(--glow)" }: { label: string; value: number; max?: number; color?: string }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div className="hairline rounded-sm p-3">
      <div className="flex items-baseline justify-between mb-2">
        <span className="mono text-[10px] tracking-[0.2em] uppercase text-muted-foreground">{label}</span>
        <span className="mono text-[11px]" style={{ color }}>{value.toFixed(1)} / {max}</span>
      </div>
      <div className="h-1 bg-border rounded-full overflow-hidden">
        <div className="h-full transition-all" style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${color}, transparent)`, boxShadow: `0 0 8px ${color}` }} />
      </div>
    </div>
  );
}
