import { FEDERATIONS } from "@/lib/federations";

export function AtlasConstellation({ size = 280 }: { size?: number }) {
  const r = size * 0.36;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} className="w-full h-auto" aria-hidden>
      <defs>
        <radialGradient id="core-glow"><stop offset="0%" stopColor="var(--glow)" stopOpacity="0.9" /><stop offset="100%" stopColor="var(--glow)" stopOpacity="0" /></radialGradient>
      </defs>
      <circle cx={size/2} cy={size/2} r={r * 1.4} fill="url(#core-glow)" opacity="0.15" />
      {FEDERATIONS.map((f, i) => {
        const a = (i / FEDERATIONS.length) * Math.PI * 2 - Math.PI / 2;
        const x = size/2 + Math.cos(a) * r;
        const y = size/2 + Math.sin(a) * r;
        return (
          <g key={f.id}>
            <line x1={size/2} y1={size/2} x2={x} y2={y} stroke={f.color} strokeOpacity="0.3" strokeWidth="0.5" />
            <circle cx={x} cy={y} r={6} fill={f.color} opacity="0.2" />
            <circle cx={x} cy={y} r={3} fill={f.color} style={{ filter: `drop-shadow(0 0 6px ${f.color})` }} />
            <text x={x} y={y - 10} fontSize="7" textAnchor="middle" fill="currentColor" className="font-mono text-foreground/70">{f.index}</text>
          </g>
        );
      })}
      <circle cx={size/2} cy={size/2} r="4" fill="var(--glow)" style={{ filter: "drop-shadow(0 0 8px var(--glow))" }} />
    </svg>
  );
}
