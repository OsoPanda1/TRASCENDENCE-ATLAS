import { FEDERATIONS } from "@/lib/federations";
export function ArchitectureMiniMap() {
  return (
    <div className="hairline rounded-sm p-4">
      <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-3">Architecture mini-map</div>
      <div className="grid grid-cols-7 gap-1">
        {FEDERATIONS.map((f) => (
          <div key={f.id} className="aspect-square rounded-sm flex items-center justify-center" style={{ background: `color-mix(in oklch, ${f.color} 25%, transparent)`, border: `1px solid ${f.color}` }}>
            <span className="font-display text-sm" style={{ color: f.color }}>{f.glyph}</span>
          </div>
        ))}
      </div>
      <div className="mono text-[9px] text-muted-foreground mt-2 tracking-[0.2em]">F1 → F7 · MD-X4 KERNEL</div>
    </div>
  );
}
