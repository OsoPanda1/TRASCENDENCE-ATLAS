import { useEffect, useState } from "react";

export function MetricCounter({ value, label, unit, color = "var(--glow)" }: { value: number; label: string; unit?: string; color?: string }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf = 0; const start = performance.now(); const dur = 1400;
    const step = (t: number) => {
      const k = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - k, 3);
      setN(value * eased);
      if (k < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  const display = value >= 1000 ? n.toLocaleString(undefined, { maximumFractionDigits: 0 }) : n.toFixed(value % 1 === 0 ? 0 : 2);
  return (
    <div className="glass rounded-sm p-5">
      <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">{label}</div>
      <div className="font-display text-3xl mt-1" style={{ color, textShadow: `0 0 16px ${color}` }}>
        {display}{unit ? <span className="text-base ml-1 text-muted-foreground">{unit}</span> : null}
      </div>
    </div>
  );
}
