export function RealmontenseBadge({ variant = "default" }: { variant?: "default" | "compact" | "ribbon" }) {
  if (variant === "compact") {
    return (
      <span className="inline-flex items-center gap-2 mono text-[9px] tracking-[0.22em] uppercase text-gold/90">
        <span className="w-1 h-1 rounded-full bg-gold shadow-[0_0_8px_var(--gold)]" />
        Orgullosamente Realmontenses
      </span>
    );
  }
  if (variant === "ribbon") {
    return (
      <div className="hairline rounded-sm px-3 py-2 flex items-center gap-3 bg-gradient-to-r from-gold/10 via-transparent to-gold/5">
        <span className="text-gold text-lg leading-none">✦</span>
        <div>
          <div className="mono text-[9px] tracking-[0.28em] uppercase text-gold/80">Real de Montes · LATAM</div>
          <div className="font-display text-sm text-foreground">Orgullosamente Realmontenses</div>
        </div>
      </div>
    );
  }
  return (
    <div className="inline-flex items-center gap-3 hairline rounded-sm px-4 py-2">
      <span className="w-2 h-2 rounded-full bg-gold shadow-[0_0_10px_var(--gold)]" />
      <span className="mono text-[10px] tracking-[0.24em] uppercase text-gold">Orgullosamente Realmontenses</span>
    </div>
  );
}
