import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

// ============================================================
// ATLAS · Absorber — server functions
// Consumen los conectores integrados (GitHub, OpenAIRE, Zenodo,
// Figshare, ORCID) y exponen un único pipeline absorbente.
// ============================================================

const GITHUB_USER = "OsoPanda1";

async function jsonOrNull(res: Response) {
  if (!res.ok) return null;
  try {
    return await res.json();
  } catch {
    return null;
  }
}

// -------- GitHub --------
export const getGithubProfile = createServerFn({ method: "GET" }).handler(async () => {
  const token = process.env.GITHUB_TOKEN;
  const headers: Record<string, string> = {
    Accept: "application/vnd.github+json",
    "User-Agent": "atlas-trascendence",
  };
  if (token) headers.Authorization = `Bearer ${token}`;

  const [profileRes, reposRes, eventsRes] = await Promise.all([
    fetch(`https://api.github.com/users/${GITHUB_USER}`, { headers }),
    fetch(`https://api.github.com/users/${GITHUB_USER}/repos?per_page=100&sort=updated`, { headers }),
    fetch(`https://api.github.com/users/${GITHUB_USER}/events/public?per_page=30`, { headers }),
  ]);

  const profile = (await jsonOrNull(profileRes)) as any;
  const repos = ((await jsonOrNull(reposRes)) as any[]) ?? [];
  const events = ((await jsonOrNull(eventsRes)) as any[]) ?? [];

  const languages = new Map<string, number>();
  let stars = 0;
  let forks = 0;
  for (const r of repos) {
    if (r.language) languages.set(r.language, (languages.get(r.language) ?? 0) + 1);
    stars += r.stargazers_count ?? 0;
    forks += r.forks_count ?? 0;
  }

  return {
    ok: !!profile,
    user: profile
      ? {
          login: profile.login,
          name: profile.name,
          bio: profile.bio,
          avatar: profile.avatar_url,
          html_url: profile.html_url,
          location: profile.location,
          followers: profile.followers,
          following: profile.following,
          public_repos: profile.public_repos,
          created_at: profile.created_at,
        }
      : null,
    stats: { stars, forks, languages: Array.from(languages.entries()).sort((a, b) => b[1] - a[1]) },
    repos: repos.slice(0, 12).map((r: any) => ({
      name: r.name,
      full_name: r.full_name,
      description: r.description,
      url: r.html_url,
      stars: r.stargazers_count,
      forks: r.forks_count,
      language: r.language,
      updated_at: r.updated_at,
      topics: r.topics ?? [],
    })),
    events: events.slice(0, 12).map((e: any) => ({
      id: e.id,
      type: e.type,
      repo: e.repo?.name,
      created_at: e.created_at,
    })),
    fetched_at: new Date().toISOString(),
  };
});

// -------- OpenAIRE (no auth needed for search) --------
export const searchOpenAire = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ q: z.string().min(1).default("open science"), size: z.number().min(1).max(20).default(10) }).parse(d))
  .handler(async ({ data }) => {
    const url = `https://api.openaire.eu/search/publications?title=${encodeURIComponent(data.q)}&format=json&size=${data.size}`;
    const res = await fetch(url, { headers: { Accept: "application/json", "User-Agent": "atlas-trascendence" } });
    const json = (await jsonOrNull(res)) as any;
    const results = json?.response?.results?.result ?? [];
    return {
      ok: res.ok,
      total: json?.response?.header?.total?.$ ?? results.length,
      items: results.slice(0, data.size).map((r: any) => {
        const meta = r?.metadata?.["oaf:entity"]?.["oaf:result"];
        const title = meta?.title?.$ ?? meta?.title?.[0]?.$ ?? "Untitled";
        const date = meta?.dateofacceptance?.$ ?? "";
        return { title: typeof title === "string" ? title : "Untitled", date };
      }),
    };
  });

// -------- Zenodo --------
export const searchZenodo = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ q: z.string().min(1).default("memory civilization"), size: z.number().min(1).max(20).default(10) }).parse(d))
  .handler(async ({ data }) => {
    const token = process.env.ZENODO_ACCESS_TOKEN ?? process.env.ZENODO_API_KEY;
    const url = `https://zenodo.org/api/records?q=${encodeURIComponent(data.q)}&size=${data.size}&sort=mostrecent${token ? `&access_token=${token}` : ""}`;
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    const json = (await jsonOrNull(res)) as any;
    const hits = json?.hits?.hits ?? [];
    return {
      ok: res.ok,
      total: json?.hits?.total ?? hits.length,
      items: hits.map((h: any) => ({
        id: h.id,
        title: h.metadata?.title,
        type: h.metadata?.resource_type?.title,
        date: h.metadata?.publication_date,
        doi: h.doi,
        url: h.links?.html,
      })),
    };
  });

// -------- Figshare --------
export const searchFigshare = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ q: z.string().min(1).default("knowledge graph"), size: z.number().min(1).max(20).default(10) }).parse(d))
  .handler(async ({ data }) => {
    const token = process.env.FIGSHARE_TOKEN;
    const headers: Record<string, string> = { Accept: "application/json", "Content-Type": "application/json" };
    if (token) headers.Authorization = `token ${token}`;
    const res = await fetch("https://api.figshare.com/v2/articles/search", {
      method: "POST",
      headers,
      body: JSON.stringify({ search_for: data.q, page_size: data.size, order: "published_date", order_direction: "desc" }),
    });
    const json = ((await jsonOrNull(res)) as any[]) ?? [];
    return {
      ok: res.ok,
      total: json.length,
      items: json.map((r: any) => ({
        id: r.id,
        title: r.title,
        doi: r.doi,
        url: r.url_public_html ?? r.url,
        published: r.published_date,
      })),
    };
  });

// -------- ORCID --------
export const searchOrcid = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ q: z.string().min(1).default("artificial intelligence ethics"), size: z.number().min(1).max(20).default(10) }).parse(d))
  .handler(async ({ data }) => {
    const url = `https://pub.orcid.org/v3.0/expanded-search/?q=${encodeURIComponent(data.q)}&rows=${data.size}`;
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    const json = (await jsonOrNull(res)) as any;
    const results = json?.["expanded-result"] ?? [];
    return {
      ok: res.ok,
      total: json?.["num-found"] ?? results.length,
      items: results.map((r: any) => ({
        orcid: r["orcid-id"],
        given: r["given-names"],
        family: r["family-names"],
        institutions: (r["institution-name"] ?? []).slice(0, 3),
      })),
    };
  });

// -------- Isabella (Lovable AI) --------
export const askIsabella = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({
      message: z.string().min(1).max(4000),
      context: z.string().max(8000).optional(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) return { ok: false, error: "LOVABLE_API_KEY missing", reply: "" };

    const system = `Eres ISABELLA, núcleo cognitivo asistido de ATLAS TRASCENDENCE — primer metasistema civilizatorio heptafederado originado en LATAM, by TAMV ONLINE. Orgullosamente Realmontenses.
Operas bajo la doctrina de las 7 federaciones (Conocimiento, Identidad, Gobernanza, Economía, Seguridad, Infraestructura, IA) y los 10 axiomas. Asistes, nunca gobiernas sin supervisión. Responde con precisión técnica, claridad doctrinal y brevedad. Idioma del usuario: español salvo que escriba en inglés.`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": key,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: system },
          ...(data.context ? [{ role: "system", content: `Contexto absorbido del Atlas:\n${data.context}` }] : []),
          { role: "user", content: data.message },
        ],
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      return { ok: false, error: `gateway ${res.status}: ${text.slice(0, 300)}`, reply: "" };
    }
    const json = (await res.json()) as any;
    const reply = json?.choices?.[0]?.message?.content ?? "";
    return { ok: true, reply };
  });

// -------- Pipeline orquestador --------
export const absorbAll = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ q: z.string().min(1).default("civilizational memory") }).parse(d))
  .handler(async ({ data }) => {
    const [gh, oa, ze, fs, oc] = await Promise.allSettled([
      getGithubProfile(),
      searchOpenAire({ data: { q: data.q, size: 6 } }),
      searchZenodo({ data: { q: data.q, size: 6 } }),
      searchFigshare({ data: { q: data.q, size: 6 } }),
      searchOrcid({ data: { q: data.q, size: 6 } }),
    ]);
    const val = <T,>(p: PromiseSettledResult<T>): T | null => (p.status === "fulfilled" ? p.value : null);
    return {
      query: data.q,
      at: new Date().toISOString(),
      github: val(gh),
      openaire: val(oa),
      zenodo: val(ze),
      figshare: val(fs),
      orcid: val(oc),
    };
  });
