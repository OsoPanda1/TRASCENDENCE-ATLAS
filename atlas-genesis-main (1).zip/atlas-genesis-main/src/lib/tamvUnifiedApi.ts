// Cliente unificado MD-X5 (REST + GraphQL + WS) — placeholder client-side.
// Las llamadas privilegiadas se hacen desde server functions; este módulo expone
// solo el "shape" de la API para autodocumentación.

export const API_BASE = "/api";

export interface ApiSpec {
  rest: { method: string; path: string; tag: string; summary: string }[];
  graphql: string[];
  ws: { channel: string; desc: string }[];
}

export const TAMV_API_SPEC: ApiSpec = {
  rest: [
    { method: "POST", path: "/v1/auth/register", tag: "Identity", summary: "Registro de usuario en TAMV" },
    { method: "POST", path: "/v1/auth/login", tag: "Identity", summary: "Inicio de sesión" },
    { method: "POST", path: "/v1/auth/refresh", tag: "Identity", summary: "Refresca el token de acceso" },
    { method: "GET",  path: "/v1/users/me", tag: "Identity", summary: "Perfil del usuario autenticado" },
    { method: "GET",  path: "/v1/users/{id}", tag: "Identity", summary: "Perfil público" },
    { method: "GET",  path: "/v1/social/feed", tag: "Social", summary: "Feed principal" },
    { method: "POST", path: "/v1/social/posts", tag: "Social", summary: "Crear post" },
    { method: "GET",  path: "/v1/social/posts/{id}", tag: "Social", summary: "Obtener post" },
    { method: "GET",  path: "/v1/social/stories", tag: "Social", summary: "Stories activas" },
    { method: "GET",  path: "/v1/xr/scenes", tag: "XR", summary: "Listar escenas XR" },
    { method: "GET",  path: "/v1/xr/scenes/{id}", tag: "XR", summary: "Detalle escena XR" },
    { method: "POST", path: "/v1/xr/dreamspaces", tag: "XR", summary: "Crear DreamSpace" },
    { method: "GET",  path: "/v1/economy/products", tag: "Economy", summary: "Productos / marketplace" },
    { method: "POST", path: "/v1/economy/orders", tag: "Economy", summary: "Crear orden" },
    { method: "GET",  path: "/v1/dao/namespaces", tag: "DAO", summary: "Espacios DAO" },
    { method: "POST", path: "/v1/dao/proposals", tag: "DAO", summary: "Crear propuesta" },
    { method: "POST", path: "/v1/dao/proposals/{id}/vote", tag: "DAO", summary: "Votar propuesta" },
    { method: "POST", path: "/v1/isabella/chat", tag: "AI", summary: "Chat con Isabella" },
    { method: "POST", path: "/v1/isabella/risk-evaluation", tag: "AI", summary: "Evaluación de riesgo" },
    { method: "POST", path: "/v1/isabella/freeze", tag: "AI", summary: "Hard stop" },
    { method: "POST", path: "/v1/isabella/resume", tag: "AI", summary: "Reanudación controlada" },
    { method: "GET",  path: "/v1/isabella/audit/{trace_id}", tag: "AI", summary: "Log de evento" },
    { method: "GET",  path: "/v1/system/health", tag: "System", summary: "Salud del sistema" },
  ],
  graphql: [
    "type User { id: ID! handle: String displayName: String avatarUrl: String }",
    "type Post { id: ID! authorId: ID! content: String! mediaUrl: String createdAt: String! }",
    "type Seguimiento { id: ID! radar: SeguimientoRadar! level: SeguimientoLevel! action: String! ts: String! }",
    "enum SeguimientoRadar { QUETZALCOATL OJO_RA GEMELO_A GEMELO_B ANUBIS HORUS OSIRIS DEKATEOTL }",
    "type Subscription { seguimientoStream(radar: SeguimientoRadar level: SeguimientoLevel): Seguimiento! orderEvents(userId: ID): Order! }",
  ],
  ws: [
    { channel: "seguimientoStream", desc: "Stream de seguimientos por radar (QUETZALCOATL/HORUS/ANUBIS/etc.)" },
    { channel: "orderEvents", desc: "Eventos de órdenes del marketplace" },
    { channel: "isabella.decisions", desc: "Stream de DecisionRecords firmados" },
    { channel: "kernel.events", desc: "Eventos EOCT en vivo" },
  ],
};
