// ATLAS · Graph engine server functions backed by Lovable Cloud.
// Provides view-model payloads for the heptafederated graph.
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

function publicClient() {
  return createClient<Database>(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
  );
}

const FED_COLOR: Record<string, string> = {
  knowledge: "#7DD3FC",
  identity: "#C4B5FD",
  governance: "#FCD34D",
  economy: "#86EFAC",
  security: "#FCA5A5",
  infrastructure: "#FDBA74",
  ai: "#F0ABFC",
};

export const getAtlasGraph = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({
      federation: z.string().optional(),
      limit: z.number().min(10).max(2000).default(500),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const supabase = publicClient();
    let entQ = supabase.from("entities").select("id,type,name,slug,classification,federation,summary,metadata,created_at").limit(data.limit);
    if (data.federation) entQ = entQ.eq("federation", data.federation as any);
    const { data: entities, error: e1 } = await entQ;
    if (e1) throw new Error(e1.message);

    const ids = (entities ?? []).map((e) => e.id);
    const { data: relations, error: e2 } = ids.length
      ? await supabase.from("relations").select("id,source_id,target_id,relation_type,weight,metadata").in("source_id", ids).limit(data.limit * 4)
      : { data: [], error: null };
    if (e2) throw new Error(e2.message);

    const nodes = (entities ?? []).map((e) => ({
      id: e.id,
      label: e.name,
      type: e.type,
      federation: e.federation ?? "infrastructure",
      classification: e.classification,
      summary: e.summary,
      visual: { color: FED_COLOR[e.federation ?? "infrastructure"] ?? "#94A3B8", size: 14 },
    }));
    const edges = (relations ?? []).map((r) => ({
      id: r.id,
      source: r.source_id,
      target: r.target_id,
      type: r.relation_type,
      weight: r.weight,
      visual: { width: 1 + (Number(r.weight ?? 1) || 1) },
    }));
    return { ok: true, nodes, edges, fetched_at: new Date().toISOString(), totals: { nodes: nodes.length, edges: edges.length } };
  });

export const getEoctStream = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ limit: z.number().min(1).max(200).default(50) }).parse(d))
  .handler(async ({ data }) => {
    const supabase = publicClient();
    const { data: events, error } = await supabase.from("eoct_events").select("id,event_type,severity,source_federation,target_federation,classification,context,ts,trace_id").order("ts", { ascending: false }).limit(data.limit);
    if (error) throw new Error(error.message);
    return { ok: true, events: events ?? [] };
  });

export const getFederationManifest = createServerFn({ method: "GET" }).handler(async () => {
  const supabase = publicClient();
  const [{ count: entCount }, { count: relCount }, { count: docCount }, { count: evCount }] = await Promise.all([
    supabase.from("entities").select("*", { count: "exact", head: true }),
    supabase.from("relations").select("*", { count: "exact", head: true }),
    supabase.from("documents").select("*", { count: "exact", head: true }),
    supabase.from("eoct_events").select("*", { count: "exact", head: true }),
  ]);
  return {
    version: "1.0.0-md-x5.r1",
    generated_at: new Date().toISOString(),
    federations: ["knowledge","identity","governance","economy","security","infrastructure","ai"],
    entities: entCount ?? 0,
    relations: relCount ?? 0,
    documents: docCount ?? 0,
    events: evCount ?? 0,
    integrity: 100,
  };
});

export const recordEoctEvent = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({
      event_type: z.enum(["OBSERVATION","DECISION","INCIDENT","STATE_TRANSITION","POLICY_CHANGE","RECONCILIATION","INGEST","PUBLISH","AUDIT","SECURITY_ALERT"]),
      source_federation: z.enum(["knowledge","identity","governance","economy","security","infrastructure","ai"]).optional(),
      severity: z.enum(["INFO","WARNING","CRITICAL"]).default("INFO"),
      context: z.record(z.string(), z.unknown()).optional(),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const supabase = publicClient();
    const { data: row, error } = await supabase.from("eoct_events").insert({
      event_type: data.event_type,
      source_federation: data.source_federation,
      severity: data.severity,
      classification: "public",
      context: (data.context ?? {}) as any,
      trace_id: "trace_" + Math.random().toString(36).slice(2, 12),
    }).select().single();
    if (error) throw new Error(error.message);
    return { ok: true, event: row };
  });
