export interface Offer {
  id: string;
  title: { es: string; en: string };
  category: "membership" | "service" | "lottery" | "data" | "promo";
  price_mxn: number | null;
  price_usd?: number | null;
  recurrence?: "monthly" | "annual" | "one-time" | "per-ticket";
  description: { es: string; en: string };
  rev_share?: { creator: number; tamv: number };
}

export const TAMV_OFFERS: Offer[] = [
  { id: "m-free", title: { es: "Free", en: "Free" }, category: "membership", price_mxn: 0, recurrence: "monthly", description: { es: "Acceso básico, sin derecho de monetización.", en: "Basic access, no monetization." } },
  { id: "m-premium", title: { es: "Premium", en: "Premium" }, category: "membership", price_mxn: 99, recurrence: "monthly", description: { es: "Monetización básica + soporte prioritario.", en: "Basic monetization + priority support." } },
  { id: "m-vip", title: { es: "VIP", en: "VIP" }, category: "membership", price_mxn: 199, recurrence: "monthly", description: { es: "Analíticas avanzadas, insignias.", en: "Advanced analytics, badges." } },
  { id: "m-elite", title: { es: "Elite", en: "Elite" }, category: "membership", price_mxn: 399, recurrence: "monthly", description: { es: "API, visibilidad y promoción interna.", en: "API, visibility, internal promo." } },
  { id: "m-celestial", title: { es: "Celestial", en: "Celestial" }, category: "membership", price_mxn: 799, recurrence: "monthly", description: { es: "IA avanzada + eventos VIP + límites casi ilimitados.", en: "Advanced AI + VIP events." } },
  { id: "m-enterprise", title: { es: "Enterprise", en: "Enterprise" }, category: "membership", price_mxn: 1999, recurrence: "monthly", description: { es: "Soporte dedicado + integraciones MSR/B2B/B2G.", en: "Dedicated support + MSR integrations." } },

  { id: "s-tickets", title: { es: "Tickets XR", en: "XR Tickets" }, category: "service", price_mxn: null, description: { es: "Tickets y conciertos XR.", en: "XR tickets and concerts." }, rev_share: { creator: 70, tamv: 30 } },
  { id: "s-channel", title: { es: "Suscripción de canal", en: "Channel subscription" }, category: "service", price_mxn: null, description: { es: "Comunidades premium.", en: "Premium communities." }, rev_share: { creator: 65, tamv: 35 } },
  { id: "s-market", title: { es: "Marketplace XR/AI", en: "XR/AI Marketplace" }, category: "service", price_mxn: null, description: { es: "Assets, escenas, packs.", en: "Assets, scenes, packs." }, rev_share: { creator: 60, tamv: 40 } },
  { id: "s-chat", title: { es: "Chats premium", en: "Premium chats" }, category: "service", price_mxn: null, description: { es: "Rooms de alto valor.", en: "High-value rooms." }, rev_share: { creator: 50, tamv: 50 } },
  { id: "s-utamv", title: { es: "UTAMV — cursos", en: "UTAMV — courses" }, category: "service", price_mxn: null, description: { es: "Universidad TAMV.", en: "TAMV University." }, rev_share: { creator: 75, tamv: 25 } },

  { id: "l-ticket", title: { es: "Lotería TAMV", en: "TAMV Lottery" }, category: "lottery", price_mxn: 40, price_usd: 2, recurrence: "per-ticket", description: { es: "50% bolsa de premios / 50% TAMV. Premio unitario 500 USD.", en: "50% prize pool / 50% TAMV. 500 USD per winning ticket." } },

  { id: "p-founders", title: { es: "Fundadores 500", en: "Founders 500" }, category: "promo", price_mxn: null, price_usd: 1000, recurrence: "one-time", description: { es: "Bono 1000 USD a los primeros 500 con ≥3000 seguidores válidos.", en: "1000 USD bonus to first 500 with ≥3000 valid followers." } },
];
