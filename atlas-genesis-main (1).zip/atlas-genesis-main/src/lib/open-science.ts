// Façades genéricas para registros Open Science.
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export interface OpenScienceRecord {
  source: "zenodo" | "figshare" | "openaire" | "orcid";
  id: string;
  title: string;
  url?: string;
  date?: string;
  doi?: string;
}

export const REGISTRY = {
  TAMV_DOI: "10.5281/zenodo.19436662",
  AUTHOR_ORCID: "0009-0008-5050-1539",
  GITHUB_USER: "OsoPanda1",
} as const;

export const openScienceStatus = createServerFn({ method: "GET" }).handler(async () => {
  const targets = [
    { name: "Zenodo", url: "https://zenodo.org/api/records?size=1" },
    { name: "Figshare", url: "https://api.figshare.com/v2/articles?page_size=1" },
    { name: "OpenAIRE", url: "https://api.openaire.eu/search/publications?size=1&format=json" },
    { name: "ORCID", url: `https://pub.orcid.org/v3.0/${REGISTRY.AUTHOR_ORCID}/record` },
  ];
  const out: { name: string; ok: boolean; ms: number }[] = [];
  await Promise.all(targets.map(async (t) => {
    const start = Date.now();
    try {
      const r = await fetch(t.url, { headers: { Accept: "application/json" } });
      out.push({ name: t.name, ok: r.ok, ms: Date.now() - start });
    } catch {
      out.push({ name: t.name, ok: false, ms: Date.now() - start });
    }
  }));
  return { ok: true, sources: out, at: new Date().toISOString() };
});
