import type { Entity, Relation, ManifestSnapshot } from "./types";
import { FEDERATIONS } from "./federations";

// Atlas Kernel — modelo en memoria del grafo civilizatorio.
// Se inicializa desde FEDERATIONS y módulos. Persistente vía localStorage en cliente.

export const ATLAS_ENTITIES: Entity[] = [
  { id: "tamv:online", type: "ORGANIZATION", label: "TAMV Online Network", fed: "infrastructure" },
  { id: "person:eoct", type: "PERSON", label: "Edwin Oswaldo Castillo Trejo (Anubis Villaseñor)", fed: "identity", meta: { orcid: "0009-0008-5050-1539" } },
  { id: "territory:real-de-montes", type: "TERRITORY", label: "Mineral del Monte, Hidalgo, MX", fed: "infrastructure", meta: { lat: 20.3833, lon: -98.85 } },
  { id: "doc:tamvprint", type: "DOCUMENT", label: "GENESIS TAMVPRINT", fed: "knowledge" },
  { id: "doc:dm-x4", type: "DOCUMENT", label: "TAMV DM-X4 Compendio", fed: "knowledge", meta: { doi: "10.5281/zenodo.19436662" } },
  { id: "ai:isabella", type: "SYSTEM", label: "Isabella Villaseñor AI (ACCS)", fed: "intelligence" },
  { id: "sys:anubis", type: "SYSTEM", label: "ANUBIS Sentinel™", fed: "security" },
  { id: "sys:bookpi", type: "SYSTEM", label: "BookPI™", fed: "knowledge" },
  { id: "sys:thcf", type: "SYSTEM", label: "THCF™ — Human Coherence Filter", fed: "intelligence" },
  { id: "sys:dekateotl", type: "SYSTEM", label: "DEKATEOTL™ veto 8-niveles", fed: "intelligence" },
  { id: "sys:phoenix", type: "SYSTEM", label: "Phoenix Protocol V2", fed: "security" },
  { id: "sys:tamv-chain", type: "SYSTEM", label: "TAMV Chain (PoS MX)", fed: "infrastructure" },
  { id: "svc:cattleya", type: "SERVICE", label: "Cattleya Pay™", fed: "economy" },
  { id: "svc:credits", type: "SERVICE", label: "TAMV Credits™", fed: "economy" },
  { id: "svc:utamv", type: "SERVICE", label: "Universidad TAMV (UTAMV)", fed: "knowledge" },
  { id: "policy:korima", type: "POLICY", label: "Kórima Digital", fed: "governance" },
  { id: "policy:fenix", type: "POLICY", label: "20% Fénix / 30% Infra / 50% Ganancia", fed: "economy" },
  { id: "repo:osopanda1", type: "REPO", label: "@OsoPanda1 GitHub Profile", fed: "infrastructure" },
];

export const ATLAS_RELATIONS: Relation[] = [
  { id: "r1", type: "BELONGS_TO", from: "person:eoct", to: "tamv:online" },
  { id: "r2", type: "CONTAINS", from: "tamv:online", to: "ai:isabella" },
  { id: "r3", type: "BACKED_BY", from: "ai:isabella", to: "sys:anubis" },
  { id: "r4", type: "DEPENDS_ON", from: "ai:isabella", to: "sys:thcf" },
  { id: "r5", type: "DEPENDS_ON", from: "ai:isabella", to: "sys:dekateotl" },
  { id: "r6", type: "PRESERVES", from: "sys:bookpi", to: "doc:dm-x4" },
  { id: "r7", type: "EXECUTES", from: "svc:cattleya", to: "sys:tamv-chain" },
  { id: "r8", type: "MONETIZES", from: "svc:utamv", to: "svc:credits" },
  { id: "r9", type: "AFFECTS", from: "policy:fenix", to: "tamv:online" },
  { id: "r10", type: "FEDERATES", from: "tamv:online", to: "territory:real-de-montes" },
  ...FEDERATIONS.map((f, i) => ({ id: `rf${i}`, type: "FEDERATES" as const, from: "tamv:online", to: `fed:${f.id}` })),
];

export function buildManifest(): ManifestSnapshot {
  return {
    version: "1.0.0-v4.0",
    api_version: "md-x5.r1",
    generated_at: new Date().toISOString(),
    federations: FEDERATIONS.map((f) => f.id),
    entities: ATLAS_ENTITIES.length + FEDERATIONS.length,
    relations: ATLAS_RELATIONS.length,
    events_24h: Math.floor(180_000 + Math.random() * 60_000),
    integrity: 100,
    signature: "dilithium5:" + Math.random().toString(36).slice(2, 18),
  };
}
