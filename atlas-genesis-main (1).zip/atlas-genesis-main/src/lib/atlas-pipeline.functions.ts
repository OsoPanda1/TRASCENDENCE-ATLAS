import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { IngestPayloadSchema } from "./ecosystem/contracts";
import { kernelRecord, kernelStatus, kernelEvents, kernelAudit, kernelRefreshManifest } from "@/kernel/kernel-core";
import { getCurrentManifest, compareManifests } from "./ecosystem/manifest";

export const ingestServer = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => IngestPayloadSchema.parse(d))
  .handler(async ({ data }) => {
    const event = kernelRecord({ type: "INGEST", fed: "knowledge", payload: { source: data.source, kind: data.kind } });
    return { ok: true, event_id: event.id, accepted_at: event.ts };
  });

export const kernelStatusFn = createServerFn({ method: "GET" }).handler(async () => kernelStatus() as any);
export const kernelEventsFn = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ limit: z.number().min(1).max(200).default(50) }).parse(d))
  .handler(async ({ data }) => ({ events: kernelEvents(data.limit) } as any));

export const kernelAuditFn = createServerFn({ method: "GET" }).handler(async () => kernelAudit() as any);

export const kernelSyncFn = createServerFn({ method: "POST" }).handler(async () => {
  const previous = getCurrentManifest();
  const next = kernelRefreshManifest();
  return { ok: true, previous_version: previous.version, current_version: next.version, diff: compareManifests(previous, next) } as any;
});

export const manifestFn = createServerFn({ method: "GET" }).handler(async () => getCurrentManifest());
