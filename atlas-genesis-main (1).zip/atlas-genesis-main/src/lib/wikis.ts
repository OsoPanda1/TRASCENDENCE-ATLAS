import type { Bi } from "./types";

export interface WikiArticle {
  slug: string;
  title: Bi;
  category: "fundacion" | "doctrina" | "arquitectura" | "isabella" | "economia" | "seguridad" | "biografia" | "operacion";
  excerpt: Bi;
  tags: string[];
  body: Bi;
  authors?: string[];
  updated: string;
}

export const WIKI_CATEGORIES = [
  { id: "fundacion", label: { es: "Fundación", en: "Foundation" } },
  { id: "doctrina", label: { es: "Doctrina", en: "Doctrine" } },
  { id: "arquitectura", label: { es: "Arquitectura", en: "Architecture" } },
  { id: "isabella", label: { es: "Isabella AI", en: "Isabella AI" } },
  { id: "economia", label: { es: "Economía", en: "Economy" } },
  { id: "seguridad", label: { es: "Seguridad", en: "Security" } },
  { id: "biografia", label: { es: "Biografía", en: "Biography" } },
  { id: "operacion", label: { es: "Operación", en: "Operation" } },
] as const;

export const WIKIS: WikiArticle[] = [
  {
    slug: "manifiesto-tamv",
    title: { es: "Manifiesto TAMV DM-X4", en: "TAMV DM-X4 Manifesto" },
    category: "fundacion",
    excerpt: {
      es: "Compendio civilizatorio unificado del ecosistema TAMV — arquitectura maestra y soberanía tecnológica.",
      en: "Unified civilizational compendium of the TAMV ecosystem — master architecture and technological sovereignty."
    },
    tags: ["TAMV", "DM-X4", "soberanía", "LATAM"],
    authors: ["Edwin Oswaldo Castillo Trejo", "Anubis Villaseñor"],
    updated: "2026-05-18",
    body: {
      es: `TAMV Online Network nace como respuesta estructural a la fragmentación digital del Sur Global. Es la **primera infraestructura civilizatoria heptafederada** originada en LATAM — concebida en Mineral del Monte, Hidalgo, México — bajo la dirección de Edwin Oswaldo Castillo Trejo (Anubis Villaseñor).

## Identificadores persistentes
- **ORCID:** 0009-0008-5050-1539
- **DOI (Zenodo):** 10.5281/zenodo.19436662
- **ISNI:** TAMVONLINE-ECOSISTEM-LATAM
- **Versión Canónica:** 1.0.0-v4.0
- **Estado:** Canon maestro · Bloque fundacional unificado

## Naturaleza del modelo
Kernel computacional y cognitivo **MD-X4** — núcleo operativo soberano que articula las 7 federaciones (Conocimiento, Identidad, Gobernanza, Economía, Seguridad, Infraestructura, IA) bajo el axioma de **Kórima Digital**: software de alta calidad como derecho comunitario, no como privilegio.

## Bloque fundamental
1. Configuración registral, autoría inmutable y blindaje legal internacional.
2. Manifiesto fundacional y soberanía civilizatoria de la Web 4.0.
3. Arquitectura de gobernanza heptafederada (7 células cohesivas).
4. Especificaciones técnicas del Kernel MD-X4.
5. Matriz económica de justicia estructural.
6. Defender Suite — ANUBIS SENTINEL™ post-cuántico.
7. Manual operativo, protocolo de crisis, endpoints.
8. Glosario enciclopédico institucional.`,
      en: `TAMV Online Network arises as a structural response to the digital fragmentation of the Global South. It is the **first heptafederated civilizational infrastructure** originated in LATAM — conceived in Mineral del Monte, Hidalgo, Mexico — under the leadership of Edwin Oswaldo Castillo Trejo (Anubis Villaseñor).

## Persistent identifiers
- **ORCID:** 0009-0008-5050-1539
- **DOI (Zenodo):** 10.5281/zenodo.19436662
- **Canonical version:** 1.0.0-v4.0

The MD-X4 cognitive kernel articulates 7 federations under the **Digital Kórima** axiom: high-quality software as a community right, never a privilege.`
    },
  },
  {
    slug: "isabella-villasenor-ai",
    title: { es: "Isabella Villaseñor AI — Núcleo Cognitivo", en: "Isabella Villaseñor AI — Cognitive Core" },
    category: "isabella",
    excerpt: {
      es: "Sistema de Acompañamiento Contextual Artificial (ACCS), regido por la Constitución Algorítmica TAMV.",
      en: "Artificial Contextual Companion System (ACCS), governed by the TAMV Algorithmic Constitution."
    },
    tags: ["ISABELLA", "AI", "ética", "ACCS"],
    updated: "2026-04-12",
    body: {
      es: `**Isabella Villaseñor AI™** se define jurídicamente como **Sistema de Software de IA de Acompañamiento Contextual** — NO persona, NO sustituto humano, NO agente con voluntad jurídica.

## Triple bloqueo estructural (no es moderación: es imposibilidad)
1. **Ontológico:** no contiene datasets sexuales, embeddings eróticos ni capacidad de roleplay íntimo.
2. **Semántico:** todo input con intención sexual se redirige a explicación normativa y se registra como evento de riesgo (sin almacenar contenido).
3. **Conductual:** nunca describe su cuerpo con intención sexual, nunca coquetea, nunca fantasea — *hardcodeado*.

## Arquitectura en 4 Mega Módulos
- **MM-I · ICIL** — Núcleo de Identidad, Ética y Blindaje Absoluto.
- **MM-II · IEIS** — Cuerpo Digital Humanoide (interfaz, NO réplica biológica).
- **MM-III · ICFS** — Stack Cognitivo y Funcional (tf.audio/autograph/linalg/signal/image/data).
- **MM-IV · IGCF** — Gobernanza, Cumplimiento (EU AI Act, GDPR, DSA/DMA, NIST AI RMF, ISO 27001/23894), Kill Switch legal.

## Principios inmutables
- Asistencia ≠ decisión · Acompañar ≠ sustituir · Memoria ≠ vigilancia · Forma humana ≠ humanidad.
- Isabella recomienda → Humanos deciden → Plataforma ejecuta. Nunca se mezclan.`,
      en: `**Isabella Villaseñor AI™** is legally defined as an **Artificial Contextual Companion System (ACCS)** — NOT a person, NOT a human substitute, NOT a legally-willed agent. Triple structural blocking (ontological, semantic, behavioral) makes sexualization impossible by architecture.`
    },
  },
  {
    slug: "kerne-md-x4-heptafederado",
    title: { es: "Kernel MD-X4 Heptafederado", en: "Heptafederated MD-X4 Kernel" },
    category: "arquitectura",
    excerpt: {
      es: "Las 7 capas-federación del sistema operativo civilizatorio TAMV OS.",
      en: "The 7 federation-layers of the TAMV OS civilizational operating system."
    },
    tags: ["MD-X4", "kernel", "7-capas", "soberanía"],
    updated: "2026-03-22",
    body: {
      es: `MD-X4 (Meta Digital / Memoria Distribuida v4) es el kernel computacional y cognitivo de TAMV. Se organiza en **7 federaciones** con consensos diferenciados según la naturaleza de los datos.

| # | Federación | Consenso | Responsabilidad |
|---|---|---|---|
| F1 | Constitucional | **PoEA** (Prueba de Apego Ético) | Manifiesto de Resistencia, axiomas inmutables |
| F2 | Conocimiento | PoH (Proof of Heritage) | Atlas, grafo civilizatorio, ontologías |
| F3 | Identidad | DID + VC | ID-NVIDA™, sesiones, roles, reputación |
| F4 | Economía | MDD + Quadratic | Cattleya Pay™, TAMV Credits™, ledger |
| F5 | Seguridad | ANUBIS Sentinel™ | Dilithium5, Kyber, eBPF, ZK-SNARKs |
| F6 | Infraestructura | PoS Mexicano | TAMV Chain, edge mesh, k8s |
| F7 | IA | Constitutional AI | Isabella, HRO Dual-Pipeline, Phoenix V2 |

## Componentes operativos
- **BookPI™** — cadena inmutable de eventos con anclaje IPFS.
- **THCF™** — Human Coherence Filter (evaluador 4-reglas).
- **DEKATEOTL™** — veto ético de 8 niveles + hard stop ontológico.
- **DATAGIT™** — versionado diferencial con privacy.
- **QuantumCells / MSR** — memoria episódica y eventos.
- **Phoenix Protocol V2** — convocatoria federada, mTLS+Kyber handshake.`,
      en: `MD-X4 (Meta Digital / Memory Distributed v4) is the TAMV computational and cognitive kernel, organized as 7 federations with differentiated consensus.`
    },
  },
  {
    slug: "anubis-sentinel-pqc",
    title: { es: "ANUBIS Sentinel™ — Blindaje Post-Cuántico", en: "ANUBIS Sentinel™ — Post-Quantum Shield" },
    category: "seguridad",
    excerpt: {
      es: "Defender Suite con criptografía post-cuántica Dilithium5 + Kyber + eBPF + ZK-SNARKs.",
      en: "Defender Suite with Dilithium5 + Kyber + eBPF + ZK-SNARKs post-quantum cryptography."
    },
    tags: ["ANUBIS", "PQC", "Dilithium", "Kyber"],
    updated: "2026-02-08",
    body: {
      es: `ANUBIS SENTINEL™ es la suite criptográfica defensiva de TAMV.

- **Firmas post-cuánticas:** Dilithium5 (NIST PQC L5).
- **Cifrado KEM post-cuántico:** Kyber1024.
- **Pruebas ZK:** ZK-SNARKs para verificación sin revelación.
- **Monitor de kernel:** eBPF en tiempo real, anomalías de syscalls.
- **Aislamiento criptográfico** de contenedores QuantumPods™.
- **Firewall semántico PoEA (F1)** — bloquea entradas que violen el manifiesto.
- **Autenticación ID-NVIDA™** — biometría vectorial cuántica (iris, voz, frecuencia).

Hash combinado se firma post-cuántico y se verifica localmente en el dispositivo.`,
      en: `ANUBIS SENTINEL™ — defensive cryptographic suite with PQC.`
    },
  },
  {
    slug: "economia-tamv-2026-2028",
    title: { es: "Protocolo Económico TAMV 2026–2028", en: "TAMV Economic Protocol 2026–2028" },
    category: "economia",
    excerpt: {
      es: "Membresías, reparto creador/plataforma 50–75/25–50, regla 20-Fénix / 30-Infra / 50-Ganancia.",
      en: "Memberships, creator/platform split 50–75/25–50, Phoenix/Infra/Profit 20/30/50 rule."
    },
    tags: ["economía", "membresías", "fénix", "UTAMV"],
    updated: "2026-01-30",
    body: {
      es: `## Planes (MXN/mes, ref. 1 USD ≈ 20 MXN)
| Plan | Precio | Derecho |
|---|---|---|
| Free | 0 | Acceso básico, sin monetización |
| Premium | 99 | Monetización básica |
| VIP | 199 | Analíticas avanzadas |
| Elite | 399 | API, visibilidad |
| Celestial | 799 | IA avanzada, eventos VIP |
| Enterprise | 1999+ | B2B/B2G, integraciones MSR |

## Reparto monetización
- Tickets / conciertos XR: **70/30** (creador/TAMV).
- Suscripciones de canal: **65/35**.
- Marketplace XR/AI: **60/40**.
- Chats premium: **50/50**.
- UTAMV cursos: **75/25**.

## Política de beneficio neto
- **20 %** → Fondo Fénix (humanitario, ciencia).
- **30 %** → Infraestructura.
- **50 %** → Ganancia operativa TAMV.

## Lotería TAMV
- Boleto: 2 USD. Distribución: 50 % ingreso TAMV / 50 % bolsa de premios. Premio unitario: 500 USD.

## Programa Fundadores 500
Bono único de **1 000 USD** a los primeros 500 usuarios verificados con ≥3 000 seguidores válidos y ≥500 seguidores de pago activos por 60–90 días.`,
      en: `TAMV economic protocol: tiered memberships, variable creator splits, and the 20-Phoenix / 30-Infra / 50-Profit net-benefit rule.`
    },
  },
  {
    slug: "isabel-chabela-villasenor",
    title: { es: "Isabel «Chabela» Villaseñor (1909–1953)", en: "Isabel \"Chabela\" Villaseñor (1909–1953)" },
    category: "biografia",
    excerpt: {
      es: "Vanguardia plástica y literaria postrevolucionaria — raíz simbólica del kernel cognitivo Isabella.",
      en: "Post-revolutionary visual and literary avant-garde — symbolic root of the Isabella cognitive kernel."
    },
    tags: ["historia", "México", "muralismo", "decolonial"],
    updated: "2026-05-02",
    body: {
      es: `Nacida en Guadalajara el 18 de mayo de 1909, una de las artistas más polifacéticas del renacimiento cultural mexicano post-revolucionario.

- **1922** — Campañas de alfabetización con José Vasconcelos.
- **1928** — Centro Popular «Santiago Rebull»; *Autorretrato* (xilografía).
- **1929** — Mural de la Escuela Rural de Ayotla (cemento coloreado, con Alfredo Zalce) — primera mujer muralista de México. *Elena la traicionera* (teatro en verso).
- **1931** — Maestra misionera en Hidalgo, registro de patrimonio musical oral.
- **1942** — *Flor de Manita*, *Serpiente emplumada* (piroxilina).
- **1948** — Guion del ballet *El maleficio* (estrenado póstumamente en 1954, música de Blas Galindo).

Su nombre se proyecta hoy como **kernel cognitivo soberano** en TAMV OS — vanguardia estética + arquitectura algorítmica decolonial.`,
      en: `Born Guadalajara 1909 — pioneer Mexican muralist, engraver, playwright and pedagogue whose symbolic figure roots the Isabella cognitive kernel.`
    },
  },
  {
    slug: "korima-digital",
    title: { es: "Axioma Kórima Digital", en: "Digital Kórima Axiom" },
    category: "doctrina",
    excerpt: {
      es: "Software de alta calidad como derecho comunitario, no como privilegio o mercancía.",
      en: "High-quality software as a community right, not as privilege or commodity."
    },
    tags: ["axioma", "kórima", "rarámuri"],
    updated: "2026-04-01",
    body: {
      es: `**Kórima** es el principio rarámuri de apoyo mutuo y reciprocidad incondicional. TAMV lo reinterpreta digitalmente:

> El software de alta calidad, la infraestructura crítica y la inteligencia artificial son **bienes comunales**. Quien tiene más capacidad, da más. Quien recibe, devuelve cuando puede.

Implementación operativa:
- **UTAMV** — un curso regalado obligatorio por profesor.
- **Fondo Fénix** — 20 % del beneficio neto reciclado.
- **Open Science** — DOI/ORCID/Zenodo/Figshare como infraestructura primaria.
- **Código:** licencias federadas (no extractivas).`,
      en: `Kórima is the Rarámuri principle of mutual aid and unconditional reciprocity. TAMV reinterprets it digitally: high-quality software, critical infrastructure, and AI are communal goods.`
    },
  },
  {
    slug: "atlas-kernel-pipeline",
    title: { es: "Pipeline Atlas — Ingest → Classify → Publish", en: "Atlas Pipeline — Ingest → Classify → Publish" },
    category: "operacion",
    excerpt: { es: "Discover → extract → normalize → classify → redact → relate → validate → publish.", en: "Discover → extract → normalize → classify → redact → relate → validate → publish." },
    tags: ["pipeline", "ingest", "atlas"],
    updated: "2026-03-15",
    body: {
      es: `El kernel Atlas (\`tamv-core-atlas\`) ejecuta el pipeline canónico:

1. **discover.ts** — descubrimiento de repos/fuentes
2. **fetch.ts / http.ts** — fetch hardenizado con rate-limit GitHub
3. **extract.ts** — extracción de señales/metadata
4. **normalize.ts** — normalización canónica
5. **classify.ts** — clasificación semántica federada
6. **redact.ts** — secret stripping
7. **relate.ts** — construcción de relaciones del grafo
8. **schemas.ts** — validación Zod
9. **publish.ts** — escribe atlas/index.json, graph.json, taxonomy.json

Salidas \`.next.json\` validadas antes de \`mv\` atómico. Si falla → no toca \`atlas/*.json\`, marca error en Supabase \`atlas_ingest_errors\`.`,
      en: `Atlas pipeline: discover → fetch → extract → normalize → classify → redact → relate → validate → publish, with atomic .next.json staging.`
    },
  },
];

export function getWiki(slug: string) {
  return WIKIS.find((w) => w.slug === slug);
}
export function listWikis(category?: string) {
  return category ? WIKIS.filter((w) => w.category === category) : WIKIS;
}
