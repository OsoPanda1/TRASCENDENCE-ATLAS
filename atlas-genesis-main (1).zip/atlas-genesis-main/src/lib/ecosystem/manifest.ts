import { buildManifest } from "../atlasKernel";
import type { ManifestSnapshot } from "../types";

let CACHE: ManifestSnapshot | null = null;

export function getCurrentManifest(): ManifestSnapshot {
  if (!CACHE) CACHE = buildManifest();
  return CACHE;
}

export function refreshManifest(): ManifestSnapshot {
  CACHE = buildManifest();
  return CACHE;
}

export function compareManifests(a: ManifestSnapshot, b: ManifestSnapshot) {
  const diff: Record<string, { a: unknown; b: unknown }> = {};
  for (const k of Object.keys(a) as (keyof ManifestSnapshot)[]) {
    if (JSON.stringify(a[k]) !== JSON.stringify(b[k])) diff[k] = { a: a[k], b: b[k] };
  }
  return { equal: Object.keys(diff).length === 0, diff };
}
