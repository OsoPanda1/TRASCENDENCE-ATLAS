// Contratos del ecosistema TAMV — schemas Zod canónicos.
import { z } from "zod";

export const EntitySchema = z.object({
  id: z.string(),
  type: z.enum(["PERSON","ORGANIZATION","TERRITORY","SYSTEM","SERVICE","DOCUMENT","POLICY","REPO","DATASET","EVENT"]),
  label: z.string(),
  fed: z.string().optional(),
  meta: z.record(z.string(), z.unknown()).optional(),
});

export const RelationSchema = z.object({
  id: z.string(),
  type: z.enum(["BELONGS_TO","CONTAINS","DEPENDS_ON","AFFECTS","BACKED_BY","EXECUTES","MONETIZES","PRESERVES","FEDERATES"]),
  from: z.string(),
  to: z.string(),
  weight: z.number().optional(),
});

export const EventSchema = z.object({
  id: z.string(),
  type: z.enum(["OBSERVATION","DECISION","INCIDENT","STATE_TRANSITION","POLICY_CHANGE","RECONCILIATION","INGEST","PUBLISH","AUDIT"]),
  entity: z.string().optional(),
  fed: z.string().optional(),
  ts: z.string(),
  payload: z.unknown().optional(),
});

export const ManifestSchema = z.object({
  version: z.string(),
  api_version: z.string(),
  generated_at: z.string(),
  federations: z.array(z.string()),
  entities: z.number(),
  relations: z.number(),
  events_24h: z.number(),
  integrity: z.number(),
  signature: z.string().optional(),
});

export const IngestPayloadSchema = z.object({
  source: z.string().min(1),
  kind: z.enum(["repo","dataset","document","event"]),
  payload: z.record(z.string(), z.unknown()),
  signature: z.string().optional(),
});

export type IngestPayload = z.infer<typeof IngestPayloadSchema>;
