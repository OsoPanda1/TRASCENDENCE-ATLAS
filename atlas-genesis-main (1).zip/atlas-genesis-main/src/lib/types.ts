// ATLAS · TAMV — tipos compartidos
export type Lang = "es" | "en";
export type Bi = Record<Lang, string>;

export type EntityType = "PERSON" | "ORGANIZATION" | "TERRITORY" | "SYSTEM" | "SERVICE" | "DOCUMENT" | "POLICY" | "REPO" | "DATASET" | "EVENT";
export type RelationType = "BELONGS_TO" | "CONTAINS" | "DEPENDS_ON" | "AFFECTS" | "BACKED_BY" | "EXECUTES" | "MONETIZES" | "PRESERVES" | "FEDERATES";
export type EventType = "OBSERVATION" | "DECISION" | "INCIDENT" | "STATE_TRANSITION" | "POLICY_CHANGE" | "RECONCILIATION" | "INGEST" | "PUBLISH" | "AUDIT";

export interface Entity { id: string; type: EntityType; label: string; fed?: string; meta?: Record<string, unknown>; }
export interface Relation { id: string; type: RelationType; from: string; to: string; weight?: number; }
export interface KernelEvent { id: string; type: EventType; entity?: string; fed?: string; ts: string; payload?: unknown; }

export interface ManifestSnapshot {
  version: string;
  api_version: string;
  generated_at: string;
  federations: string[];
  entities: number;
  relations: number;
  events_24h: number;
  integrity: number;
  signature?: string;
}

export interface RepoMeta {
  id: string;
  name: string;
  url: string;
  language?: string | null;
  stars: number;
  forks: number;
  topics: string[];
  fed?: string;
  updated_at: string;
}

export interface IsabellaDecision {
  trace_id: string;
  action: "respond" | "redirect" | "block" | "freeze";
  confidence: number;
  explanation: string;
  filters: { level: number; passed: boolean; reason?: string }[];
  ts: string;
}
