import type { Territory } from "./sot-contracts";

// Source of Truth de territorios federados TAMV.
export const TERRITORIES: Territory[] = [
  { id: "mx-hgo-real-monte", name: "Mineral del Monte, Hidalgo", iso2: "MX", lat: 20.3833, lon: -98.85, sovereignty: "federated", jurisdiction: "México · Hidalgo" },
  { id: "mx-cdmx", name: "Ciudad de México", iso2: "MX", lat: 19.4326, lon: -99.1332, sovereignty: "subnational" },
  { id: "mx-jal-gdl", name: "Guadalajara, Jalisco", iso2: "MX", lat: 20.6597, lon: -103.3496, sovereignty: "subnational" },
  { id: "mx-mor-cuer", name: "Cuernavaca, Morelos", iso2: "MX", lat: 18.9242, lon: -99.2216, sovereignty: "subnational" },
  { id: "ar-baires", name: "Buenos Aires", iso2: "AR", lat: -34.6037, lon: -58.3816, sovereignty: "national" },
  { id: "co-bogota", name: "Bogotá", iso2: "CO", lat: 4.7110, lon: -74.0721, sovereignty: "national" },
  { id: "cl-stgo", name: "Santiago", iso2: "CL", lat: -33.4489, lon: -70.6693, sovereignty: "national" },
];
