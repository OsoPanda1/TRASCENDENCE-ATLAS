import { z } from "zod";

export const TerritorySchema = z.object({
  id: z.string(),
  name: z.string(),
  iso2: z.string().length(2),
  lat: z.number(),
  lon: z.number(),
  population: z.number().optional(),
  sovereignty: z.enum(["national","subnational","autonomous","federated"]).default("federated"),
  jurisdiction: z.string().optional(),
});

export type Territory = z.infer<typeof TerritorySchema>;
