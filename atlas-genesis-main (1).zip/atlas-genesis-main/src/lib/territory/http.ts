import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { TERRITORIES } from "./sot-store";

export const listTerritories = createServerFn({ method: "GET" }).handler(async () => ({
  ok: true, territories: TERRITORIES, count: TERRITORIES.length,
}));

export const getTerritory = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ id: z.string() }).parse(d))
  .handler(async ({ data }) => {
    const t = TERRITORIES.find((x) => x.id === data.id);
    return { ok: !!t, territory: t ?? null };
  });
