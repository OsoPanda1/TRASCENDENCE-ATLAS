import { createFileRoute } from "@tanstack/react-router";
import { ConvergenceHub } from "@/components/atlas/ConvergenceHub";
import { ArchitectureMiniMap } from "@/components/atlas/ArchitectureMiniMap";
import { FlowLens } from "@/components/atlas/FlowLens";

export const Route = createFileRoute("/csp/")({ component: CSPIndex });

function CSPIndex() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-10 grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2"><ConvergenceHub /></div>
      <div className="space-y-3">
        <ArchitectureMiniMap />
        <div className="glass rounded-sm p-4 space-y-2">
          <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">Sub-planes</div>
          <FlowLens label="Canon" value={92} color="var(--glow)" />
          <FlowLens label="Assembly" value={78} color="var(--plasma)" />
          <FlowLens label="Ingestion" value={86} color="var(--aurora)" />
          <FlowLens label="Ontology" value={94} color="var(--gold)" />
        </div>
      </div>
    </section>
  );
}
