import { createFileRoute } from "@tanstack/react-router";
import { kernelEvents } from "@/kernel/kernel-core";

export const Route = createFileRoute("/api/github/events/stream")({
  server: { handlers: { GET: async () => {
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      start(controller) {
        const send = () => {
          const data = kernelEvents(10);
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
        };
        send();
        const id = setInterval(send, 4000);
        // Auto-close after 30 s in worker context
        setTimeout(() => { clearInterval(id); controller.close(); }, 30000);
      },
    });
    return new Response(stream, { headers: { "content-type": "text/event-stream", "cache-control": "no-cache" } });
  }}},
});
