import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { getAtlasGraph, getEoctStream, getFederationManifest } from "@/lib/atlas-graph.functions";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type Node = { id: string; label: string; type: string; federation: string; visual: { color: string; size: number } };
type Edge = { id: string; source: string; target: string; type: string; visual: { width: number } };

export const Route = createFileRoute("/graph")({
  head: () => ({
    meta: [
      { title: "Atlas Kernel · Grafo Civilizatorio Heptafederado" },
      { name: "description", content: "Motor de grafo en vivo de ATLAS TRASCENDENCE — entidades, relaciones y eventos EOCT desde Lovable Cloud." },
    ],
  }),
  component: GraphView,
});

const FEDS = ["knowledge","identity","governance","economy","security","infrastructure","ai"] as const;

function GraphView() {
  const [graph, setGraph] = useState<{ nodes: Node[]; edges: Edge[] } | null>(null);
  const [manifest, setManifest] = useState<any>(null);
  const [events, setEvents] = useState<any[]>([]);
  const [filter, setFilter] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  async function refresh(f?: string) {
    setLoading(true);
    const [g, m, e] = await Promise.all([
      getAtlasGraph({ data: { federation: f, limit: 500 } }),
      getFederationManifest(),
      getEoctStream({ data: { limit: 30 } }),
    ]);
    setGraph({ nodes: g.nodes as any, edges: g.edges as any });
    setManifest(m);
    setEvents(e.events);
    setLoading(false);
  }

  useEffect(() => { void refresh(filter); }, [filter]);

  // Force-directed layout (lightweight)
  const positions = useMemo(() => {
    if (!graph) return new Map<string, { x: number; y: number }>();
    const pos = new Map<string, { x: number; y: number }>();
    const N = graph.nodes.length || 1;
    graph.nodes.forEach((n, i) => {
      const a = (i / N) * Math.PI * 2;
      const r = 240 + (i % 5) * 30;
      pos.set(n.id, { x: 400 + Math.cos(a) * r, y: 300 + Math.sin(a) * r });
    });
    return pos;
  }, [graph]);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c || !graph) return;
    const ctx = c.getContext("2d")!;
    const dpr = window.devicePixelRatio || 1;
    c.width = 800 * dpr; c.height = 600 * dpr;
    c.style.width = "100%"; c.style.height = "600px";
    ctx.scale(dpr, dpr);
    ctx.fillStyle = "#020617";
    ctx.fillRect(0, 0, 800, 600);
    // edges
    ctx.strokeStyle = "rgba(125,211,252,0.18)";
    graph.edges.forEach((e) => {
      const a = positions.get(e.source); const b = positions.get(e.target);
      if (!a || !b) return;
      ctx.lineWidth = e.visual.width;
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    });
    // nodes
    graph.nodes.forEach((n) => {
      const p = positions.get(n.id); if (!p) return;
      ctx.fillStyle = n.visual.color;
      ctx.shadowColor = n.visual.color; ctx.shadowBlur = 14;
      ctx.beginPath(); ctx.arc(p.x, p.y, n.visual.size, 0, Math.PI * 2); ctx.fill();
      ctx.shadowBlur = 0;
      ctx.fillStyle = "#E2E8F0"; ctx.font = "10px ui-sans-serif";
      ctx.fillText(n.label.slice(0, 22), p.x + 10, p.y + 3);
    });
  }, [graph, positions]);

  return (
    <div className="container mx-auto py-10 space-y-6">
      <header className="space-y-2">
        <Badge variant="outline" className="border-cyan-400/40 text-cyan-300">ATLAS KERNEL · GRAPH ENGINE</Badge>
        <h1 className="text-4xl font-light tracking-tight">Grafo civilizatorio heptafederado</h1>
        <p className="text-muted-foreground max-w-3xl">
          Motor de grafo operativo (no solo informativo): cada nodo es una entidad real del metasistema, cada arista una relación semántica.
          Datos en vivo desde Lovable Cloud (Atlas Kernel + EOCT). Orgullosamente Realmontenses.
        </p>
      </header>

      {manifest && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {[
            ["Entities", manifest.entities],
            ["Relations", manifest.relations],
            ["Documents", manifest.documents],
            ["EOCT events", manifest.events],
            ["Integrity", manifest.integrity + "%"],
          ].map(([k, v]) => (
            <Card key={k as string} className="p-4 bg-slate-900/40 border-slate-800">
              <div className="text-xs uppercase text-slate-400">{k}</div>
              <div className="text-2xl font-light text-cyan-200">{String(v)}</div>
            </Card>
          ))}
        </div>
      )}

      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant={!filter ? "default" : "outline"} onClick={() => setFilter(undefined)}>Todas las federaciones</Button>
        {FEDS.map((f) => (
          <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} onClick={() => setFilter(f)}>{f}</Button>
        ))}
        <Button size="sm" variant="secondary" onClick={() => refresh(filter)} disabled={loading}>{loading ? "Sincronizando…" : "↻ Refrescar"}</Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-2 bg-slate-950 border-cyan-900/40 overflow-hidden">
          <canvas ref={canvasRef} />
        </Card>
        <Card className="p-4 bg-slate-900/40 border-slate-800 max-h-[600px] overflow-auto">
          <h3 className="text-sm uppercase text-cyan-300 mb-3">EOCT — Stream</h3>
          <ol className="space-y-2 text-xs">
            {events.map((e) => (
              <li key={e.id} className="border-l-2 border-cyan-700/40 pl-2">
                <div className="text-cyan-200">{e.event_type} <span className="text-slate-500">· {e.severity}</span></div>
                <div className="text-slate-400">{e.source_federation ?? "—"} → {e.target_federation ?? "—"}</div>
                <div className="text-slate-600">{new Date(e.ts).toLocaleString()}</div>
              </li>
            ))}
            {events.length === 0 && <li className="text-slate-500">Sin eventos. Emite uno desde /console o vía API.</li>}
          </ol>
        </Card>
      </div>
    </div>
  );
}
