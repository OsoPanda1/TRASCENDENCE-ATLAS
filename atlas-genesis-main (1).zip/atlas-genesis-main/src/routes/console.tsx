import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { useKernelStatus, useKernelEvents, useIsabellaMetrics, useOpenScienceStatus, useManifestSnapshot } from "@/hooks/use-atlas";
import { ExecutionCenterBoard } from "@/components/control/ExecutionCenterBoard";

export const Route = createFileRoute("/console")({
  head: () => ({ meta: [{ title: "Console — ATLAS TRASCENDENCE" }] }),
  component: Console,
});

function Console() {
  const status = useKernelStatus();
  const events = useKernelEvents(20);
  const isa = useIsabellaMetrics();
  const sci = useOpenScienceStatus();
  const man = useManifestSnapshot();

  const Card = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="glass rounded-sm p-5">
      <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-2">{title}</div>
      {children}
    </div>
  );

  return (
    <Shell>
      <section className="border-b border-border">
        <div className="mx-auto max-w-7xl px-6 py-10">
          <div className="chip mb-3">CONSOLE · OBSERVABILIDAD</div>
          <h1 className="font-display text-5xl">Consola operativa</h1>
          <p className="text-muted-foreground mt-2">Estado en vivo del Kernel MD-X4, Isabella ACCS, manifest civilizatorio y conectores Open Science.</p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-10 grid lg:grid-cols-3 gap-6">
        <Card title="Kernel status">
          <pre className="text-[10px] font-mono text-aurora overflow-x-auto">{JSON.stringify(status.data, null, 2)}</pre>
        </Card>
        <Card title="Isabella metrics">
          <pre className="text-[10px] font-mono text-aurora overflow-x-auto">{JSON.stringify(isa.data, null, 2)}</pre>
        </Card>
        <Card title="Manifest">
          <pre className="text-[10px] font-mono text-aurora overflow-x-auto">{JSON.stringify(man.data, null, 2)}</pre>
        </Card>
        <Card title="Open Science (live)">
          <pre className="text-[10px] font-mono text-aurora overflow-x-auto">{JSON.stringify(sci.data, null, 2)}</pre>
        </Card>
        <div className="lg:col-span-2"><ExecutionCenterBoard /></div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-14">
        <Card title="EOCT — últimos eventos">
          <div className="space-y-px text-[11px]">
            {(events.data as any)?.events?.map((e: any) => (
              <div key={e.id} className="grid grid-cols-12 gap-2 py-1.5 border-b border-border/40 last:border-0">
                <span className="col-span-3 mono text-primary">{e.id}</span>
                <span className="col-span-3 mono text-muted-foreground">{e.type}</span>
                <span className="col-span-3 mono text-foreground/80">{e.fed ?? "—"}</span>
                <span className="col-span-3 mono text-[10px] text-muted-foreground/60 text-right">{e.ts}</span>
              </div>
            )) ?? <span className="text-muted-foreground mono text-[10px]">cargando…</span>}
          </div>
        </Card>
      </section>
    </Shell>
  );
}
