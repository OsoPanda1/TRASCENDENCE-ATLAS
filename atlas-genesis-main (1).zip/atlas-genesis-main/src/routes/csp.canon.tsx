import { createFileRoute } from "@tanstack/react-router";
export const Route = createFileRoute("/csp/canon")({ component: Canon });
function Canon() {
  return (
    <section className="mx-auto max-w-5xl px-6 py-10 space-y-6">
      <h2 className="font-display text-3xl text-primary">Canon TAMV — bloque fundacional inmutable</h2>
      <p className="text-muted-foreground">DOI <span className="mono text-aurora">10.5281/zenodo.19436662</span> · ORCID <span className="mono text-aurora">0009-0008-5050-1539</span> · Versión <span className="mono text-aurora">1.0.0-v4.0</span>.</p>
      <div className="grid md:grid-cols-2 gap-4">
        {[
          ["I", "Configuración registral, autoría inmutable, blindaje legal internacional"],
          ["II", "Manifiesto fundacional, soberanía Web 4.0"],
          ["III", "Gobernanza heptafederada (7 células)"],
          ["IV", "Especificaciones técnicas Kernel MD-X4"],
          ["V", "Matriz económica de justicia estructural"],
          ["VI", "Defender Suite — ANUBIS Sentinel™ PQC"],
          ["VII", "Manual operativo, protocolo de crisis, endpoints"],
          ["VIII", "Glosario enciclopédico institucional"],
        ].map(([n, t]) => (
          <div key={n} className="glass rounded-sm p-4">
            <div className="mono text-[10px] tracking-[0.22em] text-primary">SECCIÓN {n}</div>
            <div className="font-display text-lg mt-1">{t}</div>
          </div>
        ))}
      </div>
    </section>
  );
}
