import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ingestServer } from "@/lib/atlas-pipeline.functions";

export const Route = createFileRoute("/csp/ingestion")({ component: Ingestion });

function Ingestion() {
  const [out, setOut] = useState<unknown>(null);
  const [src, setSrc] = useState("github.com/OsoPanda1");
  const [kind, setKind] = useState<"repo"|"dataset"|"document"|"event">("repo");
  const submit = async () => {
    const r = await ingestServer({ data: { source: src, kind, payload: { triggered: "manual", at: new Date().toISOString() } } });
    setOut(r);
  };
  return (
    <section className="mx-auto max-w-5xl px-6 py-10 space-y-6">
      <h2 className="font-display text-3xl text-primary">Ingestion — pipeline canónico</h2>
      <ol className="list-decimal list-inside text-sm text-muted-foreground space-y-1">
        <li><span className="text-foreground">discover</span> · descubrimiento de repos/fuentes</li>
        <li><span className="text-foreground">fetch</span> · cliente HTTP hardenizado, rate-limit GitHub</li>
        <li><span className="text-foreground">extract</span> · señales y metadata</li>
        <li><span className="text-foreground">normalize</span> · canonización</li>
        <li><span className="text-foreground">classify</span> · clasificación semántica federada</li>
        <li><span className="text-foreground">redact</span> · secret stripping</li>
        <li><span className="text-foreground">relate</span> · grafo</li>
        <li><span className="text-foreground">schemas</span> · validación Zod</li>
        <li><span className="text-foreground">publish</span> · escritura atómica</li>
      </ol>
      <div className="glass rounded-sm p-5">
        <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-3">Manual ingest</div>
        <div className="flex flex-wrap gap-3">
          <input value={src} onChange={(e) => setSrc(e.target.value)} className="hairline rounded-sm bg-transparent px-3 py-2 mono text-xs flex-1 min-w-[240px]" />
          <select value={kind} onChange={(e) => setKind(e.target.value as never)} className="hairline rounded-sm bg-transparent px-3 py-2 mono text-xs">
            <option value="repo">repo</option><option value="dataset">dataset</option><option value="document">document</option><option value="event">event</option>
          </select>
          <button onClick={submit} className="mono text-[10px] tracking-[0.22em] bg-primary/20 border border-primary/60 text-primary px-4 py-2 rounded-sm">EJECUTAR</button>
        </div>
        {out !== null && <pre className="mt-3 text-[10px] font-mono text-aurora overflow-x-auto">{JSON.stringify(out, null, 2)}</pre>}
      </div>
    </section>
  );
}
