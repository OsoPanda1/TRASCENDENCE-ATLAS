import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { useI18n } from "@/lib/i18n";
import { AXIOMS } from "@/lib/federations";

export const Route = createFileRoute("/doctrine")({
  head: () => ({
    meta: [
      { title: "Doctrina — ATLAS TRASCENDENCE" },
      { name: "description", content: "Axiomas no negociables del metasistema civilizatorio heptafederado." },
    ],
  }),
  component: DoctrinePage,
});

const PRINCIPLES = [
  { es: "Desacoplamiento estructural", en: "Structural decoupling", desc: { es: "Ningún componente compromete la estabilidad del sistema completo.", en: "No component compromises the stability of the whole system." } },
  { es: "Soberanía digital", en: "Digital sovereignty", desc: { es: "El control de datos, identidad y operación pertenece al ecosistema.", en: "Control of data, identity and operation belongs to the ecosystem." } },
  { es: "Trazabilidad total", en: "Total traceability", desc: { es: "Todo evento, decisión y transformación es auditable.", en: "Every event, decision and transformation is auditable." } },
  { es: "Memoria persistente", en: "Persistent memory", desc: { es: "El conocimiento no se pierde; se estructura, se preserva y evoluciona.", en: "Knowledge is not lost; it is structured, preserved and evolved." } },
  { es: "IA bajo control", en: "AI under control", desc: { es: "La inteligencia artificial asiste, pero no gobierna sin supervisión.", en: "AI assists, but does not govern without oversight." } },
  { es: "Seguridad transversal", en: "Cross-cutting security", desc: { es: "Todo es observado, verificado y defendido en tiempo real.", en: "Everything is observed, verified and defended in real time." } },
];

function DoctrinePage() {
  const { lang } = useI18n();
  return (
    <Shell>
      <section className="border-b border-border py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="chip mb-6">{lang === "es" ? "Doctrina central" : "Central doctrine"}</div>
          <h1 className="font-display text-5xl md:text-7xl leading-[0.95] max-w-4xl">
            {lang === "es" ? "Principios " : "Non-negotiable "}<span className="text-primary text-glow">{lang === "es" ? "no negociables." : "principles."}</span>
          </h1>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-7xl px-6 grid grid-cols-1 md:grid-cols-2 gap-px hairline rounded-sm overflow-hidden">
          {PRINCIPLES.map((p, i) => (
            <div key={p.en} className="bg-card/50 p-8">
              <div className="mono text-[10px] tracking-[0.22em] text-primary mb-3">P-{String(i + 1).padStart(2, "0")}</div>
              <h3 className="font-display text-3xl mb-3">{lang === "es" ? p.es : p.en}</h3>
              <p className="text-muted-foreground">{p.desc[lang]}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-20 border-t border-border">
        <div className="mx-auto max-w-7xl px-6">
          <div className="chip mb-4">{lang === "es" ? "Axiomas" : "Axioms"}</div>
          <h2 className="font-display text-4xl md:text-5xl mb-2">{lang === "es" ? "Diez verdades estructurales" : "Ten structural truths"}</h2>
          <p className="text-muted-foreground mb-10 max-w-2xl">
            {lang === "es" ? "Sobre estos axiomas se montan las 7 federaciones y todos los protocolos." : "Upon these axioms the 7 federations and all protocols are mounted."}
          </p>
          <div className="space-y-px">
            {AXIOMS.map((a) => (
              <div key={a.code} className="grid grid-cols-12 gap-4 py-5 border-b border-border items-baseline">
                <div className="col-span-2 md:col-span-1 mono text-[11px] tracking-[0.2em] text-primary">{a.code}</div>
                <div className="col-span-10 md:col-span-11 font-display text-2xl md:text-3xl">{a[lang]}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Shell>
  );
}
