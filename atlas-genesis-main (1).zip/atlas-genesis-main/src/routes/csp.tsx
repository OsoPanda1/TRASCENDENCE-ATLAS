import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";

export const Route = createFileRoute("/csp")({
  head: () => ({ meta: [{ title: "CSP — Canon · Assembly · Ingestion · Ontology" }] }),
  component: CSPLayout,
});

function CSPLayout() {
  const tabs = [
    { to: "/csp", label: "Overview" },
    { to: "/csp/canon", label: "Canon" },
    { to: "/csp/assembly", label: "Assembly" },
    { to: "/csp/ingestion", label: "Ingestion" },
    { to: "/csp/ontology", label: "Ontology" },
  ];
  return (
    <Shell>
      <section className="border-b border-border">
        <div className="mx-auto max-w-7xl px-6 py-10">
          <div className="chip mb-3">CSP — CIVILIZATIONAL SERVICE PLANE</div>
          <h1 className="font-display text-5xl">Canon · Assembly · Ingestion · Ontology</h1>
        </div>
        <nav className="mx-auto max-w-7xl px-6 pb-4 flex gap-4">
          {tabs.map((t) => (
            <Link key={t.to} to={t.to} className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground hover:text-foreground"
              activeOptions={{ exact: true }} activeProps={{ className: "mono text-[10px] tracking-[0.22em] uppercase text-primary text-glow" }}>{t.label}</Link>
          ))}
        </nav>
      </section>
      <Outlet />
    </Shell>
  );
}
