import { createFileRoute } from "@tanstack/react-router";
import { kernelRecord } from "@/kernel/kernel-core";

export const Route = createFileRoute("/api/github/webhook")({
  server: { handlers: { POST: async ({ request }) => {
    const body = await request.text();
    let payload: Record<string, unknown> = {};
    try { payload = JSON.parse(body); } catch {}
    const event = request.headers.get("x-github-event") ?? "unknown";
    kernelRecord({ type: "INGEST", fed: "infrastructure", payload: { source: "github.webhook", event, repo: (payload as any)?.repository?.full_name } });
    return Response.json({ ok: true, event });
  }}},
});
