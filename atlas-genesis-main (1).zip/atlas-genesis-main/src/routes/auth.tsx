import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "Auth — ATLAS TRASCENDENCE" }] }),
  component: AuthPage,
});

function AuthPage() {
  return (
    <Shell>
      <section className="mx-auto max-w-md px-6 py-20">
        <div className="chip mb-4">F-02 · IDENTIDAD</div>
        <h1 className="font-display text-4xl">Acceso TAMV</h1>
        <p className="text-sm text-muted-foreground mt-2">El subsistema de identidad federada (DID + VC + ID-NVIDA™) aún no está activado en esta instancia. Para habilitar persistencia, sesiones y roles se debe encender <span className="text-primary">Lovable Cloud</span> y configurar el broker de autenticación.</p>
        <div className="glass rounded-sm p-5 mt-6 space-y-3">
          <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">Estado del subsistema</div>
          <div className="flex items-center justify-between text-xs"><span>DID resolver</span><span className="mono text-aurora">stand-by</span></div>
          <div className="flex items-center justify-between text-xs"><span>OIDC broker</span><span className="mono text-aurora">stand-by</span></div>
          <div className="flex items-center justify-between text-xs"><span>ANUBIS handshake</span><span className="mono text-aurora">ready</span></div>
          <div className="flex items-center justify-between text-xs"><span>Cloud backend</span><span className="mono text-destructive">disabled</span></div>
        </div>
        <Link to="/console" className="mt-6 inline-block mono text-[10px] tracking-[0.22em] text-primary hover:text-glow">→ IR A CONSOLA</Link>
      </section>
    </Shell>
  );
}
