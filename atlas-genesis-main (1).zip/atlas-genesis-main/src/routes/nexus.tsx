import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { Starfield } from "@/components/Starfield";
import { NexusGraph } from "@/components/nexus/NexusGraph";
import { IntegrationsPanel } from "@/components/atlas/IntegrationsPanel";
import { CivilizationStream } from "@/components/atlas/CivilizationStream";
import { ATLAS_ENTITIES, ATLAS_RELATIONS } from "@/lib/atlasKernel";
import { MetricCounter } from "@/components/atlas/MetricCounter";

export const Route = createFileRoute("/nexus")({
  head: () => ({ meta: [
    { title: "NEXUS — ATLAS TRASCENDENCE" },
    { name: "description", content: "El Nexus civilizatorio: grafo en vivo de entidades, relaciones y federaciones TAMV." },
  ]}),
  component: NexusPage,
});

function NexusPage() {
  return (
    <Shell>
      <section className="relative border-b border-border overflow-hidden">
        <Starfield count={70} />
        <div className="relative mx-auto max-w-7xl px-6 py-14">
          <div className="chip mb-4">CAPA 2 · CONVERGENCIA</div>
          <h1 className="font-display text-6xl">NEXUS</h1>
          <p className="text-muted-foreground mt-3 max-w-2xl">Punto de convergencia de las 7 federaciones, los nodos atómicos del grafo y las integraciones externas. Aquí el sistema se ve a sí mismo.</p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12 grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2"><NexusGraph height={520} /></div>
        <div className="space-y-3">
          <MetricCounter value={ATLAS_ENTITIES.length} label="Entidades" color="var(--glow)" />
          <MetricCounter value={ATLAS_RELATIONS.length} label="Relaciones" color="var(--plasma)" />
          <MetricCounter value={7} label="Federaciones" color="var(--aurora)" />
          <MetricCounter value={100} label="Integridad" unit="%" color="var(--gold)" />
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-16 grid lg:grid-cols-2 gap-6">
        <CivilizationStream limit={10} />
        <IntegrationsPanel />
      </section>
    </Shell>
  );
}
