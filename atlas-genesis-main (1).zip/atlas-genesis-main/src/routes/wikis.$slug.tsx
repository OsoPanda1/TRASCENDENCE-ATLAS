import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { getWiki, type WikiArticle } from "@/lib/wikis";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/wikis/$slug")({
  loader: ({ params }) => {
    const a: WikiArticle | undefined = getWiki(params.slug);
    if (!a) throw notFound();
    return { a };
  },
  head: ({ loaderData }) => ({ meta: [
    { title: `${loaderData?.a.title.es ?? "Wiki"} — ATLAS TRASCENDENCE` },
    { name: "description", content: loaderData?.a.excerpt.es ?? "" },
    { property: "og:title", content: loaderData?.a.title.es ?? "" },
    { property: "og:description", content: loaderData?.a.excerpt.es ?? "" },
  ]}),
  component: WikiArticleView,
});

function renderMarkdown(md: string) {
  const lines = md.split("\n");
  const blocks: React.ReactNode[] = [];
  let i = 0;
  while (i < lines.length) {
    const l = lines[i];
    if (l.startsWith("## ")) { blocks.push(<h2 key={i} className="font-display text-2xl mt-8 mb-3 text-primary">{l.slice(3)}</h2>); i++; continue; }
    if (l.startsWith("# ")) { blocks.push(<h1 key={i} className="font-display text-3xl mt-8 mb-3">{l.slice(2)}</h1>); i++; continue; }
    if (l.startsWith("|")) {
      const tbl: string[] = [];
      while (i < lines.length && lines[i].startsWith("|")) { tbl.push(lines[i]); i++; }
      const rows = tbl.filter((r) => !/^\|\s*-+/.test(r)).map((r) => r.split("|").slice(1, -1).map((c) => c.trim()));
      blocks.push(
        <div key={"t"+i} className="my-4 overflow-x-auto"><table className="text-xs w-full hairline">
          <tbody>{rows.map((r, ri) => (
            <tr key={ri} className="border-b border-border">
              {r.map((c, ci) => <td key={ci} className={`p-2 ${ri === 0 ? "mono text-[10px] tracking-[0.18em] text-primary uppercase" : ""}`}>{c}</td>)}
            </tr>
          ))}</tbody>
        </table></div>
      );
      continue;
    }
    if (l.startsWith("- ")) {
      const items: string[] = [];
      while (i < lines.length && lines[i].startsWith("- ")) { items.push(lines[i].slice(2)); i++; }
      blocks.push(<ul key={"u"+i} className="list-disc list-inside space-y-1 my-3 text-sm">{items.map((it, k) => <li key={k}>{it}</li>)}</ul>);
      continue;
    }
    if (l.trim() === "") { blocks.push(<div key={"sp"+i} className="h-2" />); i++; continue; }
    blocks.push(<p key={"p"+i} className="text-sm leading-relaxed my-2" dangerouslySetInnerHTML={{
      __html: l.replace(/\*\*(.+?)\*\*/g, "<strong class='text-foreground'>$1</strong>").replace(/`(.+?)`/g, "<code class='mono text-[11px] text-aurora'>$1</code>")
    }} />);
    i++;
  }
  return blocks;
}

function WikiArticleView() {
  const { a } = Route.useLoaderData() as { a: WikiArticle };
  const { lang } = useI18n();
  return (
    <Shell>
      <article className="mx-auto max-w-3xl px-6 py-12">
        <Link to="/wikis" className="mono text-[10px] tracking-[0.2em] text-muted-foreground hover:text-primary">← WIKIS</Link>
        <div className="chip mt-4">{a.category}</div>
        <h1 className="font-display text-5xl mt-3">{a.title[lang]}</h1>
        <p className="text-muted-foreground mt-3">{a.excerpt[lang]}</p>
        {a.authors && (
          <div className="mono text-[10px] tracking-[0.2em] text-muted-foreground mt-4">
            {a.authors.join(" · ")} — {a.updated}
          </div>
        )}
        <div className="mt-8 prose-cosmic">{renderMarkdown(a.body[lang])}</div>
      </article>
    </Shell>
  );
}
