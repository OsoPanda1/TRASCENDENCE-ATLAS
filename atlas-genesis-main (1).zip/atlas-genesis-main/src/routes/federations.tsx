import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/federations")({
  component: () => <Outlet />,
});
