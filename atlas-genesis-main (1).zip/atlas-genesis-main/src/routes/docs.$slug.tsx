import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { TAMV_API_SPEC } from "@/lib/tamvUnifiedApi";

const DOCS: Record<string, { title: string; body: string }> = {
  architecture: { title: "ARCHITECTURE.md", body: `# TAMV Monorepo Architecture

## Sub-raíces
- **tamv-core-atlas** — kernel Atlas: pipeline de ingestión (discover/fetch/extract/normalize/classify/redact/relate/publish), threat-model.md, schemas Zod.
- **tamv-digital-nexus** — runtime nextgen (apps/web, sistemas Anubis/Dekateotl/Horus, capa constitucional, Supabase functions).
- **tamv-the-federated-frontier** — frontend público + backend tamv-atlas-core (FastAPI).

## Gates de coherencia
- atlas/index.json + graph.json + taxonomy.json escritos atómicamente (\`.next.json\` → validar → mv).
- Si validación falla → no se tocan archivos canónicos, se marca \`atlas_ingest_errors\` en Supabase.
- system_metadata.api_version controla compatibilidad entre kernel y Kodex.` },
  deployment: { title: "DEPLOYMENT.md", body: `# DEPLOYMENT
- **Runtime SSR:** Cloudflare Worker via TanStack Start.
- **Almacenamiento estado:** Lovable Cloud (Supabase managed).
- **CI/CD:** GitHub Actions con constitutional-gate.yml + ingest.yml.
- **Edge mesh:** 15 nodos simultáneos en MX (Q4 2026).
- **Bundling:** Vite 7 + nodejs_compat (sin packages Node-only).` },
  contributing: { title: "CONTRIBUTING.md", body: `# CONTRIBUTING
Antes de cualquier cambio:
1. Leer ARCHITECTURE.md.
2. Si tocas el kernel Atlas, sólo \`git add tamv-core-atlas/atlas/\`.
3. Si tocas migraciones supabase → usar branch + lint + tests RLS.
4. Versionar contratos en \`packages/contracts/\` (OpenAPI / JSON schema).
5. Auditoría \`tools/audit/trails/*\` lee \`api_version\` + \`atlas.version\`.` },
  api: { title: "TAMV MD-X5 OpenAPI", body: `# REST endpoints (resumen)
${TAMV_API_SPEC.rest.map((r) => `- \`${r.method} ${r.path}\` — ${r.summary}`).join("\n")}

# GraphQL types
${TAMV_API_SPEC.graphql.map((g) => `\`\`\`graphql\n${g}\n\`\`\``).join("\n\n")}

# WebSocket channels
${TAMV_API_SPEC.ws.map((w) => `- **${w.channel}** — ${w.desc}`).join("\n")}` },
  "isabella-protocol": { title: "Isabella Protocol", body: `# Isabella ACCS — Triple Bloqueo
1. **Ontológico** — no contiene datasets sexuales/eróticos.
2. **Semántico** — input con intención sexual se redirige + registra como riesgo.
3. **Conductual** — nunca describe cuerpo con intención sexual, nunca coquetea.

# 4 Mega Módulos
- ICIL — Identidad, Ética, Blindaje Absoluto.
- IEIS — Cuerpo Digital Humanoide (interfaz).
- ICFS — Cognitivo (tf.audio/autograph/linalg/signal/image/data).
- IGCF — Gobernanza (EU AI Act, GDPR, NIST AI RMF, ISO 27001/23894).

# Hard Stop
\`POST /v1/isabella/freeze\` congela cognición; \`POST /v1/isabella/resume\` requiere auditoría.` },
};

export const Route = createFileRoute("/docs/$slug")({
  loader: ({ params }) => {
    const d = DOCS[params.slug];
    if (!d) throw notFound();
    return { d };
  },
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.d.title ?? "Doc"} — ATLAS TRASCENDENCE` }] }),
  component: DocView,
});

function DocView() {
  const { d } = Route.useLoaderData() as { d: { title: string; body: string } };
  return (
    <Shell>
      <article className="mx-auto max-w-3xl px-6 py-12">
        <Link to="/docs" className="mono text-[10px] tracking-[0.2em] text-muted-foreground hover:text-primary">← DOCS</Link>
        <h1 className="font-display text-4xl mt-4 text-primary">{d.title}</h1>
        <pre className="mt-6 whitespace-pre-wrap text-sm leading-relaxed font-mono">{d.body}</pre>
      </article>
    </Shell>
  );
}
