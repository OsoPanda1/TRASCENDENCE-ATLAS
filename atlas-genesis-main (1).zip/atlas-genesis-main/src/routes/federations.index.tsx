import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { useI18n } from "@/lib/i18n";
import { FEDERATIONS } from "@/lib/federations";

export const Route = createFileRoute("/federations/")({
  head: () => ({
    meta: [
      { title: "Federaciones — ATLAS TRASCENDENCE" },
      { name: "description", content: "Las siete federaciones de ATLAS TRASCENDENCE: conocimiento, identidad, gobernanza, economía, seguridad, infraestructura, inteligencia." },
    ],
  }),
  component: FedIndex,
});

function FedIndex() {
  const { lang, t } = useI18n();
  return (
    <Shell>
      <section className="relative py-20 border-b border-border">
        <div className="mx-auto max-w-7xl px-6">
          <div className="chip mb-6">{lang === "es" ? "Arquitectura madre" : "Mother architecture"}</div>
          <h1 className="font-display text-5xl md:text-7xl leading-[0.95] max-w-4xl">
            {lang === "es" ? "Siete federaciones." : "Seven federations."}<br />
            <span className="text-primary text-glow">{lang === "es" ? "Una doctrina." : "One doctrine."}</span>
          </h1>
          <p className="mt-6 max-w-2xl text-muted-foreground">
            {lang === "es"
              ? "Cada federación tiene su dominio, entidades, protocolos y persistencia. Todas cooperan, ninguna domina."
              : "Each federation has its domain, entities, protocols and persistence. All cooperate, none dominates."}
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-7xl px-6 space-y-px hairline rounded-sm overflow-hidden">
          {FEDERATIONS.map((f) => (
            <Link
              key={f.id}
              to="/federations/$id"
              params={{ id: f.id }}
              className="group grid grid-cols-12 gap-6 items-center bg-card/40 hover:bg-card/70 transition p-6 md:p-8"
            >
              <div className="col-span-12 md:col-span-1 mono text-[10px] tracking-[0.25em] text-muted-foreground">{f.index}</div>
              <div className="col-span-2 md:col-span-1">
                <span className="text-4xl" style={{ color: f.color, textShadow: `0 0 18px ${f.color}` }}>{f.glyph}</span>
              </div>
              <div className="col-span-10 md:col-span-5">
                <div className="font-display text-2xl md:text-3xl">{f.name[lang]}</div>
                <div className="mono text-[10px] tracking-[0.18em] uppercase text-muted-foreground mt-1">{f.domain[lang]}</div>
              </div>
              <div className="col-span-12 md:col-span-4 text-sm text-foreground/80">{f.essence[lang]}</div>
              <div className="col-span-12 md:col-span-1 text-right mono text-[10px] tracking-[0.2em] uppercase text-primary opacity-60 group-hover:opacity-100 transition">→</div>
            </Link>
          ))}
        </div>
      </section>
    </Shell>
  );
}
