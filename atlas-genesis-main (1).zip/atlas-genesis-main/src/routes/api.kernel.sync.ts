import { createFileRoute } from "@tanstack/react-router";
import { kernelRefreshManifest, kernelRecord } from "@/kernel/kernel-core";

export const Route = createFileRoute("/api/kernel/sync")({
  server: { handlers: { POST: async () => {
    const next = kernelRefreshManifest();
    kernelRecord({ type: "RECONCILIATION", fed: "infrastructure", payload: { manifest: next.version } });
    return Response.json({ ok: true, manifest: next });
  }}},
});
