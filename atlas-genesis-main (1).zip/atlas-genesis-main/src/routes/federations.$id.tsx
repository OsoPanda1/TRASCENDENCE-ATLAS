import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { Starfield } from "@/components/Starfield";
import { useI18n } from "@/lib/i18n";
import { FEDERATIONS, type Federation, type FederationId } from "@/lib/federations";

export const Route = createFileRoute("/federations/$id")({
  loader: ({ params }) => {
    const fed: Federation | undefined = FEDERATIONS.find((f) => f.id === params.id);
    if (!fed) throw notFound();
    return { fed };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.fed.name.es} — ATLAS TRASCENDENCE` },
          { name: "description", content: loaderData.fed.essence.es },
        ]
      : [],
  }),
  notFoundComponent: () => (
    <Shell>
      <div className="mx-auto max-w-3xl px-6 py-32 text-center">
        <div className="font-display text-5xl text-primary">404</div>
        <p className="mono text-xs tracking-[0.2em] uppercase text-muted-foreground mt-2">Federation not found</p>
        <Link to="/federations" className="mt-6 inline-block mono text-[11px] tracking-[0.2em] uppercase border border-primary/40 px-4 py-2 rounded-sm hover:bg-primary/10">← Back</Link>
      </div>
    </Shell>
  ),
  component: FedDetail,
});

function FedDetail() {
  const { fed } = Route.useLoaderData() as { fed: Federation };
  const { lang, t } = useI18n();
  const others = FEDERATIONS.filter((f) => f.id !== fed.id);

  return (
    <Shell>
      <section className="relative border-b border-border overflow-hidden">
        <Starfield count={50} />
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full pointer-events-none"
             style={{ background: `radial-gradient(circle, ${fed.color} 0%, transparent 60%)`, opacity: 0.18, animation: "pulse-glow 8s ease-in-out infinite" }} />
        <div className="relative mx-auto max-w-7xl px-6 py-20">
          <Link to="/federations" className="mono text-[10px] tracking-[0.2em] uppercase text-muted-foreground hover:text-foreground transition">
            ← {t("nav.federations")}
          </Link>
          <div className="mt-8 flex flex-wrap items-start gap-6">
            <div className="text-7xl shrink-0" style={{ color: fed.color, textShadow: `0 0 32px ${fed.color}` }}>{fed.glyph}</div>
            <div>
              <div className="mono text-[10px] tracking-[0.25em] text-muted-foreground">{fed.index}</div>
              <h1 className="font-display text-4xl md:text-6xl leading-[0.98] mt-2">{fed.name[lang]}</h1>
              <div className="mono text-[10px] tracking-[0.18em] uppercase text-muted-foreground mt-3">{fed.domain[lang]}</div>
            </div>
          </div>
          <p className="mt-8 max-w-3xl text-lg text-foreground/90 leading-relaxed">{fed.essence[lang]}</p>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-7xl px-6 grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-12">
            <div>
              <div className="chip mb-4">{lang === "es" ? "Módulos" : "Modules"}</div>
              <h2 className="font-display text-3xl mb-6">{lang === "es" ? "Componentes operativos" : "Operational components"}</h2>
              <div className="space-y-px hairline rounded-sm overflow-hidden">
                {fed.modules.map((m) => (
                  <div key={m.code} className="grid grid-cols-12 gap-4 bg-card/50 p-5">
                    <div className="col-span-12 md:col-span-3 mono text-[10px] tracking-[0.2em] text-primary">{m.code}</div>
                    <div className="col-span-12 md:col-span-4 font-display text-xl">{m.name[lang]}</div>
                    <div className="col-span-12 md:col-span-5 text-sm text-muted-foreground">{m.role[lang]}</div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="chip mb-4">{lang === "es" ? "Protocolos" : "Protocols"}</div>
              <h2 className="font-display text-3xl mb-6">{lang === "es" ? "Reglas estructurales" : "Structural rules"}</h2>
              <div className="space-y-3">
                {fed.protocols.map((p) => (
                  <div key={p.code} className="glass rounded-sm p-5 flex gap-5">
                    <div className="mono text-[10px] tracking-[0.2em] text-primary shrink-0 pt-1">{p.code}</div>
                    <div className="font-display text-lg">{p.desc[lang]}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <aside className="space-y-6">
            <div className="glass rounded-sm p-6">
              <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-3">{lang === "es" ? "Estado" : "Status"}</div>
              <div className="flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-aurora shadow-[0_0_10px_var(--aurora)] animate-pulse" />
                <span className="font-display text-2xl">{lang === "es" ? "Doctrina activa" : "Doctrine active"}</span>
              </div>
              <div className="mt-4 mono text-[10px] tracking-[0.18em] text-muted-foreground">
                {lang === "es" ? "Fase 0 · Definición" : "Phase 0 · Definition"}
              </div>
            </div>

            <div className="glass rounded-sm p-6">
              <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-4">{lang === "es" ? "Otras federaciones" : "Other federations"}</div>
              <div className="space-y-2">
                {others.map((o) => (
                  <Link key={o.id} to="/federations/$id" params={{ id: o.id as FederationId }} className="flex items-center gap-3 py-1.5 group">
                    <span className="text-lg" style={{ color: o.color }}>{o.glyph}</span>
                    <span className="text-sm text-muted-foreground group-hover:text-foreground transition">{o.name[lang]}</span>
                    <span className="ml-auto mono text-[9px] tracking-[0.2em] text-muted-foreground/60">{o.index}</span>
                  </Link>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </section>
    </Shell>
  );
}
