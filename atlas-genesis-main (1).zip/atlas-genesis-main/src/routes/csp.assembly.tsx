import { createFileRoute } from "@tanstack/react-router";
import { ExecutionCenterBoard } from "@/components/control/ExecutionCenterBoard";
export const Route = createFileRoute("/csp/assembly")({ component: Assembly });
function Assembly() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-10 space-y-6">
      <h2 className="font-display text-3xl text-primary">Assembly — ensamblado del atlas</h2>
      <p className="text-muted-foreground max-w-3xl">Una vez clasificadas las entidades, el plano de Assembly compone <span className="text-foreground">index.json</span>, <span className="text-foreground">graph.json</span> y <span className="text-foreground">taxonomy.json</span>. Validación Zod, invariantes (todo nodo en grafo existe en índice) y publicación atómica vía <span className="text-foreground">.next.json → mv</span>.</p>
      <ExecutionCenterBoard />
    </section>
  );
}
