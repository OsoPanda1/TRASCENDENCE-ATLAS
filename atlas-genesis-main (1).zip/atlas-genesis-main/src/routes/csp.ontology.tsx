import { createFileRoute } from "@tanstack/react-router";

const ENTITY_TYPES = ["PERSON","ORGANIZATION","TERRITORY","SYSTEM","SERVICE","DOCUMENT","POLICY","REPO","DATASET","EVENT"];
const RELATION_TYPES = ["BELONGS_TO","CONTAINS","DEPENDS_ON","AFFECTS","BACKED_BY","EXECUTES","MONETIZES","PRESERVES","FEDERATES"];
const EVENT_TYPES = ["OBSERVATION","DECISION","INCIDENT","STATE_TRANSITION","POLICY_CHANGE","RECONCILIATION","INGEST","PUBLISH","AUDIT"];

export const Route = createFileRoute("/csp/ontology")({ component: Ontology });

function Ontology() {
  const Group = ({ title, items }: { title: string; items: string[] }) => (
    <div className="glass rounded-sm p-5">
      <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-3">{title}</div>
      <div className="flex flex-wrap gap-2">{items.map((i) => <span key={i} className="chip">{i}</span>)}</div>
    </div>
  );
  return (
    <section className="mx-auto max-w-6xl px-6 py-10 space-y-6">
      <h2 className="font-display text-3xl text-primary">Ontology — tipos base canónicos</h2>
      <p className="text-muted-foreground max-w-3xl">Ontología compartida del Atlas. Compatible con JSON-LD, schema.org, GEMET y W3C-VC. Toda entidad vive en un grafo; toda relación es tipada y temporal.</p>
      <Group title="EntityType" items={ENTITY_TYPES} />
      <Group title="RelationType" items={RELATION_TYPES} />
      <Group title="EventType" items={EVENT_TYPES} />
    </section>
  );
}
