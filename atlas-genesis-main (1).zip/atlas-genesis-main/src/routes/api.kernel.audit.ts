import { createFileRoute } from "@tanstack/react-router";
import { kernelAudit } from "@/kernel/kernel-core";

export const Route = createFileRoute("/api/kernel/audit")({
  server: { handlers: { GET: async () => Response.json(kernelAudit()) } },
});
