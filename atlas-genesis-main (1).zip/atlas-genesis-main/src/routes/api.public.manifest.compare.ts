import { createFileRoute } from "@tanstack/react-router";
import { compareManifests, getCurrentManifest } from "@/lib/ecosystem/manifest";

export const Route = createFileRoute("/api/public/manifest/compare")({
  server: { handlers: { POST: async ({ request }) => {
    let other: unknown;
    try { other = await request.json(); } catch { return new Response("invalid", { status: 400 }); }
    const cmp = compareManifests(getCurrentManifest(), other as never);
    return Response.json(cmp);
  }}},
});
