import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { Starfield } from "@/components/Starfield";
import { RealmontenseBadge } from "@/components/RealmontenseBadge";
import { useI18n } from "@/lib/i18n";
import { FEDERATIONS, AXIOMS } from "@/lib/federations";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ATLAS TRASCENDENCE — Manifiesto" },
      { name: "description", content: "Preservando todo aquello que la humanidad considera digno de ser recordado." },
    ],
  }),
  component: Index,
});

function Index() {
  const { t, lang } = useI18n();
  return (
    <Shell>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 grid-lines opacity-40" />
        <Starfield count={80} />
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[680px] h-[680px] rounded-full pointer-events-none"
             style={{ background: "radial-gradient(circle, var(--glow) 0%, transparent 60%)", opacity: 0.15, animation: "pulse-glow 8s ease-in-out infinite" }} />

        <div className="relative mx-auto max-w-7xl px-6 pt-28 pb-32">
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <div className="chip">
              <span className="w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_8px_var(--glow)]" />
              {t("brand.tag")}
            </div>
            <RealmontenseBadge variant="compact" />
          </div>
          <h1 className="font-display text-[clamp(2.5rem,6vw,5.5rem)] leading-[0.98] max-w-5xl">
            {t("hero.title").split(".")[0]}
            <span className="text-primary text-glow">.</span>
          </h1>
          <p className="mt-8 max-w-2xl text-lg text-muted-foreground leading-relaxed">{t("hero.lede")}</p>

          <div className="mt-10 flex flex-wrap gap-3">
            <Link to="/federations" className="group inline-flex items-center gap-3 px-5 py-3 bg-primary text-primary-foreground rounded-sm mono text-[11px] tracking-[0.2em] uppercase hover:bg-primary/90 transition">
              {t("hero.cta")}
              <span className="transition-transform group-hover:translate-x-1">→</span>
            </Link>
            <Link to="/genesis" className="inline-flex items-center gap-3 px-5 py-3 hairline rounded-sm mono text-[11px] tracking-[0.2em] uppercase hover:bg-foreground/5 transition">
              {t("hero.cta2")}
            </Link>
          </div>

          <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-px hairline rounded-sm overflow-hidden">
            {[
              { k: "7", v: lang === "es" ? "Federaciones" : "Federations" },
              { k: "10", v: lang === "es" ? "Axiomas" : "Axioms" },
              { k: "5", v: lang === "es" ? "Capas TAMVPRINT" : "TAMVPRINT layers" },
              { k: "∞", v: lang === "es" ? "Memoria persistente" : "Persistent memory" },
            ].map((s) => (
              <div key={s.v} className="bg-card/40 px-5 py-6">
                <div className="font-display text-4xl text-primary">{s.k}</div>
                <div className="mono text-[10px] tracking-[0.18em] uppercase text-muted-foreground mt-2">{s.v}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEDERATIONS GRID */}
      <section className="relative py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="flex items-end justify-between gap-6 mb-12">
            <div>
              <div className="chip mb-4">F · 01 — 07</div>
              <h2 className="font-display text-4xl md:text-5xl max-w-3xl">{t("section.federations")}</h2>
              <p className="mt-4 text-muted-foreground max-w-2xl">{t("section.federations.lede")}</p>
            </div>
            <Link to="/federations" className="hidden md:inline mono text-[11px] tracking-[0.2em] uppercase text-primary hover:text-glow">
              {lang === "es" ? "Ver todas →" : "View all →"}
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px hairline rounded-sm overflow-hidden">
            {FEDERATIONS.map((f) => (
              <Link
                key={f.id}
                to="/federations/$id"
                params={{ id: f.id }}
                className="group relative bg-card/50 p-6 hover:bg-card/80 transition overflow-hidden"
              >
                <div className="absolute -right-12 -top-12 w-40 h-40 rounded-full opacity-20 group-hover:opacity-40 transition" style={{ background: `radial-gradient(circle, ${f.color} 0%, transparent 70%)` }} />
                <div className="relative flex items-start justify-between mb-6">
                  <span className="mono text-[10px] tracking-[0.25em] text-muted-foreground">{f.index}</span>
                  <span className="text-3xl" style={{ color: f.color, textShadow: `0 0 18px ${f.color}` }}>{f.glyph}</span>
                </div>
                <h3 className="relative font-display text-2xl leading-tight mb-2">{f.name[lang]}</h3>
                <div className="relative mono text-[10px] tracking-[0.18em] uppercase text-muted-foreground mb-4">{f.domain[lang]}</div>
                <p className="relative text-sm text-foreground/80 leading-relaxed">{f.essence[lang]}</p>
                <div className="relative mt-6 mono text-[10px] tracking-[0.2em] uppercase text-primary opacity-0 group-hover:opacity-100 transition">
                  {t("explore")} →
                </div>
              </Link>
            ))}
            <div className="bg-card/30 p-6 flex items-center justify-center">
              <div className="text-center">
                <div className="font-display text-6xl text-primary text-glow">7</div>
                <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mt-2">
                  {lang === "es" ? "Dominios · una doctrina" : "Domains · one doctrine"}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AXIOMS */}
      <section className="relative py-24 border-t border-border">
        <div className="absolute inset-0 grid-lines opacity-20" />
        <div className="relative mx-auto max-w-7xl px-6">
          <div className="chip mb-4">AX · 01 — 10</div>
          <h2 className="font-display text-4xl md:text-5xl mb-3">{t("section.doctrine")}</h2>
          <p className="text-muted-foreground max-w-2xl mb-12">{t("section.doctrine.lede")}</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-px">
            {AXIOMS.map((a, i) => (
              <div key={a.code} className="flex items-start gap-5 py-5 border-b border-border">
                <div className="mono text-[10px] tracking-[0.2em] text-primary pt-1 w-12 shrink-0">{a.code}</div>
                <div className="font-display text-xl md:text-2xl leading-snug">{a[lang]}</div>
                <div className="ml-auto mono text-[9px] tracking-[0.2em] text-muted-foreground pt-2">{String(i + 1).padStart(2, "0")}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* GENESIS CTA */}
      <section className="relative py-28 border-t border-border overflow-hidden">
        <Starfield count={40} />
        <div className="relative mx-auto max-w-5xl px-6 text-center">
          <div className="chip mb-6">GENESIS · TAMVPRINT</div>
          <h2 className="font-display text-4xl md:text-6xl leading-tight">
            {lang === "es" ? "No construimos software." : "We do not build software."}<br />
            <span className="text-primary text-glow">{lang === "es" ? "Construimos la infraestructura de lo que la humanidad decide no olvidar." : "We build the infrastructure of what humanity chooses not to forget."}</span>
          </h2>
          <Link to="/genesis" className="mt-10 inline-flex items-center gap-3 px-6 py-3 bg-primary text-primary-foreground rounded-sm mono text-[11px] tracking-[0.2em] uppercase hover:bg-primary/90 transition">
            {t("hero.cta2")} →
          </Link>
        </div>
      </section>
    </Shell>
  );
}
