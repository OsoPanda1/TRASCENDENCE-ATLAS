import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { TAMV_API_SPEC } from "@/lib/tamvUnifiedApi";

const DOCS = [
  { slug: "architecture", title: "ARCHITECTURE.md", desc: "Arquitectura monorepo + 3 sub-raíces." },
  { slug: "deployment", title: "DEPLOYMENT.md", desc: "Cloudflare Worker SSR + Lovable Cloud." },
  { slug: "contributing", title: "CONTRIBUTING.md", desc: "Gates de versión, validación atómica del atlas." },
  { slug: "api", title: "API · MD-X5 OpenAPI", desc: "REST + GraphQL + WS unificados." },
  { slug: "isabella-protocol", title: "Isabella Protocol", desc: "Triple bloqueo, 4 mega módulos, kill-switch." },
];

export const Route = createFileRoute("/docs")({
  head: () => ({ meta: [
    { title: "Docs — ATLAS TRASCENDENCE" },
    { name: "description", content: "Documentación técnica navegable: arquitectura, deploy, API MD-X5, protocolo Isabella." },
  ]}),
  component: DocsIndex,
});

function DocsIndex() {
  return (
    <Shell>
      <section className="border-b border-border">
        <div className="mx-auto max-w-7xl px-6 py-12">
          <div className="chip mb-4">DOCUMENTACIÓN</div>
          <h1 className="font-display text-5xl">Docs <span className="text-primary text-glow">TAMV</span></h1>
          <p className="text-muted-foreground mt-3 max-w-2xl">Documentación técnica navegable del kernel, APIs, deploy e Isabella.</p>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-6 py-12 grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {DOCS.map((d) => (
          <Link key={d.slug} to="/docs/$slug" params={{ slug: d.slug }} className="glass rounded-sm p-5 hover:border-primary/50 transition">
            <div className="mono text-[10px] tracking-[0.22em] text-primary">{d.title}</div>
            <p className="text-sm text-muted-foreground mt-2">{d.desc}</p>
          </Link>
        ))}
      </section>
      <section className="mx-auto max-w-7xl px-6 pb-16">
        <h2 className="font-display text-2xl mb-4">API · resumen</h2>
        <div className="hairline rounded-sm p-4 grid md:grid-cols-2 gap-2 text-xs">
          {TAMV_API_SPEC.rest.slice(0, 12).map((r) => (
            <div key={r.path} className="flex items-center gap-3">
              <span className="mono text-[9px] px-1.5 py-0.5 rounded-sm bg-primary/20 text-primary">{r.method}</span>
              <span className="mono text-[11px]">{r.path}</span>
            </div>
          ))}
        </div>
      </section>
    </Shell>
  );
}
