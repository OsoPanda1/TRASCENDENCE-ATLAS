import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { WikiLayout } from "@/components/wiki/WikiLayout";
import { ArticleCard } from "@/components/wiki/ArticleCard";
import { WIKIS } from "@/lib/wikis";
import { useState } from "react";
import { PaginationBar } from "@/components/wiki/PaginationBar";

export const Route = createFileRoute("/wikis")({
  head: () => ({ meta: [
    { title: "Wikis — Enciclopedia TAMV · ATLAS TRASCENDENCE" },
    { name: "description", content: "Enciclopedia federada TAMV: doctrina, arquitectura, Isabella, economía, seguridad." },
  ]}),
  validateSearch: (s: Record<string, unknown>) => ({ c: typeof s.c === "string" ? s.c : undefined, q: typeof s.q === "string" ? s.q : "" }),
  component: WikisIndex,
});

function WikisIndex() {
  const { c, q } = Route.useSearch();
  const [page, setPage] = useState(1);
  const PER = 6;
  const filtered = WIKIS.filter((w) =>
    (!c || w.category === c) &&
    (!q || (w.title.es + " " + w.title.en + " " + w.tags.join(" ")).toLowerCase().includes(q.toLowerCase()))
  );
  const totalPages = Math.max(1, Math.ceil(filtered.length / PER));
  const slice = filtered.slice((page-1)*PER, page*PER);
  return (
    <Shell>
      <section className="border-b border-border">
        <div className="mx-auto max-w-7xl px-6 py-12">
          <div className="chip mb-4">CAPA 1 · CONOCIMIENTO</div>
          <h1 className="font-display text-5xl">Enciclopedia <span className="text-primary text-glow">TAMV</span></h1>
          <p className="text-muted-foreground mt-3 max-w-2xl">Wiki canónica de doctrina, arquitectura, biografía e infraestructura del metasistema heptafederado.</p>
          <div className="mt-6 flex gap-3 max-w-lg">
            <Link to="/wikis" className="hairline rounded-sm px-3 py-2 mono text-[10px] tracking-[0.2em]">Limpiar</Link>
            <input
              defaultValue={q} placeholder="Buscar en la enciclopedia…"
              onChange={(e) => { const v = e.target.value; window.history.replaceState({}, "", `/wikis?${new URLSearchParams({ ...(c?{c}:{}), q: v }).toString()}`); }}
              className="flex-1 hairline rounded-sm px-3 py-2 bg-transparent mono text-xs focus:outline-none focus:border-primary"
            />
          </div>
        </div>
      </section>
      <WikiLayout>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {slice.map((a) => <ArticleCard key={a.slug} a={a} />)}
          {slice.length === 0 && <div className="text-muted-foreground mono text-xs">Sin resultados.</div>}
        </div>
        <PaginationBar page={page} total={totalPages} onChange={setPage} />
      </WikiLayout>
    </Shell>
  );
}
