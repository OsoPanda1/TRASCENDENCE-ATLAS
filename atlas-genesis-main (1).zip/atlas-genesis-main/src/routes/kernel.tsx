import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { Starfield } from "@/components/Starfield";
import { useI18n } from "@/lib/i18n";
import { FEDERATIONS } from "@/lib/federations";
import { useMemo } from "react";

export const Route = createFileRoute("/kernel")({
  head: () => ({
    meta: [
      { title: "Atlas Kernel — ATLAS TRASCENDENCE" },
      { name: "description", content: "El grafo civilizatorio: entidades, relaciones, eventos." },
    ],
  }),
  component: Kernel,
});

const ENTITY_TYPES = ["PERSON", "ORGANIZATION", "TERRITORY", "SYSTEM", "SERVICE", "DOCUMENT", "POLICY"];
const EVENT_TYPES = ["OBSERVATION", "DECISION", "INCIDENT", "STATE_TRANSITION", "POLICY_CHANGE", "RECONCILIATION"];

function seededRand(seed: number) {
  let s = seed;
  return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
}

function Kernel() {
  const { lang, t } = useI18n();

  const nodes = useMemo(() => {
    const r = seededRand(42);
    return FEDERATIONS.map((f, i) => {
      const angle = (i / FEDERATIONS.length) * Math.PI * 2 - Math.PI / 2;
      const radius = 36;
      return {
        f,
        x: 50 + Math.cos(angle) * radius,
        y: 50 + Math.sin(angle) * radius,
        pulse: r() * 4,
      };
    });
  }, []);

  const events = useMemo(() => {
    const r = seededRand(7);
    return Array.from({ length: 8 }).map((_, i) => ({
      id: `evt_${1000 + i}`,
      type: EVENT_TYPES[Math.floor(r() * EVENT_TYPES.length)],
      entity: ENTITY_TYPES[Math.floor(r() * ENTITY_TYPES.length)],
      fed: FEDERATIONS[Math.floor(r() * FEDERATIONS.length)],
      ts: new Date(Date.now() - i * 1000 * 60 * Math.floor(r() * 30 + 1)).toISOString(),
    }));
  }, []);

  return (
    <Shell>
      <section className="relative border-b border-border overflow-hidden">
        <Starfield count={60} />
        <div className="relative mx-auto max-w-7xl px-6 py-16">
          <div className="chip mb-6">ATLAS · KERNEL</div>
          <h1 className="font-display text-5xl md:text-6xl leading-[0.95] max-w-3xl">
            {t("kernel.title")} <span className="text-primary text-glow">·</span>
          </h1>
          <p className="mt-4 text-muted-foreground max-w-2xl">{t("kernel.sub")}</p>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-7xl px-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Graph */}
          <div className="lg:col-span-2 glass rounded-sm p-6 relative">
            <div className="flex items-baseline justify-between mb-4">
              <div>
                <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">{lang === "es" ? "Grafo civilizatorio" : "Civilizational graph"}</div>
                <h3 className="font-display text-2xl">7 {lang === "es" ? "federaciones · 21 relaciones" : "federations · 21 relations"}</h3>
              </div>
              <div className="mono text-[10px] text-aurora flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-aurora shadow-[0_0_8px_var(--aurora)] animate-pulse" />
                LIVE
              </div>
            </div>
            <div className="relative aspect-square w-full grid-lines rounded-sm overflow-hidden">
              <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full">
                {nodes.map((a, i) =>
                  nodes.slice(i + 1).map((b) => (
                    <line
                      key={`${a.f.id}-${b.f.id}`}
                      x1={a.x} y1={a.y} x2={b.x} y2={b.y}
                      stroke="currentColor"
                      strokeWidth="0.15"
                      className="text-foreground/15"
                    />
                  ))
                )}
                {nodes.map((n) => (
                  <g key={n.f.id}>
                    <circle cx={n.x} cy={n.y} r="4" fill={n.f.color} opacity="0.15" />
                    <circle cx={n.x} cy={n.y} r="1.8" fill={n.f.color} style={{ filter: `drop-shadow(0 0 3px ${n.f.color})` }} />
                    <text x={n.x} y={n.y - 6} textAnchor="middle" fontSize="2.2" fill="currentColor" className="font-mono text-foreground/70">
                      {n.f.index}
                    </text>
                  </g>
                ))}
                <circle cx="50" cy="50" r="2.5" fill="var(--glow)" opacity="0.7" style={{ filter: "drop-shadow(0 0 6px var(--glow))" }} />
                <text x="50" y="46" textAnchor="middle" fontSize="2" fill="currentColor" className="font-mono">KERNEL</text>
              </svg>
            </div>
          </div>

          {/* Metrics */}
          <div className="space-y-4">
            {[
              { l: lang === "es" ? "Entidades" : "Entities", v: "1.284M", c: "var(--glow)" },
              { l: lang === "es" ? "Relaciones" : "Relations", v: "8.42M", c: "var(--plasma)" },
              { l: lang === "es" ? "Eventos / 24h" : "Events / 24h", v: "212.6K", c: "var(--aurora)" },
              { l: lang === "es" ? "Anclas MSR" : "MSR anchors", v: "9 471", c: "var(--gold)" },
              { l: lang === "es" ? "Integridad" : "Integrity", v: "100.000%", c: "var(--aurora)" },
            ].map((m) => (
              <div key={m.l} className="glass rounded-sm p-5 flex items-center justify-between">
                <div>
                  <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground">{m.l}</div>
                  <div className="font-display text-3xl mt-1" style={{ color: m.c, textShadow: `0 0 16px ${m.c}` }}>{m.v}</div>
                </div>
                <div className="w-1.5 h-12 rounded-full" style={{ background: `linear-gradient(180deg, ${m.c}, transparent)` }} />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="mx-auto max-w-7xl px-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="glass rounded-sm p-6">
            <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-2">EOCT · {lang === "es" ? "Eventos recientes" : "Recent events"}</div>
            <h3 className="font-display text-2xl mb-5">{lang === "es" ? "Trazabilidad en vivo" : "Live traceability"}</h3>
            <div className="space-y-px">
              {events.map((e) => (
                <div key={e.id} className="grid grid-cols-12 gap-3 py-2.5 border-b border-border last:border-0 items-center text-sm">
                  <div className="col-span-3 mono text-[10px] text-primary">{e.id}</div>
                  <div className="col-span-3 mono text-[10px] text-muted-foreground">{e.type}</div>
                  <div className="col-span-2 mono text-[10px] text-foreground/80">{e.entity}</div>
                  <div className="col-span-3 flex items-center gap-2 mono text-[10px]" style={{ color: e.fed.color }}>
                    <span>{e.fed.glyph}</span>{e.fed.index}
                  </div>
                  <div className="col-span-1 mono text-[9px] text-muted-foreground/60 text-right">OK</div>
                </div>
              ))}
            </div>
          </div>

          <div className="glass rounded-sm p-6">
            <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mb-2">ATLAS · {lang === "es" ? "Ontología" : "Ontology"}</div>
            <h3 className="font-display text-2xl mb-5">{lang === "es" ? "Tipos base" : "Base types"}</h3>
            <div className="mb-6">
              <div className="mono text-[10px] tracking-[0.2em] text-muted-foreground mb-2">EntityType</div>
              <div className="flex flex-wrap gap-2">
                {ENTITY_TYPES.map((e) => <span key={e} className="chip">{e}</span>)}
              </div>
            </div>
            <div className="mb-6">
              <div className="mono text-[10px] tracking-[0.2em] text-muted-foreground mb-2">RelationType</div>
              <div className="flex flex-wrap gap-2">
                {["BELONGS_TO","CONTAINS","DEPENDS_ON","AFFECTS","BACKED_BY","EXECUTES","MONETIZES"].map((e) => <span key={e} className="chip">{e}</span>)}
              </div>
            </div>
            <div>
              <div className="mono text-[10px] tracking-[0.2em] text-muted-foreground mb-2">EventType</div>
              <div className="flex flex-wrap gap-2">
                {EVENT_TYPES.map((e) => <span key={e} className="chip">{e}</span>)}
              </div>
            </div>
          </div>
        </div>
      </section>
    </Shell>
  );
}
