import { createFileRoute } from "@tanstack/react-router";
import { kernelRecord, kernelStatus } from "@/kernel/kernel-core";

export const Route = createFileRoute("/api/kernel/cron")({
  server: { handlers: { POST: async () => {
    kernelRecord({ type: "OBSERVATION", fed: "infrastructure", payload: { cron: "tick", at: new Date().toISOString() } });
    return Response.json({ ok: true, status: kernelStatus() });
  }}},
});
