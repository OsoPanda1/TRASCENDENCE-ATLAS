import { createFileRoute } from "@tanstack/react-router";
import { IngestPayloadSchema } from "@/lib/ecosystem/contracts";
import { kernelRecord } from "@/kernel/kernel-core";

export const Route = createFileRoute("/api/public/ingest")({
  server: { handlers: { POST: async ({ request }) => {
    let body: unknown;
    try { body = await request.json(); } catch { return new Response("invalid json", { status: 400 }); }
    const parsed = IngestPayloadSchema.safeParse(body);
    if (!parsed.success) return Response.json({ ok: false, errors: parsed.error.flatten() }, { status: 422 });
    const ev = kernelRecord({ type: "INGEST", fed: "knowledge", payload: parsed.data });
    return Response.json({ ok: true, event_id: ev.id, accepted_at: ev.ts });
  }}},
});
