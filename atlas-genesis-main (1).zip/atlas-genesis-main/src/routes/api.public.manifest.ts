import { createFileRoute } from "@tanstack/react-router";
import { getCurrentManifest } from "@/lib/ecosystem/manifest";

export const Route = createFileRoute("/api/public/manifest")({
  server: { handlers: { GET: async () => Response.json(getCurrentManifest()) } },
});
