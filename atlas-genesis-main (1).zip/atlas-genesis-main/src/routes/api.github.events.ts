import { createFileRoute } from "@tanstack/react-router";
import { kernelEvents } from "@/kernel/kernel-core";

export const Route = createFileRoute("/api/github/events")({
  server: { handlers: { GET: async () => Response.json({ events: kernelEvents(50).filter((e) => (e.payload as any)?.source === "github.webhook") }) } },
});
