import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { I18nProvider } from "../lib/i18n";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl text-primary text-glow">404</h1>
        <p className="mt-2 mono text-xs tracking-[0.2em] uppercase text-muted-foreground">
          Entity not found in the civilizational graph
        </p>
        <div className="mt-6">
          <Link to="/" className="mono text-xs tracking-[0.2em] uppercase border border-primary/40 px-4 py-2 rounded-sm hover:bg-primary/10 transition">
            ← Return
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-2xl">State transition failed</h1>
        <p className="mt-2 text-sm text-muted-foreground">An anomaly was caught by the boundary.</p>
        <button
          onClick={() => { router.invalidate(); reset(); }}
          className="mt-6 mono text-xs tracking-[0.2em] uppercase border border-primary/40 px-4 py-2 rounded-sm hover:bg-primary/10 transition"
        >Retry</button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "ATLAS TRASCENDENCE — Metasistema civilizatorio heptafederado" },
      { name: "description", content: "Primer metasistema civilizatorio heptafederado originado en LATAM. Preservando todo aquello que la humanidad considera digno de ser recordado." },
      { name: "author", content: "TAMV ONLINE" },
      { property: "og:title", content: "ATLAS TRASCENDENCE" },
      { property: "og:description", content: "Metasistema civilizatorio heptafederado · by TAMV ONLINE" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600&family=Inter+Tight:wght@300;400;500;600&family=JetBrains+Mono:wght@300;400;500&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <I18nProvider>
        <Outlet />
      </I18nProvider>
    </QueryClientProvider>
  );
}
