import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/Shell";
import { Starfield } from "@/components/Starfield";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/genesis")({
  head: () => ({
    meta: [
      { title: "GENESIS TAMVPRINT — ATLAS TRASCENDENCE" },
      { name: "description", content: "Arquitectura fundacional híbrida · Plano · Roadmap · Whitepaper · Manifiesto · Blueprint." },
    ],
  }),
  component: Genesis,
});

const LAYERS = [
  { code: "L1", es: "Plano arquitectónico", en: "Architectural blueprint", desc: { es: "Capas, federaciones, módulos, relaciones y límites de desacople.", en: "Layers, federations, modules, relations and decoupling boundaries." } },
  { code: "L2", es: "Roadmap evolutivo", en: "Evolutionary roadmap", desc: { es: "Orden de construcción y expansión sin colapso estructural.", en: "Order of construction and expansion without structural collapse." } },
  { code: "L3", es: "Whitepaper", en: "Whitepaper", desc: { es: "Problema, propuesta, arquitectura, seguridad, rol de la IA.", en: "Problem, proposal, architecture, security, role of AI." } },
  { code: "L4", es: "Manifiesto", en: "Manifest", desc: { es: "El alma del sistema: memoria, identidad, trazabilidad, contención.", en: "The soul of the system: memory, identity, traceability, containment." } },
  { code: "L5", es: "Blueprint operativo", en: "Operational plan", desc: { es: "Qué construir, cómo, en qué orden, con qué reglas.", en: "What to build, how, in what order, under what rules." } },
];

const PHASES = [
  { code: "Φ0", es: "Doctrina", en: "Doctrine", items: { es: ["Principios", "Lenguaje estructural", "Constitución digital"], en: ["Principles", "Structural language", "Digital constitution"] } },
  { code: "Φ1", es: "Núcleo", en: "Core", items: { es: ["Atlas Kernel", "EOCT", "Base semántica"], en: ["Atlas Kernel", "EOCT", "Semantic base"] } },
  { code: "Φ2", es: "Seguridad y observabilidad", en: "Security & observability", items: { es: ["Anubis", "Horus", "Radares · Telemetría"], en: ["Anubis", "Horus", "Radars · Telemetry"] } },
  { code: "Φ3", es: "Gobernanza", en: "Governance", items: { es: ["Protocolos", "Decisión", "Reglas"], en: ["Protocols", "Decision", "Rules"] } },
  { code: "Φ4", es: "Servicios federados", en: "Federated services", items: { es: ["Identidad", "Educación", "Economía"], en: ["Identity", "Education", "Economy"] } },
  { code: "Φ5", es: "Experiencia", en: "Experience", items: { es: ["TAMV Frontier", "Explorer", "Interfaces"], en: ["TAMV Frontier", "Explorer", "Interfaces"] } },
  { code: "Φ6", es: "Expansión", en: "Expansion", items: { es: ["Territorios", "Instituciones", "Ecosistemas"], en: ["Territories", "Institutions", "Ecosystems"] } },
];

function Genesis() {
  const { lang } = useI18n();
  return (
    <Shell>
      <section className="relative border-b border-border overflow-hidden">
        <Starfield count={70} />
        <div className="relative mx-auto max-w-7xl px-6 py-24">
          <div className="chip mb-6">GENESIS · TAMVPRINT</div>
          <h1 className="font-display text-5xl md:text-7xl leading-[0.95] max-w-4xl">
            {lang === "es" ? "Arquitectura fundacional" : "Foundational architecture"}<br />
            <span className="text-primary text-glow">{lang === "es" ? "híbrida y viva." : "hybrid and alive."}</span>
          </h1>
          <p className="mt-8 max-w-3xl text-lg text-muted-foreground">
            {lang === "es"
              ? "El punto donde la idea se convierte en estructura, la estructura en sistema, y el sistema en civilización."
              : "The point where idea becomes structure, structure becomes system, and system becomes civilization."}
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="chip mb-4">{lang === "es" ? "Cinco capas · un documento" : "Five layers · one document"}</div>
          <h2 className="font-display text-4xl mb-10">{lang === "es" ? "Capas del TAMVPRINT" : "TAMVPRINT layers"}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-px hairline rounded-sm overflow-hidden">
            {LAYERS.map((l, i) => (
              <div key={l.code} className="bg-card/50 p-6 relative">
                <div className="absolute top-3 right-4 mono text-[9px] tracking-[0.2em] text-muted-foreground">{String(i + 1).padStart(2, "0")}/05</div>
                <div className="mono text-[10px] tracking-[0.22em] text-primary mb-3">{l.code}</div>
                <h3 className="font-display text-xl mb-3 leading-tight">{lang === "es" ? l.es : l.en}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{l.desc[lang]}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 border-t border-border">
        <div className="mx-auto max-w-7xl px-6">
          <div className="chip mb-4">{lang === "es" ? "Roadmap" : "Roadmap"}</div>
          <h2 className="font-display text-4xl mb-2">{lang === "es" ? "Secuencia inamovible" : "Immovable sequence"}</h2>
          <p className="text-muted-foreground mb-12 max-w-2xl">
            {lang === "es" ? "Cada error en el núcleo escala exponencialmente. Cada acierto se vuelve permanente." : "Each core mistake scales exponentially. Each correct decision becomes permanent."}
          </p>

          <div className="relative">
            <div className="absolute left-4 top-0 bottom-0 w-px bg-gradient-to-b from-primary/60 via-primary/20 to-transparent" />
            <div className="space-y-6">
              {PHASES.map((p) => (
                <div key={p.code} className="relative pl-14">
                  <div className="absolute left-0 top-1 w-9 h-9 rounded-full glass flex items-center justify-center">
                    <span className="mono text-[10px] text-primary">{p.code}</span>
                  </div>
                  <div className="glass rounded-sm p-6">
                    <div className="font-display text-2xl mb-3">{lang === "es" ? p.es : p.en}</div>
                    <div className="flex flex-wrap gap-2">
                      {p.items[lang].map((it) => (
                        <span key={it} className="chip">{it}</span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 border-t border-border">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <h2 className="font-display text-3xl md:text-5xl leading-tight">
            “{lang === "es" ? "No estás construyendo software. Estás construyendo una infraestructura para la memoria, el poder y la continuidad de sistemas humanos y artificiales." : "You are not building software. You are building an infrastructure for the memory, power and continuity of human and artificial systems."}”
          </h2>
          <div className="mt-6 mono text-[10px] tracking-[0.25em] uppercase text-muted-foreground">— GENESIS TAMVPRINT</div>
        </div>
      </section>
    </Shell>
  );
}
