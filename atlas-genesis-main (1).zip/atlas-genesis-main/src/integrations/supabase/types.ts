export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      anchors: {
        Row: {
          algo: string
          created_at: string
          id: string
          payload_hash: string
          payload_type: string
          refs: Json
          signer_id: string | null
        }
        Insert: {
          algo?: string
          created_at?: string
          id?: string
          payload_hash: string
          payload_type: string
          refs?: Json
          signer_id?: string | null
        }
        Update: {
          algo?: string
          created_at?: string
          id?: string
          payload_hash?: string
          payload_type?: string
          refs?: Json
          signer_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "anchors_signer_id_fkey"
            columns: ["signer_id"]
            isOneToOne: false
            referencedRelation: "identities"
            referencedColumns: ["id"]
          },
        ]
      }
      citemesh_context_entities: {
        Row: {
          context_id: string
          entity_id: string
          id: string
          role: string | null
        }
        Insert: {
          context_id: string
          entity_id: string
          id?: string
          role?: string | null
        }
        Update: {
          context_id?: string
          entity_id?: string
          id?: string
          role?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "citemesh_context_entities_context_id_fkey"
            columns: ["context_id"]
            isOneToOne: false
            referencedRelation: "citemesh_contexts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "citemesh_context_entities_entity_id_fkey"
            columns: ["entity_id"]
            isOneToOne: false
            referencedRelation: "entities"
            referencedColumns: ["id"]
          },
        ]
      }
      citemesh_contexts: {
        Row: {
          created_at: string
          description: string | null
          filters: Json
          id: string
          layout: Json
          name: string
          owner_id: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          filters?: Json
          id?: string
          layout?: Json
          name: string
          owner_id?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          filters?: Json
          id?: string
          layout?: Json
          name?: string
          owner_id?: string | null
        }
        Relationships: []
      }
      document_links: {
        Row: {
          created_at: string
          document_id: string
          entity_id: string
          id: string
          relation_type: string
        }
        Insert: {
          created_at?: string
          document_id: string
          entity_id: string
          id?: string
          relation_type?: string
        }
        Update: {
          created_at?: string
          document_id?: string
          entity_id?: string
          id?: string
          relation_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "document_links_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_links_entity_id_fkey"
            columns: ["entity_id"]
            isOneToOne: false
            referencedRelation: "entities"
            referencedColumns: ["id"]
          },
        ]
      }
      document_versions: {
        Row: {
          body: string | null
          created_at: string
          created_by: string | null
          document_id: string
          hash: string | null
          id: string
          storage_uri: string | null
          version_number: number
        }
        Insert: {
          body?: string | null
          created_at?: string
          created_by?: string | null
          document_id: string
          hash?: string | null
          id?: string
          storage_uri?: string | null
          version_number: number
        }
        Update: {
          body?: string | null
          created_at?: string
          created_by?: string | null
          document_id?: string
          hash?: string | null
          id?: string
          storage_uri?: string | null
          version_number?: number
        }
        Relationships: [
          {
            foreignKeyName: "document_versions_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
        ]
      }
      documents: {
        Row: {
          author: string | null
          body: string | null
          classification: Database["public"]["Enums"]["classification_level"]
          created_at: string
          created_by: string | null
          hash: string | null
          id: string
          license: string | null
          metadata: Json
          published_at: string | null
          slug: string | null
          storage_uri: string | null
          title: string
          type: string
          updated_at: string
        }
        Insert: {
          author?: string | null
          body?: string | null
          classification?: Database["public"]["Enums"]["classification_level"]
          created_at?: string
          created_by?: string | null
          hash?: string | null
          id?: string
          license?: string | null
          metadata?: Json
          published_at?: string | null
          slug?: string | null
          storage_uri?: string | null
          title: string
          type: string
          updated_at?: string
        }
        Update: {
          author?: string | null
          body?: string | null
          classification?: Database["public"]["Enums"]["classification_level"]
          created_at?: string
          created_by?: string | null
          hash?: string | null
          id?: string
          license?: string | null
          metadata?: Json
          published_at?: string | null
          slug?: string | null
          storage_uri?: string | null
          title?: string
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "documents_author_fkey"
            columns: ["author"]
            isOneToOne: false
            referencedRelation: "entities"
            referencedColumns: ["id"]
          },
        ]
      }
      elite_certifications: {
        Row: {
          anchor_id: string
          cert_type: string
          created_at: string
          id: string
          signatures: Json
          status: string
          threshold: string
        }
        Insert: {
          anchor_id: string
          cert_type: string
          created_at?: string
          id?: string
          signatures?: Json
          status?: string
          threshold?: string
        }
        Update: {
          anchor_id?: string
          cert_type?: string
          created_at?: string
          id?: string
          signatures?: Json
          status?: string
          threshold?: string
        }
        Relationships: [
          {
            foreignKeyName: "elite_certifications_anchor_id_fkey"
            columns: ["anchor_id"]
            isOneToOne: false
            referencedRelation: "anchors"
            referencedColumns: ["id"]
          },
        ]
      }
      entities: {
        Row: {
          classification: Database["public"]["Enums"]["classification_level"]
          created_at: string
          created_by: string | null
          federation: Database["public"]["Enums"]["federation_id"] | null
          id: string
          metadata: Json
          name: string
          slug: string | null
          summary: string | null
          type: Database["public"]["Enums"]["entity_type"]
          updated_at: string
        }
        Insert: {
          classification?: Database["public"]["Enums"]["classification_level"]
          created_at?: string
          created_by?: string | null
          federation?: Database["public"]["Enums"]["federation_id"] | null
          id?: string
          metadata?: Json
          name: string
          slug?: string | null
          summary?: string | null
          type: Database["public"]["Enums"]["entity_type"]
          updated_at?: string
        }
        Update: {
          classification?: Database["public"]["Enums"]["classification_level"]
          created_at?: string
          created_by?: string | null
          federation?: Database["public"]["Enums"]["federation_id"] | null
          id?: string
          metadata?: Json
          name?: string
          slug?: string | null
          summary?: string | null
          type?: Database["public"]["Enums"]["entity_type"]
          updated_at?: string
        }
        Relationships: []
      }
      eoct_events: {
        Row: {
          actor_id: string | null
          actor_type: string | null
          classification: Database["public"]["Enums"]["classification_level"]
          context: Json
          correlation_id: string | null
          created_by: string | null
          event_type: Database["public"]["Enums"]["event_type"]
          id: string
          severity: string
          source_federation: Database["public"]["Enums"]["federation_id"] | null
          span_id: string | null
          subject_id: string | null
          subject_type: string | null
          target_federation: Database["public"]["Enums"]["federation_id"] | null
          trace_id: string | null
          ts: string
        }
        Insert: {
          actor_id?: string | null
          actor_type?: string | null
          classification?: Database["public"]["Enums"]["classification_level"]
          context?: Json
          correlation_id?: string | null
          created_by?: string | null
          event_type: Database["public"]["Enums"]["event_type"]
          id?: string
          severity?: string
          source_federation?:
            | Database["public"]["Enums"]["federation_id"]
            | null
          span_id?: string | null
          subject_id?: string | null
          subject_type?: string | null
          target_federation?:
            | Database["public"]["Enums"]["federation_id"]
            | null
          trace_id?: string | null
          ts?: string
        }
        Update: {
          actor_id?: string | null
          actor_type?: string | null
          classification?: Database["public"]["Enums"]["classification_level"]
          context?: Json
          correlation_id?: string | null
          created_by?: string | null
          event_type?: Database["public"]["Enums"]["event_type"]
          id?: string
          severity?: string
          source_federation?:
            | Database["public"]["Enums"]["federation_id"]
            | null
          span_id?: string | null
          subject_id?: string | null
          subject_type?: string | null
          target_federation?:
            | Database["public"]["Enums"]["federation_id"]
            | null
          trace_id?: string | null
          ts?: string
        }
        Relationships: []
      }
      eoct_evidence_links: {
        Row: {
          created_at: string
          document_id: string
          event_id: string
          evidence_type: string | null
          id: string
        }
        Insert: {
          created_at?: string
          document_id: string
          event_id: string
          evidence_type?: string | null
          id?: string
        }
        Update: {
          created_at?: string
          document_id?: string
          event_id?: string
          evidence_type?: string | null
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "eoct_evidence_links_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "eoct_events"
            referencedColumns: ["id"]
          },
        ]
      }
      eoct_related_entities: {
        Row: {
          entity_id: string
          event_id: string
          id: string
          role: string | null
        }
        Insert: {
          entity_id: string
          event_id: string
          id?: string
          role?: string | null
        }
        Update: {
          entity_id?: string
          event_id?: string
          id?: string
          role?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "eoct_related_entities_entity_id_fkey"
            columns: ["entity_id"]
            isOneToOne: false
            referencedRelation: "entities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "eoct_related_entities_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "eoct_events"
            referencedColumns: ["id"]
          },
        ]
      }
      federation_messages: {
        Row: {
          classification: Database["public"]["Enums"]["classification_level"]
          correlation_id: string | null
          created_at: string
          created_by: string | null
          id: string
          payload: Json
          source_federation: Database["public"]["Enums"]["federation_id"]
          target_federation: Database["public"]["Enums"]["federation_id"]
          trace_id: string | null
          type: string
        }
        Insert: {
          classification?: Database["public"]["Enums"]["classification_level"]
          correlation_id?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          payload?: Json
          source_federation: Database["public"]["Enums"]["federation_id"]
          target_federation: Database["public"]["Enums"]["federation_id"]
          trace_id?: string | null
          type: string
        }
        Update: {
          classification?: Database["public"]["Enums"]["classification_level"]
          correlation_id?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          payload?: Json
          source_federation?: Database["public"]["Enums"]["federation_id"]
          target_federation?: Database["public"]["Enums"]["federation_id"]
          trace_id?: string | null
          type?: string
        }
        Relationships: []
      }
      identities: {
        Row: {
          attributes: Json
          created_at: string
          id: string
          roles: string[]
          spiffe_id: string | null
          state: string
          type: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          attributes?: Json
          created_at?: string
          id?: string
          roles?: string[]
          spiffe_id?: string | null
          state?: string
          type: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          attributes?: Json
          created_at?: string
          id?: string
          roles?: string[]
          spiffe_id?: string | null
          state?: string
          type?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      korima_articles: {
        Row: {
          body: string
          created_at: string
          created_by: string | null
          document_id: string | null
          id: string
          number: string
          title: string
          updated_at: string
          version: number
        }
        Insert: {
          body: string
          created_at?: string
          created_by?: string | null
          document_id?: string | null
          id?: string
          number: string
          title: string
          updated_at?: string
          version?: number
        }
        Update: {
          body?: string
          created_at?: string
          created_by?: string | null
          document_id?: string | null
          id?: string
          number?: string
          title?: string
          updated_at?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "korima_articles_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          display_name: string | null
          github: string | null
          id: string
          orcid: string | null
          updated_at: string
          username: string | null
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          display_name?: string | null
          github?: string | null
          id: string
          orcid?: string | null
          updated_at?: string
          username?: string | null
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          display_name?: string | null
          github?: string | null
          id?: string
          orcid?: string | null
          updated_at?: string
          username?: string | null
        }
        Relationships: []
      }
      relations: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          metadata: Json
          relation_type: Database["public"]["Enums"]["relation_type"]
          source_id: string
          target_id: string
          valid_from: string
          valid_to: string | null
          weight: number | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          metadata?: Json
          relation_type: Database["public"]["Enums"]["relation_type"]
          source_id: string
          target_id: string
          valid_from?: string
          valid_to?: string | null
          weight?: number | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          metadata?: Json
          relation_type?: Database["public"]["Enums"]["relation_type"]
          source_id?: string
          target_id?: string
          valid_from?: string
          valid_to?: string | null
          weight?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "relations_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "entities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "relations_target_id_fkey"
            columns: ["target_id"]
            isOneToOne: false
            referencedRelation: "entities"
            referencedColumns: ["id"]
          },
        ]
      }
      transactions: {
        Row: {
          amount: number
          completed_at: string | null
          created_at: string
          created_by: string | null
          currency: string
          id: string
          metadata: Json
          source_entity_id: string | null
          status: string
          target_entity_id: string | null
          type: string
        }
        Insert: {
          amount: number
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          currency?: string
          id?: string
          metadata?: Json
          source_entity_id?: string | null
          status?: string
          target_entity_id?: string | null
          type: string
        }
        Update: {
          amount?: number
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          currency?: string
          id?: string
          metadata?: Json
          source_entity_id?: string | null
          status?: string
          target_entity_id?: string | null
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "transactions_source_entity_id_fkey"
            columns: ["source_entity_id"]
            isOneToOne: false
            referencedRelation: "entities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_target_entity_id_fkey"
            columns: ["target_entity_id"]
            isOneToOne: false
            referencedRelation: "entities"
            referencedColumns: ["id"]
          },
        ]
      }
      twin_relations: {
        Row: {
          created_at: string
          id: string
          relation_type: string
          source_twin_id: string
          target_twin_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          relation_type: string
          source_twin_id: string
          target_twin_id: string
        }
        Update: {
          created_at?: string
          id?: string
          relation_type?: string
          source_twin_id?: string
          target_twin_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "twin_relations_source_twin_id_fkey"
            columns: ["source_twin_id"]
            isOneToOne: false
            referencedRelation: "twins"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "twin_relations_target_twin_id_fkey"
            columns: ["target_twin_id"]
            isOneToOne: false
            referencedRelation: "twins"
            referencedColumns: ["id"]
          },
        ]
      }
      twins: {
        Row: {
          attributes: Json
          created_at: string
          created_by: string | null
          entity_id: string | null
          id: string
          location: Json | null
          state: string
          type: string
          updated_at: string
        }
        Insert: {
          attributes?: Json
          created_at?: string
          created_by?: string | null
          entity_id?: string | null
          id?: string
          location?: Json | null
          state?: string
          type: string
          updated_at?: string
        }
        Update: {
          attributes?: Json
          created_at?: string
          created_by?: string | null
          entity_id?: string | null
          id?: string
          location?: Json | null
          state?: string
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "twins_entity_id_fkey"
            columns: ["entity_id"]
            isOneToOne: false
            referencedRelation: "entities"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          granted_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          granted_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          granted_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "curator" | "operator" | "guardian" | "member"
      classification_level: "public" | "internal" | "sensitive" | "critical"
      entity_type:
        | "PERSON"
        | "ORGANIZATION"
        | "TERRITORY"
        | "SYSTEM"
        | "SERVICE"
        | "DOCUMENT"
        | "POLICY"
        | "DATASET"
        | "REPO"
        | "EVENT"
        | "TWIN"
      event_type:
        | "OBSERVATION"
        | "DECISION"
        | "INCIDENT"
        | "STATE_TRANSITION"
        | "POLICY_CHANGE"
        | "RECONCILIATION"
        | "INGEST"
        | "PUBLISH"
        | "AUDIT"
        | "SECURITY_ALERT"
      federation_id:
        | "knowledge"
        | "identity"
        | "governance"
        | "economy"
        | "security"
        | "infrastructure"
        | "ai"
      relation_type:
        | "BELONGS_TO"
        | "CONTAINS"
        | "DEPENDS_ON"
        | "AFFECTS"
        | "BACKED_BY"
        | "EXECUTES"
        | "MONETIZES"
        | "PRESERVES"
        | "FEDERATES"
        | "MIRRORS"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "curator", "operator", "guardian", "member"],
      classification_level: ["public", "internal", "sensitive", "critical"],
      entity_type: [
        "PERSON",
        "ORGANIZATION",
        "TERRITORY",
        "SYSTEM",
        "SERVICE",
        "DOCUMENT",
        "POLICY",
        "DATASET",
        "REPO",
        "EVENT",
        "TWIN",
      ],
      event_type: [
        "OBSERVATION",
        "DECISION",
        "INCIDENT",
        "STATE_TRANSITION",
        "POLICY_CHANGE",
        "RECONCILIATION",
        "INGEST",
        "PUBLISH",
        "AUDIT",
        "SECURITY_ALERT",
      ],
      federation_id: [
        "knowledge",
        "identity",
        "governance",
        "economy",
        "security",
        "infrastructure",
        "ai",
      ],
      relation_type: [
        "BELONGS_TO",
        "CONTAINS",
        "DEPENDS_ON",
        "AFFECTS",
        "BACKED_BY",
        "EXECUTES",
        "MONETIZES",
        "PRESERVES",
        "FEDERATES",
        "MIRRORS",
      ],
    },
  },
} as const
