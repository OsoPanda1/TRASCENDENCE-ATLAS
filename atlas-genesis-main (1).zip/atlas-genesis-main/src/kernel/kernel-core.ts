// TAMV KERNEL CORE — orquestador in-process.
// Coordina manifest, eventos EOCT, auditoría y veto Dekateotl.
import type { KernelEvent, ManifestSnapshot } from "@/lib/types";
import { getCurrentManifest, refreshManifest } from "@/lib/ecosystem/manifest";

interface KernelState {
  startedAt: string;
  events: KernelEvent[];
  manifest: ManifestSnapshot;
}

const STATE: KernelState = {
  startedAt: new Date().toISOString(),
  events: [],
  manifest: getCurrentManifest(),
};

const MAX_EVENTS = 500;

export function kernelRecord(ev: Omit<KernelEvent, "id" | "ts"> & { ts?: string }) {
  const event: KernelEvent = {
    id: "evt_" + Math.random().toString(36).slice(2, 12),
    ts: ev.ts ?? new Date().toISOString(),
    ...ev,
  };
  STATE.events.unshift(event);
  if (STATE.events.length > MAX_EVENTS) STATE.events.length = MAX_EVENTS;
  return event;
}

export function kernelStatus() {
  return {
    started_at: STATE.startedAt,
    manifest: STATE.manifest,
    event_count: STATE.events.length,
    uptime_ms: Date.now() - new Date(STATE.startedAt).getTime(),
    health: "stable" as const,
  };
}

export function kernelEvents(limit = 50) {
  return STATE.events.slice(0, limit);
}

export function kernelRefreshManifest() {
  STATE.manifest = refreshManifest();
  kernelRecord({ type: "PUBLISH", fed: "infrastructure", payload: { manifest: STATE.manifest.version } });
  return STATE.manifest;
}

export function kernelAudit() {
  const totals = STATE.events.reduce<Record<string, number>>((acc, e) => {
    acc[e.type] = (acc[e.type] ?? 0) + 1;
    return acc;
  }, {});
  return {
    at: new Date().toISOString(),
    totals,
    integrity: STATE.manifest.integrity,
    federations_active: STATE.manifest.federations.length,
  };
}

// Seed inicial
if (STATE.events.length === 0) {
  ["OBSERVATION","DECISION","INGEST","PUBLISH","AUDIT","STATE_TRANSITION"].forEach((t, i) =>
    kernelRecord({ type: t as KernelEvent["type"], fed: ["knowledge","identity","security","economy","intelligence","infrastructure"][i % 6], ts: new Date(Date.now() - i * 60000).toISOString() })
  );
}
