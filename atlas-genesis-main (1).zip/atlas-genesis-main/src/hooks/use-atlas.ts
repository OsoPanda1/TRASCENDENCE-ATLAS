import { useEffect, useState } from "react";
import { kernelStatusFn, kernelEventsFn, kernelAuditFn, manifestFn } from "@/lib/atlas-pipeline.functions";
import { isabellaStatus, isabellaMetrics } from "@/lib/ai-isabella.functions";
import { openScienceStatus } from "@/lib/open-science";
import { getGithubProfile } from "@/lib/atlas.functions";

function useAsync<T>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<unknown>(null);
  useEffect(() => {
    let alive = true;
    setLoading(true);
    fn().then((d) => alive && (setData(d), setLoading(false)))
        .catch((e) => alive && (setErr(e), setLoading(false)));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return { data, loading, err };
}

export const useKernelStatus = () => useAsync(() => kernelStatusFn(), []);
export const useKernelEvents = (limit = 30) => useAsync(() => kernelEventsFn({ data: { limit } }), [limit]);
export const useKernelAudit = () => useAsync(() => kernelAuditFn(), []);
export const useManifestSnapshot = () => useAsync(() => manifestFn(), []);
export const useIdentityStatus = () => useAsync(() => isabellaStatus(), []);
export const useIsabellaMetrics = () => useAsync(() => isabellaMetrics(), []);
export const useOpenScienceStatus = () => useAsync(() => openScienceStatus(), []);
export const useGithubRepos = () => useAsync(() => getGithubProfile(), []);

export function useKnowledgeTopology() {
  return useAsync(async () => {
    const { FEDERATIONS } = await import("@/lib/federations");
    const { ATLAS_ENTITIES, ATLAS_RELATIONS } = await import("@/lib/atlasKernel");
    return { federations: FEDERATIONS.length, entities: ATLAS_ENTITIES.length, relations: ATLAS_RELATIONS.length };
  }, []);
}
