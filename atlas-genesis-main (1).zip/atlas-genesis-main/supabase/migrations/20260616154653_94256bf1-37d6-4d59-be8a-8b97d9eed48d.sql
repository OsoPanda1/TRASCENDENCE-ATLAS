
-- ============================================================
-- ATLAS TRASCENDENCE · Canonical heptafederated schema
-- ============================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Roles
CREATE TYPE public.app_role AS ENUM ('admin','curator','operator','guardian','member');

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT,
  display_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  orcid TEXT,
  github TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.profiles TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles_public_read" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_self_write" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_self_insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  granted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "user_roles_self_read" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, username, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email,'@',1)), COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email,'@',1)));
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'member');
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Generic updated_at
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- Enums for Atlas Kernel
CREATE TYPE public.entity_type AS ENUM ('PERSON','ORGANIZATION','TERRITORY','SYSTEM','SERVICE','DOCUMENT','POLICY','DATASET','REPO','EVENT','TWIN');
CREATE TYPE public.relation_type AS ENUM ('BELONGS_TO','CONTAINS','DEPENDS_ON','AFFECTS','BACKED_BY','EXECUTES','MONETIZES','PRESERVES','FEDERATES','MIRRORS');
CREATE TYPE public.event_type AS ENUM ('OBSERVATION','DECISION','INCIDENT','STATE_TRANSITION','POLICY_CHANGE','RECONCILIATION','INGEST','PUBLISH','AUDIT','SECURITY_ALERT');
CREATE TYPE public.classification_level AS ENUM ('public','internal','sensitive','critical');
CREATE TYPE public.federation_id AS ENUM ('knowledge','identity','governance','economy','security','infrastructure','ai');

-- IDENTITIES
CREATE TABLE public.identities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  spiffe_id TEXT UNIQUE,
  roles TEXT[] NOT NULL DEFAULT '{}',
  attributes JSONB NOT NULL DEFAULT '{}'::jsonb,
  state TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.identities TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.identities TO authenticated;
GRANT ALL ON public.identities TO service_role;
ALTER TABLE public.identities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "identities_read_all" ON public.identities FOR SELECT USING (true);
CREATE POLICY "identities_owner_write" ON public.identities FOR UPDATE TO authenticated USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin')) WITH CHECK (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "identities_insert" ON public.identities FOR INSERT TO authenticated WITH CHECK (true);
CREATE TRIGGER touch_identities BEFORE UPDATE ON public.identities FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ENTITIES (Atlas Kernel)
CREATE TABLE public.entities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type public.entity_type NOT NULL,
  name TEXT NOT NULL,
  slug TEXT UNIQUE,
  classification public.classification_level NOT NULL DEFAULT 'public',
  federation public.federation_id,
  summary TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX entities_type_idx ON public.entities(type);
CREATE INDEX entities_federation_idx ON public.entities(federation);
GRANT SELECT ON public.entities TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.entities TO authenticated;
GRANT ALL ON public.entities TO service_role;
ALTER TABLE public.entities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "entities_public_read" ON public.entities FOR SELECT USING (classification = 'public' OR auth.uid() IS NOT NULL);
CREATE POLICY "entities_insert" ON public.entities FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "entities_update_own" ON public.entities FOR UPDATE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'curator'));
CREATE POLICY "entities_delete_own" ON public.entities FOR DELETE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER touch_entities BEFORE UPDATE ON public.entities FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- RELATIONS
CREATE TABLE public.relations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id UUID NOT NULL REFERENCES public.entities(id) ON DELETE CASCADE,
  target_id UUID NOT NULL REFERENCES public.entities(id) ON DELETE CASCADE,
  relation_type public.relation_type NOT NULL,
  weight NUMERIC,
  valid_from TIMESTAMPTZ NOT NULL DEFAULT now(),
  valid_to TIMESTAMPTZ,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX relations_source_idx ON public.relations(source_id);
CREATE INDEX relations_target_idx ON public.relations(target_id);
GRANT SELECT ON public.relations TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.relations TO authenticated;
GRANT ALL ON public.relations TO service_role;
ALTER TABLE public.relations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "relations_read_all" ON public.relations FOR SELECT USING (true);
CREATE POLICY "relations_insert" ON public.relations FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "relations_modify_own" ON public.relations FOR UPDATE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "relations_delete_own" ON public.relations FOR DELETE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));

-- EOCT EVENTS
CREATE TABLE public.eoct_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type public.event_type NOT NULL,
  actor_type TEXT,
  actor_id UUID,
  subject_type TEXT,
  subject_id UUID,
  source_federation public.federation_id,
  target_federation public.federation_id,
  severity TEXT NOT NULL DEFAULT 'INFO',
  trace_id TEXT,
  span_id TEXT,
  correlation_id TEXT,
  classification public.classification_level NOT NULL DEFAULT 'internal',
  context JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  ts TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX eoct_ts_idx ON public.eoct_events(ts DESC);
CREATE INDEX eoct_type_idx ON public.eoct_events(event_type);
CREATE INDEX eoct_fed_idx ON public.eoct_events(source_federation);
GRANT SELECT ON public.eoct_events TO anon;
GRANT SELECT, INSERT ON public.eoct_events TO authenticated;
GRANT ALL ON public.eoct_events TO service_role;
ALTER TABLE public.eoct_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "eoct_public_read" ON public.eoct_events FOR SELECT USING (classification IN ('public','internal') OR auth.uid() IS NOT NULL);
CREATE POLICY "eoct_insert" ON public.eoct_events FOR INSERT TO authenticated WITH CHECK (true);

CREATE TABLE public.eoct_evidence_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID NOT NULL REFERENCES public.eoct_events(id) ON DELETE CASCADE,
  document_id UUID NOT NULL,
  evidence_type TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.eoct_evidence_links TO anon;
GRANT SELECT, INSERT ON public.eoct_evidence_links TO authenticated;
GRANT ALL ON public.eoct_evidence_links TO service_role;
ALTER TABLE public.eoct_evidence_links ENABLE ROW LEVEL SECURITY;
CREATE POLICY "evidence_read_all" ON public.eoct_evidence_links FOR SELECT USING (true);
CREATE POLICY "evidence_insert" ON public.eoct_evidence_links FOR INSERT TO authenticated WITH CHECK (true);

CREATE TABLE public.eoct_related_entities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID NOT NULL REFERENCES public.eoct_events(id) ON DELETE CASCADE,
  entity_id UUID NOT NULL REFERENCES public.entities(id) ON DELETE CASCADE,
  role TEXT
);
GRANT SELECT ON public.eoct_related_entities TO anon;
GRANT SELECT, INSERT ON public.eoct_related_entities TO authenticated;
GRANT ALL ON public.eoct_related_entities TO service_role;
ALTER TABLE public.eoct_related_entities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "eoct_rel_read" ON public.eoct_related_entities FOR SELECT USING (true);
CREATE POLICY "eoct_rel_insert" ON public.eoct_related_entities FOR INSERT TO authenticated WITH CHECK (true);

-- BOOKPI documents
CREATE TABLE public.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  slug TEXT UNIQUE,
  author UUID REFERENCES public.entities(id) ON DELETE SET NULL,
  license TEXT,
  classification public.classification_level NOT NULL DEFAULT 'public',
  hash TEXT,
  storage_uri TEXT,
  body TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  published_at TIMESTAMPTZ
);
GRANT SELECT ON public.documents TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.documents TO authenticated;
GRANT ALL ON public.documents TO service_role;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "docs_public_read" ON public.documents FOR SELECT USING (classification = 'public' OR auth.uid() IS NOT NULL);
CREATE POLICY "docs_insert" ON public.documents FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "docs_update_own" ON public.documents FOR UPDATE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'curator') OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "docs_delete_own" ON public.documents FOR DELETE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER touch_docs BEFORE UPDATE ON public.documents FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE public.document_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id UUID NOT NULL REFERENCES public.documents(id) ON DELETE CASCADE,
  version_number INT NOT NULL,
  hash TEXT,
  storage_uri TEXT,
  body TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.document_versions TO anon;
GRANT SELECT, INSERT ON public.document_versions TO authenticated;
GRANT ALL ON public.document_versions TO service_role;
ALTER TABLE public.document_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "docver_read" ON public.document_versions FOR SELECT USING (true);
CREATE POLICY "docver_insert" ON public.document_versions FOR INSERT TO authenticated WITH CHECK (true);

CREATE TABLE public.document_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id UUID NOT NULL REFERENCES public.documents(id) ON DELETE CASCADE,
  entity_id UUID NOT NULL REFERENCES public.entities(id) ON DELETE CASCADE,
  relation_type TEXT NOT NULL DEFAULT 'MENTIONS',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.document_links TO anon;
GRANT SELECT, INSERT, DELETE ON public.document_links TO authenticated;
GRANT ALL ON public.document_links TO service_role;
ALTER TABLE public.document_links ENABLE ROW LEVEL SECURITY;
CREATE POLICY "doclink_read" ON public.document_links FOR SELECT USING (true);
CREATE POLICY "doclink_insert" ON public.document_links FOR INSERT TO authenticated WITH CHECK (true);

-- GEMET twins
CREATE TABLE public.twins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL,
  entity_id UUID REFERENCES public.entities(id) ON DELETE SET NULL,
  state TEXT NOT NULL DEFAULT 'PLANNED',
  attributes JSONB NOT NULL DEFAULT '{}'::jsonb,
  location JSONB,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.twins TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.twins TO authenticated;
GRANT ALL ON public.twins TO service_role;
ALTER TABLE public.twins ENABLE ROW LEVEL SECURITY;
CREATE POLICY "twins_read_all" ON public.twins FOR SELECT USING (true);
CREATE POLICY "twins_insert" ON public.twins FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());
CREATE POLICY "twins_update_own" ON public.twins FOR UPDATE TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'operator') OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER touch_twins BEFORE UPDATE ON public.twins FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE public.twin_relations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_twin_id UUID NOT NULL REFERENCES public.twins(id) ON DELETE CASCADE,
  target_twin_id UUID NOT NULL REFERENCES public.twins(id) ON DELETE CASCADE,
  relation_type TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.twin_relations TO anon;
GRANT SELECT, INSERT ON public.twin_relations TO authenticated;
GRANT ALL ON public.twin_relations TO service_role;
ALTER TABLE public.twin_relations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "twinrel_read" ON public.twin_relations FOR SELECT USING (true);
CREATE POLICY "twinrel_insert" ON public.twin_relations FOR INSERT TO authenticated WITH CHECK (true);

-- CITEMESH
CREATE TABLE public.citemesh_contexts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  filters JSONB NOT NULL DEFAULT '{}'::jsonb,
  layout JSONB NOT NULL DEFAULT '{}'::jsonb,
  owner_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.citemesh_contexts TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.citemesh_contexts TO authenticated;
GRANT ALL ON public.citemesh_contexts TO service_role;
ALTER TABLE public.citemesh_contexts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ctx_read" ON public.citemesh_contexts FOR SELECT USING (true);
CREATE POLICY "ctx_insert" ON public.citemesh_contexts FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "ctx_update_own" ON public.citemesh_contexts FOR UPDATE TO authenticated USING (owner_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE TABLE public.citemesh_context_entities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  context_id UUID NOT NULL REFERENCES public.citemesh_contexts(id) ON DELETE CASCADE,
  entity_id UUID NOT NULL REFERENCES public.entities(id) ON DELETE CASCADE,
  role TEXT
);
GRANT SELECT ON public.citemesh_context_entities TO anon;
GRANT SELECT, INSERT, DELETE ON public.citemesh_context_entities TO authenticated;
GRANT ALL ON public.citemesh_context_entities TO service_role;
ALTER TABLE public.citemesh_context_entities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ctxent_read" ON public.citemesh_context_entities FOR SELECT USING (true);
CREATE POLICY "ctxent_insert" ON public.citemesh_context_entities FOR INSERT TO authenticated WITH CHECK (true);

-- KORIMA governance
CREATE TABLE public.korima_articles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  number TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  version INT NOT NULL DEFAULT 1,
  document_id UUID REFERENCES public.documents(id) ON DELETE SET NULL,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.korima_articles TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.korima_articles TO authenticated;
GRANT ALL ON public.korima_articles TO service_role;
ALTER TABLE public.korima_articles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "korima_read" ON public.korima_articles FOR SELECT USING (true);
CREATE POLICY "korima_write" ON public.korima_articles FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'guardian') OR public.has_role(auth.uid(),'curator'));
CREATE POLICY "korima_update" ON public.korima_articles FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'guardian'));
CREATE TRIGGER touch_korima BEFORE UPDATE ON public.korima_articles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ECONOMY
CREATE TABLE public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_entity_id UUID REFERENCES public.entities(id) ON DELETE SET NULL,
  target_entity_id UUID REFERENCES public.entities(id) ON DELETE SET NULL,
  amount NUMERIC NOT NULL,
  currency TEXT NOT NULL DEFAULT 'MXN',
  type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING',
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);
GRANT SELECT ON public.transactions TO authenticated;
GRANT INSERT, UPDATE ON public.transactions TO authenticated;
GRANT ALL ON public.transactions TO service_role;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tx_read_own" ON public.transactions FOR SELECT TO authenticated USING (created_by = auth.uid() OR public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'operator'));
CREATE POLICY "tx_insert" ON public.transactions FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid());

-- MSR anchors
CREATE TABLE public.anchors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payload_hash TEXT NOT NULL,
  payload_type TEXT NOT NULL,
  algo TEXT NOT NULL DEFAULT 'SHA-256',
  signer_id UUID REFERENCES public.identities(id) ON DELETE SET NULL,
  refs JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.anchors TO anon;
GRANT SELECT, INSERT ON public.anchors TO authenticated;
GRANT ALL ON public.anchors TO service_role;
ALTER TABLE public.anchors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anchors_read" ON public.anchors FOR SELECT USING (true);
CREATE POLICY "anchors_insert" ON public.anchors FOR INSERT TO authenticated WITH CHECK (true);

CREATE TABLE public.elite_certifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  anchor_id UUID NOT NULL REFERENCES public.anchors(id) ON DELETE CASCADE,
  cert_type TEXT NOT NULL,
  signatures JSONB NOT NULL DEFAULT '[]'::jsonb,
  threshold TEXT NOT NULL DEFAULT '1/1',
  status TEXT NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.elite_certifications TO anon;
GRANT SELECT, INSERT, UPDATE ON public.elite_certifications TO authenticated;
GRANT ALL ON public.elite_certifications TO service_role;
ALTER TABLE public.elite_certifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "elite_read" ON public.elite_certifications FOR SELECT USING (true);
CREATE POLICY "elite_insert" ON public.elite_certifications FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'guardian') OR public.has_role(auth.uid(),'admin'));

-- INTER-FEDERATION MESSAGES
CREATE TABLE public.federation_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_federation public.federation_id NOT NULL,
  target_federation public.federation_id NOT NULL,
  type TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  trace_id TEXT,
  correlation_id TEXT,
  classification public.classification_level NOT NULL DEFAULT 'internal',
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX fedmsg_ts_idx ON public.federation_messages(created_at DESC);
GRANT SELECT ON public.federation_messages TO anon;
GRANT SELECT, INSERT ON public.federation_messages TO authenticated;
GRANT ALL ON public.federation_messages TO service_role;
ALTER TABLE public.federation_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "fedmsg_read" ON public.federation_messages FOR SELECT USING (classification IN ('public','internal') OR auth.uid() IS NOT NULL);
CREATE POLICY "fedmsg_insert" ON public.federation_messages FOR INSERT TO authenticated WITH CHECK (true);

-- Seed minimal canonical entities (the 7 federations)
INSERT INTO public.entities (type, name, slug, classification, federation, summary, metadata) VALUES
('ORGANIZATION','Federación de Conocimiento','fed-knowledge','public','knowledge','Atlas Kernel · Bookpi · EOCT · GEMET · CITEMESH','{}'),
('ORGANIZATION','Federación de Identidad','fed-identity','public','identity','SPIFFE/SPIRE · Identidades soberanas','{}'),
('ORGANIZATION','Federación de Gobernanza','fed-governance','public','governance','KORIMA CODEX · 4L · SDMD-7','{}'),
('ORGANIZATION','Federación de Economía','fed-economy','public','economy','Transacciones · TAMV Credits · Cattleya Pay','{}'),
('ORGANIZATION','Federación de Seguridad','fed-security','public','security','Anubis · Horus · Dekateotl · KMS híbrido','{}'),
('ORGANIZATION','Federación de Infraestructura','fed-infrastructure','public','infrastructure','Orquestación · mTLS · CI/CD · SBOM','{}'),
('ORGANIZATION','Federación de IA','fed-ai','public','ai','Isabella · Guardrails · THCF · Dekateotl veto','{}'),
('SYSTEM','Atlas Kernel','sys-atlas-kernel','public','knowledge','Grafo civilizatorio operativo','{}'),
('SYSTEM','EOCT — Event & Observation Core Tracker','sys-eoct','public','knowledge','Trazabilidad total de eventos','{}'),
('SYSTEM','Bookpi','sys-bookpi','public','knowledge','Memoria documental versionada','{}'),
('SYSTEM','GEMET','sys-gemet','public','knowledge','Gemelos digitales','{}'),
('SYSTEM','Isabella ACCS','sys-isabella','public','ai','Núcleo cognitivo orquestador','{}'),
('SYSTEM','Anubis Sentinel','sys-anubis','public','security','WAF/IDS/IPS y guardianía','{}'),
('SYSTEM','Dekateotl','sys-dekateotl','public','security','Enforcement constitucional de 8 niveles','{}'),
('TERRITORY','Mineral del Monte, Hidalgo','tx-real-monte','public','infrastructure','Cuna LATAM de ATLAS TRASCENDENCE — Orgullosamente Realmontenses','{"lat":20.3833,"lon":-98.85}'),
('PERSON','Anubis Villaseñor (EOCT)','person-eoct','public','identity','Arquitecto fundacional de ATLAS','{"orcid":"0009-0008-5050-1539"}');

-- Seed canonical relations between federations and Atlas
INSERT INTO public.relations (source_id, target_id, relation_type)
SELECT a.id, b.id, 'CONTAINS' FROM public.entities a, public.entities b
WHERE a.slug = 'fed-knowledge' AND b.slug IN ('sys-atlas-kernel','sys-eoct','sys-bookpi','sys-gemet');

INSERT INTO public.relations (source_id, target_id, relation_type)
SELECT a.id, b.id, 'CONTAINS' FROM public.entities a, public.entities b
WHERE a.slug = 'fed-ai' AND b.slug = 'sys-isabella';

INSERT INTO public.relations (source_id, target_id, relation_type)
SELECT a.id, b.id, 'CONTAINS' FROM public.entities a, public.entities b
WHERE a.slug = 'fed-security' AND b.slug IN ('sys-anubis','sys-dekateotl');

INSERT INTO public.relations (source_id, target_id, relation_type)
SELECT a.id, b.id, 'BELONGS_TO' FROM public.entities a, public.entities b
WHERE a.slug = 'person-eoct' AND b.slug = 'tx-real-monte';

-- Seed founding doctrine document
INSERT INTO public.documents (type, title, slug, classification, body, metadata)
VALUES (
  'CONSTITUTION',
  'ATLAS TRASCENDENCE — GENESIS OPERATIVA TOTAL',
  'genesis-operativa-total',
  'public',
  'Metasistema civilizatorio heptafederado, ontológico, ejecutable, versionable, monetizable y trazable, diseñado para preservar, operar y evolucionar la memoria estructurada de la humanidad.',
  '{"version":"v1.0","origin":"LATAM","by":"TAMV ONLINE"}'
);
