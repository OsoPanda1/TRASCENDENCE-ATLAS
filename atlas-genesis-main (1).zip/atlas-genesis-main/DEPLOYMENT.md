# DEPLOYMENT — ATLAS TRASCENDENCE / TAMV
- Runtime SSR: Cloudflare Worker (TanStack Start v1 + Vite 7, `nodejs_compat` flag).
- DB / Auth / Storage: Lovable Cloud (Supabase managed) — habilitar para sesiones reales.
- AI Gateway: `https://ai.gateway.lovable.dev` con `LOVABLE_API_KEY`.
- Conectores: GitHub PAT, OpenAIRE (sin auth), Zenodo, Figshare, ORCID — secrets ya integrados.

## Pipelines críticos
- `.github/workflows/atlas-ingest.yml` — cron diario; sólo escribe `tamv-core-atlas/atlas/`.
- `.github/workflows/constitutional-gate.yml` — bloquea merges que violen el Manifiesto.
- `.github/workflows/ci.yml` — build + tests + scan.

## URLs estables (Lovable)
- `project--{id}.lovable.app` — producción.
- `project--{id}-dev.lovable.app` — preview.
