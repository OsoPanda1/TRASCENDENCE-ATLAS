# ARCHITECTURE — TAMV Monorepo
3 sub-raíces canónicas:
- **tamv-core-atlas** — kernel Atlas (ingestion / classify / publish), threat-model, schemas.
- **tamv-digital-nexus** — runtime nextgen, Anubis/Horus/Dekateotl systems, capa constitucional.
- **tamv-the-federated-frontier** — frontend público + backend FastAPI `tamv-atlas-core`.

## Capas civilizatorias
1. Conocimiento (Wikis, Docs, Nexus, Ontologías).
2. Operación (Kernel Core, APIs, Webhooks, Manifest).
3. Persistencia (Cloud — pendiente habilitar).
4. Observabilidad (Auditoría, EOCT stream, Health checks).
5. DevOps (Docker, CI/CD, workflows, versionado).

## Heptafederación (MD-X4)
F1 Constitucional · F2 Conocimiento · F3 Identidad · F4 Economía · F5 Seguridad · F6 Infraestructura · F7 IA.
