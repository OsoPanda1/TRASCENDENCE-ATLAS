# CONTRIBUTING
Antes de cualquier PR:
1. Leer `ARCHITECTURE.md` y `DEPLOYMENT.md`.
2. Cambios al kernel Atlas → sólo `git add tamv-core-atlas/atlas/`.
3. Cambios al schema → bump `api_version` en `system_metadata` y actualizar `packages/contracts/`.
4. Cambios a Isabella → pasan por `constitutional-gate.yml`.
5. Tests obligatorios para policies RLS y validadores Zod.
