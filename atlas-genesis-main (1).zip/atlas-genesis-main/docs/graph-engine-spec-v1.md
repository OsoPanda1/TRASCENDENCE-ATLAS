# Atlas Kernel · Graph Engine Spec v1

> Motor de grafo operativo del metasistema ATLAS TRASCENDENCE.
> No es un knowledge graph informativo: es ejecutable, versionable y trazable.

## 1. Propósito

Representa **todas las entidades** del ecosistema (personas, organizaciones,
territorios, sistemas, servicios, políticas, documentos, transacciones,
gemelos digitales) y modela sus **relaciones semánticas**
(`BELONGS_TO`, `CONTAINS`, `DEPENDS_ON`, `AFFECTS`, `BACKED_BY`, `EXECUTES`,
`MONETIZES`, `PRESERVES`, `FEDERATES`, `MIRRORS`).

Conecta eventos EOCT, documentos Bookpi, anclas MSR/ELITE, identidades
SPIFFE y estados GEMET. Es la capa de verdad para visualización, razonamiento
(Isabella) y orquestación.

## 2. Ontología

**EntityType**: `PERSON | ORGANIZATION | TERRITORY | SYSTEM | SERVICE | DOCUMENT | POLICY | DATASET | REPO | EVENT | TWIN`

**RelationType**: ver arriba.

**EventType (EOCT)**: `OBSERVATION | DECISION | INCIDENT | STATE_TRANSITION | POLICY_CHANGE | RECONCILIATION | INGEST | PUBLISH | AUDIT | SECURITY_ALERT`

**Federación**: `knowledge | identity | governance | economy | security | infrastructure | ai`

**Clasificación**: `public | internal | sensitive | critical`

## 3. Persistencia (Lovable Cloud · Postgres)

Tablas canónicas implementadas:

- `entities`, `relations` (Atlas Kernel)
- `eoct_events`, `eoct_evidence_links`, `eoct_related_entities` (EOCT)
- `documents`, `document_versions`, `document_links` (Bookpi)
- `twins`, `twin_relations` (GEMET)
- `citemesh_contexts`, `citemesh_context_entities` (CITEMESH)
- `identities`, `profiles`, `user_roles` (Identidad)
- `korima_articles` (Gobernanza)
- `transactions` (Economía)
- `anchors`, `elite_certifications` (MSR/ELITE)
- `federation_messages` (Inter-federación)

Todas con RLS habilitado y GRANTs explícitos para `anon`, `authenticated`,
`service_role`.

## 4. API de consulta (server functions)

`src/lib/atlas-graph.functions.ts` expone:

- `getAtlasGraph({ federation?, limit })` → `{ nodes, edges }` con view-model.
- `getEoctStream({ limit })` → últimos eventos.
- `getFederationManifest()` → snapshot global.
- `recordEoctEvent(...)` → emite evento al ledger.

Ejemplo de payload:

```json
{
  "nodes": [{
    "id": "uuid", "label": "Atlas Kernel", "type": "SYSTEM",
    "federation": "knowledge",
    "visual": { "color": "#7DD3FC", "size": 14 }
  }],
  "edges": [{ "source": "...", "target": "...", "type": "CONTAINS", "visual": { "width": 2 } }]
}
```

## 5. Render

WebGL/Canvas2D para miles de nodos. Layout force-directed básico en
cliente; planeable mover a WebWorker para >5k nodos. Capas: federación,
clasificación, tiempo, severidad.

## 6. Seguridad

- Separación nodo visual ↔ nodo ejecutable (la UI nunca llama al servicio
  subyacente directamente; pasa por orquestador con RBAC + KORIMA).
- LOD por permisos: usuarios bajos ven macro; sólo `guardian/admin` ven detalle.
- Zero Trust + mTLS futuro (SPIFFE/SPIRE).
- Rate limiting y detección de exploración anómala (Anubis/Horus).
- Redacción de `sensitive/critical`.

## 7. Latencia objetivo

- Eventos críticos: <5s reflejo en UI.
- Cambios de estado: <60s.
- Manifest snapshot: <1s.

A diferencia del WEF (mapa conceptual, latencia horas/días), Atlas es
**sistema nervioso operativo**: el grafo es el reflejo actual del sistema.
