// Aggregated, typed accessors over the canonical Atlas data absorbed from the
// TAMV repositories. Keep imports per-route to allow code splitting.
import kernelSpec from "@/data/atlas-absorbed/atlas-kernel-spec.json";
import systemIndex from "@/data/atlas-absorbed/tamv-system-index.json";
import federationManifest from "@/data/atlas-absorbed/federation-manifest.json";
import federationNodes from "@/data/atlas-absorbed/federation-nodes.json";
import driveSummary from "@/data/atlas-absorbed/drive-summary.json";
import federationProtocol from "@/data/atlas-absorbed/federation-protocol.json";

export const kernel = kernelSpec as any;
export const sysIndex = systemIndex as any;
export const manifest = federationManifest as any;
export const nodes = federationNodes as any;
export const drive = driveSummary as any;
export const protocol = federationProtocol as any;

export type AbsorbedSource = {
  name: string;
  provider: string;
  size: number;
  url: string;
};
