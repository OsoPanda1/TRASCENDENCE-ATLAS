import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { nodes, protocol } from "@/lib/atlas-data";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/atlas/nodos")({
  head: () => ({
    meta: [
      { title: "Nodos Federados · Atlas Explorer" },
      { name: "description", content: "Registro vivo de nodos del bus de federación TAMV: capacidades, eventos publicados, suscripciones." },
    ],
    links: [{ rel: "canonical", href: "/atlas/nodos" }],
  }),
  component: Nodos,
});

function Nodos() {
  const list = nodes.nodes as any[];
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <section className="pt-16 pb-8 px-6">
        <div className="container-atlas">
          <Link to="/atlas" className="label-mono text-quantum inline-flex items-center gap-2 mb-6"><ArrowLeft size={12} /> atlas explorer</Link>
          <div className="label-mono mb-3">// protocolo {nodes.protocol} · kernel {nodes.kernel}</div>
          <h1 className="font-display text-4xl md:text-6xl font-semibold mb-4">{nodes.nodeCount} nodos federados</h1>
          <p className="text-muted-foreground max-w-3xl">
            Registro vivo de nodos conformes a <code className="text-quantum">{protocol.$id || nodes.protocol}</code>. Cada nodo
            declara capacidades, eventos que publica y a los que se suscribe, conformando el bus heptafederado.
          </p>
        </div>
      </section>
      <section className="px-6 pb-20">
        <div className="container-atlas grid md:grid-cols-2 gap-4">
          {list.map((n) => (
            <article key={n.nodeId} className="card-quantum rounded-lg p-5">
              <header className="mb-3">
                <div className="label-mono text-[10px] text-quantum">{n.role}</div>
                <h3 className="font-display text-lg font-semibold">{n.nodeId}</h3>
                <a href={`https://github.com/${n.repository}`} target="_blank" rel="noreferrer" className="text-xs text-muted-foreground hover:text-quantum break-all">{n.repository}</a>
              </header>
              <Tags label="capabilities" items={n.capabilities} />
              <Tags label="publishes" items={n.publishes} kind="signal" />
              <Tags label="subscribes" items={n.subscribes} kind="signal" />
            </article>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}

function Tags({ label, items, kind }: { label: string; items?: string[]; kind?: "signal" }) {
  if (!items?.length) return null;
  return (
    <div className="mt-3">
      <div className="label-mono text-[9px] mb-1">// {label}</div>
      <div className="flex flex-wrap gap-1">
        {items.map((x) => (
          <span key={x} className={`label-mono text-[10px] px-2 py-0.5 rounded border ${kind === "signal" ? "border-quantum/40 text-quantum/90" : "border-border text-muted-foreground"}`}>{x}</span>
        ))}
      </div>
    </div>
  );
}
