import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { PageHero } from "@/components/atlas/PageHero";

export const Route = createFileRoute("/universal")({
  head: () => ({
    meta: [
      { title: "Estándar Universal · Atlas Trascendence" },
      { name: "description", content: "Atlas Trascendence como infraestructura cognitiva universal: especificación abierta, niveles de adopción y relación con TAMV." },
      { property: "og:title", content: "Atlas Trascendence Universal" },
      { property: "og:description", content: "Un metastack neutro: observabilidad, conocimiento, automatización, gobernanza y dignidad como código." },
    ],
    links: [{ rel: "canonical", href: "/universal" }],
  }),
  component: Universal,
});

const capas = [
  ["Capa 0", "Observabilidad", "Salud, métricas, eventos, logs, trazas, dependencias."],
  ["Capa 1", "Telemetría", "Toda acción produce señal estructurada y versionada."],
  ["Capa 2", "Seguridad", "Identidad, mTLS, firma, integridad, secretos, políticas Zero Trust."],
  ["Capa 3", "Gobernanza", "Reglas, aprobación, excepciones, control humano significativo."],
  ["Capa 4", "Conocimiento", "Documentos, ontologías, evidencias, contexto, linaje."],
  ["Capa 5", "Automatización", "Despliegues, sincronización, ingestión, reconciliación."],
  ["Capa 6", "IA", "Clasificación, explicación, detección de anomalías, inferencia."],
  ["Capa 7", "Interfaces", "Paneles, APIs, wikis, agentes, consolas, XR."],
];

const adopcion = [
  ["Level 0", "Observabilidad", "Adopta telemetría y health-checks compatibles con OTEL."],
  ["Level 1", "Observabilidad + Conocimiento", "Suma grafo semántico, evidencias y versionado."],
  ["Level 2", "Observabilidad + Conocimiento + Ética/Ledger", "Suma EOCT, anclajes criptográficos y human-in-the-loop."],
  ["Level 3", "Stack completo", "Implementación civilizatoria total (caso TAMV)."],
];

const fusion = [
  ["GitHub", "Versionado + decisiones + políticas + contexto ético, todo trazado."],
  ["Wikipedia", "Conocimiento vivo con telemetría de uso y gobernanza auditable."],
  ["Termux", "Cliente Atlas portátil: diagnósticos y agentes en cualquier dispositivo."],
  ["Notion", "Espacio cognitivo vinculado a métricas, trazas y ledger."],
  ["Istio", "Tráfico + trazabilidad cognitiva: por qué se enrutó, bajo qué regla."],
  ["Terraform", "Infraestructura + conocimiento + políticas + dignidad como código."],
  ["OpenTelemetry", "Estándar abierto de telemetría como sustrato de observabilidad."],
  ["Google Dev / IBM", "Tooling y contratos sin vendor lock-in."],
];

function Universal() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <PageHero
        eyebrow="// estándar universal"
        title="Un órgano cognitivo universal de infraestructura."
        intro="Atlas Trascendence es un metastack neutro. TAMV es la implementación fundacional; cualquier organización, ciudad, universidad o red puede adoptarlo como GitHub, Wikipedia, Terraform u OpenTelemetry — fusionados bajo un mismo marco de dignidad, soberanía y auditoría."
      />

      <section className="px-6 pb-16">
        <div className="container-atlas grid lg:grid-cols-2 gap-10">
          <article className="card-quantum rounded-lg p-8">
            <div className="label-mono mb-3">// definición</div>
            <h2 className="font-display text-2xl font-semibold mb-4">Infraestructura cognitiva universal</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              No es una app, ni un repositorio, ni un wiki, ni un dashboard. Es un sistema operativo cognitivo
              universal que unifica observabilidad, conocimiento, automatización, gobernanza, memoria y acción
              bajo principios de dignidad, trazabilidad y soberanía técnica.
            </p>
          </article>
          <article className="card-quantum rounded-lg p-8">
            <div className="label-mono mb-3">// principio rector</div>
            <h2 className="font-display text-2xl font-semibold mb-4">Nada existe sin trazabilidad</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Si algo no puede ser <span className="text-foreground">observado, medido, auditado, explicado,
              versionado, recuperado y relacionado con su origen</span>, no pertenece al núcleo de Atlas.
            </p>
          </article>
        </div>
      </section>

      <section className="section px-6 border-t border-border">
        <div className="container-atlas">
          <div className="label-mono mb-3">// capa funcional</div>
          <h2 className="font-display text-3xl md:text-5xl font-semibold max-w-3xl mb-12">
            Ocho capas <span className="text-quantum">apiladas</span>, una sola ontología.
          </h2>
          <div className="space-y-px bg-border border border-border rounded-lg overflow-hidden">
            {capas.map(([n, t, d]) => (
              <div key={n} className="bg-card grid grid-cols-[90px_220px_1fr] gap-6 px-6 py-5 items-center">
                <div className="label-mono text-quantum">{n}</div>
                <div className="font-display font-semibold">{t}</div>
                <div className="text-sm text-muted-foreground">{d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section px-6 border-t border-border">
        <div className="container-atlas">
          <div className="label-mono mb-3">// fusión de paradigmas</div>
          <h2 className="font-display text-3xl md:text-5xl font-semibold max-w-3xl mb-12">
            Lo que GitHub, Wikipedia, Notion, Terraform e Istio hacen por separado, <span className="text-quantum">Atlas lo fusiona</span>.
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-3">
            {fusion.map(([k, v]) => (
              <div key={k} className="hairline rounded-md p-4">
                <div className="font-display font-semibold mb-1">{k}</div>
                <p className="text-xs text-muted-foreground leading-relaxed">{v}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section px-6 border-t border-border">
        <div className="container-atlas">
          <div className="label-mono mb-3">// niveles de adopción</div>
          <h2 className="font-display text-3xl md:text-5xl font-semibold max-w-3xl mb-12">
            Una escala de entrada, <span className="text-quantum">no un todo-o-nada</span>.
          </h2>
          <div className="grid md:grid-cols-2 gap-3">
            {adopcion.map(([lvl, t, d]) => (
              <div key={lvl} className="card-quantum rounded-lg p-6">
                <div className="flex items-center gap-3 mb-2">
                  <span className="label-mono text-quantum">{lvl}</span>
                  <span className="font-display font-semibold">{t}</span>
                </div>
                <p className="text-sm text-muted-foreground">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section px-6 border-t border-border">
        <div className="container-atlas">
          <div className="label-mono mb-3">// relación con TAMV</div>
          <div className="max-w-3xl">
            <p className="text-lg text-muted-foreground leading-relaxed">
              <span className="text-foreground">TAMV</span> aporta el origen, la visión, la soberanía y la doctrina.
              <span className="text-foreground"> Atlas Trascendence</span> aporta la forma universal.
              <span className="text-foreground"> Atlas Genesis</span> es la implementación de referencia.
            </p>
            <p className="mt-6 italic text-quantum/90 font-display text-xl">
              "Lo que no puede observarse no puede gobernarse. Lo que no puede auditarse no puede confiarse.
              Lo que no puede explicarse no pertenece al núcleo."
            </p>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
