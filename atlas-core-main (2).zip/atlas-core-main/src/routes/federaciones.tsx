import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { PageHero } from "@/components/atlas/PageHero";
import { ArchitectureMiniMap } from "@/components/atlas/ArchitectureMiniMap";
import { FEDERATIONS, AXIOMS } from "@/lib/federations";

export const Route = createFileRoute("/federaciones")({
  head: () => ({
    meta: [
      { title: "Heptafederación · Atlas Trascendence" },
      { name: "description", content: "Las 7 federaciones del metasistema Atlas: Conocimiento, Identidad, Gobernanza, Economía, Seguridad, Infraestructura e Inteligencia Artificial." },
      { property: "og:title", content: "Heptafederación · Atlas Trascendence" },
      { property: "og:description", content: "F1–F7: módulos, protocolos y axiomas del kernel civilizatorio." },
    ],
    links: [{ rel: "canonical", href: "/federaciones" }],
  }),
  component: Federaciones,
});

function Federaciones() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <PageHero
        eyebrow="// heptafederación"
        title="Siete federaciones, un solo grafo."
        intro="Cada federación es un dominio soberano del metasistema. Juntas, conforman el órgano cognitivo universal Atlas Trascendence."
      />

      <section className="px-6 pb-16">
        <div className="container-atlas">
          <div className="max-w-3xl mb-12">
            <ArchitectureMiniMap />
          </div>

          <div className="grid md:grid-cols-2 gap-5">
            {FEDERATIONS.map((f) => (
              <article
                key={f.id}
                className="card-quantum rounded-lg p-6"
                style={{ borderColor: `color-mix(in oklch, ${f.color} 40%, transparent)` }}
              >
                <header className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <span
                      className="w-11 h-11 grid place-items-center rounded-md font-display text-xl"
                      style={{ background: `color-mix(in oklch, ${f.color} 18%, transparent)`, color: f.color, border: `1px solid color-mix(in oklch, ${f.color} 45%, transparent)` }}
                    >
                      {f.glyph}
                    </span>
                    <div>
                      <div className="label-mono text-[10px]">{f.index}</div>
                      <h3 className="font-display text-lg font-semibold">{f.name.es}</h3>
                    </div>
                  </div>
                </header>
                <p className="text-sm text-muted-foreground mb-4">{f.essence.es}</p>
                <div className="label-mono text-[10px] mb-2">// módulos</div>
                <ul className="text-sm space-y-1 mb-4">
                  {f.modules.map((m) => (
                    <li key={m.code} className="flex gap-2">
                      <span className="label-mono text-quantum text-[10px] mt-1">{m.code}</span>
                      <span className="text-muted-foreground">{m.name.es} — {m.role.es}</span>
                    </li>
                  ))}
                </ul>
                <div className="label-mono text-[10px] mb-2">// protocolos</div>
                <ul className="text-xs text-muted-foreground space-y-1">
                  {f.protocols.map((p) => (
                    <li key={p.code}>
                      <span className="label-mono text-[10px] mr-2">{p.code}</span>{p.desc.es}
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section px-6 border-t border-border">
        <div className="container-atlas">
          <div className="label-mono mb-3">// axiomas operativos</div>
          <h2 className="font-display text-3xl md:text-5xl font-semibold mb-12 max-w-3xl">
            Diez axiomas <span className="text-quantum">irreducibles</span>.
          </h2>
          <div className="grid md:grid-cols-2 gap-px bg-border border border-border rounded-lg overflow-hidden">
            {AXIOMS.map((a) => (
              <div key={a.code} className="bg-card px-6 py-5 flex gap-4">
                <span className="label-mono text-quantum">{a.code}</span>
                <span className="text-sm">{a.es}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
