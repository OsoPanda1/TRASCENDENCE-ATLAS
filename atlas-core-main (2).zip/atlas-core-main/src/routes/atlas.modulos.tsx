import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { sysIndex } from "@/lib/atlas-data";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/atlas/modulos")({
  head: () => ({
    meta: [
      { title: "Módulos DM-X4 · Atlas Explorer" },
      { name: "description", content: "Índice canónico de los módulos DM-X4: capas, owners, endpoints, métricas, runbooks y gaps accionables." },
    ],
    links: [{ rel: "canonical", href: "/atlas/modulos" }],
  }),
  component: Modulos,
});

function Modulos() {
  const modules = sysIndex.modules as any[];
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <section className="pt-16 pb-8 px-6">
        <div className="container-atlas">
          <Link to="/atlas" className="label-mono text-quantum inline-flex items-center gap-2 mb-6"><ArrowLeft size={12} /> atlas explorer</Link>
          <div className="label-mono mb-3">// {sysIndex.index_version} · {sysIndex.mode}</div>
          <h1 className="font-display text-4xl md:text-6xl font-semibold mb-4">Módulos DM-X4</h1>
          <p className="text-muted-foreground max-w-3xl">
            Mapa canónico de las células operativas del kernel. Cada entrada lista paths de código, endpoints,
            métricas SLO, runbooks y los gaps explícitamente declarados por la doctrina.
          </p>
        </div>
      </section>
      <section className="px-6 pb-20">
        <div className="container-atlas space-y-4">
          {modules.map((m) => (
            <article key={m.id} className="card-quantum rounded-lg p-6">
              <header className="flex flex-wrap items-start justify-between gap-3 mb-4">
                <div>
                  <div className="label-mono text-[10px] text-quantum">{m.id} · {m.layer_domain}</div>
                  <h3 className="font-display text-xl font-semibold mt-1">{m.module}</h3>
                  <div className="text-xs text-muted-foreground mt-1">owner: {m.owner}</div>
                </div>
                <div className="flex gap-2">
                  <span className="chip">{m.status}</span>
                  <span className="chip">{m.maturity}</span>
                </div>
              </header>
              <div className="grid md:grid-cols-2 gap-4 text-xs">
                <Block label="code_paths" items={m.code_paths} />
                <Block label="endpoints" items={m.endpoints} />
                <Block label="metrics" items={m.metrics} />
                <Block label="runbooks" items={m.runbooks} />
                <Block label="canonical_sources" items={m.canonical_sources} />
                <Block label="actionable_gaps" items={m.actionable_gaps} warn />
              </div>
            </article>
          ))}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}

function Block({ label, items, warn = false }: { label: string; items: string[]; warn?: boolean }) {
  if (!items?.length) return null;
  return (
    <div className="hairline rounded-md p-3">
      <div className={`label-mono text-[10px] mb-2 ${warn ? "text-destructive" : "text-quantum"}`}>// {label}</div>
      <ul className="space-y-1 font-mono text-[11px] text-muted-foreground">
        {items.map((i) => <li key={i} className="break-all">· {i}</li>)}
      </ul>
    </div>
  );
}
