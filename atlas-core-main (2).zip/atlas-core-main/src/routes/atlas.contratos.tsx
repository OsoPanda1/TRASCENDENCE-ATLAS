import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { protocol, nodes } from "@/lib/atlas-data";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/atlas/contratos")({
  head: () => ({
    meta: [
      { title: "Contratos & Protocolo · Atlas Explorer" },
      { name: "description", content: "Esquema canónico tamv-federation-v1 que rige a cada nodo federado." },
    ],
    links: [{ rel: "canonical", href: "/atlas/contratos" }],
  }),
  component: Contratos,
});

function Contratos() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <section className="pt-16 pb-8 px-6">
        <div className="container-atlas">
          <Link to="/atlas" className="label-mono text-quantum inline-flex items-center gap-2 mb-6"><ArrowLeft size={12} /> atlas explorer</Link>
          <div className="label-mono mb-3">// json-schema · {nodes.protocol}</div>
          <h1 className="font-display text-4xl md:text-6xl font-semibold mb-4">Protocolo federación v1</h1>
          <p className="text-muted-foreground max-w-3xl">
            Cada nodo del bus heptafederado debe validar contra este esquema. Define identidad de nodo,
            capacidades declaradas, contratos de eventos y reglas de pertenencia al kernel canónico.
          </p>
        </div>
      </section>
      <section className="px-6 pb-20">
        <div className="container-atlas">
          <pre className="hairline rounded-md p-5 font-mono text-[11px] leading-relaxed whitespace-pre-wrap overflow-x-auto text-muted-foreground">
{JSON.stringify(protocol, null, 2)}
          </pre>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
