import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { PageHero } from "@/components/atlas/PageHero";
import { kernel, drive, manifest, nodes, sysIndex } from "@/lib/atlas-data";
import { Database, Network, FileText, Boxes, Cpu, Layers } from "lucide-react";

export const Route = createFileRoute("/atlas")({
  head: () => ({
    meta: [
      { title: "Atlas Explorer — TAMV Atlas Trascendence" },
      { name: "description", content: "Explorador del grafo Atlas: kernel, módulos DM-X4, nodos federados, inventario absorbido y catálogo de servicios." },
      { property: "og:title", content: "Atlas Explorer" },
      { property: "og:description", content: "Conocimiento absorbido en vivo desde los repositorios canónicos TAMV." },
    ],
    links: [{ rel: "canonical", href: "/atlas" }],
  }),
  component: AtlasIndex,
});

function AtlasIndex() {
  const k = kernel.kernel;
  const status = k.status as Record<string, number>;
  const cards = [
    { to: "/atlas/kernel", icon: Cpu, label: "Kernel Spec", desc: `${k.codename} v${k.version} · ${k.architecture}`, n: Object.keys(kernel.federations).length, unit: "federaciones runtime" },
    { to: "/atlas/modulos", icon: Layers, label: "Módulos DM-X4", desc: `Índice ${sysIndex.index_version} · ${sysIndex.mode}`, n: sysIndex.modules.length, unit: "módulos canónicos" },
    { to: "/atlas/nodos", icon: Network, label: "Nodos Federados", desc: `Protocolo ${nodes.protocol} · Kernel ${nodes.kernel}`, n: nodes.nodeCount, unit: "nodos activos" },
    { to: "/atlas/inventario", icon: Database, label: "Inventario Absorbido", desc: `Drive + OneDrive · snapshot ${new Date(drive.generatedAt).toISOString().slice(0,10)}`, n: drive.totals.all, unit: "documentos canónicos" },
    { to: "/atlas/catalogo", icon: Boxes, label: "Catálogo Federación", desc: `Nexus + Frontier · ${manifest.sources.length} repos`, n: manifest.catalog.nexus_services.length + manifest.catalog.frontier_core_modules.length, unit: "servicios y módulos" },
    { to: "/atlas/contratos", icon: FileText, label: "Contratos & Protocolo", desc: `${federationManifestExt(manifest)} archivos contractuales`, n: 1, unit: "esquema federation-v1" },
  ];
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <PageHero
        eyebrow="// atlas explorer"
        title="El grafo absorbido, navegable."
        intro={`Datos canónicos cargados desde los repositorios TAMV — ${drive.totals.all} documentos doctrinales, ${sysIndex.modules.length} módulos DM-X4, ${nodes.nodeCount} nodos federados y ${manifest.catalog.nexus_services.length} servicios Nexus. Nada de mock: cada vista es un dump del estado real absorbido.`}
      />

      <section className="px-6 pb-16">
        <div className="container-atlas">
          <div className="grid md:grid-cols-2 gap-px bg-border border border-border rounded-lg overflow-hidden mb-12">
            {Object.entries(status).map(([k, v]) => (
              <div key={k} className="bg-card p-5">
                <div className="flex items-center justify-between mb-2">
                  <span className="label-mono text-[10px]">{k.replace(/_/g, " ")}</span>
                  <span className="font-display text-quantum">{Math.round(v * 100)}%</span>
                </div>
                <div className="h-1.5 bg-background rounded overflow-hidden">
                  <div className="h-full bg-quantum" style={{ width: `${v * 100}%` }} />
                </div>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {cards.map((c) => (
              <Link key={c.to} to={c.to} className="card-quantum rounded-lg p-6 group">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-11 h-11 grid place-items-center rounded-md bg-quantum/10 border border-quantum/30">
                    <c.icon size={20} className="text-quantum" />
                  </div>
                  <div className="text-right">
                    <div className="font-display text-2xl text-gradient-quantum">{c.n}</div>
                    <div className="label-mono text-[9px]">{c.unit}</div>
                  </div>
                </div>
                <h3 className="font-display font-semibold text-lg mb-1 group-hover:text-quantum transition-colors">{c.label}</h3>
                <p className="text-sm text-muted-foreground">{c.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}

function federationManifestExt(m: any): number {
  return m.catalog.nexus_migrations.length + m.catalog.nexus_edge_functions.length;
}
