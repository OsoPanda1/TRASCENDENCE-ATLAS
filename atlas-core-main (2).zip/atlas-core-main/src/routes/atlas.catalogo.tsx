import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { manifest } from "@/lib/atlas-data";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/atlas/catalogo")({
  head: () => ({
    meta: [
      { title: "Catálogo Federación · Atlas Explorer" },
      { name: "description", content: "Catálogo unificado Nexus + Frontier: servicios, edge functions, migraciones, módulos core y páginas." },
    ],
    links: [{ rel: "canonical", href: "/atlas/catalogo" }],
  }),
  component: Catalogo,
});

const SECTIONS: { key: string; label: string }[] = [
  { key: "nexus_services", label: "Nexus · servicios" },
  { key: "nexus_edge_functions", label: "Nexus · edge functions" },
  { key: "nexus_migrations", label: "Nexus · migraciones" },
  { key: "frontier_core_modules", label: "Frontier · core modules" },
  { key: "frontier_pages", label: "Frontier · pages" },
];

function Catalogo() {
  const c = manifest.catalog as Record<string, any[]>;
  const sources = manifest.sources as any[];
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <section className="pt-16 pb-8 px-6">
        <div className="container-atlas">
          <Link to="/atlas" className="label-mono text-quantum inline-flex items-center gap-2 mb-6"><ArrowLeft size={12} /> atlas explorer</Link>
          <div className="label-mono mb-3">// snapshot {new Date(manifest.generated_at).toISOString().slice(0, 10)}</div>
          <h1 className="font-display text-4xl md:text-6xl font-semibold mb-4">Catálogo Federación</h1>
          <div className="grid md:grid-cols-2 gap-3 mb-8">
            {sources.map((s) => (
              <a key={s.repo} href={s.url} target="_blank" rel="noreferrer" className="hairline rounded-md p-4 hover:border-quantum/60 transition">
                <div className="label-mono text-[10px] text-quantum mb-1">{s.local}</div>
                <div className="font-mono text-sm break-all">{s.repo}</div>
              </a>
            ))}
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-px bg-border border border-border rounded-lg overflow-hidden">
            {manifest.stats.map((st: any) => (
              <div key={st.name} className="bg-card p-4">
                <div className="font-display text-2xl text-gradient-quantum">{st.file_count}</div>
                <div className="label-mono text-[9px]">{st.name}</div>
                <div className="label-mono text-[9px] mt-1 text-muted-foreground">{Math.round(st.total_bytes / 1024)} KB</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 pb-20">
        <div className="container-atlas space-y-10">
          {SECTIONS.map(({ key, label }) => {
            const items = c[key] ?? [];
            return (
              <div key={key}>
                <div className="flex items-end justify-between mb-3">
                  <h2 className="font-display text-xl font-semibold">{label}</h2>
                  <span className="label-mono text-[10px]">{items.length} entradas</span>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-2">
                  {items.map((it: any, i: number) => (
                    <div key={i} className="hairline rounded-md p-3 font-mono text-[11px] break-all">
                      <div className="text-foreground">{it.name ?? it.path ?? it}</div>
                      {it.path && <div className="text-muted-foreground text-[10px] mt-1">{it.path}</div>}
                      {it.description && <div className="text-muted-foreground text-[10px] mt-1">{it.description}</div>}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
