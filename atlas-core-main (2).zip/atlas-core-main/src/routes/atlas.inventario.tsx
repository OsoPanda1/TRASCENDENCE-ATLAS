import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { drive } from "@/lib/atlas-data";
import inventory from "@/data/atlas-absorbed/drive-inventory.json";
import { ArrowLeft, ExternalLink, Search } from "lucide-react";

export const Route = createFileRoute("/atlas/inventario")({
  head: () => ({
    meta: [
      { title: "Inventario Absorbido · Atlas Explorer" },
      { name: "description", content: "Documentos canónicos absorbidos desde Google Drive y OneDrive: doctrina, ecosistema, contratos, blueprints." },
    ],
    links: [{ rel: "canonical", href: "/atlas/inventario" }],
  }),
  component: Inventario,
});

type Item = { name: string; provider: string; size?: number; url?: string; category?: string };

function Inventario() {
  const all = useMemo(() => {
    const flat: Item[] = [];
    const inv = inventory as any;
    const arrays = Array.isArray(inv) ? inv : Object.values(inv).find((v) => Array.isArray(v));
    if (Array.isArray(arrays)) {
      for (const it of arrays as any[]) {
        flat.push({
          name: it.name ?? it.title ?? "(sin nombre)",
          provider: it.provider ?? "?",
          size: it.size,
          url: it.url,
          category: it.category ?? it.tag ?? "otro",
        });
      }
    }
    return flat;
  }, []);
  const [cat, setCat] = useState<string>("doctrina");
  const [q, setQ] = useState("");
  const cats = Object.keys(drive.byCategory) as string[];
  const filtered = useMemo(() => {
    return all
      .filter((i) => (cat === "*" ? true : i.category === cat))
      .filter((i) => (q ? i.name.toLowerCase().includes(q.toLowerCase()) : true))
      .slice(0, 200);
  }, [all, cat, q]);

  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <section className="pt-16 pb-8 px-6">
        <div className="container-atlas">
          <Link to="/atlas" className="label-mono text-quantum inline-flex items-center gap-2 mb-6"><ArrowLeft size={12} /> atlas explorer</Link>
          <div className="label-mono mb-3">// snapshot {new Date(drive.generatedAt).toISOString().slice(0, 10)}</div>
          <h1 className="font-display text-4xl md:text-6xl font-semibold mb-4">{drive.totals.all} documentos absorbidos</h1>
          <div className="flex flex-wrap gap-2 mb-6">
            <span className="chip">Google Drive · {drive.totals.google_drive}</span>
            <span className="chip">OneDrive · {drive.totals.microsoft_onedrive}</span>
          </div>
          <div className="grid grid-cols-3 md:grid-cols-9 gap-px bg-border border border-border rounded-lg overflow-hidden">
            {cats.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`bg-card px-3 py-3 text-center transition-colors ${cat === c ? "text-quantum" : "text-muted-foreground hover:text-foreground"}`}
              >
                <div className="font-display text-lg">{(drive.byCategory as any)[c]}</div>
                <div className="label-mono text-[9px]">{c}</div>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 pb-20">
        <div className="container-atlas">
          <div className="hairline rounded-md p-3 flex items-center gap-3 mb-4">
            <Search size={14} className="text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Buscar documento por nombre…"
              className="flex-1 bg-transparent outline-none text-sm placeholder:text-muted-foreground"
            />
            <button onClick={() => setCat("*")} className="label-mono text-[10px] text-quantum">todas las categorías</button>
          </div>
          <div className="space-y-px bg-border border border-border rounded-lg overflow-hidden">
            {filtered.map((it, i) => (
              <a
                key={i}
                href={it.url ?? "#"}
                target="_blank"
                rel="noreferrer"
                className="bg-card grid grid-cols-[100px_1fr_auto] gap-4 px-4 py-3 items-center hover:bg-card/70 transition-colors"
              >
                <span className="label-mono text-[10px]">{it.provider.replace("_", " ")}</span>
                <span className="text-sm truncate">{it.name}</span>
                <span className="label-mono text-[10px] text-muted-foreground flex items-center gap-2">
                  {it.size ? `${Math.round(it.size / 1024)} KB` : ""} <ExternalLink size={11} />
                </span>
              </a>
            ))}
            {!filtered.length && <div className="bg-card p-6 text-center text-sm text-muted-foreground">Sin resultados.</div>}
          </div>
          <p className="label-mono text-[10px] mt-3 text-muted-foreground">Mostrando primeros 200 resultados · filtro vivo cliente.</p>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
