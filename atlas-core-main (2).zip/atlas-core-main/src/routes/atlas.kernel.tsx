import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { kernel } from "@/lib/atlas-data";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/atlas/kernel")({
  head: () => ({
    meta: [
      { title: "Kernel Spec · Atlas Explorer" },
      { name: "description", content: "Especificación completa del Atlas Kernel: runtime, gateway, federaciones, pipeline, seguridad y observabilidad." },
    ],
    links: [{ rel: "canonical", href: "/atlas/kernel" }],
  }),
  component: KernelView,
});

function KernelView() {
  const k = kernel.kernel;
  const rt = kernel.runtime;
  const fed = kernel.federations as Record<string, any>;
  const sec = kernel.security;
  const obs = kernel.observability;
  const pa = kernel.professional_assessment;

  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />

      <section className="pt-16 pb-12 px-6">
        <div className="container-atlas">
          <Link to="/atlas" className="label-mono text-quantum inline-flex items-center gap-2 mb-6"><ArrowLeft size={12} /> atlas explorer</Link>
          <div className="label-mono mb-3">// kernel spec · {k.version}</div>
          <h1 className="font-display text-4xl md:text-6xl font-semibold mb-4">{k.name}</h1>
          <div className="flex flex-wrap gap-2 mb-6">
            {[k.codename, k.architecture, k.mode, k.classification].map((t: string) => (
              <span key={t} className="chip">{t}</span>
            ))}
          </div>
          <p className="text-muted-foreground max-w-3xl">{k.description}</p>
        </div>
      </section>

      <Section title="Misión · Visión · Objetivos">
        <div className="grid md:grid-cols-2 gap-5">
          <Card label="Misión" text={k.mission} />
          <Card label="Visión" text={k.vision} />
        </div>
        <ul className="mt-6 grid md:grid-cols-2 gap-2">
          {k.objectives.map((o: string) => (
            <li key={o} className="hairline rounded-md p-3 text-sm flex gap-2">
              <span className="text-quantum">▸</span>
              <span>{o}</span>
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Gateway · OmniKernelGatewayX6">
        <div className="hairline rounded-md p-5 font-mono text-xs">
          <div className="grid md:grid-cols-2 gap-4">
            <KV k="engine" v={rt.gateway.engine} />
            <KV k="modes" v={rt.gateway.modes.join(" · ")} />
            <KV k="rate window" v={`${rt.gateway.features.rate_limiting.window_ms}ms`} />
            <KV k="max req/window" v={rt.gateway.features.rate_limiting.max_requests_per_window} />
            <KV k="daily quota" v={rt.gateway.features.rate_limiting.per_user_daily_quota} />
            <KV k="replay protection" v={rt.gateway.features.replay_protection.enabled ? "enabled · redis" : "off"} />
            <KV k="max payload" v={`${rt.gateway.features.payload_constraints.max_payload_bytes} bytes`} />
          </div>
        </div>
      </Section>

      <Section title="Federaciones runtime">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(fed).map(([id, f]: [string, any]) => (
            <div key={id} className="card-quantum rounded-lg p-5">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-display font-semibold uppercase tracking-wide">{id}</h4>
                <span className={`label-mono text-[10px] ${f.priority === "critical" ? "text-quantum" : ""}`}>{f.priority}</span>
              </div>
              <div className="label-mono text-[10px] mb-3">{f.role}</div>
              <ul className="text-xs text-muted-foreground space-y-1">
                {f.modules?.map((m: string) => <li key={m}>· {m}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Seguridad">
        <div className="grid md:grid-cols-2 gap-4">
          {Object.entries(sec).map(([k, v]: any) => (
            <div key={k} className="hairline rounded-md p-4">
              <div className="label-mono text-[10px] mb-2">{k}</div>
              <pre className="font-mono text-[11px] whitespace-pre-wrap text-muted-foreground">{JSON.stringify(v, null, 2)}</pre>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Observabilidad">
        <div className="grid md:grid-cols-2 gap-4">
          {Object.entries(obs).map(([k, v]: any) => (
            <div key={k} className="hairline rounded-md p-4">
              <div className="label-mono text-[10px] mb-2">{k}</div>
              <pre className="font-mono text-[11px] whitespace-pre-wrap text-muted-foreground">{JSON.stringify(v, null, 2)}</pre>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Assessment profesional">
        <div className="grid md:grid-cols-2 gap-4">
          {Object.entries(pa).map(([k, v]: any) => (
            <div key={k} className="hairline rounded-md p-4">
              <div className="label-mono text-[10px] mb-2">{k}</div>
              {Array.isArray(v) ? (
                <ul className="text-sm space-y-1">{v.map((x: any, i: number) => <li key={i} className="text-muted-foreground">· {typeof x === "string" ? x : JSON.stringify(x)}</li>)}</ul>
              ) : (
                <pre className="font-mono text-[11px] whitespace-pre-wrap text-muted-foreground">{JSON.stringify(v, null, 2)}</pre>
              )}
            </div>
          ))}
        </div>
      </Section>

      <SiteFooter />
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="section px-6 border-t border-border">
      <div className="container-atlas">
        <div className="label-mono mb-3">// {title.toLowerCase()}</div>
        <h2 className="font-display text-2xl md:text-3xl font-semibold mb-8">{title}</h2>
        {children}
      </div>
    </section>
  );
}
function KV({ k, v }: { k: string; v: any }) {
  return <div className="flex justify-between gap-3 border-b border-border/40 py-1"><span className="text-muted-foreground">{k}</span><span className="text-foreground">{String(v)}</span></div>;
}
function Card({ label, text }: { label: string; text: string }) {
  return (
    <div className="card-quantum rounded-lg p-5">
      <div className="label-mono mb-2 text-[10px]">{label}</div>
      <p className="text-sm text-muted-foreground leading-relaxed">{text}</p>
    </div>
  );
}
