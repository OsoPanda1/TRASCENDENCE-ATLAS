import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { PageHero } from "@/components/atlas/PageHero";

export const Route = createFileRoute("/servicios")({
  head: () => ({
    meta: [
      { title: "Servicios Federados — TAMV Atlas Trascendence" },
      { name: "description", content: "Identidad, educación UTAMV, economía Lucrum Prime y gobernanza digital sobre el runtime Atlas." },
      { property: "og:title", content: "Servicios Federados" },
      { property: "og:url", content: "/servicios" },
    ],
    links: [{ rel: "canonical", href: "/servicios" }],
  }),
  component: Page,
});

const services = [
  { t: "Identidad Digital", d: "Perfiles verificables para personas, organizaciones, territorios y sistemas. Linajes científicos, claims firmados, reputación auditable.", features: ["Verifiable Credentials", "DID resolvers", "Reputación contextual", "Linajes AKAÉ"] },
  { t: "UTAMV · Educación", d: "Universidad TAMV. Cursos, certificaciones, badges y trayectorias formativas ancladas al grafo de conocimiento.", features: ["Currícula como grafo", "Badges firmados", "Trayectorias adaptativas", "Anclaje BookPI"] },
  { t: "Lucrum Prime · Economía", d: "Modelo económico federado. Compra a $0.004 USD / canje a $0.002 USD. Membresías escalables y flujos de valor auditados.", features: ["Free → Celestial", "Premium $19.90", "VIP $24.99", "Gold/Elite/Celestial", "Marketplace auditado"] },
  { t: "Gobernanza Digital", d: "Votaciones, propuestas, reglamentos, decisiones colegiadas y trazabilidad política completa.", features: ["Propuestas firmadas", "Quórum verificable", "Apelación auditada", "Constitución compilada"] },
  { t: "Reputación & Confianza", d: "Registros de cumplimiento, sanciones, permisos y riesgos. Reputación que no se inventa: se demuestra.", features: ["Sanciones reversibles", "Reputación por contexto", "Decay temporal", "Apelación pública"] },
  { t: "TAMV Frontier", d: "Portal unificado de acceso. Single sign-on al Atlas: cualquier proyecto, espacio o herramienta desde un solo punto.", features: ["SSO federado", "Permisos contextuales", "Mapa de proyectos", "Onboarding territorial"] },
];

function Page() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <PageHero
        eyebrow="// servicios federados"
        title={<>SDK de <span className="text-quantum">civilización digital</span>.</>}
        intro="Identidad, educación, economía y gobernanza como servicios componibles. Cualquiera puede construir una universidad, una ciudad digital, una red de proyectos o un metaverso serio sobre estas APIs."
      />

      <section className="px-6 pb-32">
        <div className="container-atlas">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {services.map((s, i) => (
              <div key={s.t} className="card-quantum rounded-lg p-7">
                <span className="label-mono text-[10px]">service · 0{i + 1}</span>
                <h3 className="font-display text-xl font-semibold mt-3 mb-3">{s.t}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-5">{s.d}</p>
                <ul className="space-y-1.5">
                  {s.features.map((f) => (
                    <li key={f} className="font-mono text-[11px] text-foreground/70 flex items-center gap-2">
                      <span className="w-1 h-1 rounded-full bg-quantum" /> {f}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
