import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { PageHero } from "@/components/atlas/PageHero";
import { Shield, Lock, Eye, AlertTriangle, KeyRound, Scale } from "lucide-react";
import anubisImg from "@/assets/anubis.png.asset.json";

export const Route = createFileRoute("/seguridad")({
  head: () => ({
    meta: [
      { title: "Seguridad — TAMV Atlas Trascendence" },
      { name: "description", content: "Anubis Sentinel System, Dekateotl Security, criptografía post-cuántica y guardianes constitucionales." },
      { property: "og:title", content: "Seguridad" },
      { property: "og:url", content: "/seguridad" },
    ],
    links: [{ rel: "canonical", href: "/seguridad" }],
  }),
  component: Page,
});

const pillars = [
  { icon: Shield, t: "Anubis Sentinel System™", d: "Sistema de protección integral con capas de IA, cifrado post-cuántico y gestión de claves centralizada. Detección, contención y respuesta orquestadas." },
  { icon: Eye, t: "Dekateotl Security", d: "Marco ofensivo/defensivo. Red teaming continuo, threat hunting y detección de anomalías sobre el grafo Atlas." },
  { icon: KeyRound, t: "Criptografía Post-Cuántica", d: "Canales y firmas resistentes a adversarios cuánticos. Migración gradual de primitivas clásicas a híbridas Kyber/Dilithium." },
  { icon: Scale, t: "Guardianes Constitucionales", d: "Módulos que hacen cumplir en runtime la constitución digital, las políticas éticas y las reglas territoriales. La política no es decoración." },
  { icon: Lock, t: "Zero-Trust entre Servicios", d: "Nada confía por defecto. mTLS, identidades de workload, mínimo privilegio y rotación automática de credenciales." },
  { icon: AlertTriangle, t: "SIEM & Decision Forensics", d: "Telemetría centralizada, alertas correlacionadas, respuesta coordinada y reconstrucción forense de cualquier decisión crítica." },
];

function Page() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <PageHero
        eyebrow="// confianza"
        title={<>Secure by design, <span className="text-quantum">no como parche.</span></>}
        intro="La capa que convierte a Atlas en aceptable para gobiernos, universidades, comunidades y territorios. La seguridad y la gobernanza se cimentan ANTES del código de negocio, no después del primer incidente."
      />

      <section className="px-6 pb-32">
        <div className="container-atlas">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {pillars.map((p, i) => (
              <div key={p.t} className="card-quantum rounded-lg p-7">
                <div className="flex items-start justify-between mb-5">
                  <div className="w-11 h-11 grid place-items-center rounded-md bg-quantum/10 border border-quantum/30">
                    <p.icon size={20} className="text-quantum" />
                  </div>
                  <span className="label-mono text-[10px]">pillar · 0{i + 1}</span>
                </div>
                <h3 className="font-display text-xl font-semibold mb-2">{p.t}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{p.d}</p>
              </div>
            ))}
          </div>

          <div className="mt-16 card-quantum rounded-lg p-8 md:p-12">
            <div className="label-mono mb-4">// modelo de amenaza</div>
            <h3 className="font-display text-2xl md:text-3xl font-semibold mb-6">Qué protegemos. De quién.</h3>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <div className="label-mono mb-3 text-foreground">Qué protegemos</div>
                <ul className="space-y-2 text-muted-foreground text-sm">
                  <li>· Datos de identidad y linajes AKAÉ</li>
                  <li>· Conocimiento custodiado (BookPI)</li>
                  <li>· Decisiones colegiadas y votos</li>
                  <li>· Tokens económicos y flujos Lucrum</li>
                  <li>· Claves criptográficas y secretos</li>
                </ul>
              </div>
              <div>
                <div className="label-mono mb-3 text-foreground">Adversarios contemplados</div>
                <ul className="space-y-2 text-muted-foreground text-sm">
                  <li>· Internos malintencionados</li>
                  <li>· Externos automáticos (bots, ransomware)</li>
                  <li>· Externos dirigidos (APT)</li>
                  <li>· Adversarios estatales</li>
                  <li>· Adversarios cuánticos futuros</li>
                </ul>
              </div>
            </div>
          </div>

          {/* TRIBUTO ANUBIS VILLASEÑOR */}
          <div className="mt-16 card-quantum rounded-lg overflow-hidden grid md:grid-cols-[minmax(0,1fr)_1.2fr]">
            <div className="relative bg-black">
              <img
                src={anubisImg.url}
                alt="Anubis Villaseñor — Leyenda Urbana · Alianzas LATAM"
                className="w-full h-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent to-background/30 pointer-events-none" />
            </div>
            <div className="p-8 md:p-10">
              <div className="label-mono mb-3 text-quantum">// tributo · guardián simbólico</div>
              <h3 className="font-display text-2xl md:text-3xl font-semibold mb-4">
                Anubis Villaseñor — <span className="text-quantum">Leyenda Urbana</span>
              </h3>
              <p className="label-mono text-[11px] mb-5 normal-case tracking-wide text-muted-foreground">
                Alianzas LATAM · 2020 – 2025/35 · Orgullosamente Realmontense
              </p>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                El módulo Anubis Sentinel hereda su nombre de la leyenda urbana latinoamericana de
                Alianzas LATAM: el guardián que pesa el corazón de cada acción antes de dejarla pasar.
                Custodia los umbrales del grafo, certifica el linaje de cada evento y sella la frontera
                entre lo verificable y lo descartado.
              </p>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Convive con <span className="text-foreground">Horus</span> (observación continua),
                <span className="text-foreground"> Dekateotl</span> (política constitucional) y los
                <span className="text-foreground"> Aztek Gods</span> de Tenochtitlan (clusters de
                respuesta de alto impacto). Cuatro guardianías, un mismo plano heptafederado.
              </p>
            </div>
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
