import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { PageHero } from "@/components/atlas/PageHero";

export const Route = createFileRoute("/kernels")({
  head: () => ({
    meta: [
      { title: "Kernels — TAMV Atlas Trascendence" },
      { name: "description", content: "Núcleos de ejecución: tracing, métricas, reglas, IA, economía y gobernanza. La JVM civilizatoria de Atlas." },
      { property: "og:title", content: "Kernels" },
      { property: "og:url", content: "/kernels" },
    ],
    links: [{ rel: "canonical", href: "/kernels" }],
  }),
  component: Page,
});

const kernels = [
  { id: "@atlas/kernel-tracing", t: "Tracing Kernel", d: "AsyncLocalStorage compartido. Cada operación critical lleva traceId, correlationId y userId. Reconstrucción forense de cualquier decisión.", apis: ["startSpan()", "endSpan()", "currentContext()", "decisionLog()"] },
  { id: "@atlas/kernel-metrics", t: "Métricas LTOS", d: "RED (Rate/Errors/Duration), USE (Utilization/Saturation/Errors), AI (latencia/tokens/groundedness), Territorial (densidad/cobertura).", apis: ["counter()", "histogram()", "territorialGauge()"] },
  { id: "@atlas/kernel-rules", t: "Rules Kernel", d: "Compila políticas declarativas a checks ejecutables en runtime. Cada acceso pasa por el evaluador de políticas.", apis: ["compile()", "evaluate()", "explain()"] },
  { id: "@atlas/kernel-ai", t: "Isabella Cognitive Kernel", d: "Memoria jerárquica, grafo + embeddings, razonamiento multi-paso con trazabilidad, orquestación de micro-agentes y guardrails.", apis: ["recall()", "reason()", "delegate()", "guard()"] },
  { id: "@atlas/kernel-economy", t: "Lucrum Prime Kernel", d: "Membresías Free → Celestial, monetización digital, flujos de valor entre actores, donaciones y marketplaces auditados.", apis: ["mint()", "redeem()", "settle()", "audit()"] },
  { id: "@atlas/kernel-governance", t: "Governance Kernel", d: "Votaciones, propuestas, reglamentos, decisiones colegiadas. Trazabilidad política completa.", apis: ["propose()", "vote()", "ratify()", "challenge()"] },
];

function Page() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <PageHero
        eyebrow="// kernels"
        title={<>Núcleos de ejecución. <span className="text-quantum">El runtime que todo lo demás hereda.</span></>}
        intro="Cada kernel es un módulo independiente, versionado y observable. Toda app, servicio o territorio sobre Atlas usa estos kernels en lugar de reinventar las mismas capas una y otra vez."
      />

      <section className="px-6 pb-32">
        <div className="container-atlas">
          <div className="grid md:grid-cols-2 gap-5">
            {kernels.map((k, i) => (
              <div key={k.id} className="card-quantum rounded-lg p-7">
                <div className="flex items-start justify-between mb-4">
                  <span className="label-mono text-[10px]">kernel · 0{i + 1}</span>
                  <span className="pulse-dot" />
                </div>
                <h3 className="font-display text-2xl font-semibold mb-1">{k.t}</h3>
                <code className="font-mono text-xs text-quantum">{k.id}</code>
                <p className="text-sm text-muted-foreground leading-relaxed mt-4 mb-5">{k.d}</p>
                <div className="flex flex-wrap gap-1.5">
                  {k.apis.map((api) => (
                    <code key={api} className="font-mono text-[11px] px-2 py-1 rounded bg-background/60 border border-border text-foreground/70">
                      {api}
                    </code>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
