import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { PageHero } from "@/components/atlas/PageHero";
import { CheckCircle2, Circle, Loader } from "lucide-react";

export const Route = createFileRoute("/roadmap")({
  head: () => ({
    meta: [
      { title: "Roadmap — TAMV Atlas Trascendence" },
      { name: "description", content: "Fases 0 a 7: doctrina, Security 02, RBAC/ABAC, Observabilidad 03, Atlas Schema EOCT/GEMET, gobernanza federada y visualización." },
      { property: "og:title", content: "Roadmap heptafederado" },
      { property: "og:url", content: "/roadmap" },
    ],
    links: [{ rel: "canonical", href: "/roadmap" }],
  }),
  component: Page,
});

const phases = [
  {
    s: "active",
    q: "Fase 0",
    t: "Doctrina + glosario",
    d: "Atlas Doctrine v0: 7 federaciones, sistemas clave (EOCT, GEMET, CITEMESH, 4L, SDMD-7, KORIMA, BookPI, MSR, ELITE HEHEP). Reglas inmutables para la AI.",
    artifact: "docs/atlas-doctrine-v0.md",
  },
  {
    s: "active",
    q: "Fase 1",
    t: "Security 02 · Zero Trust",
    d: "Modelo de identidades federadas (OIDC/SAML para humanos, JWT m2m para servicios). mTLS, segmentación, HSM/KMS, baseline de hardening.",
    artifact: "security/zero-trust-architecture-atlas.md",
  },
  {
    s: "next",
    q: "Fase 2",
    t: "RBAC / ABAC",
    d: "Roles base, atributos por federación, matriz de permisos para EOCT, GEMET, CITEMESH, kernels. Policies ejecutables tipo OPA.",
    artifact: "security/policies/atlas-policies-v1.yaml",
  },
  {
    s: "next",
    q: "Fase 3",
    t: "Kernel de Observabilidad 03",
    d: "Métricas RED/USE/AI/Territorial, tracing W3C, audit trail anclado a BookPI/MSR. Radares Ojo de Ra y Quetzalcóatl con guardianías.",
    artifact: "observability/metrics-spec-atlas-v1.md",
  },
  {
    s: "planned",
    q: "Fase 4",
    t: "Atlas Schema EOCT + GEMET",
    d: "Ontologías formales: eventos, twins territoriales, estados, relaciones. Conexión bidireccional con spans y métricas.",
    artifact: "atlas/schema/eoct-ontology-v1.yaml",
  },
  {
    s: "planned",
    q: "Fase 5",
    t: "Gobernanza federada",
    d: "Protocolos de cambio, gestión de incidentes, flujos KORIMA Codex. Traducción a policies, configs y guardrails de IA.",
    artifact: "governance/federated-governance-protocols-v1.md",
  },
  {
    s: "future",
    q: "Fase 6",
    t: "Script unificado de despliegue",
    d: "Playbooks IaC que crean identidades federadas, mTLS, policies RBAC/ABAC, logging y métricas. Validaciones automáticas.",
    artifact: "deploy/atlas-security-baseline-and-rbac.ts",
  },
  {
    s: "future",
    q: "Fase 7",
    t: "Roadmap + arquitectura interactiva",
    d: "Diagrama heptafederado navegable y roadmap consumiendo la documentación como única fuente de verdad.",
    artifact: "explorer/atlas-architecture-graph.json",
  },
];

const icon = (s: string) =>
  s === "done" ? <CheckCircle2 size={20} className="text-quantum" /> :
  s === "active" ? <Loader size={20} className="text-quantum animate-spin" style={{ animationDuration: "3s" }} /> :
  <Circle size={20} className="text-muted-foreground" />;

function Page() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <PageHero
        eyebrow="// roadmap heptafederado"
        title={<>Ocho fases. <span className="text-quantum">Cero atajos.</span></>}
        intro="No pienses en meses: piensa en orden de artefactos. Nada de apps ni pantallas hasta que Security 02, RBAC, Kernel de Observabilidad 03 y Atlas Schema EOCT/GEMET estén definidos, versionados y auditados."
      />

      <section className="px-6 pb-32">
        <div className="container-atlas">
          <div className="relative pl-8 md:pl-12">
            <div className="absolute left-2 md:left-4 top-2 bottom-2 w-px bg-border" />
            <div className="space-y-6">
              {phases.map((p, i) => (
                <div key={i} className="relative">
                  <div className="absolute -left-8 md:-left-12 top-7 w-6 h-6 grid place-items-center rounded-full bg-background border border-border">
                    {icon(p.s)}
                  </div>
                  <div className="card-quantum rounded-lg p-6 md:p-7">
                    <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                      <span className="label-mono text-quantum">{p.q}</span>
                      <span className="label-mono text-[10px] px-2 py-1 rounded border border-border bg-background/40">
                        {p.s === "done" ? "completado" : p.s === "active" ? "en curso" : p.s === "next" ? "siguiente" : p.s === "planned" ? "planeado" : "futuro"}
                      </span>
                    </div>
                    <h3 className="font-display text-xl font-semibold mb-2">{p.t}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed mb-3">{p.d}</p>
                    <div className="label-mono text-[10px] text-quantum/70">↳ {p.artifact}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
