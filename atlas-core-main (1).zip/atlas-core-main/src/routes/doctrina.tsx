import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { PageHero } from "@/components/atlas/PageHero";
import { BookOpen, Shield, KeyRound, Eye, Database, Scale, Boxes, Layers3, Swords, Radar, Lock, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/doctrina")({
  head: () => ({
    meta: [
      { title: "Doctrina de Combate — TAMV Atlas Trascendence" },
      { name: "description", content: "Atlas Doctrine v1 — modo guerra: 6 axiomas blindados, plano 00–03 con análisis de amenaza, zero trust de combate y observabilidad como radar anti-misiles." },
      { property: "og:title", content: "Doctrina Heptafederada · Modo Guerra" },
      { property: "og:url", content: "/doctrina" },
    ],
    links: [{ rel: "canonical", href: "/doctrina" }],
  }),
  component: Page,
});

const federations = [
  { n: "F1", t: "Conocimiento", d: "Atlas Schema, EOCT, GEMET, CITEMESH, BookPI. La verdad versionada." },
  { n: "F2", t: "Identidad", d: "AKAÉ Core, federación OIDC/SAML, identidades de workload SPIFFE, linaje." },
  { n: "F3", t: "Gobernanza", d: "KORIMA Codex, 4L, SDMD-7, Dekateotl. La constitución ejecutable." },
  { n: "F4", t: "Economía", d: "Lucrum Prime, contratos, MSR Blockchain, ELITE HEHEP para consenso élite." },
  { n: "F5", t: "Seguridad", d: "Anubis Sentinel, Horus, criptografía híbrida pre/post-cuántica, zero-trust mTLS." },
  { n: "F6", t: "Infraestructura", d: "Multi-cloud + edge + on-prem, pipelines hexagonales dobles, infra federada." },
  { n: "F7", t: "IA cognitiva", d: "Isabella Villaseñor AI, guardrails, memorias trazables, decisión auditable." },
];

const planes = [
  { icon: BookOpen,  k: "00", t: "Doctrina + análisis de amenaza", d: "Atlas Doctrine v1: protect surface, escenarios de ataque (DDoS, ransomware, compromiso de claves, abuso de IA, inyección), matriz de criticidad y modo degradado por sistema." },
  { icon: Database,  k: "01", t: "Atlas Kernel como escudo", d: "Atlas Schema v1 con clasificación pública/sensible/crítica por campo. Anclaje obligatorio de entidades de alto impacto en BookPI/MSR/HEHEP." },
  { icon: Shield,    k: "02", t: "Zero Trust de combate", d: "Inventario duro de HVAs, micro-segmentación real, default deny entre federaciones, ZTNA: oculta la red, expone sólo apps. mTLS SPIFFE/SPIRE." },
  { icon: Radar,     k: "03", t: "Observabilidad como radar", d: "Kernel LTOS + Ojo de Ra + Quetzalcóatl. Señales de seguridad prioritarias, detección estadística + ML, guardianías con respuesta automática." },
  { icon: Scale,     k: "04", t: "Gobernanza y lenguajes", d: "KORIMA Codex como código constitucional. 4L (lógica, legal, lived, legacy) + SDMD-7 con ciclo gobernanza–riesgo." },
  { icon: Boxes,     k: "05", t: "Infraestructura hexagonal", d: "Pipeline doble: código + conocimiento. Cada federación se aísla, degrada y opera en modo reducido sin colapso." },
  { icon: Layers3,   k: "06", t: "APIs propias API-First", d: "EOCT, GEMET, CITEMESH y kernels expuestos con contratos versionados, anclados a BookPI/MSR." },
  { icon: KeyRound,  k: "07", t: "Experiencias y dominios", d: "RDM Digital Hub, TAMV Online, UTAMV, territorios. Instancias del núcleo, nunca atajos." },
];

const axioms = [
  { t: "Superficie mínima y segmentada", d: "Ningún servicio, puerto o feature se expone sin proxy de terminación dura, política explícita y telemetría activa. Cada servicio es un HVA potencial: se segmenta para bloquear movimiento lateral." },
  { t: "Identidad fuerte y acceso extremo", d: "RBAC + ABAC contextual, JIT/JEA para tareas sensibles. Identidad de workload (SPIFFE) para todo. Prohibido: cuentas compartidas, secrets en código, permisos globales sin expiración." },
  { t: "Telemetría como sistema nervioso", d: "Sin métricas + trace + audit, un módulo no es producción. Todo acceso, cambio y decisión de IA genera EOCT + span + métrica crítica. Se usa para detección, forense y verificación de políticas." },
  { t: "Cripto híbrida y migración PQC", d: "Día 1 con TLS híbrido (X25519 + KEM PQ). Estados críticos anclados a MSR Blockchain y ELITE HEHEP. Claves diseñadas pensando en migración post-cuántica, no como parche futuro." },
  { t: "Gobernanza y riesgo integrados", d: "Inventario exhaustivo de datos, apps, assets, workflows con HVAs marcados. Ciclo formal de definir → aprobar → versionar políticas → evaluar riesgo → postmortem. Sin él, todo blindaje envejece." },
  { t: "Automatización defensiva y resiliencia federada", d: "Nada de héroes: policies ejecutables, orquestación, automatización. Cada federación puede aislar, degradar y seguir operando en modo reducido. Atlas prefiere degradarse antes que quedar expuesta." },
];

const threats = [
  { t: "DDoS / abuso de capacidad", d: "Rate limit por identidad, circuit breakers conservadores, ZTNA en borde, degradación controlada con códigos 429/503." },
  { t: "Ransomware / persistencia", d: "Snapshots inmutables, anclaje en MSR, segmentación dura entre kernels, restauración verificable desde BookPI." },
  { t: "Compromiso de claves", d: "SVIDs SPIFFE de vida corta, KMS central con rotación programada y por evento, revocación inmediata por Anubis/Horus." },
  { t: "Abuso de IA / prompt injection", d: "Guardianía de IA: filtros contra extracción de secretos, jailbreaks y manipulación de contexto. Memorias trazables, decisiones auditadas en EOCT." },
  { t: "Inyección de inputs", d: "7 capas: WAF, protocolo, schema Zod, semántica TAMV, contexto, rate por identidad, guardianía IA. Default deny, nunca normalizar en silencio." },
];

function Page() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <PageHero
        eyebrow="// atlas doctrine v0"
        title={<>Heptafederado. <span className="text-quantum">Modo guerra. Sin atajos.</span></>}
        intro="Atlas Trascendence nace en zona hostil. Assume breach, federated security, defensa antes que feature. Siete federaciones, ocho planos, seis axiomas blindados. La AI no inventa: ejecuta este orden y rechaza cualquier diseño que viole los principios."
      />

      {/* AXIOMAS */}
      <section className="px-6 pb-20">
        <div className="container-atlas">
          <div className="label-mono mb-3">// axiomas inmutables</div>
          <h2 className="font-display text-3xl md:text-4xl font-semibold mb-10 max-w-3xl">
            Seis reglas que <span className="text-quantum">ningún módulo puede romper</span>.
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {axioms.map((a, i) => (
              <div key={i} className="card-quantum rounded-lg p-6">
                <div className="flex items-center gap-4 mb-3">
                  <div className="label-mono text-quantum text-xl">0{i + 1}</div>
                  <h3 className="font-display font-semibold">{a.t}</h3>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">{a.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MODO GUERRA — AMENAZAS */}
      <section className="px-6 pb-20 border-t border-border pt-20">
        <div className="container-atlas">
          <div className="flex items-center gap-3 mb-3">
            <Swords size={16} className="text-quantum" />
            <span className="label-mono">// modo guerra · escenarios de ataque</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-semibold mb-4 max-w-3xl">
            Atlas nace en <span className="text-quantum">zona hostil</span>.
          </h2>
          <p className="text-muted-foreground max-w-2xl mb-10 text-sm leading-relaxed">
            No hay fase beta segura. La primera exposición es ya entorno hostil: assume breach,
            federated security, sin modo hobby ni modo demo en producción.
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {threats.map((th, i) => (
              <div key={i} className="card-quantum rounded-lg p-6">
                <AlertTriangle size={18} className="text-quantum mb-3" />
                <h3 className="font-display font-semibold mb-2">{th.t}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{th.d}</p>
              </div>
            ))}
            <div className="card-quantum rounded-lg p-6 bg-quantum/5">
              <Lock size={18} className="text-quantum mb-3" />
              <h3 className="font-display font-semibold mb-2">Protect Surface &gt; Attack Surface</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Antes de listar lo atacable, definimos lo valioso: conocimiento, identidad,
                gobernanza. Todo lo demás se diseña para protegerlo.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SIETE FEDERACIONES */}
      <section className="px-6 pb-20 border-t border-border pt-20">
        <div className="container-atlas">
          <div className="label-mono mb-3">// 7 federaciones</div>
          <h2 className="font-display text-3xl md:text-4xl font-semibold mb-10 max-w-3xl">
            Siete dominios, <span className="text-quantum">un solo plano federado</span>.
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {federations.map((f) => (
              <div key={f.n} className="card-quantum rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="font-display text-2xl text-gradient-quantum">{f.n}</div>
                  <span className="label-mono text-[10px]">federación</span>
                </div>
                <h3 className="font-display text-lg font-semibold mb-2">{f.t}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PLAN DE OBRA */}
      <section className="px-6 pb-32 border-t border-border pt-20">
        <div className="container-atlas">
          <div className="label-mono mb-3">// plan de obra heptafederado</div>
          <h2 className="font-display text-3xl md:text-4xl font-semibold mb-12 max-w-3xl">
            Ocho planos. <span className="text-quantum">Cada uno habilita al siguiente</span>.
          </h2>

          <div className="space-y-px bg-border border border-border rounded-lg overflow-hidden">
            {planes.map((p) => (
              <div key={p.k} className="bg-card grid grid-cols-[80px_1fr] md:grid-cols-[80px_260px_1fr] gap-6 px-6 py-6 items-center">
                <div className="w-11 h-11 grid place-items-center rounded-md bg-quantum/10 border border-quantum/30">
                  <p.icon size={20} className="text-quantum" />
                </div>
                <div>
                  <div className="label-mono text-quantum">PLANO {p.k}</div>
                  <div className="font-display font-semibold text-lg mt-1">{p.t}</div>
                </div>
                <div className="text-sm text-muted-foreground col-span-2 md:col-span-1">{p.d}</div>
              </div>
            ))}
          </div>

          <div className="mt-12 card-quantum rounded-lg p-8 md:p-10">
            <div className="label-mono mb-3">// condición de avance</div>
            <p className="text-muted-foreground leading-relaxed mb-6">
              La AI no puede pasar del Plano 00 al 01 sin entregar análisis de amenaza, protect
              surface, tabla de criticidad y estrategia de defensa por escenario. Documentos
              canónicos versionados en el repositorio:
            </p>
            <ul className="grid md:grid-cols-2 gap-x-8 gap-y-2 text-sm font-mono text-quantum/90">
              <li>docs/atlas-doctrine-v1.md</li>
              <li>security/zero-trust-battle-ready.md</li>
              <li>security/microservices-zero-trust-design.md</li>
              <li>security/hybrid-encryption-strategy.md</li>
              <li>security/kms-hybrid-architecture-atlas.md</li>
              <li>security/segmentation-architecture-atlas.md</li>
              <li>security/circuit-breaker-thresholds-atlas.md</li>
              <li>security/input-validation-paranoid-mode.md</li>
              <li>security/service-policies.yaml</li>
              <li>observability/security-signals-spec.md</li>
              <li>observability/anomaly-detection-spec-kernel03.md</li>
              <li>tests/security/atlas-injection-and-stress-plan.md</li>
            </ul>
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
