import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { PageHero } from "@/components/atlas/PageHero";
import { User, Box, Link2, Zap, Shield, Workflow, Eye } from "lucide-react";

export const Route = createFileRoute("/lenguaje")({
  head: () => ({
    meta: [
      { title: "Lenguaje Atlas — TAMV Atlas Trascendence" },
      { name: "description", content: "Las 7 primitivas del lenguaje Atlas: identidades, entidades, relaciones, eventos, políticas, flujos y contextos." },
      { property: "og:title", content: "Lenguaje Atlas" },
      { property: "og:url", content: "/lenguaje" },
    ],
    links: [{ rel: "canonical", href: "/lenguaje" }],
  }),
  component: Page,
});

const primitives = [
  { icon: User, name: "Identidades", sig: "Identity<T>", desc: "Actores del sistema: personas, organizaciones, territorios, agentes. Con historia, reputación y políticas asociadas.", ex: "{ id, kind, claims[], reputation, since }" },
  { icon: Box, name: "Entidades", sig: "Entity<T>", desc: "Conceptos modelados: lugares, cursos, documentos, modelos, reglas, gemelos digitales.", ex: "{ id, type, attributes, version, source }" },
  { icon: Link2, name: "Relaciones", sig: "Edge<A,B>", desc: "Vínculos semánticos, sociales, económicos, jurídicos o temporales entre nodos del grafo.", ex: "{ from, to, predicate, weight, evidence }" },
  { icon: Zap, name: "Eventos", sig: "Event<T>", desc: "Cosas que pasan: visitas, decisiones, votaciones, cambios de estado, alertas. Inmutables y firmados.", ex: "{ id, type, actor, ts, payload, traceId }" },
  { icon: Shield, name: "Políticas", sig: "Policy", desc: "Reglas de acceso, gobernanza, ética, compliance — compiladas a runtime checks ejecutables.", ex: "{ scope, predicate, effect, enforcement }" },
  { icon: Workflow, name: "Flujos", sig: "Flow", desc: "Secuencias de acciones: rutas, misiones, procesos, playbooks, pipelines de IA o gobernanza.", ex: "{ steps[], guards, on_error, observers }" },
  { icon: Eye, name: "Contextos", sig: "Context<P>", desc: "Vistas parciales del Atlas para proyectos específicos (RDM, UTAMV, TAMV Online). Misma fuente, distintas lentes.", ex: "{ project, scope, filters, permissions }" },
];

function Page() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <PageHero
        eyebrow="// lenguaje atlas"
        title={<>7 primitivas. <span className="text-quantum">Infinitos dominios.</span></>}
        intro="Atlas Trascendence define un lenguaje civilizatorio: como Java o Python para programas, pero para ecosistemas. Estas son las primitivas con las que se modela cualquier territorio, organización o red de proyectos."
      />

      <section className="px-6 pb-32">
        <div className="container-atlas">
          <div className="grid md:grid-cols-2 gap-5">
            {primitives.map((p, i) => (
              <div key={p.name} className="card-quantum rounded-lg p-7">
                <div className="flex items-start justify-between mb-5">
                  <div className="w-12 h-12 grid place-items-center rounded-md bg-quantum/10 border border-quantum/30">
                    <p.icon size={20} className="text-quantum" />
                  </div>
                  <span className="label-mono text-[10px]">primitive · 0{i + 1}</span>
                </div>
                <h3 className="font-display text-2xl font-semibold mb-1">{p.name}</h3>
                <code className="font-mono text-xs text-quantum">{p.sig}</code>
                <p className="text-sm text-muted-foreground leading-relaxed mt-4">{p.desc}</p>
                <pre className="mt-5 p-4 rounded-md bg-background/60 border border-border font-mono text-xs text-muted-foreground overflow-x-auto">
                  {p.ex}
                </pre>
              </div>
            ))}
          </div>

          <div className="mt-20 card-quantum rounded-lg p-8 md:p-12">
            <div className="label-mono mb-4">// composición</div>
            <h3 className="font-display text-2xl md:text-3xl font-semibold mb-6">Atlas es la JVM civilizatoria</h3>
            <p className="text-muted-foreground leading-relaxed mb-6">
              Estas siete primitivas se ejecutan sobre los kernels (métricas, tracing, IA, economía, gobernanza),
              de manera parecida a como un programa Java se ejecuta sobre la JVM. Atlas es el runtime; tus proyectos
              —RDM Digital OS, TAMV Online, UTAMV, otros territorios— son los programas.
            </p>
            <pre className="p-5 rounded-md bg-background/60 border border-border font-mono text-xs leading-relaxed overflow-x-auto">
{`atlas.create(Entity, { type: "territorio", name: "Real del Monte" })
  .link(Identity.of("comunidad-rdm"), "custodia")
  .under(Policy.requires("consentimiento-colectivo"))
  .emit(Event.of("territorio.registrado"))
  .within(Context.of("rdm-digital-os"))`}
            </pre>
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
