import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Network, Brain, Shield, Layers, Globe2, GitBranch } from "lucide-react";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "TAMV Atlas Trascendence — Sistema Operativo Civilizatorio" },
      { name: "description", content: "Preservando aquello que las personas consideran digno de ser recordado. Lenguaje, grafo vivo e infraestructura federada con trazabilidad, ética y soberanía digital." },
      { property: "og:title", content: "TAMV Atlas Trascendence" },
      { property: "og:description", content: "Sistema operativo civilizatorio: conocimiento, identidad, IA y gobernanza federados." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

const domains = [
  { icon: Layers, label: "Núcleo civilizatorio", desc: "Atlas Kernel · AKAÉ Core · BookPI · reconciliación de fuentes y evidencias." },
  { icon: Brain, label: "Inteligencia cognitiva", desc: "Isabella Villaseñor AI — orquestadora con memoria, guardrails y trazabilidad." },
  { icon: Network, label: "Servicios federados", desc: "Identidad, UTAMV educación, economía Lucrum Prime y gobernanza digital." },
  { icon: Globe2, label: "Experiencia federada", desc: "Frontier, Atlas Explorer, wikis, XR y aplicaciones territoriales." },
  { icon: Shield, label: "Confianza y seguridad", desc: "Anubis Sentinel · Dekateotl · criptografía post-cuántica · guardianes constitucionales." },
  { icon: GitBranch, label: "Runtime federado", desc: "Orquestación, service mesh, observabilidad LTOS y auditoría forense." },
];

const principles = ["Soberanía digital", "Verificabilidad", "Apertura", "Ética ejecutable", "Evolución responsable"];

function Index() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />

      {/* HERO */}
      <section className="relative pt-24 pb-32 px-6">
        <div className="container-atlas">
          <div className="chip mb-8"><span className="pulse-dot" /> v1.0 · Atlas Trascendence Online</div>

          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-semibold leading-[0.95] tracking-tight max-w-5xl">
            <span className="text-foreground">El sistema operativo</span>
            <br />
            <span className="text-gradient-quantum">civilizatorio.</span>
          </h1>

          <p className="mt-10 text-xl md:text-2xl text-muted-foreground max-w-3xl leading-relaxed font-light">
            Un lenguaje, un grafo vivo y una infraestructura federada donde conocimiento, identidad,
            IA, educación y gobernanza conviven con <span className="text-foreground">trazabilidad, ética y soberanía digital</span>.
          </p>

          <p className="mt-6 italic text-quantum/90 font-display text-lg max-w-3xl">
            "Preservando aquello que las personas consideran digno de ser recordado."
          </p>

          <div className="mt-12 flex flex-wrap gap-4">
            <Link to="/manifiesto" className="btn-quantum">
              Leer el manifiesto <ArrowRight size={14} />
            </Link>
            <Link to="/arquitectura" className="btn-ghost-quantum">
              Ver la arquitectura
            </Link>
          </div>

          {/* metrics strip */}
          <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-px bg-border border border-border rounded-lg overflow-hidden">
            {[
              { k: "6", v: "capas arquitectónicas" },
              { k: "7", v: "primitivas del lenguaje" },
              { k: "∞", v: "dominios federables" },
              { k: "100%", v: "auditable y trazable" },
            ].map((m) => (
              <div key={m.v} className="bg-card px-6 py-8">
                <div className="font-display text-4xl font-semibold text-gradient-quantum">{m.k}</div>
                <div className="label-mono mt-2 text-[10px]">{m.v}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* DOMAINS */}
      <section className="section px-6 border-t border-border">
        <div className="container-atlas">
          <div className="label-mono mb-3">// dominios</div>
          <h2 className="font-display text-3xl md:text-5xl font-semibold max-w-3xl">
            Seis dominios <span className="text-quantum">conectados por un solo núcleo</span>.
          </h2>
          <p className="mt-6 text-muted-foreground max-w-2xl">
            Atlas no es una app: es un runtime. Cualquier proyecto —territorios, universidades, redes de IA,
            ecosistemas económicos— se monta sobre estas capas como un programa Java sobre la JVM.
          </p>

          <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {domains.map((d, i) => (
              <div key={d.label} className="card-quantum rounded-lg p-6">
                <div className="flex items-start justify-between mb-6">
                  <div className="w-11 h-11 grid place-items-center rounded-md bg-quantum/10 border border-quantum/30">
                    <d.icon size={20} className="text-quantum" />
                  </div>
                  <span className="label-mono text-[10px]">0{i + 1}</span>
                </div>
                <h3 className="font-display font-semibold text-lg mb-2">{d.label}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{d.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRINCIPLES */}
      <section className="section px-6 border-t border-border">
        <div className="container-atlas">
          <div className="label-mono mb-3">// principios estructurales</div>
          <h2 className="font-display text-3xl md:text-5xl font-semibold max-w-3xl">
            La tecnología que moldea comunidades debe comportarse <span className="text-quantum">como institución responsable</span>.
          </h2>

          <div className="mt-16 flex flex-wrap gap-3">
            {principles.map((p, i) => (
              <div key={p} className="border-quantum rounded-md px-6 py-4 flex items-center gap-4">
                <span className="label-mono text-quantum">0{i + 1}</span>
                <span className="font-display text-lg">{p}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BUILD ORDER */}
      <section className="section px-6 border-t border-border">
        <div className="container-atlas">
          <div className="label-mono mb-3">// orden de construcción</div>
          <h2 className="font-display text-3xl md:text-5xl font-semibold max-w-3xl mb-12">
            Secure & observable <span className="text-quantum">by design</span>.
          </h2>

          <div className="space-y-px bg-border border border-border rounded-lg overflow-hidden">
            {[
              { n: "01", t: "Lenguaje Atlas", d: "Ontología canónica: Identidades, Entidades, Relaciones, Eventos, Políticas, Flujos, Contextos." },
              { n: "02", t: "Security Baseline", d: "Modelo de amenaza, zero-trust entre servicios, mínimo privilegio, cifrado por defecto, SAST/DAST/SCA en CI." },
              { n: "03", t: "Observability Kernel", d: "Logs estructurados con traceId, métricas RED/USE/AI/Territorial, tracing distribuido, decision store auditable." },
              { n: "04", t: "Contratos de API", d: "OpenAPI/GraphQL versionados antes que el código de negocio." },
              { n: "05", t: "Kernels de ejecución", d: "Storage federado (relacional + grafo + frío), middleware de seguridad, AsyncLocalStorage compartido." },
              { n: "06", t: "Servicios y experiencias", d: "Identidad, UTAMV, economía, gobernanza, Frontier, Explorer — heredan garantías sin reinventarlas." },
            ].map((s) => (
              <div key={s.n} className="bg-card grid grid-cols-[80px_1fr] md:grid-cols-[100px_240px_1fr] gap-6 px-6 py-6 items-center">
                <div className="label-mono text-2xl text-quantum">{s.n}</div>
                <div className="font-display font-semibold text-lg">{s.t}</div>
                <div className="text-sm text-muted-foreground col-span-2 md:col-span-1">{s.d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section px-6 border-t border-border">
        <div className="container-atlas text-center">
          <h2 className="font-display text-3xl md:text-5xl font-semibold max-w-3xl mx-auto">
            Atlas Trascendence existe para que la memoria <span className="text-quantum">no dependa de quien hoy tenga el servidor</span>.
          </h2>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <Link to="/manifiesto" className="btn-quantum">Manifiesto fundacional</Link>
            <Link to="/roadmap" className="btn-ghost-quantum">Roadmap de despliegue</Link>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
