import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { PageHero } from "@/components/atlas/PageHero";

export const Route = createFileRoute("/arquitectura")({
  head: () => ({
    meta: [
      { title: "Arquitectura — TAMV Atlas Trascendence" },
      { name: "description", content: "Las 6 capas federadas: núcleo civilizatorio, inteligencia cognitiva, servicios, experiencia, confianza e infraestructura." },
      { property: "og:title", content: "Arquitectura" },
      { property: "og:url", content: "/arquitectura" },
    ],
    links: [{ rel: "canonical", href: "/arquitectura" }],
  }),
  component: Page,
});

const layers = [
  {
    n: "06",
    name: "Experiencia federada",
    color: "from-quantum/20",
    components: ["TAMV Frontier", "Atlas Explorer", "Wiki civilizatoria", "Paneles XR", "Apps territoriales"],
    desc: "Donde las personas tocan Atlas. Notion + Wikipedia + GitHub + dashboards, pero gobernados por un grafo base, tracing común y permisos compartidos.",
  },
  {
    n: "05",
    name: "Servicios federados",
    components: ["Identidad digital", "UTAMV educación", "Economía Lucrum Prime", "Gobernanza digital", "Reputación"],
    desc: "Un SDK de civilización digital. Cualquiera puede construir una universidad, ciudad digital o red de proyectos sobre estas APIs.",
  },
  {
    n: "04",
    name: "Inteligencia cognitiva",
    components: ["Isabella Villaseñor AI", "Detección PII", "Anti-alucinación", "Guardrails constitucionales", "Evaluadores de confianza"],
    desc: "Capa cognitiva común que aprende de múltiples dominios, respeta políticas locales y se integra con tracing y métricas para auditoría forense.",
  },
  {
    n: "03",
    name: "Núcleo civilizatorio",
    components: ["Atlas Kernel (ontología)", "AKAÉ Core (identidad profunda)", "BookPI (anclaje de evidencia)", "Reconciliación de versiones"],
    desc: "Wikipedia + Git + grafo semántico + archivo histórico. Responde: qué sabemos, de quién, desde cuándo y bajo qué condiciones.",
  },
  {
    n: "02",
    name: "Confianza y seguridad",
    components: ["Anubis Sentinel System™", "Dekateotl Security", "Criptografía post-cuántica", "Guardianes constitucionales", "SIEM + telemetría"],
    desc: "Lo que convierte a Atlas en aceptable para gobiernos, universidades y comunidades. Secure by design, no como parche.",
  },
  {
    n: "01",
    name: "Infraestructura federada",
    components: ["Orquestación K8s + Service Mesh", "Tracing distribuido", "Métricas LTOS (RED/USE/AI/Territorial)", "Decision store", "Interoperabilidad cloud/edge/on-prem"],
    desc: "Kubernetes + Terraform + observabilidad, pero pensado para territorios y clusters de conocimiento. La base sobre la que todo lo demás corre.",
  },
];

function Page() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <PageHero
        eyebrow="// arquitectura"
        title={<>Seis capas. <span className="text-quantum">Un solo runtime.</span></>}
        intro="De abajo hacia arriba: cada capa proporciona garantías que las superiores heredan sin reinventarlas. La infraestructura entrega observabilidad; la seguridad entrega zero-trust; el núcleo entrega memoria verificable; los servicios entregan capacidades; la experiencia entrega humanidad."
      />

      <section className="px-6 pb-32">
        <div className="container-atlas">
          <div className="space-y-4">
            {layers.map((l) => (
              <div key={l.n} className="card-quantum rounded-lg p-8 md:p-10">
                <div className="grid md:grid-cols-[160px_1fr] gap-8">
                  <div>
                    <div className="font-display text-5xl md:text-6xl font-semibold text-gradient-quantum">{l.n}</div>
                    <div className="label-mono mt-2 text-[10px]">capa</div>
                  </div>
                  <div>
                    <h2 className="font-display text-2xl md:text-3xl font-semibold mb-3">{l.name}</h2>
                    <p className="text-muted-foreground leading-relaxed mb-6">{l.desc}</p>
                    <div className="flex flex-wrap gap-2">
                      {l.components.map((c) => (
                        <span key={c} className="px-3 py-1.5 rounded-md border border-border bg-background/40 text-xs font-mono text-foreground/80">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
