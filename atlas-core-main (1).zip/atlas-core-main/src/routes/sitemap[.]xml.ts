import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";

const BASE_URL = "";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries = [
          { path: "/", priority: "1.0", changefreq: "weekly" as const },
          { path: "/doctrina", priority: "0.95", changefreq: "monthly" as const },
          { path: "/manifiesto", priority: "0.9", changefreq: "monthly" as const },
          { path: "/lenguaje", priority: "0.9", changefreq: "monthly" as const },
          { path: "/arquitectura", priority: "0.9", changefreq: "monthly" as const },
          { path: "/kernels", priority: "0.8", changefreq: "monthly" as const },
          { path: "/servicios", priority: "0.8", changefreq: "monthly" as const },
          { path: "/seguridad", priority: "0.8", changefreq: "monthly" as const },
          { path: "/roadmap", priority: "0.7", changefreq: "weekly" as const },
        ];
        const urls = entries.map((e) => `  <url>\n    <loc>${BASE_URL}${e.path}</loc>\n    <changefreq>${e.changefreq}</changefreq>\n    <priority>${e.priority}</priority>\n  </url>`).join("\n");
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`;
        return new Response(xml, { headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=3600" } });
      },
    },
  },
});
