import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/atlas/SiteHeader";
import { SiteFooter } from "@/components/atlas/SiteFooter";
import { QuantumBackdrop } from "@/components/atlas/QuantumBackdrop";
import { PageHero } from "@/components/atlas/PageHero";

export const Route = createFileRoute("/manifiesto")({
  head: () => ({
    meta: [
      { title: "Manifiesto — TAMV Atlas Trascendence" },
      { name: "description", content: "Declaración fundacional del sistema operativo civilizatorio Atlas Trascendence." },
      { property: "og:title", content: "Manifiesto — TAMV Atlas Trascendence" },
      { property: "og:url", content: "/manifiesto" },
    ],
    links: [{ rel: "canonical", href: "/manifiesto" }],
  }),
  component: Page,
});

function Page() {
  return (
    <div className="min-h-screen">
      <QuantumBackdrop />
      <SiteHeader />
      <PageHero
        eyebrow="Manifiesto fundacional"
        title={<>La memoria no debe depender <span className="text-quantum">de quien hoy tenga el servidor.</span></>}
        intro="Atlas Trascendence nace como respuesta a una pregunta: cómo construir infraestructura digital que comunidades, territorios e instituciones puedan confiar durante décadas, no durante un ciclo de inversión."
      />

      <section className="px-6 pb-32">
        <div className="container-atlas max-w-3xl space-y-12">
          {[
            { t: "Preservar lo que importa", b: "Slogan: \"Preservando aquello que las personas consideran digno de ser recordado.\" No toda la información merece persistencia. El Atlas existe para custodiar lo que una comunidad —tras deliberación— declara digno de memoria: territorios, linajes, decisiones, conocimiento, identidad." },
            { t: "Soberanía operativa", b: "El ecosistema debe poder funcionar sin dependencia estructural externa. Esto no significa aislamiento: significa que cambiar de proveedor, infraestructura o jurisdicción nunca debe destruir el sistema." },
            { t: "Verificabilidad como derecho", b: "Toda decisión crítica debe poder reconstruirse. Logs estructurados, decision store, evidencia anclada por BookPI. Ninguna persona tiene que confiar en la palabra del sistema; puede auditarlo." },
            { t: "Ética ejecutable", b: "Las políticas no son decoración legal. Se compilan, se aplican en runtime y se vigilan por guardianes constitucionales. Si la política dice que cierto dato no sale, no sale —ni por error, ni por presión, ni por bug." },
            { t: "Apertura interoperable", b: "Atlas habla estándares abiertos (W3C, OpenTelemetry, JSON-LD, OpenAPI). No es una jaula. Cualquier proyecto puede entrar, federarse y salir con sus datos intactos." },
            { t: "Evolución responsable", b: "Aprender sí, pero con límites. Meta-aprendizaje seguro con auditoría humana. El sistema se vuelve más inteligente sin volverse más opaco." },
          ].map((s, i) => (
            <article key={s.t}>
              <div className="label-mono mb-3">// {String(i + 1).padStart(2, "0")}</div>
              <h2 className="font-display text-2xl md:text-3xl font-semibold mb-4">{s.t}</h2>
              <p className="text-muted-foreground leading-relaxed text-lg">{s.b}</p>
            </article>
          ))}

          <div className="divider-scan" />

          <blockquote className="border-l-2 border-quantum pl-6 italic font-display text-xl text-foreground/90">
            "La tecnología que moldea comunidades debe comportarse como institución responsable, no como caja negra.
            Atlas existe para que el ecosistema TAMV tenga memoria, dirección, coherencia y capacidad de respuesta
            sin perder humanidad."
            <footer className="not-italic label-mono mt-4 text-[10px]">— Kernel Canónico de Isabella Villaseñor AI</footer>
          </blockquote>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
