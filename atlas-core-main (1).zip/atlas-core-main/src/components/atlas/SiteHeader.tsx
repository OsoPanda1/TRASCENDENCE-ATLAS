import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import tamvLogo from "@/assets/logotamv.png.asset.json";

const nav = [
  { to: "/doctrina", label: "Doctrina" },
  { to: "/manifiesto", label: "Manifiesto" },
  { to: "/lenguaje", label: "Lenguaje" },
  { to: "/arquitectura", label: "Arquitectura" },
  { to: "/kernels", label: "Kernels" },
  { to: "/servicios", label: "Servicios" },
  { to: "/seguridad", label: "Seguridad" },
  { to: "/roadmap", label: "Roadmap" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-background/70 border-b border-border">
      <div className="container-atlas flex items-center justify-between py-4 px-6">
        <Link to="/" className="flex items-center gap-3 group">
          <img
            src={tamvLogo.url}
            alt="TAMV Online Network"
            className="w-10 h-10 object-contain drop-shadow-[0_0_12px_rgba(56,189,248,0.35)] group-hover:drop-shadow-[0_0_18px_rgba(56,189,248,0.6)] transition-all"
          />
          <div className="leading-tight">
            <div className="font-display font-semibold text-foreground text-sm tracking-wide">TAMV ATLAS</div>
            <div className="label-mono text-[10px]">TRASCENDENCE</div>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors font-mono uppercase tracking-wider text-[11px]"
              activeProps={{ className: "px-3 py-2 text-sm text-quantum font-mono uppercase tracking-wider text-[11px]" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-2">
          <div className="pulse-dot" />
          <span className="label-mono text-[10px]">v1.0 · sovereign</span>
        </div>

        <button className="lg:hidden text-foreground" onClick={() => setOpen(!open)} aria-label="Menú">
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden border-t border-border bg-background/95">
          <nav className="flex flex-col px-6 py-4 gap-1">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setOpen(false)}
                className="px-3 py-3 text-sm text-muted-foreground hover:text-foreground font-mono uppercase tracking-wider text-[11px] border-b border-border/40"
              >
                {n.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
