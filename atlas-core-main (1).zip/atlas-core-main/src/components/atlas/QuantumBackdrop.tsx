export function QuantumBackdrop() {
  return (
    <>
      <div className="fixed inset-0 -z-10 grid-quantum opacity-60" aria-hidden />
      <div className="fixed inset-0 -z-10 pointer-events-none" aria-hidden>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full blur-3xl"
          style={{ background: "radial-gradient(circle, oklch(0.32 0.18 230 / 0.18), transparent 60%)" }} />
      </div>
    </>
  );
}
