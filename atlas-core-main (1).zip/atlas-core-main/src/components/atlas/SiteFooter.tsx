import { Link } from "@tanstack/react-router";
import tamvLogo from "@/assets/logotamv.png.asset.json";

export function SiteFooter() {
  return (
    <footer className="border-t border-border mt-32">
      <div className="container-atlas px-6 py-16">
        <div className="grid md:grid-cols-4 gap-10">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <img src={tamvLogo.url} alt="TAMV" className="w-9 h-9 object-contain" />
              <div>
                <div className="font-display font-semibold tracking-wide">TAMV ATLAS TRASCENDENCE</div>
                <div className="label-mono text-[10px]">construido por TAMV Online Network</div>
              </div>
            </div>
            <p className="text-sm text-muted-foreground max-w-md leading-relaxed">
              Sistema operativo civilizatorio. Un lenguaje, un grafo vivo y una infraestructura federada donde
              conocimiento, identidad, IA, educación y gobernanza conviven con trazabilidad, ética y soberanía digital.
            </p>
            <p className="mt-4 label-mono italic normal-case tracking-wide text-quantum/80">
              "Preservando aquello que las personas consideran digno de ser recordado."
            </p>
          </div>

          <div>
            <div className="label-mono mb-4">Atlas</div>
            <ul className="space-y-2 text-sm">
              <li><Link to="/doctrina" className="text-muted-foreground hover:text-foreground">Doctrina v0</Link></li>
              <li><Link to="/manifiesto" className="text-muted-foreground hover:text-foreground">Manifiesto</Link></li>
              <li><Link to="/lenguaje" className="text-muted-foreground hover:text-foreground">Lenguaje Atlas</Link></li>
              <li><Link to="/arquitectura" className="text-muted-foreground hover:text-foreground">Arquitectura</Link></li>
              <li><Link to="/roadmap" className="text-muted-foreground hover:text-foreground">Roadmap</Link></li>
            </ul>
          </div>

          <div>
            <div className="label-mono mb-4">Plataforma</div>
            <ul className="space-y-2 text-sm">
              <li><Link to="/kernels" className="text-muted-foreground hover:text-foreground">Kernels</Link></li>
              <li><Link to="/servicios" className="text-muted-foreground hover:text-foreground">Servicios Federados</Link></li>
              <li><Link to="/seguridad" className="text-muted-foreground hover:text-foreground">Seguridad</Link></li>
            </ul>
          </div>
        </div>

        <div className="divider-scan my-10" />

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <p className="label-mono text-[10px]">
            © {new Date().getFullYear()} TAMV Online Network · Sistema Operativo Territorial Soberano
          </p>
          <div className="flex gap-6 label-mono text-[10px]">
            <span>node: atlas-01</span>
            <span>region: global</span>
            <span className="flex items-center gap-2"><span className="pulse-dot" /> online</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
