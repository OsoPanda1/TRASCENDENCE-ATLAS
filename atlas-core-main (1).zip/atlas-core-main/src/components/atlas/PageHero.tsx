import type { ReactNode } from "react";

export function PageHero({
  eyebrow,
  title,
  intro,
  children,
}: {
  eyebrow: string;
  title: ReactNode;
  intro?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <section className="section pb-16 relative">
      <div className="container-atlas">
        <div className="chip mb-6">
          <span className="pulse-dot" /> {eyebrow}
        </div>
        <h1 className="font-display text-4xl md:text-6xl font-semibold leading-[1.05] text-gradient-quantum max-w-4xl">
          {title}
        </h1>
        {intro && (
          <p className="mt-6 text-lg text-muted-foreground max-w-3xl leading-relaxed">{intro}</p>
        )}
        {children}
      </div>
    </section>
  );
}
