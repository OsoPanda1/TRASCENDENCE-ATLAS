/**
 * Inventario absorbido desde Google Drive + Microsoft OneDrive.
 * Generado en tiempo de build vía connector-gateway.lovable.dev.
 * Fuente de verdad consumida por /atlas y /drive para mostrar
 * la fusión real de archivos del CEO en el Atlas TAMV.
 */
import summary from "./drive-onedrive.summary.json";
import inventory from "./drive-onedrive.inventory.json";

export interface AbsorbedFile {
  provider: "google_drive" | "microsoft_onedrive";
  id: string;
  name: string;
  mime: string;
  modified: string;
  size: number;
  url?: string;
  category: string;
}

export const ABSORPTION_SUMMARY = summary as {
  generatedAt: string;
  totals: { all: number; google_drive: number; microsoft_onedrive: number };
  byCategory: Record<string, number>;
  topByCategory: Record<string, Array<{ name: string; provider: string; size: number; url?: string }>>;
};

export const ABSORPTION_INVENTORY = inventory as {
  generatedAt: string;
  files: AbsorbedFile[];
};

export const CATEGORY_LABELS: Record<string, string> = {
  doctrina: "Doctrina · Canon · Isabella",
  ecosistema: "Ecosistema TAMV/RDM/UTAMV",
  blueprint: "Blueprints · Atlas · Roadmaps",
  "api-contracts": "APIs · Contratos · Schemas",
  "legal-forense": "Legal · Forense",
  documento: "Documentos",
  datos: "Datos · Hojas",
  presentacion: "Presentaciones",
  "media-image": "Imágenes",
  "media-video": "Video",
  "media-audio": "Audio",
  "archivo-zip": "ZIPs / Archivos",
  carpeta: "Carpetas",
  otro: "Otros",
};
