/**
 * UNIFIED TAMV ATLAS — Fusión final
 * ----------------------------------
 * Curaduría única que entrelaza:
 *  - Identidad soberana del CEO (canon1.docx).
 *  - Kernel MD-X4/MD-X5 y sus 8 capas (rdm-hub-unite).
 *  - Núcleos federados RDM/UTAMV/CITEMESH.
 *  - Sub-proyectos lovable fusionados:
 *      · Shadow Realm Studio (HEP-7 · usuarios/comunidad)
 *      · Project Genesis (HEP-2 · DreamSpaces + Isabella runtime)
 *      · tamv-digital-genesis (HEP-1 · vitrina cero)
 *      · rdm-turismodigital (HEP-3 · Nodo Cero territorial)
 *      · rdm-hub-unite (HEP-6 · Codex/Federaciones/Mapa)
 *      · genesis-digytamv-nexus (HEP-2 · onboarding metaversal)
 *  - Identificadores académicos: ORCID, Zenodo DOI, etc.
 *
 * Esta es la única fuente de verdad consumida por /atlas
 * para el "atlas final" del ecosistema TAMV.
 */

import type { HeHexagonId, HepDomainId } from "../contracts/elite-hehep";

export const TAMV_SOVEREIGN_IDENTITY = {
  legalName: "Edwin Oswaldo Castillo Trejo",
  alias: "Anubis Villaseñor",
  role: "CEO Fundador · Lead Systems Architect",
  base: "Real del Monte, Hidalgo · México",
  orcid: "0009-0008-5050-1539",
  orcidUrl: "https://orcid.org/0009-0008-5050-1539",
  zenodoDoi: "10.5281/zenodo.19436662",
  zenodoUrl: "https://doi.org/10.5281/zenodo.19436662",
  github: "https://github.com/OsoPanda1",
  motto:
    "Innovation is only authentic when it is sovereign. Engineering the operating system of a new digital civilization from the heart of Real del Monte.",
  hoursInvested: 21600,
  yearsResisting: 5,
} as const;

export const TAMV_PUBLISHING_NETWORK = [
  { id: "orcid", label: "ORCID", url: "https://orcid.org/0009-0008-5050-1539" },
  { id: "zenodo", label: "Zenodo", url: "https://doi.org/10.5281/zenodo.19436662" },
  { id: "figshare", label: "Figshare", url: "https://figshare.com" },
  { id: "openaire", label: "OpenAIRE", url: "https://www.openaire.eu" },
  { id: "datacite", label: "DataCite", url: "https://datacite.org" },
  { id: "frontiers", label: "Frontiers", url: "https://www.frontiersin.org" },
  { id: "avixa", label: "AVIXA", url: "https://avixa.org" },
] as const;

export interface KernelLayer {
  id: string;
  name: string;
  desc: string;
  hexagon: HeHexagonId;
  domain: HepDomainId;
}

export const KERNEL_LAYERS: KernelLayer[] = [
  { id: "L1", name: "Identidad Soberana (ID-NVIDA)", desc: "Credenciales verificables, perfil único cifrado.", hexagon: "HE-Identity", domain: "HEP-7" },
  { id: "L2", name: "Kernel MD-X4", desc: "Núcleo de observabilidad, telemetría ética y orquestación.", hexagon: "HE-Publish", domain: "HEP-1" },
  { id: "L3", name: "Kernel MD-X5", desc: "Capa de seguridad epistémica, defensa anti-desinformación.", hexagon: "HE-Transform", domain: "HEP-4" },
  { id: "L4", name: "Cells & Federaciones", desc: "Unidades autónomas territoriales interoperables.", hexagon: "HE-Publish", domain: "HEP-1" },
  { id: "L5", name: "Isabella Villaseñor AI", desc: "IA guardiana del ecosistema, acompaña con ética explícita.", hexagon: "HE-Identity", domain: "HEP-7" },
  { id: "L6", name: "REALITO AI", desc: "Asistente turístico-cultural del Nodo Cero RDM.", hexagon: "HE-Transform", domain: "HEP-3" },
  { id: "L7", name: "DreamSpaces XR", desc: "Capa inmersiva 3D/4D, gemelos territoriales.", hexagon: "HE-Ingest", domain: "HEP-3" },
  { id: "L8", name: "Economía Korima", desc: "Economía interna gamificada, intercambio justo.", hexagon: "HE-Economy", domain: "HEP-5" },
];

export interface FusedProject {
  id: string;
  title: string;
  origin: "kernel" | "lovable-project" | "github-repo" | "uploaded-zip";
  hexagon: HeHexagonId;
  domain: HepDomainId;
  summary: string;
  url?: string;
  pages: string[];
}

export const FUSED_PROJECTS: FusedProject[] = [
  {
    id: "tamv-core-kernel",
    title: "TAMV Core Kernel",
    origin: "kernel",
    hexagon: "HE-Publish",
    domain: "HEP-1",
    summary: "Router heptafederado · BookPI · Contratos · Atlas final.",
    url: "https://kernel-tamv.lovable.app",
    pages: ["/", "/atlas", "/canon", "/isabella", "/drive", "/docs", "/contracts", "/bookpi", "/rdm"],
  },
  {
    id: "shadow-realm-studio",
    title: "Shadow Realm Studio",
    origin: "lovable-project",
    hexagon: "HE-Identity",
    domain: "HEP-7",
    summary: "Comunidad federada: Circle, Plaza, GlobalWall, Actions, PunishmentZone.",
    pages: ["Actions", "Auth", "Circle", "Dashboard", "GlobalWall", "Memberships", "Onboarding", "Plaza", "Profile", "PunishmentZone", "Report", "VideoHub"],
  },
  {
    id: "project-genesis",
    title: "Project Genesis",
    origin: "lovable-project",
    hexagon: "HE-Transform",
    domain: "HEP-2",
    summary: "Runtime Isabella + DreamSpaces + Wallet + Marketplace + DevHub.",
    pages: ["About", "Auth", "CEO", "Dashboard", "DevHub", "DreamSpaces", "GlobalWall", "Isabella", "Marketplace", "Wallet"],
  },
  {
    id: "tamv-digital-genesis",
    title: "tamv-digital-genesis",
    origin: "lovable-project",
    hexagon: "HE-Publish",
    domain: "HEP-1",
    summary: "Vitrina cero / landing genesis del ecosistema.",
    pages: ["Index"],
  },
  {
    id: "rdm-turismodigital",
    title: "RDM Turismo Digital",
    origin: "uploaded-zip",
    hexagon: "HE-Ingest",
    domain: "HEP-3",
    summary: "Nodo Cero territorial: identidad, comercio, repositorio, turismo.",
    pages: ["Auth", "ComercioRegistro", "Dashboard", "Home", "Identidad", "Repositorio", "Territorio", "Turismo"],
  },
  {
    id: "rdm-hub-unite",
    title: "RDM Hub Unite",
    origin: "uploaded-zip",
    hexagon: "HE-Publish",
    domain: "HEP-6",
    summary: "Codex doctrinal, federaciones, mapa, observatorio, LTOS, rutas.",
    pages: ["Anubis", "Codex", "Dichos", "Federaciones", "Historia", "Index", "LTOS", "MDX4", "Mapa", "Negocios", "Observatorio", "Rutas", "TAMV", "Transporte"],
  },
  {
    id: "genesis-digytamv-nexus",
    title: "Genesis · DigyTAMV Nexus",
    origin: "uploaded-zip",
    hexagon: "HE-Transform",
    domain: "HEP-2",
    summary: "Onboarding metaversal · membresías · documentación operativa.",
    pages: ["Auth", "Documentation", "Index", "Login", "Membership", "MetaverseHome", "Register"],
  },
];

export const TAMV_NUCLEI = [
  { id: "rdm", name: "RDM Digital", icon: "⛰", desc: "Nodo Cero territorial · Real del Monte." },
  { id: "utamv", name: "UTAMV", icon: "🎓", desc: "Universidad TAMV · academia digital soberana." },
  { id: "citemesh", name: "CITEMESH", icon: "🕸", desc: "Red de centros de investigación interoperables." },
  { id: "isabella", name: "Isabella Villaseñor AI", icon: "✦", desc: "IA guardiana del ecosistema." },
  { id: "realito", name: "REALITO", icon: "◈", desc: "Asistente operativo del Nodo Cero." },
] as const;

export const UNIFIED_ATLAS_VERSION = "ATLAS-FINAL-v1" as const;
