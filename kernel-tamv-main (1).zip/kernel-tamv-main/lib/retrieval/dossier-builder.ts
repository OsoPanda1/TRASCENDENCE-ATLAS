import type { EvidenceDoc } from "../canonical/types";
import { listNodes } from "../memory/graph-store";
import { rankByQuery } from "../memory/vector-index";

export interface Dossier {
  query: string;
  docs: EvidenceDoc[];
  hasEvidence: boolean;
}

export async function buildDossier(query: string, topK = 5): Promise<Dossier> {
  const all = listNodes();
  const docs = await rankByQuery(query, all, { topK, mode: "lexical" });
  return { query, docs, hasEvidence: docs.length > 0 };
}
