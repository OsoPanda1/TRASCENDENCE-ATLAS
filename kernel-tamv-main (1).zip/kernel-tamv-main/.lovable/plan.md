# Plan: TAMVAI / Isabella Gateway + Canon doctrinal

## Alcance
Bajar a código, dentro de este monorepo TanStack Start, los contratos y servicios que definiste: Isabella Gateway (chat + recommendation), OpenAPI 3.1 canónico (TAMV UNIFIED + TAMVAI), capa de routing dinámico de modelos, observabilidad, seguridad Zero Trust, y el Canon doctrinal Isabella v1.

No reescribiré el kernel MD-X4 ya existente (`lib/kernel`, `lib/canonical`, `lib/memory`, `/kernel` UI) — lo conecto como backend de evidencia.

## Estructura nueva

```text
docs/
  isabella-canon/
    00_foundation.md … 20_api_blueprint.md   (canon v1 completo)
  tamv/
    constitution.ts
    ethics-legal.ts
    architecture.ts
    blueprint.ts
    security.ts
    observability.ts
    roadmap.ts
    tamvai-manual.ts
api/openapi/
  tamv-unified-api.yml
  tamvai-api.yml
lib/isabella/
  gateway/
    router.ts          (selectModel por reglas + fallback)
    models.config.ts   (declarativo, hot-reloadable)
    guardrails.ts      (filtros prompt/respuesta, 4 capas)
    audit.ts           (AI_AUDIT events → BookPI emitter existente)
    metrics.ts         (counters/histograms en memoria, expuestos en /metrics)
    chat.ts            (handler chat, stub modelo local)
    recommendation.ts  (handler rule-based v1)
  canon/
    index.ts           (carga del Canon como CanonicalNodes en el kernel)
src/routes/api/public/
  ai/isabella/chat.ts             (POST, valida Zod ≡ OpenAPI, audita, rate-limit)
  ai/isabella/recommendation.ts   (POST)
  ai/metrics.ts                   (GET text/plain Prometheus exposition)
  openapi/tamv-unified.ts         (GET YAML)
  openapi/tamvai.ts               (GET YAML)
src/routes/
  isabella.tsx       (consola UI: chat playground + recomendación + estado del gateway)
  canon.tsx          (navegador del Canon v1, secciones 00–20)
src/components/tamv/
  IsabellaConsole.tsx
  CanonBrowser.tsx
```

## Decisiones técnicas

- **Runtime**: Cloudflare Worker (TSS) — no Fastify/Node-only. Sustituyo `jsonwebtoken`/`prom-client`/OTel SDK por equivalentes Worker-safe: verificación JWT con `jose` (ya web-crypto), métricas in-memory exportadas en formato Prometheus text, rate-limit token-bucket en memoria por worker (suficiente para preview; documentado para mover a Durable Object / Upstash más tarde).
- **Validación**: Zod en cada handler, derivado del OpenAPI; los YAML quedan como fuente de verdad servidos en `/api/public/openapi/*` para Swagger UI / generación de SDKs.
- **Auth Zero Trust**: middleware compartido. En `/api/public/ai/*` se exige `Authorization: Bearer` salvo modo `dev` (header `x-tamv-dev: 1` + `KERNEL_SIGNING_KEY` válida). Rechazo 401/429 estandarizado.
- **Routing dinámico**: reglas declarativas (`messagesLength`, `mode`, `previousModelFailed`) evaluadas por funciones tipadas, sin `eval`. Modelo por defecto `mdx5-stub` que produce respuesta determinista mientras no hay vLLM. Modelos externos quedan `enabled:false` por defecto — switching listo, sin vendor lock-in.
- **Auditoría**: cada llamada emite `AI_AUDIT` vía `emitEliteBookPiEvent` con `he_hep_context: { hexagon: 'HE-Identity', domain: 'HEP-7' }` y se persiste también como `CanonicalEvent` (`POLICY_EVALUATED`) en el event-log del kernel — auditable desde `/kernel` por `traceId`.
- **Guardrails (4 capas)**: 1) longitud y schema, 2) lista negra de patrones (autolesión, violencia explícita, prompt-injection típica), 3) anonimización de PII básica en `promptPreview`, 4) `riskFlags` que pueden bloquear (`status: BLOCKED`).
- **Canon Isabella v1**: 21 markdowns en `docs/isabella-canon/` + loader `lib/isabella/canon/index.ts` que los ingiere como `CanonicalNode` (`type: DOCUMENT`, `ontologyClass: isabella.canon.*`) al arranque, junto a los seeds existentes — el RAG del kernel responde inmediatamente sobre el canon.
- **UI moderna**: `/isabella` con consola tipo terminal/chat (framer-motion, tokens del design system existente), `/canon` con sidebar de 21 secciones + render markdown. Header actualizado con entradas "Isabella" y "Canon".

## Fuera de alcance (explícito)
- Conexión real a vLLM/Ollama/OpenAI (queda el adaptador con `enabled:false`).
- TTS, streaming SSE real (la respuesta soporta `stream:false` ahora; SSE queda como TODO comentado en `chat.ts`).
- Persistencia de rate-limit / audit fuera del worker (queda interfaz `AuditSink`, impl in-memory + BookPI bridge).
- Procesar los `.zip` adjuntos como ingesta automática (el `GithubIngestor` existente cubre el caso bajo demanda; meter binarios al repo violaría las reglas de assets).
- Codex_Installer.exe — ignorado (binario Windows no relevante al web app).

## Pasos de implementación
1. Canon doctrinal: 21 `.md` + loader que los registra como nodos canónicos al boot.
2. OpenAPI YAMLs + rutas `GET` que los sirven.
3. `lib/isabella/gateway/*`: tipos, router, guardrails, métricas, audit, handlers chat y recommendation.
4. Rutas `/api/public/ai/isabella/{chat,recommendation}` y `/api/public/ai/metrics` con auth + rate-limit + Zod.
5. UI `/isabella` (consola) y `/canon` (browser), entradas en `Header`.
6. `docs/tamv/*.ts` con las constantes doctrinales que ya entregaste (constitución, ética, arquitectura, blueprint, seguridad, observabilidad, roadmap, tamvai-manual).
7. Verificación: build, `curl` a `/api/public/ai/isabella/recommendation` vía `invoke-server-function`, revisar `/api/public/ai/metrics`, navegar `/isabella` y `/canon`.

## Riesgos
- El worker-runtime obliga a sustituir libs Node-only — ya contemplado.
- Rate-limit/audit en memoria se reinician en cada despliegue de preview; aceptable para v1, documentado.
- El Canon como markdown estático debe importarse vía `import.meta.glob` para que el bundler lo incluya en el worker.

¿Procedo con esta implementación tal cual?
