import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Header } from "@/components/tamv/Header";
import { CANON_SECTIONS } from "../../lib/isabella/canon/sections";

export const Route = createFileRoute("/canon")({
  head: () => ({
    meta: [
      { title: "Canon Isabella v2 — TAMV" },
      {
        name: "description",
        content:
          "Canonical Knowledge Library v2.0 — fusión doctrinal del kernel canónico Isabella Villaseñor AI: propósito, arquitectura, seguridad, gobernanza, esquemas y APIs.",
      },
      { property: "og:title", content: "Canon Isabella v2" },
      {
        property: "og:description",
        content: "Kernel cognitivo, ético y orquestador de TAMV Online — fuente única de verdad.",
      },
    ],
  }),
  component: CanonPage,
});

function CanonPage() {
  const [activeId, setActiveId] = useState(CANON_SECTIONS[0].id);
  const active = CANON_SECTIONS.find((s) => s.id === activeId)!;
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main className="mx-auto max-w-7xl px-6 py-10">
        <header className="mb-8">
          <h1 className="font-display text-3xl tracking-tight">
            Canon <span className="text-primary">Isabella v2</span>
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Canonical Knowledge Library · Infraestructura Cognitiva Soberana de TAMV Online
          </p>
        </header>

        <div className="grid gap-6 lg:grid-cols-[260px_minmax(0,1fr)]">
          <aside className="rounded-xl border border-border/40 bg-card/30 p-3 h-fit sticky top-24">
            <ol className="space-y-0.5">
              {CANON_SECTIONS.map((s) => (
                <li key={s.id}>
                  <button
                    onClick={() => setActiveId(s.id)}
                    className={`w-full text-left px-3 py-2 rounded-md text-xs font-mono flex items-baseline gap-2 transition ${
                      s.id === activeId
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted/30"
                    }`}
                  >
                    <span className="tabular-nums opacity-60">
                      {String(s.index).padStart(2, "0")}
                    </span>
                    <span className="truncate">{s.title}</span>
                  </button>
                </li>
              ))}
            </ol>
          </aside>

          <motion.article
            key={active.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-xl border border-border/40 bg-card/30 p-8 space-y-4"
          >
            <div className="flex items-baseline justify-between gap-4 border-b border-border/40 pb-4">
              <div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                  {active.ontologyClass}
                </div>
                <h2 className="font-display text-2xl mt-1">
                  {String(active.index).padStart(2, "0")} · {active.title}
                </h2>
              </div>
              <div className="flex gap-1 flex-wrap justify-end max-w-xs">
                {active.tags.map((t) => (
                  <span
                    key={t}
                    className="text-[10px] font-mono px-1.5 py-0.5 rounded border border-border/50 text-muted-foreground"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
            <pre className="text-sm whitespace-pre-wrap leading-relaxed font-sans text-foreground/90">
              {active.body}
            </pre>
          </motion.article>
        </div>
      </main>
    </div>
  );
}
