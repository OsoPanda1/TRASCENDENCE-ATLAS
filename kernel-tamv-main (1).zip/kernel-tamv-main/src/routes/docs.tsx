import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Header } from "@/components/tamv/Header";
import { Footer } from "@/components/tamv/Footer";

export const Route = createFileRoute("/docs")({
  head: () => ({
    meta: [
      { title: "API Docs — TAMV Unified & TAMVAI" },
      { name: "description", content: "Especificaciones OpenAPI, estado de webhooks y health de conectores federados TAMV." },
    ],
  }),
  component: DocsPage,
});

type HealthState = {
  webhook?: { configured: boolean; eventCount: number; latest: any };
  drive?: { ok: boolean; count?: number; error?: string };
  onedrive?: { ok: boolean; count?: number; error?: string };
  ai?: { ok: boolean };
};

function DocsPage() {
  const [health, setHealth] = useState<HealthState>({});
  const [yaml, setYaml] = useState<{ unified?: string; tamvai?: string }>({});
  const [tab, setTab] = useState<"unified" | "tamvai">("unified");

  useEffect(() => {
    (async () => {
      const safeJson = async (url: string) => {
        try {
          const r = await fetch(url);
          return r.ok ? await r.json() : { error: `HTTP ${r.status}` };
        } catch (e: any) {
          return { error: String(e?.message ?? e) };
        }
      };
      const [wh, dr, od, ai] = await Promise.all([
        safeJson("/api/github/events"),
        safeJson("/api/public/drive/list?pageSize=5"),
        safeJson("/api/public/onedrive/list"),
        safeJson("/api/public/ai/status"),
      ]);
      setHealth({
        webhook: { configured: !!wh?.configured, eventCount: wh?.eventCount ?? 0, latest: wh?.latest ?? null },
        drive: { ok: !dr?.error, count: dr?.files?.length, error: dr?.error },
        onedrive: { ok: !od?.error, count: od?.value?.length, error: od?.error },
        ai: { ok: !ai?.error },
      });

      const [u, t] = await Promise.all([
        fetch("/api/public/openapi/tamv-unified").then((r) => r.text()).catch(() => "# error"),
        fetch("/api/public/openapi/tamvai").then((r) => r.text()).catch(() => "# error"),
      ]);
      setYaml({ unified: u, tamvai: t });
    })();
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />
      <main className="flex-1 mx-auto max-w-7xl w-full px-6 py-10 space-y-8">
        <div>
          <div className="text-[11px] font-mono uppercase tracking-[0.3em] text-primary">Docs · OpenAPI · Health</div>
          <h1 className="mt-2 font-display text-4xl">API & Conectores Federados</h1>
          <p className="mt-3 text-muted-foreground max-w-3xl">
            Estado vivo de la federación: webhook GitHub, Google Drive, OneDrive, AI Gateway, más las especificaciones OpenAPI publicadas para TAMV Unified y TAMVAI.
          </p>
        </div>

        <section className="grid md:grid-cols-4 gap-3">
          <HealthCard label="GitHub Webhook" ok={!!health.webhook?.configured} detail={`${health.webhook?.eventCount ?? 0} eventos`} />
          <HealthCard label="Google Drive" ok={!!health.drive?.ok} detail={health.drive?.error ?? `${health.drive?.count ?? 0} archivos`} />
          <HealthCard label="OneDrive" ok={!!health.onedrive?.ok} detail={health.onedrive?.error ?? `${health.onedrive?.count ?? 0} items`} />
          <HealthCard label="Isabella AI" ok={!!health.ai?.ok} detail={health.ai?.ok ? "online" : "offline"} />
        </section>

        {health.webhook?.latest ? (
          <section className="rounded-xl border border-border/60 bg-card p-4">
            <div className="text-[10px] font-mono uppercase tracking-[0.25em] text-muted-foreground">Último evento GitHub</div>
            <div className="mt-2 font-mono text-xs text-foreground">
              {health.webhook.latest.event} · {health.webhook.latest.repository?.full_name ?? "—"} · {new Date(health.webhook.latest.receivedAt).toLocaleString("es-MX")}
            </div>
          </section>
        ) : null}

        <section>
          <div className="flex items-center gap-2 border-b border-border/60">
            {(["unified", "tamvai"] as const).map((k) => (
              <button
                key={k}
                onClick={() => setTab(k)}
                className={`px-4 py-2 text-sm font-mono uppercase tracking-widest border-b-2 -mb-px transition-colors ${
                  tab === k ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                {k === "unified" ? "TAMV Unified" : "TAMVAI"}
              </button>
            ))}
            <div className="ml-auto flex gap-3 text-[11px] font-mono">
              <a className="text-primary hover:underline" href="/api/public/openapi/tamv-unified" target="_blank" rel="noreferrer">/openapi/tamv-unified ↗</a>
              <a className="text-primary hover:underline" href="/api/public/openapi/tamvai" target="_blank" rel="noreferrer">/openapi/tamvai ↗</a>
            </div>
          </div>
          <pre className="mt-4 max-h-[60vh] overflow-auto rounded-lg border border-border/60 bg-black/60 p-4 text-[11px] leading-relaxed font-mono text-zinc-200">
            {tab === "unified" ? yaml.unified ?? "loading…" : yaml.tamvai ?? "loading…"}
          </pre>
        </section>
      </main>
      <Footer />
    </div>
  );
}

function HealthCard({ label, ok, detail }: { label: string; ok: boolean; detail?: string }) {
  return (
    <div className="rounded-xl border border-border/60 bg-card p-4">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-muted-foreground">{label}</span>
        <span className={`h-2 w-2 rounded-full ${ok ? "bg-emerald-400" : "bg-red-400"}`} />
      </div>
      <div className="mt-2 text-sm font-mono text-foreground">{ok ? "OK" : "DOWN"}</div>
      {detail ? <div className="mt-1 text-[11px] text-muted-foreground truncate">{detail}</div> : null}
    </div>
  );
}
