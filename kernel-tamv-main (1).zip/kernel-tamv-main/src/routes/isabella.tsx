import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Header } from "@/components/tamv/Header";

export const Route = createFileRoute("/isabella")({
  head: () => ({
    meta: [
      { title: "Isabella — TAMVAI Gateway" },
      {
        name: "description",
        content:
          "Consola conversacional con Isabella Villaseñor AI. RAG estricto sobre el Canon, guardrails MD-X4 y auditoría BookPI.",
      },
      { property: "og:title", content: "Isabella — TAMVAI Gateway" },
      {
        property: "og:description",
        content: "Conversación soberana con guardrails MD-X4 y trazabilidad por traceId.",
      },
    ],
  }),
  component: IsabellaPage,
});

type Msg = { role: "user" | "assistant"; content: string; meta?: unknown };

interface ChatApiResponse {
  conversationId: string;
  model: string;
  status: "OK" | "BLOCKED" | "ERROR";
  message?: string;
  chunks: { chunkId: string; text: string; emotion: string; sequence: number }[];
  audit: { id: string; traceId: string; latencyMs: number };
  citations: { nodeId: string; title: string; score: number; sha256: string }[];
}

function IsabellaPage() {
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      content:
        "Hola. Soy Isabella. Pregúntame y respondo solo con lo que el Canon respalde. Sin evidencia, te lo digo.",
    },
  ]);
  const [input, setInput] = useState("");
  const [mode, setMode] =
    useState<"default" | "tutor" | "mediator" | "territorial">("default");

  const mut = useMutation({
    mutationFn: async (text: string) => {
      const res = await fetch("/api/public/ai/isabella/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, { role: "user", content: text }].map((m) => ({
            role: m.role,
            content: m.content,
          })),
          mode,
        }),
      });
      const json: ChatApiResponse = await res.json();
      return json;
    },
    onSuccess: (out) => {
      const text =
        out.status === "BLOCKED"
          ? out.message ?? "BLOCKED por guardrails."
          : out.chunks.map((c) => c.text).join("\n\n");
      setMessages((m) => [
        ...m,
        { role: "assistant", content: text, meta: out },
      ]);
    },
  });

  function send() {
    if (!input.trim()) return;
    const text = input.trim();
    setMessages((m) => [...m, { role: "user", content: text }]);
    setInput("");
    mut.mutate(text);
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main className="mx-auto max-w-5xl px-6 py-10 space-y-6">
        <div className="flex items-baseline justify-between">
          <div>
            <h1 className="font-display text-3xl tracking-tight">
              Isabella <span className="text-primary">·</span> Gateway TAMVAI
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              RAG estricto · Guardrails MD-X4 · Audit BookPI (HE-Identity / HEP-7)
            </p>
          </div>
          <div className="flex gap-1 text-[11px] font-mono">
            {(["default", "tutor", "mediator", "territorial"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`px-2.5 py-1 rounded border ${
                  mode === m
                    ? "border-primary text-primary bg-primary/10"
                    : "border-border/50 text-muted-foreground hover:text-foreground"
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        <section className="rounded-xl border border-border/40 bg-card/30 backdrop-blur p-5 space-y-4 min-h-[480px]">
          <AnimatePresence initial={false}>
            {messages.map((m, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-3 ${
                  m.role === "user" ? "flex-row-reverse" : ""
                }`}
              >
                <div
                  className={`size-8 rounded-md border flex items-center justify-center text-xs font-mono shrink-0 ${
                    m.role === "user"
                      ? "border-primary/40 text-primary"
                      : "border-emerald-500/40 text-emerald-400"
                  }`}
                >
                  {m.role === "user" ? "yo" : "iv"}
                </div>
                <div
                  className={`rounded-lg px-4 py-3 max-w-[80%] text-sm whitespace-pre-wrap leading-relaxed ${
                    m.role === "user"
                      ? "bg-primary/10 border border-primary/30"
                      : "bg-card/60 border border-border/40"
                  }`}
                >
                  {m.content}
                  {m.role === "assistant" &&
                  m.meta &&
                  (m.meta as ChatApiResponse).citations?.length ? (
                    <div className="mt-3 pt-3 border-t border-border/30 space-y-1">
                      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
                        Evidencia
                      </div>
                      {(m.meta as ChatApiResponse).citations.slice(0, 3).map((c) => (
                        <div
                          key={c.nodeId}
                          className="flex items-baseline gap-3 text-[11px] font-mono"
                        >
                          <span className="text-primary tabular-nums w-10">
                            {c.score.toFixed(2)}
                          </span>
                          <span className="flex-1 truncate">{c.title}</span>
                          <span className="text-muted-foreground">
                            {c.sha256.slice(0, 8)}
                          </span>
                        </div>
                      ))}
                      <div className="text-[10px] font-mono text-muted-foreground pt-1">
                        trace · {(m.meta as ChatApiResponse).audit.traceId.slice(0, 12)} ·{" "}
                        {(m.meta as ChatApiResponse).audit.latencyMs}ms ·{" "}
                        {(m.meta as ChatApiResponse).model}
                      </div>
                    </div>
                  ) : null}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {mut.isPending && (
            <div className="text-xs font-mono text-muted-foreground animate-pulse">
              Isabella está pensando con evidencia…
            </div>
          )}
        </section>

        <div className="flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Pregunta algo (BookPI, MD-X4, Korima, Atlas…)"
            className="flex-1 bg-card/40 border border-border/50 focus:border-primary/60 outline-none rounded-md px-4 py-3 text-sm"
          />
          <button
            onClick={send}
            disabled={mut.isPending || !input.trim()}
            className="px-5 py-3 rounded-md bg-primary text-primary-foreground text-sm font-medium disabled:opacity-40 hover:opacity-90 transition"
          >
            Enviar
          </button>
        </div>

        <div className="text-[10px] font-mono text-muted-foreground">
          Endpoints: <code>/api/public/ai/isabella/chat</code> ·{" "}
          <code>/api/public/ai/isabella/recommendation</code> ·{" "}
          <code>/api/public/ai/metrics</code> ·{" "}
          <code>/api/public/openapi/tamvai</code>
        </div>
      </main>
    </div>
  );
}
