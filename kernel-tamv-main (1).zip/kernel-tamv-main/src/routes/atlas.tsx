import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/tamv/Header";
import { Footer } from "@/components/tamv/Footer";
import { NexusGraph } from "@/components/tamv/NexusGraph";
import { FEDERATIONS, type FederationId } from "@/lib/ecosystem/contracts";
import { REPOS } from "@/lib/ecosystem/manifest";
import {
  TAMV_SOVEREIGN_IDENTITY,
  TAMV_PUBLISHING_NETWORK,
  KERNEL_LAYERS,
  FUSED_PROJECTS,
  TAMV_NUCLEI,
  UNIFIED_ATLAS_VERSION,
} from "../../lib/atlas/unified-tamv-atlas";
import {
  ABSORPTION_SUMMARY,
  CATEGORY_LABELS,
} from "../../lib/atlas/data/absorption";

export const Route = createFileRoute("/atlas")({
  head: () => ({
    meta: [
      { title: "Atlas Final TAMV — Heptafederación MD-X4 · MD-X5" },
      {
        name: "description",
        content:
          "Fusión doctrinal del ecosistema TAMV: kernel, 7 federaciones, 8 capas MD-X4/X5, núcleos RDM/UTAMV/CITEMESH y todos los sub-proyectos federados. DOI 10.5281/zenodo.19436662.",
      },
      { property: "og:title", content: "Atlas Final · TAMV" },
      {
        property: "og:description",
        content: "Cartografía viva de la heptafederación TAMV. Atlas final fusionado.",
      },
    ],
  }),
  component: AtlasPage,
});

function AtlasPage() {
  const fedIds = Object.keys(FEDERATIONS) as FederationId[];
  const I = TAMV_SOVEREIGN_IDENTITY;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 px-6 py-12">
        <div className="mx-auto max-w-7xl space-y-16">
          {/* HERO */}
          <section>
            <div className="text-[11px] font-mono uppercase tracking-[0.3em] text-primary">
              {UNIFIED_ATLAS_VERSION} · Atlas Final
            </div>
            <h1 className="mt-2 font-display text-4xl md:text-5xl">
              Heptafederación MD-X4 — fusión total
            </h1>
            <p className="mt-3 max-w-3xl text-muted-foreground">
              Centro: kernel TAMV. Anillo medio: 7 federaciones doctrinales. Anillo externo:
              repos vivos y sub-proyectos fusionados (Shadow Realm, Project Genesis, RDM Hub,
              RDM Turismo, Genesis Nexus, tamv-digital-genesis).
            </p>
            <div className="mt-6">
              <NexusGraph />
            </div>
          </section>

          {/* SOBERANÍA */}
          <section className="rounded-xl border border-border/60 bg-card p-6">
            <div className="text-[11px] font-mono uppercase tracking-[0.3em] text-primary">
              Soberanía
            </div>
            <h2 className="mt-1 font-display text-2xl">{I.legalName} · «{I.alias}»</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {I.role} — {I.base}
            </p>
            <blockquote className="mt-4 border-l-2 border-primary pl-4 text-sm italic text-muted-foreground">
              {I.motto}
            </blockquote>
            <div className="mt-5 grid sm:grid-cols-2 md:grid-cols-4 gap-3 font-mono text-[11px]">
              <a
                href={I.orcidUrl}
                target="_blank"
                rel="noreferrer"
                className="rounded-md border border-border/60 p-3 hover:border-primary"
              >
                <div className="uppercase tracking-widest text-muted-foreground">ORCID</div>
                <div className="mt-1 text-foreground">{I.orcid}</div>
              </a>
              <a
                href={I.zenodoUrl}
                target="_blank"
                rel="noreferrer"
                className="rounded-md border border-border/60 p-3 hover:border-primary"
              >
                <div className="uppercase tracking-widest text-muted-foreground">DOI Zenodo</div>
                <div className="mt-1 text-foreground">{I.zenodoDoi}</div>
              </a>
              <a
                href={I.github}
                target="_blank"
                rel="noreferrer"
                className="rounded-md border border-border/60 p-3 hover:border-primary"
              >
                <div className="uppercase tracking-widest text-muted-foreground">GitHub</div>
                <div className="mt-1 text-foreground">OsoPanda1</div>
              </a>
              <div className="rounded-md border border-border/60 p-3">
                <div className="uppercase tracking-widest text-muted-foreground">Resistencia</div>
                <div className="mt-1 text-foreground">
                  {I.hoursInvested.toLocaleString()} h · {I.yearsResisting} años
                </div>
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {TAMV_PUBLISHING_NETWORK.map((p) => (
                <a
                  key={p.id}
                  href={p.url}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-border/60 px-3 py-1 font-mono text-[10px] uppercase tracking-widest hover:border-primary"
                >
                  {p.label}
                </a>
              ))}
            </div>
          </section>

          {/* FEDERACIONES */}
          <section>
            <h2 className="font-display text-2xl">7 federaciones</h2>
            <div className="mt-4 grid md:grid-cols-7 gap-3">
              {fedIds.map((id) => {
                const f = FEDERATIONS[id];
                const count = REPOS.filter((r) => r.federation === id).length;
                return (
                  <div
                    key={id}
                    className="rounded-lg border border-border/60 bg-card p-3"
                  >
                    <div className="flex items-baseline justify-between">
                      <span
                        className="font-display text-xl"
                        style={{ color: f.color }}
                      >
                        {f.sigil}
                      </span>
                      <span className="font-mono text-[10px] text-muted-foreground">
                        {count}
                      </span>
                    </div>
                    <div className="mt-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                      {f.id}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* CAPAS KERNEL */}
          <section>
            <h2 className="font-display text-2xl">8 capas · Kernel MD-X4 / MD-X5</h2>
            <div className="mt-4 grid md:grid-cols-2 gap-3">
              {KERNEL_LAYERS.map((l) => (
                <div
                  key={l.id}
                  className="rounded-lg border border-border/60 bg-card p-4"
                >
                  <div className="flex items-baseline justify-between">
                    <span className="font-mono text-xs text-primary">{l.id}</span>
                    <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                      {l.hexagon} · {l.domain}
                    </span>
                  </div>
                  <h3 className="mt-1 font-display text-lg">{l.name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{l.desc}</p>
                </div>
              ))}
            </div>
          </section>

          {/* NÚCLEOS */}
          <section>
            <h2 className="font-display text-2xl">Núcleos federados</h2>
            <div className="mt-4 grid sm:grid-cols-2 md:grid-cols-5 gap-3">
              {TAMV_NUCLEI.map((n) => (
                <div
                  key={n.id}
                  className="rounded-lg border border-border/60 bg-card p-4"
                >
                  <div className="text-2xl">{n.icon}</div>
                  <div className="mt-1 font-display text-lg">{n.name}</div>
                  <p className="mt-1 text-xs text-muted-foreground">{n.desc}</p>
                </div>
              ))}
            </div>
          </section>

          {/* SUB-PROYECTOS FUSIONADOS */}
          <section>
            <h2 className="font-display text-2xl">
              Sub-proyectos fusionados ({FUSED_PROJECTS.length})
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Origen: kernel, proyectos Lovable conectados y archivos cargados (ZIP).
              Cada nodo declara su pipeline (He) y dominio (Hep).
            </p>
            <div className="mt-4 grid md:grid-cols-2 lg:grid-cols-3 gap-3">
              {FUSED_PROJECTS.map((p) => (
                <article
                  key={p.id}
                  className="rounded-lg border border-border/60 bg-card p-4"
                >
                  <div className="flex items-baseline justify-between">
                    <span className="font-mono text-[10px] uppercase tracking-widest text-primary">
                      {p.origin}
                    </span>
                    <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                      {p.hexagon} · {p.domain}
                    </span>
                  </div>
                  <h3 className="mt-1 font-display text-lg">{p.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{p.summary}</p>
                  <div className="mt-3 flex flex-wrap gap-1">
                    {p.pages.map((pg) => (
                      <span
                        key={pg}
                        className="rounded border border-border/50 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground"
                      >
                        {pg}
                      </span>
                    ))}
                  </div>
                  {p.url ? (
                    <a
                      href={p.url}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-3 inline-block font-mono text-[10px] uppercase tracking-widest text-primary hover:underline"
                    >
                      abrir ↗
                    </a>
                  ) : null}
                </article>
              ))}
            </div>
          </section>

          {/* ── ABSORCIÓN DRIVE + ONEDRIVE ───────────────────────────── */}
          <section className="space-y-4">
            <div className="flex items-baseline justify-between">
              <h2 className="font-display text-2xl">Absorción Drive + OneDrive</h2>
              <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                {ABSORPTION_SUMMARY.totals.all} archivos · Drive {ABSORPTION_SUMMARY.totals.google_drive} · OneDrive {ABSORPTION_SUMMARY.totals.microsoft_onedrive}
              </span>
            </div>
            <p className="text-sm text-muted-foreground max-w-3xl">
              Inventario federado de los archivos del CEO absorbidos desde Google Drive y Microsoft OneDrive vía el connector-gateway de Lovable. Clasificado por dominio doctrinal y operativo del Atlas.
            </p>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
              {Object.entries(ABSORPTION_SUMMARY.byCategory)
                .sort((a, b) => b[1] - a[1])
                .map(([cat, count]) => (
                  <article key={cat} className="rounded-lg border border-border/60 bg-card/50 p-4">
                    <div className="flex items-baseline justify-between">
                      <h3 className="font-display text-sm">{CATEGORY_LABELS[cat] ?? cat}</h3>
                      <span className="font-mono text-xs text-primary">{count}</span>
                    </div>
                    <ul className="mt-2 space-y-1">
                      {(ABSORPTION_SUMMARY.topByCategory[cat] ?? []).slice(0, 4).map((f, i) => (
                        <li key={i} className="truncate font-mono text-[10px] text-muted-foreground">
                          <span className="text-foreground/70">[{f.provider === "google_drive" ? "GD" : "OD"}]</span>{" "}
                          {f.url ? (
                            <a href={f.url} target="_blank" rel="noreferrer" className="hover:text-primary">
                              {f.name}
                            </a>
                          ) : (
                            f.name
                          )}
                        </li>
                      ))}
                    </ul>
                  </article>
                ))}
            </div>
            <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              generado · {new Date(ABSORPTION_SUMMARY.generatedAt).toLocaleString("es-MX")}
            </p>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  );
}
