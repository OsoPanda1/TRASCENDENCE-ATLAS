import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/tamv/Header";

export const Route = createFileRoute("/drive")({
  head: () => ({
    meta: [
      { title: "Drive · OneDrive — TAMV Bridge" },
      {
        name: "description",
        content:
          "Browser federado de Google Drive y Microsoft OneDrive conectados vía connector gateway, listo para ingestar documentos al Canon Isabella.",
      },
      { property: "og:title", content: "TAMV · Drive Bridge" },
    ],
  }),
  component: DrivePage,
});

type DriveFile = {
  id: string;
  name: string;
  mimeType?: string;
  modifiedTime?: string;
  size?: string;
  webViewLink?: string;
};
type OneDriveItem = {
  id: string;
  name: string;
  size?: number;
  lastModifiedDateTime?: string;
  webUrl?: string;
  file?: unknown;
  folder?: unknown;
};

function DrivePage() {
  const [provider, setProvider] = useState<"drive" | "onedrive">("drive");
  const [q, setQ] = useState("");

  const drive = useQuery({
    queryKey: ["drive", q],
    enabled: provider === "drive",
    queryFn: async () => {
      const url = `/api/public/drive/list${q ? `?q=${encodeURIComponent(`name contains '${q}'`)}` : ""}`;
      const r = await fetch(url);
      return r.json() as Promise<{ files?: DriveFile[]; error?: string; status?: number }>;
    },
  });

  const onedrive = useQuery({
    queryKey: ["onedrive", q],
    enabled: provider === "onedrive",
    queryFn: async () => {
      const url = `/api/public/onedrive/list${q ? `?q=${encodeURIComponent(q)}` : ""}`;
      const r = await fetch(url);
      return r.json() as Promise<{ value?: OneDriveItem[]; error?: string; status?: number }>;
    },
  });

  const loading = provider === "drive" ? drive.isLoading : onedrive.isLoading;
  const data = provider === "drive" ? drive.data : onedrive.data;
  const items: Array<{ id: string; name: string; meta: string; href?: string }> =
    provider === "drive"
      ? (data && "files" in data && data.files ? data.files : []).map((f) => ({
          id: f.id,
          name: f.name,
          meta: `${f.mimeType ?? ""} · ${f.modifiedTime?.slice(0, 10) ?? ""}`,
          href: f.webViewLink,
        }))
      : (data && "value" in data && data.value ? data.value : []).map((f) => ({
          id: f.id,
          name: f.name,
          meta: `${f.folder ? "folder" : "file"} · ${
            f.lastModifiedDateTime?.slice(0, 10) ?? ""
          }`,
          href: f.webUrl,
        }));

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main className="mx-auto max-w-5xl px-6 py-10 space-y-6">
        <header className="flex items-end justify-between">
          <div>
            <h1 className="font-display text-3xl tracking-tight">
              Drive <span className="text-primary">·</span> OneDrive
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Bridge federado vía connector gateway. Fuente para ingesta al Canon Isabella.
            </p>
          </div>
          <div className="flex gap-1 text-[11px] font-mono">
            {(["drive", "onedrive"] as const).map((p) => (
              <button
                key={p}
                onClick={() => setProvider(p)}
                className={`px-2.5 py-1 rounded border ${
                  provider === p
                    ? "border-primary text-primary bg-primary/10"
                    : "border-border/50 text-muted-foreground hover:text-foreground"
                }`}
              >
                {p === "drive" ? "google drive" : "onedrive"}
              </button>
            ))}
          </div>
        </header>

        <div className="flex gap-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={
              provider === "drive"
                ? "buscar por nombre (filtro 'name contains')"
                : "buscar (q)"
            }
            className="flex-1 bg-card/40 border border-border/50 focus:border-primary/60 outline-none rounded-md px-4 py-2.5 text-sm"
          />
        </div>

        <section className="rounded-xl border border-border/40 bg-card/30 backdrop-blur divide-y divide-border/30">
          {loading && (
            <div className="px-4 py-6 text-xs font-mono text-muted-foreground animate-pulse">
              consultando {provider}…
            </div>
          )}
          {!loading && data && "error" in data && data.error && (
            <div className="px-4 py-6 text-xs font-mono text-destructive">
              {data.error} · status {data.status ?? "?"}
            </div>
          )}
          {!loading &&
            items.map((it) => (
              <a
                key={it.id}
                href={it.href}
                target="_blank"
                rel="noreferrer"
                className="flex items-baseline gap-4 px-4 py-3 hover:bg-muted/20 transition"
              >
                <span className="text-primary font-mono text-[10px] uppercase tracking-widest w-12">
                  {provider === "drive" ? "gdrv" : "od"}
                </span>
                <span className="flex-1 text-sm truncate">{it.name}</span>
                <span className="text-[10px] font-mono text-muted-foreground truncate max-w-[40%]">
                  {it.meta}
                </span>
              </a>
            ))}
          {!loading && items.length === 0 && !(data && "error" in data && data.error) && (
            <div className="px-4 py-6 text-xs font-mono text-muted-foreground">
              sin resultados
            </div>
          )}
        </section>

        <div className="text-[10px] font-mono text-muted-foreground">
          Endpoints: <code>/api/public/drive/list</code> ·{" "}
          <code>/api/public/onedrive/list</code> · gateway Lovable
        </div>
      </main>
    </div>
  );
}
