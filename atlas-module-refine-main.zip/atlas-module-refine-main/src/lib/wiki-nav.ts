export type WikiSection = {
  title: string;
  items: { to: string; label: string }[];
};

export const wikiNav: WikiSection[] = [
  {
    title: "Portada",
    items: [
      { to: "/", label: "Landing público" },
      { to: "/wiki", label: "Wiki canónica" },
      { to: "/atlas", label: "Atlas — arquitectura" },
    ],
  },
  {
    title: "Quiénes somos",
    items: [
      { to: "/origen", label: "Origen y dónde comenzamos" },
      { to: "/mision-vision", label: "Misión, visión y valores" },
      { to: "/objetivos", label: "Objetivos" },
    ],
  },
  {
    title: "Estrategia",
    items: [
      { to: "/posicionamiento", label: "Posicionamiento" },
      { to: "/estrategias", label: "Estrategias" },
      { to: "/servicio-atlas", label: "Servicio Atlas" },
    ],
  },
  {
    title: "Participa",
    items: [
      { to: "/convocatoria", label: "Convocatoria abierta" },
    ],
  },
  {
    title: "Documentos",
    items: [
      { to: "/auditoria", label: "Auditoría canónica v1.0" },
    ],
  },
];
