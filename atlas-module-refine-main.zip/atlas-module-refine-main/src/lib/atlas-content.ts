/**
 * Atlas TAMV — Contenido canónico extraído de:
 * - wikiatlasofi.docx (TAMV Core Kernel / ELITE HeHep)
 * - WIKIRDMLDTOS.docx (RDM Digital LTOS / arquitectura territorial)
 * - RDMLAWIKI.docx (Compilación RDM Digital Plataforma LTOS)
 * - pasted-2026-06-12T00-08-36-040Z.txt (copy hero y narrativa devs)
 *
 * No inventar contenido nuevo. Sólo reordenar y exponer para la UI.
 */

export const heroCopy = {
  kicker: "Atlas TAMV · v1.0",
  title: "Compilador civilizatorio y Atlas vivo de conocimiento soberano",
  subtitle:
    "Plataforma federada para versionar, evaluar y promover conocimiento como si fuera código: grafo vivo, constitución computable y guardianías distribuidas — desde Real del Monte para el mundo.",
  bullets: [
    "Grafo global de conocimiento, código, políticas y territorios.",
    "Compilador civilizatorio que simula impacto antes de promover cambios.",
    "Constitución computable que bloquea lo que viola soberanía, dignidad o trazabilidad.",
  ],
  ctaPrimary: { label: "Explorar el Atlas", to: "/atlas" as const },
  ctaSecondary: { label: "Unirte a la convocatoria", to: "/convocatoria" as const },
} as const;

export const pipelineStages = [
  {
    id: "ingesta",
    name: "Ingesta",
    role: "HE-Ingest",
    body:
      "Repos, docs, DOIs, APIs, datasets, políticas y nodos territoriales entran al ecosistema vía API unificada y eventos BookPI firmados.",
  },
  {
    id: "guardianias",
    name: "Guardianías",
    role: "HE-Transform",
    body:
      "Siete guardianes responden: ¿pertenece? ¿qué es? ¿con qué se conecta? ¿qué puede romper? ¿viola la constitución? ¿cómo cambia el grafo? ¿en qué estado queda?",
  },
  {
    id: "grafo",
    name: "Grafo Atlas",
    role: "HE-Publish",
    body:
      "Módulos, nodos, políticas, APIs, DOIs, actores y territorios se proyectan en un grafo vivo con linaje y dependencias trazables.",
  },
  {
    id: "fitness",
    name: "Fitness civilizatorio",
    role: "HE-Science",
    body:
      "Se mide coherencia, trazabilidad, cobertura, reutilización, contradicción y fragmentación. Si sube sin violar invariantes, se promueve.",
  },
  {
    id: "promocion",
    name: "Promoción / congelamiento",
    role: "HE-Identity",
    body:
      "Cada cambio queda en uno de tres estados: experimental, promovido o rechazado. Los módulos estables se congelan con doc canónica.",
  },
] as const;

export const guardians = [
  { q: "¿Pertenece al ecosistema?", g: "Identidad" },
  { q: "¿Qué es?", g: "Ontología" },
  { q: "¿Con qué se conecta?", g: "Semántica" },
  { q: "¿Qué puede romper?", g: "Riesgo" },
  { q: "¿Viola la constitución?", g: "Constitución" },
  { q: "¿Cómo cambia el grafo?", g: "Simulación" },
  { q: "¿En qué estado queda?", g: "Promoción" },
] as const;

export const layers = [
  { id: "L0", name: "DEKATEOTL™", role: "Filtro ontológico / parada ética" },
  { id: "L1", name: "TAMV Memory", role: "Memoria episódica (SDMD-7)" },
  { id: "L2", name: "BookPI™", role: "Cripto-inmutabilidad / libro mayor" },
  { id: "L3", name: "ANUBIS Sentinel™", role: "Seguridad perimetral / correlación de amenazas" },
  { id: "L4", name: "HyperRender X4", role: "Capa sensorial (XR / 4D)" },
  { id: "L5", name: "ID-NVIDA™", role: "Identidad soberana / DID / ZKP" },
  { id: "L6", name: "Isabella AI™", role: "Cognición neuro-simbólica / UX" },
  { id: "L7", name: "Master Architect", role: "Macro-gobernanza / pipelines THCF" },
] as const;

export const federations = [
  { id: "tecnologica", name: "Tecnológica", body: "Kernel, IA, sistemas y Nexus." },
  { id: "cultural", name: "Cultural", body: "Documentación, manuscritos, tomos, génesis y wiki." },
  { id: "gubernamental", name: "Gubernamental", body: "Protocolos, canon, legal y federación." },
  { id: "economica", name: "Económica", body: "Mercado, comercio, wallets, Cattleya Pay y fondos Phoenix." },
  { id: "educativa", name: "Educativa", body: "Academia, cursos, UTAMV y pedagogía." },
  { id: "salud", name: "Salud", body: "Clínica, telemedicina y servicios sanitarios." },
  { id: "comunicacion", name: "Comunicación", body: "Radio, prensa, medios y relato público." },
] as const;

export const hexagons = [
  { id: "HE-Ingest", name: "Ingesta", role: "Web, sensores, APIs, XR, logs y señales federadas." },
  { id: "HE-Transform", name: "Transformación", role: "Filtrado de 4 capas, guardianes y normalización." },
  { id: "HE-Publish", name: "Publicación", role: "Artefactos, contratos y eventos BookPI verificables." },
  { id: "HE-Science", name: "Ciencia", role: "Ciencia abierta, DOIs, ORCID y evidencia académica." },
  { id: "HE-Economy", name: "Economía", role: "Reputación, DAO, tokenomics y justicia económica." },
  { id: "HE-Identity", name: "Identidad", role: "Identidad soberana, IsabellaCoreProtocol, GoS y DIDs." },
] as const;

export const hepDomains = [
  { id: "HEP-1", name: "Central", role: "Kernel core, BookPI, contratos y router heptafederado." },
  { id: "HEP-2", name: "Operaciones", role: "Synapse AI, Encore Flow, Nexus y DreamSpaces runtime." },
  { id: "HEP-3", name: "Infraestructura", role: "Edge, XR rendering, HoloWall, NVLink/CXL y multinube." },
  { id: "HEP-4", name: "Seguridad", role: "Dekateotl, guardianes, filtrado 4 capas y cripto post-cuántica." },
  { id: "HEP-5", name: "Financiera", role: "Oracle Sentinel Economy, Ember Stream, AuraBid y BidVision." },
  { id: "HEP-6", name: "Logística", role: "Puentes oníricos, rutas y distribución de experiencias." },
  { id: "HEP-7", name: "Usuarios", role: "IsabellaCoreProtocol, Quantum Pets y diario 24h." },
] as const;

export const components = [
  {
    id: "id-nvida",
    name: "ID-NVIDA",
    body: "Identidad soberana con perfiles verificados de ciudadanos, comercios y guardianes, wallets y DIDs.",
  },
  {
    id: "isabella",
    name: "Isabella AI · Realito",
    body: "Cognición neuro-simbólica bajo reglas EOCT, registrada en BookPI como narrativa auditable.",
  },
  {
    id: "bookpi",
    name: "BookPI™",
    body: "Libro mayor cripto-inmutable. Toda decisión relevante de IA o sistema queda trazada y explicable.",
  },
  {
    id: "cattleya",
    name: "Cattleya Pay · MSR",
    body: "Ledger SQL idempotente, Stripe MXN y reglas de distribución 20/30/50 entre fondos, infraestructura y reservas.",
  },
  {
    id: "twin",
    name: "Real del Monte Twin",
    body: "Gemelo digital 4D con POIs, telemetría de visitantes y capas de rutas, eventos y densidad.",
  },
  {
    id: "guardian",
    name: "Guardian Console",
    body: "Consolas y dashboards ECG para monitoreo en tiempo real de guardianes y políticas activas.",
  },
] as const;

export const nodoCero = {
  title: "Nodo Cero · Real del Monte, Hidalgo",
  body: [
    "RDM Digital es el Sistema Operativo Territorial Soberano para el Pueblo Mágico de Real del Monte. Unifica identidad digital, turismo inteligente, gemelos digitales, economía local y gobernanza en una sola infraestructura auditable, diseñada para replicarse en otros territorios.",
    "Se despliega como LTOS (Local Territorial Operating System): una capa de software que convierte la ciudad física en infraestructura digital interoperable, documentada con estándares académicos (DOI, ORCID, DataCite) y gobernada por principios éticos explícitos.",
  ],
  manifesto: [
    "Territorio como interfaz: la unidad de diseño es el territorio, sus rutas, capas y relaciones.",
    "Relaciones sobre contenido: prima la red de vínculos (mina–evento–persona) sobre páginas sueltas.",
    "Evidencia antes de narrativa: cada afirmación se ancla a registros verificables (DOI, ORCID, MSR, BookPI).",
    "Inteligencia contextual: el sistema interpreta tiempo, lugar e historia, no solo preguntas.",
    "Federación: el modelo está diseñado para que otros territorios se sumen bajo el mismo protocolo.",
  ],
} as const;

export const positioning = {
  title: "Qué hace único al Atlas",
  body:
    "Atlas TAMV no compite con GitHub, GitLab o Wikipedia: se sienta por encima. Donde Wikipedia versiona artículos, GitHub repositorios y Sourcegraph explora código, el Atlas versiona ecosistemas completos —código, políticas, nodos territoriales, datos, DOIs, identidad, gobernanza y memoria histórica— bajo una constitución computable.",
  pillars: [
    {
      name: "Constitución computable",
      body: "Invariantes formales (soberanía, dignidad, trazabilidad, identidad federada) que ninguna IA ni módulo puede romper.",
    },
    {
      name: "Fitness ecosistémico",
      body: "El valor de un cambio se mide por su efecto en el grafo completo, no por la belleza local del código.",
    },
    {
      name: "Tribunal de guardianías",
      body: "Siete módulos especializados evalúan identidad, ontología, semántica, riesgo, constitución, simulación y promoción.",
    },
  ],
} as const;

export const callToAction = {
  title: "Convocatoria abierta",
  body:
    "Buscamos desarrolladores de infraestructura, especialistas en gobernanza de datos, investigadores, comerciantes y comunidades territoriales que quieran sumar su nodo al Atlas. La federación no se delega: se construye.",
  audiences: [
    { who: "Devs e infra", what: "Implementan guardianías, adaptadores BookPI, módulos He y registros federados." },
    { who: "Investigadores", what: "Aportan evidencia con DOI, ORCID y datasets verificables." },
    { who: "Comercios y comunidades", what: "Suman su territorio como nodo del LTOS y reciben visibilidad orgánica." },
    { who: "Instituciones", what: "Operan dominios Hep bajo gobernanza explícita y auditable." },
  ],
} as const;
