import { Link, useRouterState } from "@tanstack/react-router";
import { type ReactNode, useState } from "react";
import { Menu, X } from "lucide-react";

const nav = [
  { to: "/atlas", label: "Atlas" },
  { to: "/wiki", label: "Wiki" },
  { to: "/origen", label: "Origen" },
  { to: "/mision-vision", label: "Misión" },
  { to: "/servicio-atlas", label: "Servicio" },
  { to: "/convocatoria", label: "Convocatoria" },
] as const;

export function LandingTopbar() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur-md">
      <div className="max-w-[1280px] mx-auto px-5 h-16 flex items-center gap-6">
        <Link to="/" className="flex items-center gap-2.5 group shrink-0">
          <span className="w-9 h-9 rounded-md bg-ink text-parchment grid place-items-center font-display font-bold text-sm shadow-sm">
            TA
          </span>
          <span className="font-display text-[17px] font-semibold tracking-tight">
            Atlas <span className="text-primary">TAMV</span>
          </span>
        </Link>

        <nav className="hidden lg:flex items-center gap-1 ml-4">
          {nav.map((item) => {
            const active = pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`px-3 py-1.5 rounded text-sm transition-colors ${
                  active
                    ? "text-foreground font-medium"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex-1" />

        <Link
          to="/convocatoria"
          className="hidden sm:inline-flex items-center px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-medium shadow-sm hover:opacity-90 transition"
        >
          Sumar mi nodo
        </Link>

        <button
          className="lg:hidden p-2 -mr-2 rounded hover:bg-muted"
          onClick={() => setOpen(!open)}
          aria-label="Menú"
        >
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden border-t border-border bg-card">
          <nav className="px-5 py-3 flex flex-col">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="py-2.5 text-sm border-b border-border/40 last:border-0"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}

export function LandingFooter() {
  return (
    <footer className="mt-24 border-t border-border bg-card/50">
      <div className="max-w-[1280px] mx-auto px-5 py-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-8 text-sm">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="w-7 h-7 rounded bg-ink text-parchment grid place-items-center font-display font-bold text-xs">
              TA
            </span>
            <span className="font-display font-semibold">Atlas TAMV</span>
          </div>
          <p className="text-muted-foreground leading-relaxed">
            Enciclopedia abierta del ecosistema TAMV. Orgullosamente Realmontenses,
            desde el centro de Latinoamérica para el mundo.
          </p>
        </div>
        <div>
          <h4 className="font-display text-xs uppercase tracking-wider text-muted-foreground mb-3">
            Plataforma
          </h4>
          <ul className="space-y-1.5">
            <li><Link to="/atlas" className="hover:text-primary">Atlas — arquitectura</Link></li>
            <li><Link to="/wiki" className="hover:text-primary">Wiki canónica</Link></li>
            <li><Link to="/auditoria" className="hover:text-primary">Auditoría v1.0</Link></li>
            <li><Link to="/servicio-atlas" className="hover:text-primary">Servicio Atlas</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-xs uppercase tracking-wider text-muted-foreground mb-3">
            Quiénes somos
          </h4>
          <ul className="space-y-1.5">
            <li><Link to="/origen" className="hover:text-primary">Origen y Nodo Cero</Link></li>
            <li><Link to="/mision-vision" className="hover:text-primary">Misión y visión</Link></li>
            <li><Link to="/objetivos" className="hover:text-primary">Objetivos</Link></li>
            <li><Link to="/posicionamiento" className="hover:text-primary">Posicionamiento</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-xs uppercase tracking-wider text-muted-foreground mb-3">
            Participa
          </h4>
          <ul className="space-y-1.5">
            <li><Link to="/convocatoria" className="hover:text-primary">Convocatoria abierta</Link></li>
            <li><Link to="/estrategias" className="hover:text-primary">Estrategias</Link></li>
            <li>
              <a
                href="https://github.com/OsoPanda1/tamv-atlas-nextgen"
                target="_blank"
                rel="noreferrer"
                className="hover:text-primary"
              >
                Repositorio en GitHub
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="max-w-[1280px] mx-auto px-5 py-4 flex flex-wrap gap-3 justify-between text-xs text-muted-foreground">
          <span>© {new Date().getFullYear()} Atlas TAMV · Nodo Cero Real del Monte, Hidalgo</span>
          <span>Contenido bajo licencia abierta (CC BY-SA 4.0 propuesta)</span>
        </div>
      </div>
    </footer>
  );
}

export function LandingLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <LandingTopbar />
      <main className="flex-1">{children}</main>
      <LandingFooter />
    </div>
  );
}
