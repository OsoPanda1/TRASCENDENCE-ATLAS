import { Link, useRouterState } from "@tanstack/react-router";
import { type ReactNode, useState } from "react";
import { wikiNav } from "@/lib/wiki-nav";
import { Menu, X, Search } from "lucide-react";

type TocItem = { id: string; label: string };

export function WikiShell({
  title,
  subtitle,
  toc,
  children,
  meta,
}: {
  title: string;
  subtitle?: string;
  toc?: TocItem[];
  children: ReactNode;
  meta?: { label: string; value: string }[];
}) {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen flex flex-col">
      {/* Topbar */}
      <header className="border-b border-border bg-card/80 backdrop-blur sticky top-0 z-30">
        <div className="max-w-[1400px] mx-auto px-4 h-14 flex items-center gap-4">
          <button
            className="lg:hidden p-2 -ml-2 rounded hover:bg-muted"
            onClick={() => setOpen(!open)}
            aria-label="Menú"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
          <Link to="/" className="flex items-center gap-2.5 group">
            <span className="w-8 h-8 rounded-md bg-primary text-primary-foreground grid place-items-center font-display font-bold text-sm shadow-sm">
              TA
            </span>
            <span className="font-display text-lg font-semibold tracking-tight">
              Atlas <span className="text-primary">TAMV</span>
            </span>
            <span className="hidden md:inline text-xs text-muted-foreground border-l border-border pl-2 ml-1">
              Enciclopedia libre · v1.0
            </span>
          </Link>
          <div className="flex-1" />
          <div className="hidden md:flex items-center gap-2 bg-muted px-3 py-1.5 rounded-md text-sm text-muted-foreground w-64">
            <Search size={14} />
            <span className="text-xs">Buscar en el Atlas…</span>
            <kbd className="ml-auto text-[10px] bg-background px-1.5 py-0.5 rounded border border-border">⌘K</kbd>
          </div>
          <a
            href="https://github.com/OsoPanda1/tamv-atlas-nextgen"
            target="_blank"
            rel="noreferrer"
            className="hidden sm:inline text-xs text-muted-foreground hover:text-foreground"
          >
            Repositorio
          </a>
        </div>
      </header>

      <div className="max-w-[1400px] w-full mx-auto flex-1 grid lg:grid-cols-[240px_1fr_220px] gap-0">
        {/* Sidebar */}
        <aside
          className={`${
            open ? "block" : "hidden"
          } lg:block border-r border-border bg-sidebar/60 lg:sticky lg:top-14 lg:self-start lg:h-[calc(100vh-3.5rem)] overflow-y-auto`}
        >
          <nav className="p-5 space-y-6 text-sm">
            {wikiNav.map((section) => (
              <div key={section.title}>
                <h3 className="font-display text-[11px] uppercase tracking-[0.12em] text-muted-foreground mb-2">
                  {section.title}
                </h3>
                <ul className="space-y-0.5">
                  {section.items.map((item) => {
                    const active = pathname === item.to;
                    return (
                      <li key={item.to}>
                        <Link
                          to={item.to}
                          onClick={() => setOpen(false)}
                          className={`block px-2 py-1.5 rounded text-[13.5px] leading-snug border-l-2 transition-colors ${
                            active
                              ? "border-primary bg-accent/60 text-foreground font-medium"
                              : "border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/60"
                          }`}
                        >
                          {item.label}
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
            <div className="pt-4 border-t border-border text-[11px] text-muted-foreground leading-relaxed">
              Orgullosamente Realmontenses<br />
              Desde el centro de Latinoamérica<br />
              para el mundo.
            </div>
          </nav>
        </aside>

        {/* Main */}
        <main className="px-5 sm:px-10 py-10 max-w-[820px] w-full">
          <div className="text-xs text-muted-foreground mb-2">
            <Link to="/" className="hover:text-foreground">Atlas TAMV</Link>
            {pathname !== "/" && <span> / {title}</span>}
          </div>
          <h1 className="font-display text-4xl sm:text-5xl font-semibold tracking-tight text-foreground">
            {title}
          </h1>
          {subtitle && (
            <p className="mt-2 text-base text-muted-foreground italic">{subtitle}</p>
          )}
          {meta && meta.length > 0 && (
            <dl className="mt-6 grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 bg-card border border-border rounded-md text-sm">
              {meta.map((m) => (
                <div key={m.label}>
                  <dt className="text-[10px] uppercase tracking-wider text-muted-foreground">{m.label}</dt>
                  <dd className="font-medium text-foreground mt-0.5">{m.value}</dd>
                </div>
              ))}
            </dl>
          )}
          <div className="mt-2 h-px bg-border" />
          <article className="prose-tamv mt-4">{children}</article>

          <footer className="mt-16 pt-6 border-t border-border text-xs text-muted-foreground flex flex-wrap gap-x-6 gap-y-1">
            <span>© {new Date().getFullYear()} Atlas TAMV</span>
            <span>Contenido bajo licencia abierta (CC BY-SA 4.0 propuesta)</span>
            <span>Última revisión canónica: 11 jun 2026</span>
          </footer>
        </main>

        {/* TOC */}
        <aside className="hidden lg:block border-l border-border lg:sticky lg:top-14 lg:self-start lg:h-[calc(100vh-3.5rem)] overflow-y-auto">
          <div className="p-5 text-sm">
            <h3 className="font-display text-[11px] uppercase tracking-[0.12em] text-muted-foreground mb-3">
              En esta página
            </h3>
            {toc && toc.length > 0 ? (
              <ul className="space-y-1.5">
                {toc.map((t) => (
                  <li key={t.id}>
                    <a
                      href={`#${t.id}`}
                      className="text-[13px] text-muted-foreground hover:text-primary block leading-snug"
                    >
                      {t.label}
                    </a>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-muted-foreground">Sin secciones.</p>
            )}
            <div className="mt-8 pt-4 border-t border-border">
              <h3 className="font-display text-[11px] uppercase tracking-[0.12em] text-muted-foreground mb-2">
                Herramientas
              </h3>
              <ul className="space-y-1 text-[13px]">
                <li><a className="text-muted-foreground hover:text-primary" href="#">Citar esta página</a></li>
                <li><a className="text-muted-foreground hover:text-primary" href="#">Versión PDF</a></li>
                <li><a className="text-muted-foreground hover:text-primary" href="#">Historial</a></li>
              </ul>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

export function Section({ id, title, children }: { id: string; title: string; children: ReactNode }) {
  return (
    <section id={id}>
      <h2>{title}</h2>
      {children}
    </section>
  );
}
