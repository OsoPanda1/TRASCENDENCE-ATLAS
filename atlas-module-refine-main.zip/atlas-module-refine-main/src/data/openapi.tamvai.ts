import { createFileRoute } from "@tanstack/react-router";
import { renderPrometheus } from "../../../../lib/isabella/gateway/metrics";

export const Route = createFileRoute("/api/public/ai/metrics")({
  server: {
    handlers: {
      GET: async () =>
        new Response(renderPrometheus(), {
          status: 200,
          headers: {
            "Content-Type": "text/plain; version=0.0.4; charset=utf-8",
            "Access-Control-Allow-Origin": "*",
          },
        }),
    },
  },
});
