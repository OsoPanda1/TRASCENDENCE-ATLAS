/**
 * Isabella Gateway — modelos declarativos.
 * Reglas evaluadas por funciones tipadas (no eval).
 */

export type ProviderKind = "local-stub" | "local-vllm" | "external-llm" | "lovable-ai";

export interface ModelConfig {
  id: string;
  provider: ProviderKind;
  endpoint?: string;
  maxTokens: number;
  temperature: number;
  costWeight: number;
  enabled: boolean;
  description: string;
}

export interface RoutingContext {
  messagesLength: number;
  mode: ChatMode;
  previousModelFailed: boolean;
}

export type ChatMode = "default" | "tutor" | "mediator" | "territorial";

export interface RoutingRule {
  name: string;
  match: (ctx: RoutingContext) => boolean;
  targetModelId: string;
}

export const MODELS: Record<string, ModelConfig> = {
  "mdx5-stub": {
    id: "mdx5-stub",
    provider: "local-stub",
    maxTokens: 2048,
    temperature: 0.7,
    costWeight: 0,
    enabled: true,
    description:
      "Stub determinista del kernel MD-X5 — sintetiza respuestas a partir del Canon Isabella sin llamar a un LLM externo.",
  },
  "mdx5-large": {
    id: "mdx5-large",
    provider: "local-vllm",
    endpoint: "http://mdx5-large:8000/v1/chat",
    maxTokens: 8192,
    temperature: 0.6,
    costWeight: 2,
    enabled: false,
    description: "Modelo soberano grande (auto-hospedado vLLM). Pendiente de despliegue.",
  },
  "external-backup": {
    id: "external-backup",
    provider: "external-llm",
    endpoint: "https://vendor.example.com/v1/chat",
    maxTokens: 4096,
    temperature: 0.7,
    costWeight: 3,
    enabled: false,
    description: "Vendor externo de respaldo. Deshabilitado por defecto (soberanía).",
  },
};

export const DEFAULT_MODEL_ID = "mdx5-stub";

export const ROUTING_RULES: RoutingRule[] = [
  {
    name: "backup-on-failure",
    match: (c) => c.previousModelFailed,
    targetModelId: "external-backup",
  },
  {
    name: "long-form-or-territorial",
    match: (c) => c.messagesLength >= 800 || c.mode === "tutor" || c.mode === "territorial",
    targetModelId: "mdx5-large",
  },
  {
    name: "short-default",
    match: (c) => c.messagesLength < 800 && c.mode === "default",
    targetModelId: "mdx5-stub",
  },
];
