import { createFileRoute } from "@tanstack/react-router";

/**
 * Legacy endpoint — el subsistema TAMVArtifact se reemplazó por el kernel
 * canónico MD-X4. Para ingesta usa POST /api/public/ingest.
 */
export const Route = createFileRoute("/api/kernel/artifacts/sync")({
  server: {
    handlers: {
      POST: async () =>
        new Response(
          JSON.stringify(
            {
              ok: false,
              error: "deprecated",
              replacement: "/api/public/ingest",
            },
            null,
            2,
          ),
          {
            status: 410,
            headers: { "Content-Type": "application/json; charset=utf-8" },
          },
        ),
    },
  },
});
