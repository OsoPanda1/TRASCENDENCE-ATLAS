/**
 * Métricas Prometheus-like in-memory (worker-safe).
 * Exposición en formato text/plain compatible con Prometheus.
 */

interface CounterMetric {
  kind: "counter";
  name: string;
  help: string;
  values: Map<string, number>;
}
interface HistogramMetric {
  kind: "histogram";
  name: string;
  help: string;
  buckets: number[];
  series: Map<string, { count: number; sum: number; bucketCounts: number[] }>;
}

type Metric = CounterMetric | HistogramMetric;

const registry = new Map<string, Metric>();

function labelKey(labels: Record<string, string | number>): string {
  return Object.entries(labels)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}="${String(v).replace(/"/g, '\\"')}"`)
    .join(",");
}

function getOrCreateCounter(name: string, help: string): CounterMetric {
  let m = registry.get(name);
  if (!m) {
    m = { kind: "counter", name, help, values: new Map() };
    registry.set(name, m);
  }
  return m as CounterMetric;
}

function getOrCreateHistogram(
  name: string,
  help: string,
  buckets: number[],
): HistogramMetric {
  let m = registry.get(name);
  if (!m) {
    m = { kind: "histogram", name, help, buckets, series: new Map() };
    registry.set(name, m);
  }
  return m as HistogramMetric;
}

export function incCounter(
  name: string,
  help: string,
  labels: Record<string, string | number>,
  by = 1,
) {
  const m = getOrCreateCounter(name, help);
  const key = labelKey(labels);
  m.values.set(key, (m.values.get(key) ?? 0) + by);
}

export function observeHistogram(
  name: string,
  help: string,
  buckets: number[],
  labels: Record<string, string | number>,
  value: number,
) {
  const m = getOrCreateHistogram(name, help, buckets);
  const key = labelKey(labels);
  let s = m.series.get(key);
  if (!s) {
    s = { count: 0, sum: 0, bucketCounts: buckets.map(() => 0) };
    m.series.set(key, s);
  }
  s.count += 1;
  s.sum += value;
  for (let i = 0; i < buckets.length; i++) {
    if (value <= buckets[i]) s.bucketCounts[i] += 1;
  }
}

export function renderPrometheus(): string {
  const lines: string[] = [];
  for (const m of registry.values()) {
    lines.push(`# HELP ${m.name} ${m.help}`);
    lines.push(`# TYPE ${m.name} ${m.kind}`);
    if (m.kind === "counter") {
      for (const [k, v] of m.values) {
        lines.push(`${m.name}{${k}} ${v}`);
      }
    } else {
      for (const [k, s] of m.series) {
        for (let i = 0; i < m.buckets.length; i++) {
          const lbl = k ? `${k},le="${m.buckets[i]}"` : `le="${m.buckets[i]}"`;
          lines.push(`${m.name}_bucket{${lbl}} ${s.bucketCounts[i]}`);
        }
        const lblInf = k ? `${k},le="+Inf"` : `le="+Inf"`;
        lines.push(`${m.name}_bucket{${lblInf}} ${s.count}`);
        lines.push(`${m.name}_sum{${k}} ${s.sum}`);
        lines.push(`${m.name}_count{${k}} ${s.count}`);
      }
    }
  }
  return lines.join("\n") + "\n";
}

// Métricas canónicas usadas por el gateway
export const REQUESTS_TOTAL = "isabella_http_requests_total";
export const LLM_LATENCY = "isabella_llm_latency_seconds";
export const LATENCY_BUCKETS = [0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10];
