import { ReactNode } from "react";
import { Lock } from "lucide-react";

interface Props {
  isAuthorized: boolean;
  children: ReactNode;
}

export const AnubisGuard = ({ isAuthorized, children }: Props) => {
  if (!isAuthorized) {
    return (
      <div className="flex flex-col items-center justify-center p-12 bg-red-950/10 border border-red-500/20 rounded-xl">
        <Lock className="text-red-500 w-12 h-12 mb-4 animate-pulse" />
        <h2 className="text-red-500 font-bold uppercase tracking-widest text-xs">Acceso Denegado por Anubis</h2>
        <p className="text-[10px] text-gray-500 mt-2">Firma mzTAFa1 no detectada</p>
      </div>
    );
  }
  return <>{children}</>;
};
