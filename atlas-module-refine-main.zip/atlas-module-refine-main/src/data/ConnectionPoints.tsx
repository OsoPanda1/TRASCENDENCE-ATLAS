import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

interface Point {
  id: number;
  x: number;
  y: number;
  baseX: number;
  baseY: number;
  label: string;
}

const labels = [
  "Quantum ID", "Edge AI", "XR Core", "Neural Net", "Blockchain",
  "Multisensory", "Ethics Layer", "Cloud Mesh", "Cyber Shield", 
  "Analytics", "Isabella", "DreamSpaces", "Federation", "Gateway",
  "Validator", "Orchestrator", "Sovereign"
];

const ConnectionPoints = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [points, setPoints] = useState<Point[]>([]);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [hoveredPoint, setHoveredPoint] = useState<number | null>(null);

  useEffect(() => {
    const generatePoints = () => {
      const centerX = 50;
      const centerY = 50;
      const newPoints: Point[] = [];
      
      for (let i = 0; i < 17; i++) {
        const angle = (i / 17) * Math.PI * 2;
        const radius = 30 + Math.random() * 10;
        const x = centerX + Math.cos(angle) * radius;
        const y = centerY + Math.sin(angle) * radius;
        
        newPoints.push({
          id: i,
          x,
          y,
          baseX: x,
          baseY: y,
          label: labels[i],
        });
      }
      setPoints(newPoints);
    };
    
    generatePoints();
  }, []);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setMousePos({ x, y });
  };

  const getInfluencedPosition = (point: Point) => {
    const dx = mousePos.x - point.baseX;
    const dy = mousePos.y - point.baseY;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const influence = Math.max(0, 1 - distance / 30) * 5;
    
    return {
      x: point.baseX + (dx > 0 ? influence : -influence),
      y: point.baseY + (dy > 0 ? influence : -influence),
    };
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-full min-h-[500px]"
      onMouseMove={handleMouseMove}
    >
      {/* Connection lines */}
      <svg className="absolute inset-0 w-full h-full">
        <defs>
          <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="hsl(180, 100%, 50%)" stopOpacity="0.3" />
            <stop offset="50%" stopColor="hsl(285, 55%, 35%)" stopOpacity="0.5" />
            <stop offset="100%" stopColor="hsl(180, 100%, 50%)" stopOpacity="0.3" />
          </linearGradient>
        </defs>
        
        {points.map((point, i) => {
          const pos = getInfluencedPosition(point);
          // Connect to next 3 points
          return [1, 2, 3].map((offset) => {
            const nextPoint = points[(i + offset) % points.length];
            if (!nextPoint) return null;
            const nextPos = getInfluencedPosition(nextPoint);
            return (
              <motion.line
                key={`${i}-${offset}`}
                x1={`${pos.x}%`}
                y1={`${pos.y}%`}
                x2={`${nextPos.x}%`}
                y2={`${nextPos.y}%`}
                stroke="url(#lineGradient)"
                strokeWidth="1"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={{ pathLength: 1, opacity: 0.6 }}
                transition={{ duration: 1.5, delay: i * 0.05 }}
              />
            );
          });
        })}
        
        {/* Center connection */}
        {points.map((point, i) => {
          const pos = getInfluencedPosition(point);
          return (
            <motion.line
              key={`center-${i}`}
              x1="50%"
              y1="50%"
              x2={`${pos.x}%`}
              y2={`${pos.y}%`}
              stroke="hsl(43, 75%, 52%)"
              strokeWidth="0.5"
              strokeOpacity="0.2"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 1, delay: i * 0.03 }}
            />
          );
        })}
      </svg>
      
      {/* Center core */}
      <motion.div
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        <div className="relative">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-tamv-cyan/20 to-tamv-violet/20 backdrop-blur-xl border border-primary/30 flex items-center justify-center">
            <span className="font-orbitron text-xs text-primary font-bold">CORE</span>
          </div>
          <div className="absolute inset-0 rounded-full border border-primary/20 animate-pulse-ring" />
          <div className="absolute inset-0 rounded-full border border-accent/10 animate-pulse-ring" style={{ animationDelay: '0.5s' }} />
        </div>
      </motion.div>
      
      {/* Points */}
      {points.map((point, i) => {
        const pos = getInfluencedPosition(point);
        const isHovered = hoveredPoint === i;
        
        return (
          <motion.div
            key={point.id}
            className="absolute cursor-pointer"
            style={{ 
              left: `${pos.x}%`, 
              top: `${pos.y}%`,
              transform: 'translate(-50%, -50%)'
            }}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5, delay: i * 0.05 }}
            onMouseEnter={() => setHoveredPoint(i)}
            onMouseLeave={() => setHoveredPoint(null)}
          >
            <div className={`relative ${isHovered ? 'z-10' : ''}`}>
              <div className={`w-4 h-4 rounded-full transition-all duration-300 ${
                isHovered 
                  ? 'bg-primary scale-150 cyber-glow' 
                  : 'bg-primary/60'
              }`} />
              
              {isHovered && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute left-1/2 -translate-x-1/2 top-6 whitespace-nowrap"
                >
                  <div className="glass-card px-3 py-1.5 text-xs font-mono">
                    <span className="text-primary">{point.label}</span>
                    <span className="text-muted-foreground ml-2">#{String(i + 1).padStart(2, '0')}</span>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};

export default ConnectionPoints;
