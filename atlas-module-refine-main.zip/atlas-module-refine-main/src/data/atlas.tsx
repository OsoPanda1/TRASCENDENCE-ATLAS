import { createFileRoute } from "@tanstack/react-router";
import { TAMV_UNIFIED_OPENAPI_YAML } from "../../../../lib/isabella/openapi/specs";

export const Route = createFileRoute("/api/public/openapi/tamv-unified")({
  server: {
    handlers: {
      GET: async () =>
        new Response(TAMV_UNIFIED_OPENAPI_YAML, {
          status: 200,
          headers: {
            "Content-Type": "application/yaml; charset=utf-8",
            "Access-Control-Allow-Origin": "*",
          },
        }),
    },
  },
});
