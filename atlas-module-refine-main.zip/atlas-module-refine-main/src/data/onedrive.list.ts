import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { handleChat } from "../../../../lib/isabella/gateway/chat";
import {
  checkAuthAndRate,
  jsonError,
  jsonOk,
} from "../../../../lib/isabella/gateway/security";

const ChatSchema = z.object({
  sessionId: z.string().max(128).optional().nullable(),
  userId: z.string().max(128).optional().nullable(),
  messages: z
    .array(
      z.object({
        role: z.enum(["system", "user", "assistant"]),
        content: z.string().min(1).max(20_000),
      }),
    )
    .min(1)
    .max(50),
  locale: z.string().min(2).max(10).optional(),
  mode: z.enum(["default", "tutor", "mediator", "territorial"]).optional(),
  stream: z.boolean().optional(),
});

export const Route = createFileRoute("/api/public/ai/isabella/chat")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, {
          status: 204,
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization, X-TAMV-Dev",
          },
        }),
      POST: async ({ request }) => {
        const auth = checkAuthAndRate(request);
        if (!auth.ok) return jsonError(auth.status, auth.reason);

        let raw: unknown;
        try {
          raw = await request.json();
        } catch {
          return jsonError(400, "invalid_json");
        }
        const parsed = ChatSchema.safeParse(raw);
        if (!parsed.success)
          return jsonError(400, "validation_failed", { issues: parsed.error.issues });

        try {
          const out = await handleChat({
            ...parsed.data,
            userId: parsed.data.userId ?? auth.actorId,
          });
          const status = out.status === "BLOCKED" ? 403 : 200;
          return jsonOk(out, status);
        } catch (err) {
          return jsonError(500, "chat_failed", {
            message: err instanceof Error ? err.message : String(err),
          });
        }
      },
    },
  },
});
