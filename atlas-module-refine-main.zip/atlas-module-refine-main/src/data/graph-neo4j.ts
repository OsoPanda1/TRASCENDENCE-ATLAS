import { loadIsabellaCanon } from "../canon";
import { auditAi, type AiAuditEvent } from "./audit";
import { incCounter, REQUESTS_TOTAL } from "./metrics";

export interface RecommendationRequest {
  userId?: string | null;
  context?: {
    page?: string;
    pillar?: string;
    locale?: string;
  };
}

export interface IsabellaRecommendation {
  title: string;
  subtitle: string;
  ctaLabel: string;
  ctaHref: string;
  highlightPillar: string;
  audit: AiAuditEvent;
}

const REGISTRY: Array<Omit<IsabellaRecommendation, "audit">> = [
  {
    title: "Explora el Canon Isabella v1",
    subtitle: "21 secciones doctrinales — empieza por la Constitución.",
    ctaLabel: "Abrir Canon",
    ctaHref: "/canon",
    highlightPillar: "memoria",
  },
  {
    title: "Consulta soberana con RAG estricto",
    subtitle: "Pregunta al kernel MD-X4. Sin evidencia, sin respuesta.",
    ctaLabel: "Entrar al Kernel",
    ctaHref: "/kernel",
    highlightPillar: "soberanía",
  },
  {
    title: "Camina la heptafederación",
    subtitle: "Siete dominios HEP atravesados por seis pipelines HE.",
    ctaLabel: "Ver Atlas",
    ctaHref: "/atlas",
    highlightPillar: "federación",
  },
  {
    title: "Habla con Isabella",
    subtitle: "Consola conversacional con guardrails MD-X4 y BookPI.",
    ctaLabel: "Abrir consola",
    ctaHref: "/isabella",
    highlightPillar: "comunidad",
  },
];

export async function handleRecommendation(
  req: RecommendationRequest,
): Promise<IsabellaRecommendation> {
  loadIsabellaCanon();
  const idx = Math.floor(Date.now() / 60_000) % REGISTRY.length;
  const pick = REGISTRY[idx];

  const audit = await auditAi({
    endpoint: "recommendation",
    userId: req.userId,
    model: "rule-based-v1",
    prompt: JSON.stringify(req.context ?? {}),
    response: JSON.stringify(pick),
    status: "OK",
    riskFlags: [],
    latencyMs: 1,
  });

  incCounter(
    REQUESTS_TOTAL,
    "Total de llamadas al gateway Isabella",
    { endpoint: "recommendation", status: "ok" },
  );

  return { ...pick, audit };
}
