/**
 * Zero-Trust ligero para /api/public/ai/*.
 * Hoy: rate-limit por IP/actor + autenticación opcional con secret compartido.
 * Mañana: validación de JWT con `jose` cuando exista PKI federada.
 */

const BUCKETS = new Map<string, { count: number; resetAt: number }>();
const WINDOW_MS = 60_000;
const LIMIT = 60;

export interface AuthOk {
  ok: true;
  actorId: string;
  isAuthenticated: boolean;
}
export interface AuthErr {
  ok: false;
  status: 401 | 429;
  reason: string;
}

export function checkAuthAndRate(request: Request): AuthOk | AuthErr {
  const auth = request.headers.get("authorization");
  const devKey = request.headers.get("x-tamv-dev");
  const sharedSecret =
    (typeof process !== "undefined" && process.env.KERNEL_SIGNING_KEY) || null;

  let actorId = "anon:public";
  let isAuthenticated = false;

  if (auth?.startsWith("Bearer ")) {
    // Tokens reales se validan con JWT cuando exista PKI; por ahora
    // se acepta como portador anónimo identificado por hash corto del token.
    const token = auth.slice(7).trim();
    actorId = `bearer:${token.slice(0, 12)}`;
    isAuthenticated = true;
  } else if (devKey && sharedSecret && devKey === sharedSecret) {
    actorId = "dev:tamv";
    isAuthenticated = true;
  } else if (request.method !== "GET") {
    // En modo abierto preview aceptamos anónimo, sólo rate-limit más estricto.
  }

  // Rate-limit por (actor|ip)
  const ip =
    request.headers.get("cf-connecting-ip") ||
    request.headers.get("x-forwarded-for") ||
    "0.0.0.0";
  const key = `${actorId}|${ip}`;
  const now = Date.now();
  const bucket = BUCKETS.get(key) ?? { count: 0, resetAt: now + WINDOW_MS };
  if (now > bucket.resetAt) {
    bucket.count = 0;
    bucket.resetAt = now + WINDOW_MS;
  }
  const max = isAuthenticated ? LIMIT : Math.floor(LIMIT / 4);
  bucket.count += 1;
  BUCKETS.set(key, bucket);
  if (bucket.count > max) {
    return { ok: false, status: 429, reason: "rate_limited" };
  }

  return { ok: true, actorId, isAuthenticated };
}

export function jsonError(status: number, error: string, extra?: unknown) {
  return new Response(JSON.stringify({ ok: false, error, ...(extra as object) }, null, 2), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" },
  });
}

export function jsonOk(body: unknown, status = 200) {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
    },
  });
}
