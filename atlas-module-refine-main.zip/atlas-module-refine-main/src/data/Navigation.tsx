import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Home, Bot, BarChart3, Network, Sparkles, GraduationCap, Globe, Shield, BookLock } from "lucide-react";
import tamvLogo from "@/assets/tamv-logo.jpg";

const navItems = [
  { path: "/", label: "Inicio", icon: Home },
  { path: "/tamv/core", label: "Core", icon: Network },
  { path: "/tamv", label: "Omniverso", icon: BarChart3 },
  { path: "/dreamspaces", label: "DreamSpaces", icon: Sparkles },
  { path: "/university", label: "Universidad", icon: GraduationCap },
  { path: "/ecosystem", label: "Ecosistema", icon: Globe },
  { path: "/audit", label: "Auditoría", icon: Shield },
  { path: "/canon", label: "Canon", icon: BookLock },
  { path: "/isabella", label: "Isabella", icon: Bot },
];

const Navigation = () => {
  const location = useLocation();

  return (
    <motion.nav 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.2 }}
      className="fixed top-10 left-0 right-0 z-40 py-4"
    >
      <div className="container mx-auto px-4">
        <div className="glass-card px-6 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg overflow-hidden cyber-glow">
              <img src={tamvLogo} alt="TAMV" className="w-full h-full object-cover" />
            </div>
            <span className="font-orbitron text-lg font-bold text-glow-cyan hidden sm:block">
              TAMV<span className="text-accent">.</span>ONLINE
            </span>
          </Link>
          
          <div className="flex items-center gap-1 sm:gap-2">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path;
              const Icon = item.icon;
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`relative px-3 py-2 rounded-lg flex items-center gap-2 transition-all duration-300 font-medium text-sm
                    ${isActive 
                      ? "text-primary bg-primary/10" 
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                    }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden md:inline">{item.label}</span>
                  {isActive && (
                    <motion.div
                      layoutId="nav-indicator"
                      className="absolute inset-0 rounded-lg border border-primary/50 cyber-glow"
                      style={{ zIndex: -1 }}
                      transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </motion.nav>
  );
};

export default Navigation;
