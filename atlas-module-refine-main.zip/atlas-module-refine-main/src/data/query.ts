import { createFileRoute } from "@tanstack/react-router";
import { listModels } from "../../../../lib/isabella/gateway/router";
import { canonStatus } from "../../../../lib/isabella/canon";

export const Route = createFileRoute("/api/public/ai/status")({
  server: {
    handlers: {
      GET: async () =>
        new Response(
          JSON.stringify(
            {
              gateway: "isabella-gateway",
              version: "1.0.0",
              models: listModels(),
              canon: canonStatus(),
              endpoints: {
                chat: "/api/public/ai/isabella/chat",
                recommendation: "/api/public/ai/isabella/recommendation",
                metrics: "/api/public/ai/metrics",
                openapi: {
                  tamvUnified: "/api/public/openapi/tamv-unified",
                  tamvai: "/api/public/openapi/tamvai",
                },
              },
            },
            null,
            2,
          ),
          {
            status: 200,
            headers: {
              "Content-Type": "application/json; charset=utf-8",
              "Access-Control-Allow-Origin": "*",
            },
          },
        ),
    },
  },
});
