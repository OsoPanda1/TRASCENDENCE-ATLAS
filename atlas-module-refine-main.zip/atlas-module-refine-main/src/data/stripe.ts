import { createFileRoute } from "@tanstack/react-router";

const GATEWAY = "https://connector-gateway.lovable.dev/microsoft_onedrive/v1.0";

export const Route = createFileRoute("/api/public/onedrive/list")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const lovableKey = process.env.LOVABLE_API_KEY;
        const odKey = process.env.MICROSOFT_ONEDRIVE_API_KEY;
        if (!lovableKey || !odKey) {
          return Response.json(
            { error: "onedrive_not_configured", missing: { lovable: !lovableKey, onedrive: !odKey } },
            { status: 503 },
          );
        }
        const url = new URL(request.url);
        const folder = url.searchParams.get("folder");
        const search = url.searchParams.get("q");
        const path = search
          ? `/me/drive/root/search(q='${encodeURIComponent(search)}')`
          : folder
            ? `/me/drive/items/${encodeURIComponent(folder)}/children`
            : `/me/drive/root/children`;
        const res = await fetch(
          `${GATEWAY}${path}?$top=50&$select=id,name,size,lastModifiedDateTime,webUrl,file,folder`,
          {
            headers: {
              Authorization: `Bearer ${lovableKey}`,
              "X-Connection-Api-Key": odKey,
            },
          },
        );
        const text = await res.text();
        if (!res.ok) {
          return Response.json(
            { error: "onedrive_gateway_error", status: res.status, body: text.slice(0, 500) },
            { status: res.status },
          );
        }
        return new Response(text, {
          status: 200,
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
