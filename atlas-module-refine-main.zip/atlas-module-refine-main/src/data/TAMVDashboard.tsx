import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { 
  Activity, Shield, Coins, Users, Globe, Cpu, 
  TrendingUp, Zap, Lock, Server, Database, Sparkles
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import Visualizer4D from "./Visualizer4D";

interface TelemetryData {
  temp: number;
  integrity: number;
  alpha_sync: number;
  quantum_coherence: number;
  neural_load: number;
  memory_quantum: number;
  timestamp: number;
}

interface LayerStatus {
  id: number;
  name: string;
  status: string;
  health: number;
  latency: number;
}

interface GuardianStatus {
  dekateotl_shield: string;
  safeguards: string;
  threat_level: string;
  hollow_wall: string;
  active_nodes: number;
  quantum_integrity: number;
  layers_status: Record<string, string>;
}

const TAMVDashboard = () => {
  const [telemetry, setTelemetry] = useState<TelemetryData | null>(null);
  const [layers, setLayers] = useState<LayerStatus[]>([]);
  const [guardian, setGuardian] = useState<GuardianStatus | null>(null);
  const [valuation, setValuation] = useState<number>(25000000);
  const [isLoading, setIsLoading] = useState(true);

  // Cargar datos del guardian
  useEffect(() => {
    const loadGuardianData = async () => {
      try {
        // Status del guardian
        const { data: guardianData } = await supabase.functions.invoke('tamv-guardian', {
          body: null,
          method: 'GET'
        });
        if (guardianData) setGuardian(guardianData);

        // Capas federadas
        const { data: layersData } = await supabase.functions.invoke('tamv-guardian/federated-layers', {
          body: null,
          method: 'GET'
        });
        if (layersData?.layers) setLayers(layersData.layers);

        // Valoración
        const { data: valuationData } = await supabase.functions.invoke('tamv-economy/valuation', {
          body: null,
          method: 'GET'
        });
        if (valuationData?.project_valuation) setValuation(valuationData.project_valuation);

      } catch (error) {
        console.error("Error loading dashboard data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadGuardianData();
  }, []);

  // Simular telemetría en tiempo real
  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const { data } = await supabase.functions.invoke('tamv-guardian/telemetry', {
          body: null,
          method: 'GET'
        });
        if (data?.payload) {
          setTelemetry(data.payload);
        }
      } catch (error) {
        // Generar datos localmente si falla
        setTelemetry({
          temp: 34 + Math.random() * 2,
          integrity: 0.95 + Math.random() * 0.05,
          alpha_sync: 0.97 + Math.random() * 0.03,
          quantum_coherence: 0.92 + Math.random() * 0.08,
          neural_load: 0.3 + Math.random() * 0.4,
          memory_quantum: 0.5 + Math.random() * 0.3,
          timestamp: Date.now()
        });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Panel Principal - Visualizador 4D */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="lg:col-span-2 glass-card p-6 border-primary/30"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center border border-primary/30">
              <Cpu className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-orbitron text-lg font-bold text-white">Motor Cuántico MD-X4</h3>
              <p className="text-xs text-muted-foreground">Visualización en tiempo real</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-xs text-green-500 font-mono">ONLINE</span>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          {/* Visualizador 4D */}
          <div className="flex-shrink-0">
            <Visualizer4D telemetry={telemetry || undefined} className="rounded-xl border border-primary/20" />
          </div>

          {/* Telemetría */}
          <div className="flex-1 grid grid-cols-2 gap-4">
            <TelemetryCard
              icon={Activity}
              label="Integridad"
              value={telemetry?.integrity || 0.98}
              format="percent"
              color="cyan"
            />
            <TelemetryCard
              icon={Zap}
              label="Sync Alpha"
              value={telemetry?.alpha_sync || 0.99}
              format="percent"
              color="violet"
            />
            <TelemetryCard
              icon={Sparkles}
              label="Coherencia Q"
              value={telemetry?.quantum_coherence || 0.95}
              format="percent"
              color="pink"
            />
            <TelemetryCard
              icon={Server}
              label="Carga Neural"
              value={telemetry?.neural_load || 0.45}
              format="percent"
              color="amber"
            />
            <TelemetryCard
              icon={Database}
              label="Mem. Cuántica"
              value={telemetry?.memory_quantum || 0.6}
              format="percent"
              color="emerald"
            />
            <TelemetryCard
              icon={Activity}
              label="Temperatura"
              value={telemetry?.temp || 35.2}
              format="temp"
              color="red"
            />
          </div>
        </div>
      </motion.div>

      {/* Panel de Valoración */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-card p-6 border-accent/30"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent/20 to-primary/20 flex items-center justify-center border border-accent/30">
            <TrendingUp className="w-5 h-5 text-accent" />
          </div>
          <div>
            <h3 className="font-orbitron text-lg font-bold text-white">Valoración TAMV</h3>
            <p className="text-xs text-muted-foreground">Oracle en tiempo real</p>
          </div>
        </div>

        <div className="text-center py-6">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-accent to-primary font-orbitron"
          >
            {formatCurrency(valuation)}
          </motion.div>
          <p className="text-xs text-muted-foreground mt-2">USD • Tendencia Exponencial</p>
        </div>

        <div className="space-y-3 mt-6">
          <MetricRow label="Usuarios Activos/Día" value="15,000" trend="+12%" />
          <MetricRow label="Transacciones/Mes" value="250K" trend="+28%" />
          <MetricRow label="Creadores Totales" value="5,000" trend="+45%" />
          <MetricRow label="Volumen NFT 30d" value="$1.5M" trend="+67%" />
        </div>
      </motion.div>

      {/* Guardian Status */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass-card p-6 border-green-500/30"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500/20 to-emerald-500/20 flex items-center justify-center border border-green-500/30">
            <Shield className="w-5 h-5 text-green-500" />
          </div>
          <div>
            <h3 className="font-orbitron text-lg font-bold text-white">Anubis Sentinel</h3>
            <p className="text-xs text-muted-foreground">Protocolo DEKATEOTL</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <StatusBadge 
            label="Escudo" 
            value={guardian?.dekateotl_shield || "ACTIVE"} 
            color="green" 
          />
          <StatusBadge 
            label="Salvaguardas" 
            value={guardian?.safeguards || "11/11"} 
            color="cyan" 
          />
          <StatusBadge 
            label="Amenazas" 
            value={guardian?.threat_level || "ZERO"} 
            color="emerald" 
          />
          <StatusBadge 
            label="Hollow Wall" 
            value={guardian?.hollow_wall || "SEALED"} 
            color="violet" 
          />
        </div>

        <div className="mt-4 pt-4 border-t border-white/10">
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">Integridad Cuántica</span>
            <span className="text-green-500 font-mono">{((guardian?.quantum_integrity || 0.9999) * 100).toFixed(2)}%</span>
          </div>
        </div>
      </motion.div>

      {/* Capas Federadas */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="lg:col-span-2 glass-card p-6 border-violet-500/30"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500/20 to-purple-500/20 flex items-center justify-center border border-violet-500/30">
            <Globe className="w-5 h-5 text-violet-500" />
          </div>
          <div>
            <h3 className="font-orbitron text-lg font-bold text-white">7 Capas Federadas</h3>
            <p className="text-xs text-muted-foreground">Arquitectura heptafederada en tiempo real</p>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {(layers.length ? layers : defaultLayers).map((layer, i) => (
            <motion.div
              key={layer.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + i * 0.1 }}
              className="text-center"
            >
              <div 
                className="w-full aspect-square rounded-lg flex items-center justify-center mb-2 relative overflow-hidden"
                style={{
                  background: `linear-gradient(135deg, ${getLayerColor(i)})`,
                }}
              >
                <span className="text-white font-bold text-lg">L{layer.id}</span>
                <div 
                  className="absolute bottom-0 left-0 right-0 bg-black/50"
                  style={{ height: `${100 - layer.health}%` }}
                />
              </div>
              <p className="text-[10px] font-mono text-muted-foreground truncate">{layer.name}</p>
              <p className="text-[9px] text-primary">{layer.health}%</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

// Componentes auxiliares
const TelemetryCard = ({ 
  icon: Icon, 
  label, 
  value, 
  format, 
  color 
}: { 
  icon: any; 
  label: string; 
  value: number; 
  format: 'percent' | 'temp'; 
  color: string;
}) => {
  const displayValue = format === 'percent' 
    ? `${(value * 100).toFixed(1)}%`
    : `${value.toFixed(1)}°C`;

  const colorClasses: Record<string, string> = {
    cyan: "from-cyan-500/20 to-cyan-600/20 border-cyan-500/30 text-cyan-500",
    violet: "from-violet-500/20 to-violet-600/20 border-violet-500/30 text-violet-500",
    pink: "from-pink-500/20 to-pink-600/20 border-pink-500/30 text-pink-500",
    amber: "from-amber-500/20 to-amber-600/20 border-amber-500/30 text-amber-500",
    emerald: "from-emerald-500/20 to-emerald-600/20 border-emerald-500/30 text-emerald-500",
    red: "from-red-500/20 to-red-600/20 border-red-500/30 text-red-500",
  };

  return (
    <div className={`p-3 rounded-lg bg-gradient-to-br ${colorClasses[color]} border`}>
      <div className="flex items-center gap-2 mb-1">
        <Icon className="w-3 h-3" />
        <span className="text-[10px] text-muted-foreground">{label}</span>
      </div>
      <div className={`text-lg font-bold font-mono ${colorClasses[color].split(' ').pop()}`}>
        {displayValue}
      </div>
    </div>
  );
};

const MetricRow = ({ label, value, trend }: { label: string; value: string; trend: string }) => (
  <div className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
    <span className="text-xs text-muted-foreground">{label}</span>
    <div className="flex items-center gap-2">
      <span className="text-sm font-mono text-white">{value}</span>
      <span className="text-[10px] text-green-500">{trend}</span>
    </div>
  </div>
);

const StatusBadge = ({ label, value, color }: { label: string; value: string; color: string }) => {
  const colorClasses: Record<string, string> = {
    green: "bg-green-500/20 text-green-500 border-green-500/30",
    cyan: "bg-cyan-500/20 text-cyan-500 border-cyan-500/30",
    emerald: "bg-emerald-500/20 text-emerald-500 border-emerald-500/30",
    violet: "bg-violet-500/20 text-violet-500 border-violet-500/30",
  };

  return (
    <div className={`p-3 rounded-lg ${colorClasses[color]} border`}>
      <p className="text-[10px] text-muted-foreground mb-1">{label}</p>
      <p className="text-sm font-mono font-bold">{value}</p>
    </div>
  );
};

const getLayerColor = (index: number) => {
  const colors = [
    "rgba(6, 182, 212, 0.4), rgba(59, 130, 246, 0.4)",
    "rgba(139, 92, 246, 0.4), rgba(168, 85, 247, 0.4)",
    "rgba(236, 72, 153, 0.4), rgba(244, 63, 94, 0.4)",
    "rgba(245, 158, 11, 0.4), rgba(249, 115, 22, 0.4)",
    "rgba(16, 185, 129, 0.4), rgba(20, 184, 166, 0.4)",
    "rgba(99, 102, 241, 0.4), rgba(59, 130, 246, 0.4)",
    "rgba(239, 68, 68, 0.4), rgba(236, 72, 153, 0.4)",
  ];
  return colors[index] || colors[0];
};

const defaultLayers: LayerStatus[] = [
  { id: 1, name: "ID-CORE", status: "ACTIVE", health: 98, latency: 12 },
  { id: 2, name: "DATA-VAULT", status: "ACTIVE", health: 99, latency: 8 },
  { id: 3, name: "SOCIAL-NET", status: "ACTIVE", health: 97, latency: 15 },
  { id: 4, name: "ECON-CHAIN", status: "ACTIVE", health: 96, latency: 18 },
  { id: 5, name: "AI-ETHICS", status: "ACTIVE", health: 99, latency: 5 },
  { id: 6, name: "WORLDS-XR", status: "ACTIVE", health: 94, latency: 22 },
  { id: 7, name: "QUANTUM-INFRA", status: "ACTIVE", health: 95, latency: 10 },
];

export default TAMVDashboard;