import { createFileRoute } from "@tanstack/react-router";

const GATEWAY = "https://connector-gateway.lovable.dev/google_drive/drive/v3";

export const Route = createFileRoute("/api/public/drive/list")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const lovableKey = process.env.LOVABLE_API_KEY;
        const driveKey = process.env.GOOGLE_DRIVE_API_KEY;
        if (!lovableKey || !driveKey) {
          return Response.json(
            { error: "drive_not_configured", missing: { lovable: !lovableKey, drive: !driveKey } },
            { status: 503 },
          );
        }
        const url = new URL(request.url);
        const q = url.searchParams.get("q") ?? "";
        const pageSize = url.searchParams.get("pageSize") ?? "50";
        const params = new URLSearchParams({
          pageSize,
          fields: "files(id,name,mimeType,modifiedTime,size,webViewLink,iconLink)",
          orderBy: "modifiedTime desc",
        });
        if (q) params.set("q", q);
        const res = await fetch(`${GATEWAY}/files?${params}`, {
          headers: {
            Authorization: `Bearer ${lovableKey}`,
            "X-Connection-Api-Key": driveKey,
          },
        });
        const text = await res.text();
        if (!res.ok) {
          return Response.json(
            { error: "drive_gateway_error", status: res.status, body: text.slice(0, 500) },
            { status: res.status },
          );
        }
        return new Response(text, {
          status: 200,
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
