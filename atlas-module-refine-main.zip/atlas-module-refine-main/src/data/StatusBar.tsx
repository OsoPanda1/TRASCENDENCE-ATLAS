import { Shield, Activity, Zap } from "lucide-react";
import { motion } from "framer-motion";

const StatusBar = () => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 backdrop-blur-md bg-background/80"
    >
      <div className="container mx-auto px-4 py-2 flex items-center justify-between text-xs font-mono">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-primary font-semibold">SECURE NODE: ACTIVE</span>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-muted-foreground">
            <Shield className="w-3 h-3" />
            <span>mzTAFa1</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 text-muted-foreground">
            <Activity className="w-3 h-3 text-primary" />
            <span>Ecosystem Online</span>
          </div>
          <div className="flex items-center gap-2 text-accent">
            <Zap className="w-3 h-3" />
            <span className="font-semibold">TAMV v4.0</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default StatusBar;
