import { motion, useAnimationFrame } from "framer-motion";
import { useRef, useState, useEffect, useCallback } from "react";

// Interfaces extendidas para la infraestructura TAMV
interface Particle {
  id: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  size: number;
  hue: number;
  life: number;
}

export interface TelemetryData {
  temp: number;
  integrity: number;
  alpha_sync: number;
  quantum_coherence: number;
  neural_load: number;
  memory_quantum: number;
}

interface Visualizer4DProps {
  telemetry?: TelemetryData;
  className?: string;
  isAuthorized?: boolean; // Nueva prop de seguridad
}

const Visualizer4D = ({ telemetry, className = "", isAuthorized = false }: Visualizer4DProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [rotation, setRotation] = useState({ x: 0, y: 0, z: 0 });
  const frameRef = useRef(0);

  // Inicializar partículas con el color del Santuario (Cyan/Emerald)
  useEffect(() => {
    const initialParticles: Particle[] = [];
    const count = isAuthorized ? 150 : 50; // Más densidad si el Arquitecto está presente
    for (let i = 0; i < count; i++) {
      initialParticles.push({
        id: i,
        x: (Math.random() - 0.5) * 200,
        y: (Math.random() - 0.5) * 200,
        z: (Math.random() - 0.5) * 200,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        vz: (Math.random() - 0.5) * 0.4,
        size: Math.random() * 3 + 1,
        hue: isAuthorized ? 160 : 10, // Emerald si OK, Rojo alerta si no
        life: 1,
      });
    }
    setParticles(initialParticles);
  }, [isAuthorized]);

  // Animación vinculada a la Coherencia Cuántica
  useAnimationFrame((time) => {
    frameRef.current = time;
    
    // La velocidad de rotación depende de la integridad del sistema
    const speedFactor = (telemetry?.integrity || 1) * 0.002;
    
    setRotation(prev => ({
      x: prev.x + speedFactor,
      y: prev.y + speedFactor * 1.5,
      z: prev.z + speedFactor * 0.5,
    }));

    setParticles(prev => prev.map(p => {
      let nx = p.x + p.vx;
      let ny = p.y + p.vy;
      let nz = p.z + p.vz;

      if (Math.abs(nx) > 100) p.vx *= -1;
      if (Math.abs(ny) > 100) p.vy *= -1;
      if (Math.abs(nz) > 100) p.vz *= -1;

      // Efecto de telemetría: la coherencia cuántica estabiliza el color
      const quantumFactor = telemetry?.quantum_coherence || 0.95;
      const baseHue = isAuthorized ? 160 : 0; // Emerald vs Rojo
      
      return {
        ...p,
        x: nx,
        y: ny,
        z: nz,
        hue: (baseHue + Math.sin(frameRef.current * 0.001) * 20 * (1 - quantumFactor)),
      };
    }));
  });

  const project = useCallback((x: number, y: number, z: number) => {
    const { x: rx, y: ry, z: rz } = rotation;
    const cos = Math.cos;
    const sin = Math.sin;
    
    // Rotación 3D
    let y1 = y * cos(rx) - z * sin(rx);
    let z1 = y * sin(rx) + z * cos(rx);
    let x2 = x * cos(ry) + z1 * sin(ry);
    let z2 = -x * sin(ry) + z1 * cos(ry);
    let x3 = x2 * cos(rz) - y1 * sin(rz);
    let y3 = x2 * sin(rz) + y1 * cos(rz);
    
    const scale = 400 / (400 + z2); // Perspectiva ajustada para Lovable
    
    return {
      x: x3 * scale + 150,
      y: y3 * scale + 150,
      scale,
      z: z2,
    };
  }, [rotation]);

  return (
    <div 
      ref={containerRef}
      className={`relative w-full h-full min-h-[400px] flex items-center justify-center overflow-hidden bg-black/40 backdrop-blur-sm rounded-2xl border border-white/5 ${className}`}
    >
      {/* Cuadrícula de Datos Alamexa */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0" style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 150, 0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 255, 150, 0.05) 1px, transparent 1px)
          `,
          backgroundSize: "40px 40px",
        }} />
      </div>

      <svg className="absolute inset-0 w-full h-full p-4" viewBox="0 0 300 300">
        <defs>
          <filter id="glow4d">
            <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        
        {/* Renderizado de Nube de Puntos (Gaussian Splats Sim) */}
        {particles
          .map(p => ({ ...p, ...project(p.x, p.y, p.z) }))
          .sort((a, b) => a.z - b.z)
          .map(p => (
            <circle
              key={p.id}
              cx={p.x}
              cy={p.y}
              r={p.size * p.scale}
              fill={`hsla(${p.hue}, 80%, 50%, ${0.4 + p.scale * 0.5})`}
              filter="url(#glow4d)"
              className="transition-colors duration-500"
            />
          ))
        }

        {/* Red Neuronal de Conexión */}
        {particles
          .map(p => ({ ...p, ...project(p.x, p.y, p.z) }))
          .filter((_, i) => i < (isAuthorized ? 40 : 15))
          .map((p1, i, arr) => 
            arr.slice(i + 1).filter((_, j) => j < 2).map((p2) => {
              const dist = Math.hypot(p1.x - p2.x, p1.y - p2.y);
              if (dist < 80) {
                return (
                  <line
                    key={`${p1.id}-${p2.id}`}
                    x1={p1.x}
                    y1={p1.y}
                    x2={p2.x}
                    y2={p2.y}
                    stroke={`hsla(${p1.hue}, 70%, 50%, ${0.2 * (1 - dist / 80)})`}
                    strokeWidth={0.5}
                  />
                );
              }
              return null;
            })
          )
        }
      </svg>

      {/* Overlay de Telemetría Dinámica */}
      {telemetry && (
        <div className="absolute top-4 left-4 font-mono text-[9px] text-emerald-500/80 space-y-1 bg-black/50 p-2 border border-emerald-500/20 rounded">
          <div className="flex justify-between gap-4">
            <span>COHERENCIA:</span>
            <span>{(telemetry.quantum_coherence * 100).toFixed(2)}%</span>
          </div>
          <div className="flex justify-between gap-4">
            <span>NODO_SINC:</span>
            <span>{(telemetry.alpha_sync * 100).toFixed(2)}%</span>
          </div>
        </div>
      )}

      {/* Sello de Seguridad en la esquina */}
      <div className="absolute bottom-4 right-4 font-mono text-[8px] text-gray-600 uppercase tracking-widest">
        TAMV-ENGINE-MDX5 // mzTAFa1
      </div>
    </div>
  );
};

export default Visualizer4D;
