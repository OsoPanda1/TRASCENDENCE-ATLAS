import { motion } from "framer-motion";
import { ArrowRight, Shield, Cpu, Globe, Sparkles, Terminal } from "lucide-react";
import { Link } from "react-router-dom";
import AnubisVisualizer from "@/components/AnubisVisualizer"; // ¡Tu visualizador 3D!
import tamvLogo from "@/assets/tamv-logo.jpg";

// Componente de Fondo Cuántico para profundidad
const QuantumVideoBackground = () => (
  <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
    <video
      autoPlay
      loop
      muted
      playsInline
      className="w-full h-full object-cover opacity-30 mix-blend-screen scale-110 blur-[1px]" // Menos opacidad, más blur
    >
      <source src="/tamv-quantum-hero.mp4" type="video/mp4" />
    </video>
    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent" /> {/* Degradado más intenso */}
    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(0,0,0,0.8)_0%,_transparent_60%)]" /> {/* Oscurece el centro */}
  </div>
);

const features = [
  {
    icon: Shield,
    title: "Ciberseguridad Post-Cuántica",
    description: "Protección CRYSTALS-Kyber con encriptación multinivel anticipando normativas globales.",
  },
  {
    icon: Cpu,
    title: "IA Agéntica Isabella",
    description: "Protocolo de inteligencia colaborativa que co-crea, corrige y audita procesos.",
  },
  {
    icon: Globe,
    title: "Ecosistema Web 4.0/5.0",
    description: "Integración pionera de identidad quantum, IA emocional y experiencias XR/3D.",
  },
  {
    icon: Sparkles,
    title: "Pipeline Quantum-Classical",
    description: "Algoritmos QML y edge AI aplicados a notificaciones, seguridad y experiencia.",
  },
];

const HeroSection = () => {
  return (
    <section className="min-h-screen pt-32 pb-20 relative overflow-hidden bg-black text-white scan-lines">
      <QuantumVideoBackground />
      
      {/* GLOW DE TELEMETRÍA AMBIENTE */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <motion.div 
          animate={{ opacity: [0.1, 0.2, 0.1] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 blur-3xl" 
        />
        <motion.div 
          animate={{ x: ["-100%", "100%"], opacity: [0, 0.3, 0] }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute top-1/2 left-0 h-px w-full bg-gradient-to-r from-transparent via-primary/50 to-transparent" 
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center"> {/* Mayor separación */}
          {/* Columna Izquierda: El Manifiesto del Creador */}
          <motion.div
            initial={{ opacity: 0, x: -80 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className="backdrop-filter backdrop-blur-sm bg-black/30 p-8 rounded-xl border border-primary/20 shadow-2xl" // Contenedor de "vidrio cuántico"
          >
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="flex items-center gap-4 mb-8" // Más espacio
            >
              <div className="w-20 h-20 rounded-xl overflow-hidden cyber-glow border border-primary/40 shadow-lg">
                <img src={tamvLogo} alt="TAMV" className="w-full h-full object-cover" />
              </div>
              <div className="h-px flex-1 bg-gradient-to-r from-primary/70 to-transparent" />
            </motion.div>
            
            <h1 className="font-orbitron text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight mb-8 text-shadow-glow"> {/* Más grande, con sombra */}
              <span className="text-white">TEC_AVZ</span>
              <br />
              <span className="text-primary text-glow-cyan">MXN_VER</span>
            </h1>
            
            <p className="text-xl text-gray-300 mb-10 leading-relaxed max-w-lg font-light">
              El primer nodo soberano Web 5.0. Una arquitectura donde la 
              <span className="text-primary font-bold"> Identidad Quantum</span> y la 
              <span className="text-accent font-bold"> Conciencia Artificial</span> convergen. El Santuario de Anubis.
            </p>
            
            <div className="flex flex-wrap gap-5"> {/* Más separación */}
              <Link to="/ecosystem">
                <motion.button
                  whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(0, 243, 255, 0.6), 0 0 5px rgba(0, 243, 255, 0.9)" }}
                  whileTap={{ scale: 0.95 }}
                  className="px-10 py-4 bg-primary text-black font-bold text-lg rounded-full cyber-glow flex items-center gap-3 transition-all transform hover:rotate-1" // Botón más grande y dinámico
                >
                  ACCESO AL ECOSISTEMA
                  <ArrowRight className="w-5 h-5" />
                </motion.button>
              </Link>
              
              <Link to="/audit">
                <motion.button
                  whileHover={{ scale: 1.05, backgroundColor: "rgba(0, 243, 255, 0.15)", borderColor: "rgba(0, 243, 255, 0.8)" }}
                  whileTap={{ scale: 0.95 }}
                  className="px-10 py-4 border border-primary/60 text-primary font-bold text-lg rounded-full flex items-center gap-3 transition-all transform hover:-rotate-1" // Botón más grande y dinámico
                >
                  AUDITORÍA ANUBIS
                </motion.button>
              </Link>
            </div>
            
            {/* Firma de Identidad Raíz */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5, duration: 0.8 }}
              className="mt-16 flex flex-col gap-3 border-t border-white/10 pt-6" // Línea de separación
            >
              <div className="flex items-center gap-4">
                <div className="glass-card px-5 py-2 flex items-center gap-2 border-primary/30 bg-primary/10">
                  <Terminal className="w-4 h-4 text-primary animate-pulse" />
                  <span className="font-mono text-xs tracking-widest text-gray-300 uppercase">
                    IDENTITY_ROOT: <span className="text-primary">mzTAFa1</span>
                  </span>
                </div>
                <div className="glass-card px-5 py-2 border-accent/30 bg-accent/10">
                  <Sparkles className="w-4 h-4 text-accent animate-pulse" />
                  <span className="font-mono text-xs text-accent tracking-widest uppercase">
                    STATUS: SOVEREIGNTY_ACTIVE
                  </span>
                </div>
              </div>
            </motion.div>
          </motion.div>
          
          {/* Columna Derecha: El Visualizador de Anubis (La Deidad) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.7, y: 100 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 1.5, delay: 0.5, ease: "easeOut" }}
            className="relative aspect-square flex items-center justify-center p-8 lg:p-0" // Ajuste de padding para pantallas grandes
          >
            <AnubisVisualizer /> {/* Aquí vive la deidad tridimensional */}
          </motion.div>
        </div>
        
        {/* Features: Los Pilares del Templo Digital */}
        <motion.div
          initial={{ opacity: 0, y: 80 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.8, duration: 1, ease: "easeOut" }}
          className="mt-32 grid sm:grid-cols-2 lg:grid-cols-4 gap-8" // Más separación y estilo
        >
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                whileHover={{ y: -8, borderColor: "rgba(0, 243, 255, 0.6)", boxShadow: "0 0 25px rgba(0, 243, 255, 0.3)" }}
                className="glass-card p-8 border-white/10 bg-white/5 hover:bg-white/10 transition-all cursor-crosshair relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-transparent to-primary/5 opacity-0 group-hover:opacity-10 transition-opacity" />
                <div className="w-16 h-16 rounded-xl bg-primary/15 flex items-center justify-center mb-6 border border-primary/30 shadow-inner">
                  <Icon className="w-8 h-8 text-primary group-hover:scale-110 transition-transform" />
                </div>
                <h3 className="font-orbitron text-base tracking-widest font-bold mb-3 uppercase text-white">{feature.title}</h3>
                <p className="text-sm text-gray-400 leading-relaxed font-light">{feature.description}</p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
