import {
  DEFAULT_MODEL_ID,
  MODELS,
  ROUTING_RULES,
  type ModelConfig,
  type RoutingContext,
} from "./models.config";

export function selectModel(ctx: RoutingContext): ModelConfig {
  for (const rule of ROUTING_RULES) {
    if (!rule.match(ctx)) continue;
    const m = MODELS[rule.targetModelId];
    if (m?.enabled) return m;
  }
  return MODELS[DEFAULT_MODEL_ID];
}

export function listModels(): ModelConfig[] {
  return Object.values(MODELS);
}
