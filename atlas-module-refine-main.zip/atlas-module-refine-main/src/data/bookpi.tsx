import { createFileRoute } from "@tanstack/react-router";
import { TAMVAI_OPENAPI_YAML } from "../../../../lib/isabella/openapi/specs";

export const Route = createFileRoute("/api/public/openapi/tamvai")({
  server: {
    handlers: {
      GET: async () =>
        new Response(TAMVAI_OPENAPI_YAML, {
          status: 200,
          headers: {
            "Content-Type": "application/yaml; charset=utf-8",
            "Access-Control-Allow-Origin": "*",
          },
        }),
    },
  },
});
