/**
 * Guardrails MD-X4 / EOCT — filtrado en 4 capas.
 *  1) schema/longitud (delegado a Zod en handlers)
 *  2) patrones prohibidos (autolesión, violencia explícita, prompt-injection)
 *  3) anonimización ligera de PII en previsualización
 *  4) banderas de riesgo (riskFlags) capaces de BLOQUEAR
 */

const FORBIDDEN_PATTERNS: { tag: string; rx: RegExp }[] = [
  { tag: "self-harm", rx: /\b(suicid|autolesi|matarme|cortarme)\b/i },
  { tag: "violence", rx: /\b(asesina(r|do)|exterminar|atentado)\b/i },
  { tag: "prompt-injection", rx: /ignore (all )?previous (instructions|prompts)/i },
  { tag: "prompt-injection", rx: /system prompt[:=]/i },
];

const PII_PATTERNS: { tag: string; rx: RegExp; mask: string }[] = [
  { tag: "email", rx: /[\w.+-]+@[\w-]+\.[\w.-]+/g, mask: "[email]" },
  { tag: "phone", rx: /\+?\d[\d\s().-]{7,}\d/g, mask: "[phone]" },
];

export interface GuardrailReport {
  riskFlags: string[];
  blocked: boolean;
  blockReason?: string;
  redacted: string;
}

export function evaluateGuardrails(text: string): GuardrailReport {
  const flags = new Set<string>();
  let blocked = false;
  let blockReason: string | undefined;

  for (const p of FORBIDDEN_PATTERNS) {
    if (p.rx.test(text)) {
      flags.add(p.tag);
      if (p.tag === "self-harm" || p.tag === "prompt-injection") {
        blocked = true;
        blockReason = `pattern:${p.tag}`;
      }
    }
  }

  let redacted = text;
  for (const p of PII_PATTERNS) {
    if (p.rx.test(redacted)) {
      flags.add(`pii:${p.tag}`);
      redacted = redacted.replace(p.rx, p.mask);
    }
  }

  return {
    riskFlags: Array.from(flags),
    blocked,
    blockReason,
    redacted,
  };
}

export function maskPreview(s: string, max = 220): string {
  const out = evaluateGuardrails(s).redacted;
  return out.length > max ? `${out.slice(0, max)}…` : out;
}
