import { createFileRoute } from "@tanstack/react-router";

/**
 * Legacy endpoint — auditoría ahora vive en GET /api/public/audit/$traceId.
 */
export const Route = createFileRoute("/api/kernel/artifacts/audit")({
  server: {
    handlers: {
      POST: async () =>
        new Response(
          JSON.stringify(
            {
              ok: false,
              error: "deprecated",
              replacement: "/api/public/audit/{traceId}",
            },
            null,
            2,
          ),
          {
            status: 410,
            headers: { "Content-Type": "application/json; charset=utf-8" },
          },
        ),
    },
  },
});
