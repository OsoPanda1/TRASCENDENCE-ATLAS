import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import anubis3D from "@/assets/anubis-3d.png";

const AnubisVisualizer = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  // Valores de rastreo cuántico (Mouse Position)
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  // Física Orgánica: El "alma" del movimiento - más pronunciada
  const springConfig = { damping: 25, stiffness: 150, mass: 0.8 };
  const rotateX = useSpring(useTransform(mouseY, [-500, 500], [20, -20]), springConfig);
  const rotateY = useSpring(useTransform(mouseX, [-500, 500], [-20, 20]), springConfig);
  
  // Efectos adicionales de profundidad
  const translateZ = useSpring(useTransform(mouseX, [-500, 0, 500], [-30, 0, -30]), springConfig);
  const glowIntensity = useSpring(useTransform(mouseY, [-500, 500], [0.5, 1]), springConfig);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = e.clientX - (rect.left + rect.width / 2);
      const y = e.clientY - (rect.top + rect.height / 2);
      mouseX.set(x);
      mouseY.set(y);
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [mouseX, mouseY]);

  return (
    <div 
      ref={containerRef} 
      className="relative w-full h-[600px] flex items-center justify-center select-none overflow-hidden"
      style={{ perspective: "2000px" }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Fondo de partículas cuánticas */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        {/* Partículas flotantes animadas */}
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-primary/60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -100, 0],
              x: [0, Math.random() * 50 - 25, 0],
              opacity: [0, 1, 0],
              scale: [0, 1.5, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 3,
              ease: "easeInOut"
            }}
          />
        ))}
        
        {/* Línea de escaneo tipo Grafana */}
        <motion.div 
          animate={{ top: ["0%", "100%", "0%"] }}
          transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
          className="absolute left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-primary/40 to-transparent blur-[1px]"
        />
      </div>

      {/* 🌌 Halo de Conciencia Isabella (Multi-capa) */}
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.2, 0.4, 0.2],
        }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="absolute w-[90%] h-[90%] bg-[radial-gradient(circle,hsl(var(--tamv-violet)/0.3)_0%,transparent_50%)] blur-[60px]"
      />
      <motion.div
        animate={{
          scale: [1.1, 1, 1.1],
          opacity: [0.15, 0.35, 0.15],
          rotate: [0, 180, 360],
        }}
        transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
        className="absolute w-[70%] h-[70%] bg-[radial-gradient(circle,hsl(var(--tamv-cyan)/0.25)_0%,transparent_60%)] blur-[80px]"
      />

      {/* Anillos orbitales */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="absolute w-[500px] h-[500px] border border-primary/20 rounded-full"
        style={{ transformStyle: "preserve-3d", rotateX: 75 }}
      />
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        className="absolute w-[400px] h-[400px] border border-secondary/20 rounded-full"
        style={{ transformStyle: "preserve-3d", rotateX: 60, rotateZ: 45 }}
      />

      {/* 🎭 El Cuerpo de Anubis (3D Layer Principal) */}
      <motion.div
        style={{
          rotateX,
          rotateY,
          translateZ,
          transformStyle: "preserve-3d",
        }}
        className="relative z-10 w-full max-w-[420px]"
      >
        {/* Sombra dinámica */}
        <motion.div
          className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-[300px] h-[50px] bg-black/40 blur-[30px] rounded-full"
          style={{ scaleX: glowIntensity }}
        />
        
        {/* Glow trasero */}
        <motion.div
          className="absolute inset-0 -z-10 blur-[40px]"
          animate={{
            background: [
              "radial-gradient(circle, hsl(180 100% 50% / 0.3) 0%, transparent 70%)",
              "radial-gradient(circle, hsl(285 55% 50% / 0.3) 0%, transparent 70%)",
              "radial-gradient(circle, hsl(180 100% 50% / 0.3) 0%, transparent 70%)",
            ]
          }}
          transition={{ duration: 5, repeat: Infinity }}
        />

        <motion.img
          src={anubis3D}
          alt="Anubis - Guardián del Santuario Digital TAMV"
          className="w-full h-auto drop-shadow-[0_0_50px_hsl(180_100%_50%/0.4)]"
          animate={{ 
            y: [0, -20, 0],
            filter: [
              "brightness(1) contrast(1) saturate(1)",
              "brightness(1.15) contrast(1.1) saturate(1.1)",
              "brightness(1) contrast(1) saturate(1)"
            ]
          }}
          transition={{ 
            y: { duration: 4, repeat: Infinity, ease: "easeInOut" },
            filter: { duration: 3, repeat: Infinity, ease: "easeInOut" }
          }}
          whileHover={{ scale: 1.05 }}
        />

        {/* Aura mística pulsante alrededor de la figura */}
        <motion.div
          className="absolute inset-0 pointer-events-none"
          animate={{
            boxShadow: [
              "0 0 60px 20px hsl(180 100% 50% / 0.1)",
              "0 0 80px 30px hsl(180 100% 50% / 0.2)",
              "0 0 60px 20px hsl(180 100% 50% / 0.1)",
            ]
          }}
          transition={{ duration: 2.5, repeat: Infinity }}
        />

        {/* 💠 Puntos de Datos Flotantes (Metadata mzTAFa1) */}
        <motion.div 
          className="absolute -right-16 top-1/4 space-y-2"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <div className="h-[1px] w-16 bg-gradient-to-r from-primary to-transparent" />
          <motion.p 
            className="font-mono text-[10px] text-primary tracking-widest uppercase"
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            Telemetry: Active
          </motion.p>
          <p className="font-mono text-[10px] text-accent tracking-widest uppercase">Node: mzTAFa1</p>
          <p className="font-mono text-[8px] text-muted-foreground">Quantum: Stable</p>
        </motion.div>

        {/* Datos a la izquierda */}
        <motion.div 
          className="absolute -left-20 top-1/3 space-y-2 text-right"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.7 }}
        >
          <div className="h-[1px] w-16 bg-gradient-to-l from-secondary to-transparent ml-auto" />
          <p className="font-mono text-[10px] text-secondary tracking-widest uppercase">Sovereignty</p>
          <p className="font-mono text-[10px] text-muted-foreground">DM-X4™</p>
        </motion.div>
      </motion.div>

      {/* 🏁 Filtro de Escaneo de Seguridad (Scanlines sutiles) */}
      <div className="absolute inset-0 pointer-events-none opacity-30 bg-[linear-gradient(transparent_50%,hsl(180_100%_50%/0.02)_50%)] bg-[length:100%_4px]" />

      {/* 📑 Etiqueta de Identidad */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="absolute bottom-8 right-8 flex flex-col items-end gap-1"
      >
        <div className="flex gap-2 items-center">
          <motion.span 
            className="w-2 h-2 rounded-full bg-primary"
            animate={{ scale: [1, 1.3, 1], opacity: [1, 0.7, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
          <span className="font-mono text-[10px] text-primary uppercase tracking-widest">Sovereign Identity Verified</span>
        </div>
        <div className="w-32 h-[1px] bg-gradient-to-r from-transparent to-primary/50" />
        <span className="font-mono text-[8px] text-muted-foreground">TAMV Online • Genesis 2026</span>
      </motion.div>

      {/* Indicador de estado arriba-izquierda */}
      <motion.div
        className="absolute top-8 left-8 flex items-center gap-3"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            <span className="font-mono text-[9px] text-green-400 uppercase">System Online</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-primary" />
            <span className="font-mono text-[9px] text-muted-foreground uppercase">Isabella MD-X4</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AnubisVisualizer;