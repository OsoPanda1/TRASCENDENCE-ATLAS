/**
 * Auditoría de prompts/respuestas IA.
 * Doble destino:
 *  1) BookPI vía emitEliteBookPiEvent (HE-Identity / HEP-7)
 *  2) Event-log canónico del kernel (POLICY_EVALUATED) para trazabilidad por traceId
 */

import { randomUUID } from "node:crypto";
import { emitEliteBookPiEvent } from "../../contracts/bookpi-emitter";
import { appendEvent } from "../../memory/event-log";
import { maskPreview } from "./guardrails";

export interface AiAuditInput {
  endpoint: "chat" | "recommendation";
  traceId?: string;
  userId?: string | null;
  sessionId?: string | null;
  model: string;
  prompt: string;
  response: string;
  status: "OK" | "BLOCKED" | "ERROR";
  riskFlags?: string[];
  latencyMs?: number;
}

export interface AiAuditEvent {
  id: string;
  traceId: string;
  timestamp: string;
  endpoint: AiAuditInput["endpoint"];
  userId: string | null;
  sessionId: string | null;
  model: string;
  promptPreview: string;
  responsePreview: string;
  status: AiAuditInput["status"];
  riskFlags: string[];
  latencyMs: number;
}

export async function auditAi(input: AiAuditInput): Promise<AiAuditEvent> {
  const ev: AiAuditEvent = {
    id: randomUUID(),
    traceId: input.traceId ?? randomUUID(),
    timestamp: new Date().toISOString(),
    endpoint: input.endpoint,
    userId: input.userId ?? null,
    sessionId: input.sessionId ?? null,
    model: input.model,
    promptPreview: maskPreview(input.prompt),
    responsePreview: maskPreview(input.response),
    status: input.status,
    riskFlags: input.riskFlags ?? [],
    latencyMs: Math.round(input.latencyMs ?? 0),
  };

  // 1) BookPI ELITE HeHep (HE-Identity / HEP-7)
  try {
    await emitEliteBookPiEvent({
      protocol: "tamvai.gateway.audit.v1",
      type: "AiInvocation",
      source: "isabella-gateway",
      repository: "OsoPanda1/oso-data-weaver",
      context: { hexagon: "HE-Identity", domain: "HEP-7" },
      payload: ev,
      meta: { doctrine: "MD-X4", scope: "tamvai-gateway" },
    });
  } catch {
    /* best-effort, no romper la respuesta */
  }

  // 2) Event-log canónico del kernel (auditable desde /kernel por traceId)
  try {
    appendEvent({
      eventId: ev.id,
      eventType: "POLICY_EVALUATED",
      timestamp: ev.timestamp,
      actorId: ev.userId ?? "anon:isabella",
      payload: {
        traceId: ev.traceId,
        endpoint: ev.endpoint,
        model: ev.model,
        status: ev.status,
        riskFlags: ev.riskFlags,
        latencyMs: ev.latencyMs,
        promptPreview: ev.promptPreview,
        responsePreview: ev.responsePreview,
      },
    });
  } catch {
    /* best-effort */
  }

  return ev;
}
