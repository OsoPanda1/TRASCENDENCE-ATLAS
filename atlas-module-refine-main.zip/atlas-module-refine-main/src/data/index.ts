import { createHash } from "node:crypto";

/**
 * Módulo doctrinal MD-X4 — inferencia de etiquetas y territorio
 * a partir de la cabecera/payload de un evento ELITE HeHep.
 * Implementación mínima auto-suficiente (sin dependencias externas).
 */

export function sortKeys(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sortKeys);
  if (!value || typeof value !== "object") return value;
  const o = value as Record<string, unknown>;
  return Object.keys(o)
    .sort()
    .reduce<Record<string, unknown>>((acc, k) => {
      acc[k] = sortKeys(o[k]);
      return acc;
    }, {});
}

export function sha256(value: unknown): string {
  return createHash("sha256")
    .update(typeof value === "string" ? value : JSON.stringify(sortKeys(value)))
    .digest("hex");
}

const DOMAIN_TAGS: Record<string, string[]> = {
  "HEP-1": ["central", "kernel"],
  "HEP-2": ["operaciones", "pipeline"],
  "HEP-3": ["infraestructura", "edge"],
  "HEP-4": ["seguridad", "guardian"],
  "HEP-5": ["economia", "ledger"],
  "HEP-6": ["logistica", "experiencia"],
  "HEP-7": ["usuarios", "identidad"],
};

const HEXAGON_TAGS: Record<string, string[]> = {
  "HE-Ingest": ["ingesta"],
  "HE-Transform": ["transformacion", "guardrails"],
  "HE-Publish": ["publicacion"],
  "HE-Science": ["ciencia-abierta"],
  "HE-Economy": ["economia-creativa"],
  "HE-Identity": ["identidad", "etica"],
};

export interface DoctrineInferenceInput {
  header: {
    type?: string;
    protocol?: string;
    repository?: string;
    he_hep_context?: { hexagon?: string; domain?: string };
  };
  payload?: unknown;
  meta?: Record<string, unknown>;
}

export function inferDoctrineTags(input: DoctrineInferenceInput): string[] {
  const tags = new Set<string>(["mdx4"]);
  const ctx = input.header.he_hep_context ?? {};
  for (const t of DOMAIN_TAGS[ctx.domain ?? ""] ?? []) tags.add(t);
  for (const t of HEXAGON_TAGS[ctx.hexagon ?? ""] ?? []) tags.add(t);
  if (input.header.type) tags.add(input.header.type.toLowerCase());
  if (input.header.protocol) tags.add(input.header.protocol.toLowerCase());
  return Array.from(tags);
}

export function inferTerritory(
  input: DoctrineInferenceInput,
): string | null {
  const ctx = input.header.he_hep_context;
  if (!ctx?.domain) return null;
  return `tamv://${ctx.domain.toLowerCase()}/${(ctx.hexagon ?? "core").toLowerCase()}`;
}
