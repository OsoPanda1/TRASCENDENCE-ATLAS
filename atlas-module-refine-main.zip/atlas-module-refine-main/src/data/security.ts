import { tamvKernel } from "../../kernel/kernel";
import { nodeCount } from "../../memory/graph-store";
import { CANON_SECTIONS, type CanonSection } from "./sections";
import type { CanonicalNode } from "../../canonical/types";

let loaded = false;

/** Ingiere el Canon Isabella v1 al kernel como CanonicalNodes (idempotente). */
export function loadIsabellaCanon() {
  if (loaded) return;
  const ts = new Date().toISOString();
  const raws = CANON_SECTIONS.map((s) =>
    ({
      id: `canon:isabella:${s.id}`,
      type: "DOCUMENT" as const,
      title: `Canon Isabella · ${String(s.index).padStart(2, "0")} ${s.title}`,
      body: s.body,
      metadata: {
        createdAt: ts,
        updatedAt: ts,
        source: "isabella-canon:v1",
        author: "Edwin Oswaldo Castillo Trejo",
        version: "1.0",
        license: "CC-BY-SA-4.0",
      },
      semantic: {
        ontologyClass: s.ontologyClass,
        tags: ["isabella", "canon", ...s.tags],
        language: "es",
        scope: "core" as const,
      },
      relations: [],
      dependencies: [],
      lineage: [],
      state: {
        integrity: "VALID" as const,
        constitutional: "APPROVED" as const,
        synchronization: "SYNCED" as const,
        operational: "ACTIVE" as const,
      },
    }) satisfies Omit<CanonicalNode, "canonicalHash" | "identityHash" | "versionHash">,
  );
  tamvKernel.ingest(raws, { federation: "central", actorId: "seed:isabella-canon" });
  loaded = true;
}

export function canonStatus() {
  return {
    loaded,
    sections: CANON_SECTIONS.length,
    nodes: nodeCount(),
  };
}

export { CANON_SECTIONS };
export type { CanonSection };
