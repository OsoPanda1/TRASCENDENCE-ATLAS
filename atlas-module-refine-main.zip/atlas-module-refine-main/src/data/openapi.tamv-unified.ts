import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { handleRecommendation } from "../../../../lib/isabella/gateway/recommendation";
import {
  checkAuthAndRate,
  jsonError,
  jsonOk,
} from "../../../../lib/isabella/gateway/security";

const Schema = z.object({
  userId: z.string().max(128).optional().nullable(),
  context: z
    .object({
      page: z.string().max(128).optional(),
      pillar: z.string().max(64).optional(),
      locale: z.string().max(10).optional(),
    })
    .optional(),
});

export const Route = createFileRoute("/api/public/ai/isabella/recommendation")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, {
          status: 204,
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization, X-TAMV-Dev",
          },
        }),
      POST: async ({ request }) => {
        const auth = checkAuthAndRate(request);
        if (!auth.ok) return jsonError(auth.status, auth.reason);

        let raw: unknown = {};
        try {
          const text = await request.text();
          raw = text ? JSON.parse(text) : {};
        } catch {
          return jsonError(400, "invalid_json");
        }
        const parsed = Schema.safeParse(raw);
        if (!parsed.success)
          return jsonError(400, "validation_failed", { issues: parsed.error.issues });

        const out = await handleRecommendation({
          ...parsed.data,
          userId: parsed.data.userId ?? auth.actorId,
        });
        return jsonOk(out);
      },
    },
  },
});
