/**
 * Handler de chat — invoca al modelo seleccionado (stub MD-X5 por defecto),
 * con guardrails, métricas, auditoría y RAG opcional contra el kernel canónico.
 */

import { tamvKernel, seedKernelIfEmpty } from "../../kernel/kernel";
import { loadIsabellaCanon } from "../canon";
import { selectModel } from "./router";
import {
  REQUESTS_TOTAL,
  LLM_LATENCY,
  LATENCY_BUCKETS,
  incCounter,
  observeHistogram,
} from "./metrics";
import { evaluateGuardrails } from "./guardrails";
import { auditAi, type AiAuditEvent } from "./audit";

export type ChatRole = "system" | "user" | "assistant";

export interface ChatMessage {
  role: ChatRole;
  content: string;
}

export interface ChatRequest {
  sessionId?: string | null;
  userId?: string | null;
  messages: ChatMessage[];
  locale?: string;
  mode?: "default" | "tutor" | "mediator" | "territorial";
  stream?: boolean;
}

export interface ChatChunk {
  chunkId: string;
  text: string;
  emotion: "calm" | "warm" | "focused" | "stern";
  sequence: number;
}

export interface ChatResponse {
  conversationId: string;
  model: string;
  status: "OK" | "BLOCKED" | "ERROR";
  message?: string;
  chunks: ChatChunk[];
  audit: AiAuditEvent;
  citations: { nodeId: string; title: string; score: number; sha256: string }[];
}

function lastUserContent(messages: ChatMessage[]): string {
  for (let i = messages.length - 1; i >= 0; i--) {
    if (messages[i].role === "user") return messages[i].content;
  }
  return "";
}

export async function handleChat(req: ChatRequest): Promise<ChatResponse> {
  seedKernelIfEmpty();
  loadIsabellaCanon();

  const conversationId = req.sessionId ?? `s-${Date.now().toString(36)}`;
  const userText = lastUserContent(req.messages);
  const messagesLength = JSON.stringify(req.messages).length;
  const mode = req.mode ?? "default";

  // 1) Guardrails sobre el último mensaje del usuario
  const guard = evaluateGuardrails(userText);
  if (guard.blocked) {
    const audit = await auditAi({
      endpoint: "chat",
      userId: req.userId,
      sessionId: req.sessionId,
      model: "mdx5-stub",
      prompt: userText,
      response: "",
      status: "BLOCKED",
      riskFlags: guard.riskFlags,
      latencyMs: 0,
    });
    incCounter(
      REQUESTS_TOTAL,
      "Total de llamadas al gateway Isabella",
      { endpoint: "chat", status: "blocked" },
    );
    return {
      conversationId,
      model: "mdx5-stub",
      status: "BLOCKED",
      message: `BLOCKED: ${guard.blockReason ?? "policy"}`,
      chunks: [],
      audit,
      citations: [],
    };
  }

  // 2) Modelo
  const model = selectModel({ messagesLength, mode, previousModelFailed: false });

  // 3) RAG estricto contra el kernel canónico
  const t0 = Date.now();
  const kernelOut = await tamvKernel.handleQuery(userText || "tamv", {
    actorId: req.userId ?? "anon:isabella-chat",
    federation: "central",
    language: req.locale ?? "es-MX",
  });
  const latencyMs = Date.now() - t0;
  observeHistogram(
    LLM_LATENCY,
    "Latencia de invocación de modelo (segundos)",
    LATENCY_BUCKETS,
    { model: model.id },
    latencyMs / 1000,
  );

  // 4) Construir respuesta determinista (stub) a partir de evidencia
  const hasEvidence = kernelOut.E.length > 0;
  const intro =
    mode === "tutor"
      ? "Te explico paso a paso a partir del canon:"
      : mode === "mediator"
        ? "Te muestro una lectura serena y referenciada:"
        : mode === "territorial"
          ? "Desde la doctrina territorial TAMV:"
          : "Esto es lo que el canon respalda:";

  const body = hasEvidence
    ? kernelOut.E.slice(0, 3)
        .map((e, i) => `[${i + 1}] ${e.title} — ${e.excerpt}`)
        .join("\n\n")
    : "Aún no encuentro evidencia primaria. Isabella no fabrica contenido sin canon (RAG estricto).";

  const text = `${intro}\n\n${body}`;
  const chunks: ChatChunk[] = text.split(/\n\n+/).map((part, i) => ({
    chunkId: `c${i + 1}`,
    text: part,
    emotion: hasEvidence ? "warm" : "focused",
    sequence: i + 1,
  }));

  // 5) Auditoría
  const audit = await auditAi({
    endpoint: "chat",
    traceId: kernelOut.R.traceId,
    userId: req.userId,
    sessionId: req.sessionId,
    model: model.id,
    prompt: userText,
    response: text,
    status: hasEvidence ? "OK" : "OK",
    riskFlags: guard.riskFlags,
    latencyMs,
  });

  incCounter(
    REQUESTS_TOTAL,
    "Total de llamadas al gateway Isabella",
    { endpoint: "chat", status: hasEvidence ? "ok" : "insufficient" },
  );

  return {
    conversationId,
    model: model.id,
    status: "OK",
    chunks,
    audit,
    citations: kernelOut.E.map((e) => ({
      nodeId: e.nodeId,
      title: e.title,
      score: e.score,
      sha256: e.citation.sha256,
    })),
  };
}
