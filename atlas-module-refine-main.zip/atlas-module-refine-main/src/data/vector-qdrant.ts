export const TAMVAI_OPENAPI_YAML = `openapi: 3.1.0
info:
  title: TAMVAI / Isabella AI API
  version: "1.0.0"
  description: |
    API soberana de orquestación de IA del ecosistema TAMV
    (Isabella Villaseñor AI, kernel MD-X4/MD-X5).
servers:
  - url: https://kernel-tamv.lovable.app
    description: Producción Lovable
paths:
  /api/public/ai/isabella/chat:
    post:
      tags: [AI]
      summary: Chat con Isabella AI (RAG estricto sobre el Canon).
      operationId: postIsabellaChat
      security:
        - bearerAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: "#/components/schemas/ChatRequest"
      responses:
        "200":
          description: Respuesta del modelo.
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/ChatResponse"
        "403": { description: BLOCKED por guardrails. }
        "429": { description: Rate limit. }
  /api/public/ai/isabella/recommendation:
    post:
      tags: [AI]
      summary: Recomendación personalizada de Isabella AI.
      operationId: postIsabellaRecommendation
      security:
        - bearerAuth: []
      requestBody:
        required: false
        content:
          application/json:
            schema:
              $ref: "#/components/schemas/RecommendationRequest"
      responses:
        "200":
          description: Recomendación.
          content:
            application/json:
              schema:
                $ref: "#/components/schemas/IsabellaRecommendation"
  /api/public/ai/metrics:
    get:
      tags: [Observability]
      summary: Exposición Prometheus del gateway.
      responses:
        "200":
          description: text/plain Prometheus exposition.
  /api/public/ai/status:
    get:
      tags: [Observability]
      summary: Estado del gateway, modelos y canon.
      responses:
        "200": { description: OK }
components:
  schemas:
    Message:
      type: object
      required: [role, content]
      properties:
        role: { type: string, enum: [system, user, assistant] }
        content: { type: string }
    ChatRequest:
      type: object
      required: [messages]
      properties:
        sessionId: { type: string, nullable: true }
        userId: { type: string, nullable: true }
        messages:
          type: array
          items: { $ref: "#/components/schemas/Message" }
          minItems: 1
        locale: { type: string, default: "es-MX" }
        mode:
          type: string
          enum: [default, tutor, mediator, territorial]
          default: default
        stream: { type: boolean, default: false }
    ChatChunk:
      type: object
      required: [chunkId, text, sequence]
      properties:
        chunkId: { type: string }
        text: { type: string }
        emotion: { type: string, enum: [calm, warm, focused, stern] }
        sequence: { type: integer }
    ChatResponse:
      type: object
      properties:
        conversationId: { type: string }
        model: { type: string }
        status: { type: string, enum: [OK, BLOCKED, ERROR] }
        chunks:
          type: array
          items: { $ref: "#/components/schemas/ChatChunk" }
        citations:
          type: array
          items:
            type: object
            properties:
              nodeId: { type: string }
              title: { type: string }
              score: { type: number }
              sha256: { type: string }
    RecommendationRequest:
      type: object
      properties:
        userId: { type: string, nullable: true }
        context:
          type: object
          properties:
            page: { type: string }
            pillar: { type: string }
            locale: { type: string }
    IsabellaRecommendation:
      type: object
      required: [title, subtitle, ctaLabel, ctaHref, highlightPillar]
      properties:
        title: { type: string }
        subtitle: { type: string }
        ctaLabel: { type: string }
        ctaHref: { type: string }
        highlightPillar: { type: string }
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
`;

export const TAMV_UNIFIED_OPENAPI_YAML = `openapi: 3.1.0
info:
  title: TAMV UNIFIED API
  version: "1.0.0"
  description: API unificada del ecosistema TAMV (Social + XR + DAO + Economía + IA).
servers:
  - url: https://kernel-tamv.lovable.app
paths:
  /api/public/health:
    get: { tags: [System], summary: Health del kernel., responses: { "200": { description: OK } } }
  /api/public/systemic:
    get: { tags: [System], summary: Estado HeHep agregado., responses: { "200": { description: OK } } }
  /api/public/ingest:
    post:
      tags: [Knowledge]
      summary: Ingesta canónica (MD-X4).
      responses: { "200": { description: OK } }
  /api/public/query:
    post:
      tags: [Knowledge]
      summary: Consulta RAG estricta al kernel.
      responses: { "200": { description: OK } }
  /api/public/audit/{traceId}:
    get:
      tags: [Audit]
      summary: Reporte de auditoría por traceId.
      parameters:
        - in: path
          name: traceId
          required: true
          schema: { type: string, format: uuid }
      responses: { "200": { description: OK }, "404": { description: Not Found } }
  /api/public/ai/isabella/chat:
    post: { tags: [AI], summary: Chat con Isabella AI., responses: { "200": { description: OK } } }
  /api/public/ai/isabella/recommendation:
    post: { tags: [AI], summary: Recomendación Isabella., responses: { "200": { description: OK } } }
components:
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
`;
