import { createFileRoute } from "@tanstack/react-router";
import { WikiShell, Section } from "@/components/wiki/WikiShell";

export const Route = createFileRoute("/posicionamiento")({
  head: () => ({
    meta: [
      { title: "Posicionamiento — Atlas TAMV" },
      { name: "description", content: "Cómo se posiciona el Atlas TAMV frente al ecosistema digital global." },
    ],
  }),
  component: Posicionamiento,
});

function Posicionamiento() {
  return (
    <WikiShell
      title="Posicionamiento"
      subtitle="Qué somos, qué no somos, y dónde nos paramos en el mapa digital."
      toc={[
        { id: "que-somos", label: "Qué somos" },
        { id: "que-no", label: "Qué NO somos" },
        { id: "frente-a", label: "Frente a otros actores" },
        { id: "geopolitico", label: "Posicionamiento geopolítico" },
      ]}
    >
      <Section id="que-somos" title="Qué somos">
        <p>
          Somos una <strong>infraestructura pública digital federada</strong> con raíz
          territorial latinoamericana. Operamos como un bien común técnico: contratos
          abiertos, módulos versionados, gobernanza explícita y un núcleo ético no
          negociable.
        </p>
      </Section>

      <Section id="que-no" title="Qué NO somos">
        <ul>
          <li>No somos una <em>startup</em> que persigue una salida a bolsa.</li>
          <li>No somos un <em>marketplace</em> ni una red social al uso.</li>
          <li>No somos un <em>wrapper</em> de modelos de IA con branding bonito.</li>
          <li>No somos un proyecto extractivo: el dato territorial pertenece al territorio.</li>
          <li>No somos una <em>web3</em> especulativa: usamos lo que sirve, no lo que está de moda.</li>
        </ul>
      </Section>

      <Section id="frente-a" title="Frente a otros actores">
        <p>
          Frente a las grandes plataformas globales, ofrecemos <strong>soberanía
          verificable</strong>. Frente a los ecosistemas open source genéricos, ofrecemos
          <strong> arraigo territorial</strong>. Frente a los proyectos cívicos puramente
          discursivos, ofrecemos <strong>código operativo, auditado y congelable</strong>.
        </p>
        <p>
          No competimos con Wikipedia, GitHub o GitLab: <em>aprendemos de ellos y nos
          inspiramos en su rigor documental</em> para aplicarlo a un problema distinto —el
          de la identidad y la memoria digital del territorio.
        </p>
      </Section>

      <Section id="geopolitico" title="Posicionamiento geopolítico">
        <p>
          México está literalmente en el <strong>centro geográfico del continente
          americano</strong>. El Atlas TAMV toma esa centralidad y la convierte en
          posicionamiento estratégico: <em>desde el centro de Latinoamérica, para el
          mundo</em>. No pedimos permiso para construir infraestructura digital propia.
        </p>
      </Section>
    </WikiShell>
  );
}
