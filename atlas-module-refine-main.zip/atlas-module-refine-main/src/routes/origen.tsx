import { createFileRoute } from "@tanstack/react-router";
import { WikiShell, Section } from "@/components/wiki/WikiShell";

export const Route = createFileRoute("/origen")({
  head: () => ({
    meta: [
      { title: "Origen y dónde comenzamos — Atlas TAMV" },
      { name: "description", content: "El Atlas TAMV nació en Real del Monte como respuesta a la necesidad de soberanía digital territorial en Latinoamérica." },
      { property: "og:title", content: "Origen del Atlas TAMV" },
    ],
  }),
  component: Origen,
});

function Origen() {
  return (
    <WikiShell
      title="Origen y dónde comenzamos"
      subtitle="Desde un pueblo minero en el corazón de México hacia una infraestructura digital para Latinoamérica."
      meta={[
        { label: "Lugar de origen", value: "Real del Monte, Hidalgo" },
        { label: "Año cero", value: "2024" },
        { label: "Primer núcleo", value: "OsoPanda1" },
        { label: "Estado", value: "Federación activa" },
      ]}
      toc={[
        { id: "raiz", label: "La raíz: Real del Monte" },
        { id: "germen", label: "El germen del Atlas" },
        { id: "hitos", label: "Hitos fundacionales" },
        { id: "ahora", label: "Dónde estamos hoy" },
      ]}
    >
      <Section id="raiz" title="La raíz: Real del Monte">
        <p>
          El Atlas TAMV no nace en un laboratorio ni en una incubadora corporativa. Nace en
          <strong> Real del Monte</strong>, un pueblo minero del estado de Hidalgo, México,
          con más de cuatro siglos de historia, neblina permanente y una identidad cultural
          que resistió ciclos de bonanza, abandono y reinvención. Esa misma tenacidad es la
          que late en la arquitectura del Atlas.
        </p>
        <p>
          Decir <strong>"orgullosamente Realmontenses"</strong> no es decoración: es una
          declaración de origen y de método. Aquí se construye con paciencia de minero, con
          memoria de pueblo, y con la certeza de que las soluciones digitales serias
          empiezan mirando de frente al territorio que las sostiene.
        </p>
      </Section>

      <Section id="germen" title="El germen del Atlas">
        <p>
          El proyecto inicial fue una pregunta incómoda: <em>¿por qué nuestras comunidades
          dependen de plataformas extranjeras incluso para nombrar lo propio?</em> A partir
          de esa pregunta surgieron, en cascada, los componentes que hoy forman el Atlas:
        </p>
        <ul>
          <li>Un <strong>registro de identidad soberana</strong> para personas, comercios e instituciones del territorio.</li>
          <li>Un <strong>compilador civilizatorio</strong> capaz de absorber e integrar repositorios, archivos y saberes dispersos.</li>
          <li>Un <strong>motor ético</strong> (Isabella) que actúa como mediador entre la inteligencia artificial y las personas reales.</li>
          <li>Una <strong>capa constitucional</strong> que convierte los valores en código ejecutable y auditable.</li>
        </ul>
      </Section>

      <Section id="hitos" title="Hitos fundacionales">
        <ul>
          <li><strong>2024 · Año cero.</strong> Primeros repositorios bajo la cuenta <code>OsoPanda1</code>. Definición del propósito y de la cultura de trabajo.</li>
          <li><strong>2025 · Federación inicial.</strong> Nacen <em>Digital Nexus</em> y <em>The Federated Frontier</em>; se define la capa constitucional y se publica el primer canon civilizatorio.</li>
          <li><strong>2026 · Congelamiento por módulos.</strong> Se publica la <em>Auditoría canónica v1.0</em> y comienza el cierre formal de módulos estables (RFC-0001, RFC-0002).</li>
        </ul>
      </Section>

      <Section id="ahora" title="Dónde estamos hoy">
        <p>
          Hoy el Atlas TAMV es una <strong>federación viva</strong> de subproyectos con un
          núcleo claro y reglas de gobernanza explícitas. La etapa actual no busca crecer en
          superficie, sino <strong>cerrar módulos funcionales</strong> con documentación
          canónica, tests de contrato y versiones congeladas. El futuro inmediato es
          consolidación, no expansión.
        </p>
      </Section>
    </WikiShell>
  );
}
