import { createFileRoute, Link } from "@tanstack/react-router";
import { WikiShell, Section } from "@/components/wiki/WikiShell";

export const Route = createFileRoute("/wiki")({
  head: () => ({
    meta: [
      { title: "Wiki canónica — Atlas TAMV" },
      {
        name: "description",
        content:
          "Enciclopedia canónica del ecosistema TAMV: principios, componentes y rutas de navegación oficiales.",
      },
    ],
  }),
  component: WikiPortada,
});

function WikiPortada() {
  return (
    <WikiShell
      title="Atlas TAMV — Wiki canónica"
      subtitle="Enciclopedia abierta del ecosistema TAMV — identidad digital soberana, gobernanza ética y federación de conocimiento."
      meta={[
        { label: "Tipo", value: "Plataforma federada" },
        { label: "Origen", value: "Real del Monte, México" },
        { label: "Alcance", value: "Latinoamérica → Mundo" },
        { label: "Versión canónica", value: "v1.0" },
        { label: "Licencia", value: "CC BY-SA 4.0" },
        { label: "Estado", value: "Activo · congelando módulos" },
      ]}
      toc={[
        { id: "resumen", label: "Resumen" },
        { id: "que-es", label: "¿Qué es el Atlas TAMV?" },
        { id: "principios", label: "Principios fundacionales" },
        { id: "componentes", label: "Componentes del ecosistema" },
        { id: "navegacion", label: "Cómo navegar esta wiki" },
      ]}
    >
      <Section id="resumen" title="Resumen">
        <p>
          <strong>Atlas TAMV</strong> es la enciclopedia abierta y la plataforma informativa
          canónica del ecosistema <strong>TAMV</strong> (Territorios, Atlas, Memoria y Vínculo):
          una infraestructura cívica-digital construida para articular <em>identidad soberana</em>,
          <em> economía local</em>, <em>conocimiento federado</em> y <em>gobernanza ética</em>
          en clave latinoamericana, con raíz en <strong>Real del Monte</strong> y vocación de
          alcance planetario.
        </p>
        <p>
          Esta wiki documenta —al estilo de Wikipedia, Python, GitHub o GitLab— qué somos,
          de dónde venimos, hacia dónde vamos, cómo trabajamos y cómo puedes sumarte. Cada
          artículo es revisable, citable y versionado.
        </p>
        <blockquote>
          Orgullosamente Realmontenses. Desde el centro de Latinoamérica para el mundo.
        </blockquote>
      </Section>

      <Section id="que-es" title="¿Qué es el Atlas TAMV?">
        <p>
          El Atlas es una <strong>plataforma federada</strong> compuesta por un núcleo
          constitucional (capa de políticas y guardias éticos), un motor de inteligencia
          contextual llamado <strong>Isabella</strong>, un sistema de identidad
          soberana (SSI/DID), un compilador civilizatorio que absorbe y unifica fuentes de
          conocimiento, y una red de aplicaciones territoriales que conectan personas,
          comercios, instituciones, cultura y memoria.
        </p>
        <p>
          A diferencia de un ERP, una red social o un buscador, el Atlas TAMV es
          deliberadamente <em>infraestructura pública digital</em>: contratos abiertos,
          documentación canónica, módulos congelables y gobernanza explícita.
        </p>
      </Section>

      <Section id="principios" title="Principios fundacionales">
        <ul>
          <li><strong>Soberanía sobre la identidad y los datos</strong> de personas, territorios y comunidades.</li>
          <li><strong>Ética operativa, no decorativa</strong>: la capa constitucional bloquea acciones, no las maquilla.</li>
          <li><strong>Federación antes que centralización</strong>: el conocimiento vive distribuido y se compone.</li>
          <li><strong>Territorio primero</strong>: cada decisión vuelve a la economía local y a la cultura del lugar.</li>
          <li><strong>Congelamiento responsable</strong>: módulos cerrados con doc canónica antes de seguir expandiendo.</li>
        </ul>
      </Section>

      <Section id="componentes" title="Componentes del ecosistema">
        <p>El Atlas TAMV se organiza en capas claramente delimitadas:</p>
        <ul>
          <li><strong>Backend Core</strong> — kernel runtime, gateway omni-kernel, registro de identidad, métricas de auditoría.</li>
          <li><strong>Compilador Civilizatorio</strong> — canon v1, absorción de repos, RFCs de unificación.</li>
          <li><strong>Capa Constitucional</strong> — motor de constitución, registro de políticas, auditoría inmutable.</li>
          <li><strong>Isabella</strong> — orquestador ético con doble pipeline, filtro óctuple y escudo de integridad.</li>
          <li><strong>Federación Digital Nexus</strong> — dominios de economía, gobernanza, IA, social y XR.</li>
          <li><strong>Frontera Federada</strong> — protocolo, THCF, EOCT, MSR, BookPI.</li>
          <li><strong>Wiki & Frontier</strong> — esta plataforma de conocimiento abierto.</li>
        </ul>
      </Section>

      <Section id="navegacion" title="Cómo navegar esta wiki">
        <p>El menú lateral agrupa los artículos en cinco grandes secciones:</p>
        <ol>
          <li><Link to="/origen">Origen y dónde comenzamos</Link> — la historia desde Real del Monte.</li>
          <li><Link to="/mision-vision">Misión, visión y valores</Link> — el porqué.</li>
          <li><Link to="/objetivos">Objetivos</Link> — los resultados a 1, 3 y 10 años.</li>
          <li><Link to="/posicionamiento">Posicionamiento</Link> y <Link to="/estrategias">estrategias</Link>.</li>
          <li><Link to="/servicio-atlas">El servicio Atlas</Link> y la <Link to="/convocatoria">convocatoria abierta</Link>.</li>
        </ol>
        <p>
          También está disponible el documento técnico de{" "}
          <Link to="/auditoria">Auditoría canónica v1.0</Link>, base del congelamiento por módulos.
        </p>
      </Section>
    </WikiShell>
  );
}
