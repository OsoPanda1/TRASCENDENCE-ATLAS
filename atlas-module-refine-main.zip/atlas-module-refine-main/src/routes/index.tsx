import { createFileRoute, Link } from "@tanstack/react-router";
import { LandingLayout } from "@/components/landing/LandingShell";
import {
  heroCopy,
  pipelineStages,
  guardians,
  layers,
  federations,
  components,
  nodoCero,
  positioning,
  callToAction,
} from "@/lib/atlas-content";
import { ArrowRight, BookOpen, Globe2, Shield, GitBranch, Mountain } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Atlas TAMV — Compilador civilizatorio y Atlas vivo de conocimiento soberano" },
      {
        name: "description",
        content:
          "Plataforma federada para versionar, evaluar y promover conocimiento como si fuera código. Grafo vivo, constitución computable y guardianías distribuidas. Desde Real del Monte para el mundo.",
      },
      { property: "og:title", content: "Atlas TAMV — Conocimiento soberano federado" },
      {
        property: "og:description",
        content:
          "Compilador civilizatorio, constitución computable y siete guardianías sobre un grafo vivo de código, políticas y territorios.",
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <LandingLayout>
      <Hero />
      <Pillars />
      <Pipeline />
      <NodoCero />
      <Architecture />
      <Federations />
      <Components />
      <Convocatoria />
    </LandingLayout>
  );
}

/* ------------------------------- Hero ------------------------------- */

function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-border">
      <div
        aria-hidden
        className="absolute inset-0 -z-10 opacity-[0.35]"
        style={{
          backgroundImage:
            "radial-gradient(at 15% 10%, color-mix(in oklab, var(--copper) 28%, transparent) 0, transparent 45%), radial-gradient(at 85% 90%, color-mix(in oklab, var(--ink) 20%, transparent) 0, transparent 50%)",
        }}
      />
      <div
        aria-hidden
        className="absolute inset-0 -z-10 opacity-[0.08]"
        style={{
          backgroundImage:
            "linear-gradient(to right, var(--ink) 1px, transparent 1px), linear-gradient(to bottom, var(--ink) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          maskImage: "radial-gradient(ellipse at center, black 30%, transparent 75%)",
        }}
      />

      <div className="max-w-[1280px] mx-auto px-5 pt-20 pb-24 lg:pt-28 lg:pb-32 grid lg:grid-cols-[1.15fr_0.85fr] gap-12 items-center">
        <div>
          <div className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-primary font-medium mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            {heroCopy.kicker}
          </div>
          <h1 className="font-display text-5xl sm:text-6xl lg:text-[68px] leading-[1.02] font-semibold tracking-tight">
            {heroCopy.title.split(":")[0]}:
            <br />
            <span className="text-primary">{heroCopy.title.split(":")[1].trim()}</span>
          </h1>
          <p className="mt-7 text-lg text-muted-foreground leading-relaxed max-w-[58ch]">
            {heroCopy.subtitle}
          </p>

          <ul className="mt-7 space-y-2.5 max-w-[58ch]">
            {heroCopy.bullets.map((b) => (
              <li key={b} className="flex gap-3 text-[15px] leading-relaxed">
                <span className="mt-2 w-1.5 h-1.5 rounded-full bg-copper shrink-0" />
                <span>{b}</span>
              </li>
            ))}
          </ul>

          <div className="mt-9 flex flex-wrap gap-3">
            <Link
              to={heroCopy.ctaPrimary.to}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-md bg-ink text-parchment text-[15px] font-medium shadow-sm hover:opacity-90 transition group"
            >
              {heroCopy.ctaPrimary.label}
              <ArrowRight size={16} className="group-hover:translate-x-0.5 transition-transform" />
            </Link>
            <Link
              to={heroCopy.ctaSecondary.to}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-border bg-card text-[15px] font-medium hover:bg-muted transition"
            >
              {heroCopy.ctaSecondary.label}
            </Link>
          </div>
        </div>

        {/* Decorative grafo card */}
        <div className="relative">
          <div className="rounded-xl border border-border bg-card/90 backdrop-blur shadow-[0_30px_60px_-30px_color-mix(in_oklab,var(--ink)_40%,transparent)] p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground font-medium">
                Compilador · estado del grafo
              </span>
              <span className="text-[10px] text-primary font-mono">G0 → G1</span>
            </div>
            <div className="grid grid-cols-2 gap-3 text-[13px]">
              {[
                { k: "Coherencia", v: "+8.4%", up: true },
                { k: "Trazabilidad", v: "100%", up: true },
                { k: "Contradicciones", v: "−3", up: true },
                { k: "Fragmentación", v: "−12%", up: true },
                { k: "Cobertura", v: "+5", up: true },
                { k: "Reutilización", v: "+2.1×", up: true },
              ].map((s) => (
                <div key={s.k} className="rounded-md border border-border/70 bg-background px-3 py-2.5">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.k}</div>
                  <div className="font-display font-semibold text-lg mt-0.5 text-foreground">{s.v}</div>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-border/70 flex items-center justify-between text-[11px]">
              <span className="text-muted-foreground">Decisión guardianías</span>
              <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">
                PROMOVER
              </span>
            </div>
          </div>
          <div className="absolute -bottom-3 -right-3 -z-10 w-full h-full rounded-xl bg-copper/15" />
        </div>
      </div>
    </section>
  );
}

/* ------------------------------ Pillars ----------------------------- */

function Pillars() {
  const items = [
    { icon: Shield, ...positioning.pillars[0] },
    { icon: GitBranch, ...positioning.pillars[1] },
    { icon: BookOpen, ...positioning.pillars[2] },
  ];
  return (
    <section className="max-w-[1280px] mx-auto px-5 py-20">
      <header className="max-w-2xl mb-10">
        <SectionLabel>Diferencia estructural</SectionLabel>
        <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight mt-3">
          {positioning.title}
        </h2>
        <p className="mt-4 text-muted-foreground leading-relaxed">{positioning.body}</p>
      </header>
      <div className="grid md:grid-cols-3 gap-5">
        {items.map(({ icon: Icon, name, body }) => (
          <div
            key={name}
            className="rounded-lg border border-border bg-card p-6 hover:border-primary/40 transition group"
          >
            <div className="w-10 h-10 rounded-md bg-accent grid place-items-center text-primary mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition">
              <Icon size={18} />
            </div>
            <h3 className="font-display font-semibold text-lg">{name}</h3>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ----------------------------- Pipeline ----------------------------- */

function Pipeline() {
  return (
    <section className="border-y border-border bg-card/40">
      <div className="max-w-[1280px] mx-auto px-5 py-20">
        <header className="max-w-2xl mb-12">
          <SectionLabel>Cómo funciona</SectionLabel>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight mt-3">
            Del artefacto al ecosistema
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            En Atlas TAMV cada documento, repositorio o protocolo no se evalúa en aislado, sino por
            su efecto en el ecosistema completo. El corazón es un compilador civilizatorio que opera
            sobre un grafo vivo: G0 (estado actual) → G1 (estado simulado).
          </p>
        </header>

        <ol className="relative grid lg:grid-cols-5 gap-px bg-border rounded-xl overflow-hidden border border-border">
          {pipelineStages.map((s, i) => (
            <li key={s.id} className="bg-card p-6 relative">
              <div className="flex items-center gap-2 mb-3">
                <span className="font-mono text-[10px] text-primary bg-primary/10 px-1.5 py-0.5 rounded">
                  0{i + 1}
                </span>
                <span className="font-mono text-[10px] text-muted-foreground">{s.role}</span>
              </div>
              <h3 className="font-display font-semibold text-base leading-snug">{s.name}</h3>
              <p className="mt-2 text-[13px] text-muted-foreground leading-relaxed">{s.body}</p>
            </li>
          ))}
        </ol>

        <div className="mt-10 rounded-xl border border-border bg-background p-6 sm:p-8">
          <h3 className="font-display text-lg font-semibold">Las siete preguntas que respondemos antes de promover</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Cada cambio es interrogado por una guardianía especializada. Una sola respuesta crítica
            negativa bloquea la promoción.
          </p>
          <div className="mt-5 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {guardians.map((g, i) => (
              <div key={g.q} className="flex gap-3 items-start text-sm">
                <span className="font-mono text-[11px] text-primary border border-primary/30 rounded px-1.5 py-0.5 mt-0.5">
                  G{i + 1}
                </span>
                <div>
                  <div className="font-medium text-foreground">{g.q}</div>
                  <div className="text-[12px] text-muted-foreground">Guardián de {g.g}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* --------------------------- Nodo Cero RDM -------------------------- */

function NodoCero() {
  return (
    <section className="max-w-[1280px] mx-auto px-5 py-20">
      <div className="grid lg:grid-cols-[0.95fr_1fr] gap-12 items-start">
        <div>
          <SectionLabel>Nodo Cero</SectionLabel>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight mt-3">
            {nodoCero.title}
          </h2>
          {nodoCero.body.map((p, i) => (
            <p key={i} className="mt-4 text-muted-foreground leading-relaxed">
              {p}
            </p>
          ))}
          <Link
            to="/origen"
            className="inline-flex items-center gap-2 mt-6 text-sm font-medium text-primary hover:gap-3 transition-all"
          >
            Cómo nació RDM Digital <ArrowRight size={15} />
          </Link>
        </div>

        <div className="rounded-xl border border-border bg-card p-7">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 rounded-md bg-ink text-parchment grid place-items-center">
              <Mountain size={18} />
            </div>
            <div>
              <div className="font-display font-semibold">Manifiesto LTOS</div>
              <div className="text-[11px] text-muted-foreground uppercase tracking-wider">
                Local Territorial Operating System
              </div>
            </div>
          </div>
          <ol className="space-y-3">
            {nodoCero.manifesto.map((m, i) => (
              <li key={i} className="flex gap-3 text-[14px] leading-relaxed">
                <span className="font-display font-semibold text-copper shrink-0 w-6">
                  0{i + 1}
                </span>
                <span>{m}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}

/* --------------------------- Architecture --------------------------- */

function Architecture() {
  return (
    <section className="border-y border-border bg-ink text-parchment relative overflow-hidden">
      <div
        aria-hidden
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(to right, var(--parchment) 1px, transparent 1px), linear-gradient(to bottom, var(--parchment) 1px, transparent 1px)",
          backgroundSize: "48px 48px",
        }}
      />
      <div className="max-w-[1280px] mx-auto px-5 py-20 relative">
        <header className="max-w-2xl mb-12">
          <div className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-copper font-medium mb-4">
            <span className="w-1.5 h-1.5 rounded-full bg-copper" />
            Arquitectura canónica · MD-X4
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight">
            Heptafederación en ocho capas
          </h2>
          <p className="mt-4 text-parchment/70 leading-relaxed">
            El Kernel MD-X4 organiza el sistema en ocho capas (L0–L7), seis pipelines hexagonales
            He y siete dominios heptafederados Hep. Cada operación se categoriza por su función
            y por su jurisdicción de gobernanza.
          </p>
        </header>

        <div className="grid lg:grid-cols-2 gap-10">
          <div>
            <h3 className="font-display text-lg font-semibold mb-4 flex items-center gap-2">
              <span className="w-6 h-px bg-copper" /> Pila de ejecución L0–L7
            </h3>
            <ul className="rounded-lg border border-parchment/15 divide-y divide-parchment/10 overflow-hidden">
              {layers.map((l) => (
                <li key={l.id} className="px-4 py-3 grid grid-cols-[44px_minmax(0,1fr)] gap-3 items-baseline hover:bg-parchment/5 transition">
                  <span className="font-mono text-copper text-sm">{l.id}</span>
                  <div>
                    <div className="font-display font-semibold">{l.name}</div>
                    <div className="text-[12.5px] text-parchment/65">{l.role}</div>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display text-lg font-semibold mb-4 flex items-center gap-2">
              <span className="w-6 h-px bg-copper" /> Six He · Seven Hep
            </h3>
            <Link
              to="/atlas"
              className="block rounded-lg border border-parchment/15 bg-parchment/[0.03] p-5 hover:bg-parchment/[0.06] transition group"
            >
              <div className="text-[11px] uppercase tracking-wider text-parchment/50 mb-2">
                Pipelines hexagonales (He)
              </div>
              <div className="font-mono text-[13px] text-parchment/85 leading-relaxed">
                HE-Ingest · HE-Transform · HE-Publish · HE-Science · HE-Economy · HE-Identity
              </div>
              <div className="text-[11px] uppercase tracking-wider text-parchment/50 mt-5 mb-2">
                Dominios heptafederados (Hep)
              </div>
              <div className="font-mono text-[13px] text-parchment/85 leading-relaxed">
                HEP-1 Central · HEP-2 Operaciones · HEP-3 Infraestructura · HEP-4 Seguridad ·
                HEP-5 Financiera · HEP-6 Logística · HEP-7 Usuarios
              </div>
              <div className="mt-5 inline-flex items-center gap-2 text-sm text-copper font-medium group-hover:gap-3 transition-all">
                Ver mapa completo del Atlas <ArrowRight size={15} />
              </div>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

/* --------------------------- Federations ---------------------------- */

function Federations() {
  return (
    <section className="max-w-[1280px] mx-auto px-5 py-20">
      <header className="max-w-2xl mb-10">
        <SectionLabel>Siete federaciones</SectionLabel>
        <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight mt-3">
          Dominios soberanos del ecosistema
        </h2>
        <p className="mt-4 text-muted-foreground leading-relaxed">
          Cada repositorio, tabla y módulo se clasifica en una federación funcional. Esto
          facilita la gobernanza distribuida y la expansión a otros municipios bajo el mismo
          protocolo.
        </p>
      </header>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-border rounded-xl overflow-hidden border border-border">
        {federations.map((f, i) => (
          <div key={f.id} className="bg-card p-5 hover:bg-accent/40 transition">
            <div className="flex items-baseline gap-2 mb-2">
              <span className="font-mono text-[10px] text-copper">F-0{i + 1}</span>
              <h3 className="font-display font-semibold text-base">{f.name}</h3>
            </div>
            <p className="text-[13px] text-muted-foreground leading-relaxed">{f.body}</p>
          </div>
        ))}
        <div className="bg-ink text-parchment p-5 sm:col-span-2 lg:col-span-1 grid place-items-center text-center">
          <div>
            <Globe2 size={22} className="text-copper mx-auto mb-2" />
            <div className="font-display font-semibold">Federación viva</div>
            <div className="text-[12px] text-parchment/70 mt-1">
              +100 repos coordinados bajo el mismo canon
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* --------------------------- Components ----------------------------- */

function Components() {
  return (
    <section className="border-t border-border bg-card/40">
      <div className="max-w-[1280px] mx-auto px-5 py-20">
        <header className="max-w-2xl mb-10">
          <SectionLabel>Componentes centrales</SectionLabel>
          <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight mt-3">
            Las piezas vivas del Atlas
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Identidad soberana, libro mayor cripto-inmutable, IA contextual auditable, ledger
            económico idempotente y gemelo digital territorial. Cada pieza opera bajo la
            constitución y registra sus decisiones.
          </p>
        </header>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {components.map((c) => (
            <article
              key={c.id}
              className="rounded-lg border border-border bg-background p-6 hover:shadow-[0_12px_40px_-20px_color-mix(in_oklab,var(--ink)_30%,transparent)] transition"
            >
              <h3 className="font-display font-semibold text-lg text-foreground">{c.name}</h3>
              <p className="mt-2 text-[14px] text-muted-foreground leading-relaxed">{c.body}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* --------------------------- Convocatoria --------------------------- */

function Convocatoria() {
  return (
    <section className="max-w-[1280px] mx-auto px-5 py-24">
      <div className="rounded-2xl border border-border bg-gradient-to-br from-card via-card to-accent/40 p-8 sm:p-12 relative overflow-hidden">
        <div
          aria-hidden
          className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-copper/10 blur-3xl"
        />
        <div className="relative grid lg:grid-cols-[1fr_1fr] gap-10 items-center">
          <div>
            <SectionLabel>Súmate</SectionLabel>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight mt-3">
              {callToAction.title}
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed max-w-[52ch]">
              {callToAction.body}
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link
                to="/convocatoria"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-md bg-ink text-parchment text-[15px] font-medium hover:opacity-90 transition"
              >
                Ver convocatoria abierta <ArrowRight size={16} />
              </Link>
              <Link
                to="/wiki"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-border bg-background text-[15px] font-medium hover:bg-muted transition"
              >
                Leer la wiki
              </Link>
            </div>
          </div>
          <ul className="space-y-2.5">
            {callToAction.audiences.map((a) => (
              <li
                key={a.who}
                className="rounded-md border border-border bg-background p-4 flex gap-4"
              >
                <div className="font-display font-semibold text-[15px] w-40 shrink-0 text-primary">
                  {a.who}
                </div>
                <div className="text-[13.5px] text-muted-foreground leading-relaxed">{a.what}</div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------ Helpers ----------------------------- */

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-copper font-medium">
      <span className="w-6 h-px bg-copper" />
      {children}
    </span>
  );
}
