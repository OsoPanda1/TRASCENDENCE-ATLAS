import { createFileRoute, Link } from "@tanstack/react-router";
import { WikiShell, Section } from "@/components/wiki/WikiShell";

export const Route = createFileRoute("/servicio-atlas")({
  head: () => ({
    meta: [
      { title: "El servicio Atlas — Atlas TAMV" },
      { name: "description", content: "Qué ofrece el servicio Atlas TAMV, sus módulos y cómo se usa." },
    ],
  }),
  component: Servicio,
});

function Servicio() {
  return (
    <WikiShell
      title="El servicio Atlas"
      subtitle="Qué entrega el Atlas TAMV a personas, comercios, instituciones y territorios."
      meta={[
        { label: "Tipo de servicio", value: "Infraestructura pública" },
        { label: "Modelo", value: "Federado · Open" },
        { label: "Acceso", value: "Por invitación territorial" },
        { label: "Estado", value: "v1.0 en consolidación" },
      ]}
      toc={[
        { id: "para-quien", label: "Para quién es" },
        { id: "modulos", label: "Módulos del servicio" },
        { id: "como-usarlo", label: "Cómo usarlo" },
        { id: "garantias", label: "Garantías" },
      ]}
    >
      <Section id="para-quien" title="Para quién es">
        <ul>
          <li><strong>Personas</strong> que quieren una identidad digital portable, verificable y bajo su control.</li>
          <li><strong>Comercios y servicios locales</strong> que necesitan visibilidad orgánica anclada al territorio.</li>
          <li><strong>Instituciones culturales y educativas</strong> que requieren preservar memoria y emitir credenciales.</li>
          <li><strong>Gobiernos locales</strong> que buscan infraestructura digital propia sin depender de proveedores extranjeros.</li>
          <li><strong>Investigadores y desarrolladores</strong> que quieren construir sobre contratos abiertos.</li>
        </ul>
      </Section>

      <Section id="modulos" title="Módulos del servicio">
        <ul>
          <li><strong>Identidad Soberana (IDNVIDA)</strong> — DIDs, credenciales verificables, perfiles federados.</li>
          <li><strong>Compilador Civilizatorio</strong> — absorción y unificación de fuentes de conocimiento.</li>
          <li><strong>Isabella</strong> — guía e intérprete con filtros éticos verificables.</li>
          <li><strong>Capa Constitucional</strong> — políticas como código, auditoría inmutable.</li>
          <li><strong>UTAMV</strong> — universidad federada, cursos y certificaciones.</li>
          <li><strong>Dreamspaces XR</strong> — experiencias inmersivas territoriales.</li>
          <li><strong>RDM Digital</strong> — pueblos y comunidades en formato digital persistente.</li>
        </ul>
      </Section>

      <Section id="como-usarlo" title="Cómo usarlo">
        <ol>
          <li>Solicitar acceso vía la <Link to="/convocatoria">convocatoria abierta</Link>.</li>
          <li>Recibir un DID territorial y la documentación canónica del módulo que vas a usar.</li>
          <li>Integrar contra los contratos abiertos (<code>OpenAPI v3.1</code> o SDKs publicados).</li>
          <li>Operar bajo la capa constitucional: tus acciones quedan auditadas, no vigiladas.</li>
        </ol>
      </Section>

      <Section id="garantias" title="Garantías">
        <ul>
          <li>Los módulos marcados <code>@1.0</code> no rompen contratos sin RFC público.</li>
          <li>Toda decisión ética del sistema es <em>explicable y reversible</em>.</li>
          <li>Tus datos territoriales no se exportan fuera de la federación sin tu consentimiento explícito.</li>
        </ul>
      </Section>
    </WikiShell>
  );
}
