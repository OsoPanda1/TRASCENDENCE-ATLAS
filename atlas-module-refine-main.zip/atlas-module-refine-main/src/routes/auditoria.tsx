import { createFileRoute } from "@tanstack/react-router";
import { WikiShell, Section } from "@/components/wiki/WikiShell";

export const Route = createFileRoute("/auditoria")({
  head: () => ({
    meta: [
      { title: "Auditoría canónica v1.0 — Atlas TAMV" },
      { name: "description", content: "Informe de auditoría profesional del monorepo tamv-atlas-nextgen y propuesta de congelamiento por módulos." },
    ],
  }),
  component: Auditoria,
});

function Auditoria() {
  return (
    <WikiShell
      title="Auditoría canónica v1.0"
      subtitle="Informe profesional del repositorio tamv-atlas-nextgen y plan de congelamiento por módulos."
      meta={[
        { label: "Versión", value: "1.0" },
        { label: "Fecha", value: "11 jun 2026" },
        { label: "Autor", value: "Lovable Atlas Audit" },
        { label: "Estado", value: "Aprobado para freeze" },
      ]}
      toc={[
        { id: "objetivo", label: "Objetivo" },
        { id: "mapa", label: "Mapa ejecutivo" },
        { id: "freeze", label: "Módulos a congelar v1.0" },
        { id: "beta", label: "Módulos en beta" },
        { id: "deprecated", label: "Deprecaciones" },
        { id: "siguientes", label: "Próximos pasos" },
        { id: "documento", label: "Documento completo" },
      ]}
    >
      <Section id="objetivo" title="Objetivo">
        <p>
          Declarar v1.0 estables los módulos maduros del monorepo
          <code> tamv-atlas-nextgen</code>, marcar zonas en evolución y proponer un
          protocolo de congelamiento (RFC + tag Git + documentación canónica) para
          detener la expansión y consolidar lo construido.
        </p>
      </Section>

      <Section id="mapa" title="Mapa ejecutivo del repositorio">
        <ul>
          <li><strong>Backend núcleo</strong> · alta madurez · congelar.</li>
          <li><strong>Compilador civilizatorio</strong> · canon ya escrito · congelar.</li>
          <li><strong>Federación Digital Nexus</strong> · alta, con duplicación de edge functions · congelar subset.</li>
          <li><strong>Frontera federada</strong> · contratos limpios · congelar protocolo.</li>
          <li><strong>Wiki / Frontier</strong> · mucho contenido en stub · reestructurar antes de congelar.</li>
          <li><strong>Infra y contratos</strong> · duplicados entre carpetas · unificar.</li>
        </ul>
      </Section>

      <Section id="freeze" title="Módulos a congelar v1.0">
        <ul>
          <li><code>backend-core@1.0</code> — kernel, gateway, isabella, civcompiler.</li>
          <li><code>civilizational-compiler@1.0</code> — canon v1 + RFCs.</li>
          <li><code>constitutional-layer@1.0</code> — engine, policy registry, audit trail.</li>
          <li><code>isabella-ethics@1.0</code> — octuple filter, shield, hard stop, double pipeline.</li>
          <li><code>protocol-core@1.0</code> — protocol + THCF + api.contracts.</li>
          <li><code>contracts-openapi@3.1.0</code> — OpenAPI + schemas + policies.</li>
          <li><code>ops-scripts@1.0</code> — build, classify, consolidate, review.</li>
        </ul>
      </Section>

      <Section id="beta" title="Módulos en beta · no congelar todavía">
        <ul>
          <li>Omni-Kernel, RDM Digital, MSR, Sovereign Identity, Nexus.</li>
          <li>Hooks XR (Integrity, Performance, Permissions, Presence).</li>
          <li>Contenido wiki en estado stub o draft.</li>
          <li>Edge functions pendientes de consolidación.</li>
        </ul>
      </Section>

      <Section id="deprecated" title="Deprecaciones recomendadas">
        <ul>
          <li><code>auth-service</code> v1 y v2 → conservar solo v3.</li>
          <li>Variantes <code>*-enhanced</code> → consolidar en una sola.</li>
          <li>Duplicados de <code>MatrixRain</code> y <code>WikiHome</code>.</li>
          <li><code>repo-unification-sample.json</code> → archivar.</li>
        </ul>
      </Section>

      <Section id="siguientes" title="Próximos pasos recomendados">
        <ol>
          <li>RFC-0003 — Consolidación de edge functions.</li>
          <li>Crear <code>packages/contracts/</code> raíz unificado.</li>
          <li>Etiquetar <code>backend-core@1.0.0</code>, <code>civilizational-compiler@1.0.0</code> y <code>protocol-core@1.0.0</code>.</li>
          <li>Auditoría de contenido wiki por estado.</li>
          <li>Activar <code>freeze-gate.yml</code> en CI.</li>
        </ol>
      </Section>

      <Section id="documento" title="Documento completo">
        <p>
          La auditoría completa, con tablas detalladas y protocolo de congelamiento por
          módulo, está disponible como documento descargable en formato Markdown.
        </p>
        <p>
          → <strong>Archivo:</strong> <code>TAMV_ATLAS_AUDITORIA_v1.md</code>
        </p>
      </Section>
    </WikiShell>
  );
}
