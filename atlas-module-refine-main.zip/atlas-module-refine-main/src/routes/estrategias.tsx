import { createFileRoute } from "@tanstack/react-router";
import { WikiShell, Section } from "@/components/wiki/WikiShell";

export const Route = createFileRoute("/estrategias")({
  head: () => ({
    meta: [
      { title: "Estrategias — Atlas TAMV" },
      { name: "description", content: "Estrategia técnica, editorial, de federación y de adopción del Atlas TAMV." },
    ],
  }),
  component: Estrategias,
});

function Estrategias() {
  return (
    <WikiShell
      title="Estrategias"
      subtitle="Cómo lo hacemos: cuatro frentes coordinados."
      toc={[
        { id: "tecnica", label: "Estrategia técnica" },
        { id: "editorial", label: "Estrategia editorial" },
        { id: "federacion", label: "Estrategia de federación" },
        { id: "adopcion", label: "Estrategia de adopción" },
      ]}
    >
      <Section id="tecnica" title="Estrategia técnica · congelar antes de crecer">
        <ul>
          <li><strong>Módulos cerrados</strong> con doc canónica antes de aceptar nuevas dependencias.</li>
          <li><strong>Contratos públicos versionados</strong> (OpenAPI v3.1, JSON Schema, Avro) como única fuente de verdad.</li>
          <li><strong>Pruebas sobre el contrato</strong>, no sobre la implementación.</li>
          <li><strong>CI con gates de congelamiento</strong>: ningún PR rompe un módulo @1.0 sin RFC.</li>
          <li><strong>Una sola versión por capacidad</strong>: prohibido <code>service-v2</code>, <code>service-enhanced</code>.</li>
        </ul>
      </Section>

      <Section id="editorial" title="Estrategia editorial · wiki como producto">
        <p>
          Esta wiki es un <em>producto</em>, no un anexo. Cada artículo pasa por estados
          explícitos: <code>stub</code> → <code>draft</code> → <code>review</code> →
          <code>canon</code>. Solo lo <em>canon</em> aparece sin advertencias. La estética
          es deliberadamente clásica: tipografía editorial, jerarquía clara, sin ruido
          visual, inspirada en Wikipedia y en la documentación de Python.
        </p>
      </Section>

      <Section id="federacion" title="Estrategia de federación · territorios primero">
        <ul>
          <li>Un territorio piloto antes que diez teóricos.</li>
          <li>Gobernanza local real, no un consejo simbólico.</li>
          <li>Identidad soberana antes que features sociales.</li>
          <li>Cada federación se documenta como un artículo de la wiki.</li>
        </ul>
      </Section>

      <Section id="adopcion" title="Estrategia de adopción · invitar, no convencer">
        <p>
          No hacemos campañas de growth. Hacemos <strong>convocatorias claras</strong>:
          quién encaja, qué aporta y qué recibe. La adopción crece por reputación técnica y
          por resultados territoriales medibles, no por ruido.
        </p>
      </Section>
    </WikiShell>
  );
}
