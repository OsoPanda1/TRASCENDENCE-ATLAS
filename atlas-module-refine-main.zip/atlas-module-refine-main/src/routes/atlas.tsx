import { createFileRoute, Link } from "@tanstack/react-router";
import { WikiShell, Section } from "@/components/wiki/WikiShell";
import { layers, hexagons, hepDomains, pipelineStages, guardians, components } from "@/lib/atlas-content";

export const Route = createFileRoute("/atlas")({
  head: () => ({
    meta: [
      { title: "Atlas — Arquitectura canónica MD-X4 · TAMV" },
      {
        name: "description",
        content:
          "Mapa completo del Atlas TAMV: ocho capas L0–L7, seis pipelines hexagonales He, siete dominios heptafederados Hep y las siete guardianías del compilador civilizatorio.",
      },
    ],
  }),
  component: AtlasOverview,
});

function AtlasOverview() {
  return (
    <WikiShell
      title="Arquitectura canónica del Atlas"
      subtitle="Kernel MD-X4 heptafederado: ocho capas, seis pipelines He, siete dominios Hep y siete guardianías."
      meta={[
        { label: "Doctrina", value: "ELITE HeHep" },
        { label: "Kernel", value: "MD-X4 / ATLAS_CORE" },
        { label: "Capas", value: "L0–L7" },
        { label: "Pipelines He", value: "6" },
        { label: "Dominios Hep", value: "7" },
        { label: "Guardianías", value: "7" },
      ]}
      toc={[
        { id: "doctrina", label: "Doctrina ELITE HeHep" },
        { id: "capas", label: "Capas L0–L7" },
        { id: "hexagonos", label: "Pipelines hexagonales He" },
        { id: "dominios", label: "Dominios heptafederados Hep" },
        { id: "pipeline", label: "Pipeline civilizatorio" },
        { id: "guardianias", label: "Las siete guardianías" },
        { id: "componentes", label: "Componentes centrales" },
        { id: "navegar", label: "Cómo seguir leyendo" },
      ]}
    >
      <Section id="doctrina" title="Doctrina ELITE HeHep">
        <p>
          <strong>ELITE HeHep</strong> es el acrónimo de <em>Ecosistema Latino Interfederado TAMV
          Enterprise — Hexagonal Heptafederado</em>. Es la doctrina arquitectónica del kernel
          MD-X4 y aplica tanto a la organización funcional (pipelines hexagonales He) como a la
          gobernanza por dominios soberanos (heptafederación Hep).
        </p>
        <p>
          Cada operación queda categorizada por su pipeline funcional <strong>y</strong> por su
          dominio de gobernanza. Esa doble clasificación es obligatoria en todo evento BookPI que
          cruza dominios.
        </p>
      </Section>

      <Section id="capas" title="Capas L0–L7">
        <p>El kernel se estructura en ocho capas especializadas:</p>
        <div className="not-prose overflow-x-auto -mx-2 my-4">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="text-left border-b border-border">
                <th className="py-2 px-2 font-display text-xs uppercase tracking-wider text-muted-foreground w-16">Capa</th>
                <th className="py-2 px-2 font-display text-xs uppercase tracking-wider text-muted-foreground">Nombre</th>
                <th className="py-2 px-2 font-display text-xs uppercase tracking-wider text-muted-foreground">Rol</th>
              </tr>
            </thead>
            <tbody>
              {layers.map((l) => (
                <tr key={l.id} className="border-b border-border/60">
                  <td className="py-2.5 px-2 font-mono text-copper">{l.id}</td>
                  <td className="py-2.5 px-2 font-medium">{l.name}</td>
                  <td className="py-2.5 px-2 text-muted-foreground">{l.role}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      <Section id="hexagonos" title="Pipelines hexagonales (He)">
        <p>Representan las etapas funcionales del procesamiento de datos y conocimiento.</p>
        <ul>
          {hexagons.map((h) => (
            <li key={h.id}>
              <strong>{h.id} — {h.name}.</strong> {h.role}
            </li>
          ))}
        </ul>
      </Section>

      <Section id="dominios" title="Dominios heptafederados (Hep)">
        <p>Representan las jurisdicciones de gobernanza. Cada nodo del ecosistema declara su dominio Hep raíz.</p>
        <ul>
          {hepDomains.map((d) => (
            <li key={d.id}>
              <strong>{d.id} — {d.name}.</strong> {d.role}
            </li>
          ))}
        </ul>
      </Section>

      <Section id="pipeline" title="Pipeline civilizatorio">
        <p>
          Todo aporte al Atlas atraviesa cinco etapas. El compilador opera siempre sobre el grafo
          completo: <code>G0 → G1</code>.
        </p>
        <ol>
          {pipelineStages.map((s) => (
            <li key={s.id}>
              <strong>{s.name}</strong> <em>({s.role})</em>. {s.body}
            </li>
          ))}
        </ol>
      </Section>

      <Section id="guardianias" title="Las siete guardianías">
        <p>
          Antes de promover, siete módulos especializados responden una pregunta crítica cada uno.
          Una respuesta negativa de la guardianía de Constitución bloquea automáticamente la
          promoción (short-circuit).
        </p>
        <ol>
          {guardians.map((g) => (
            <li key={g.q}>
              <strong>Guardián de {g.g}:</strong> {g.q}
            </li>
          ))}
        </ol>
      </Section>

      <Section id="componentes" title="Componentes centrales">
        <ul>
          {components.map((c) => (
            <li key={c.id}>
              <strong>{c.name}.</strong> {c.body}
            </li>
          ))}
        </ul>
      </Section>

      <Section id="navegar" title="Cómo seguir leyendo">
        <p>Para profundizar, recomendamos esta ruta de lectura:</p>
        <ol>
          <li><Link to="/origen">Origen y Nodo Cero RDM</Link> — de dónde nace el ecosistema.</li>
          <li><Link to="/mision-vision">Misión, visión y valores</Link> — el porqué.</li>
          <li><Link to="/servicio-atlas">El servicio Atlas</Link> — qué consume un nodo nuevo.</li>
          <li><Link to="/auditoria">Auditoría canónica v1.0</Link> — qué módulos se están congelando.</li>
          <li><Link to="/convocatoria">Convocatoria abierta</Link> — cómo sumar tu nodo.</li>
        </ol>
      </Section>
    </WikiShell>
  );
}
