import { createFileRoute } from "@tanstack/react-router";
import { WikiShell, Section } from "@/components/wiki/WikiShell";

export const Route = createFileRoute("/mision-vision")({
  head: () => ({
    meta: [
      { title: "Misión, visión y valores — Atlas TAMV" },
      { name: "description", content: "Misión, visión y valores que sostienen la arquitectura ética y técnica del Atlas TAMV." },
    ],
  }),
  component: MisionVision,
});

function MisionVision() {
  return (
    <WikiShell
      title="Misión, visión y valores"
      subtitle="El porqué del Atlas, lo que hacemos hoy y lo que aspiramos a ser."
      toc={[
        { id: "mision", label: "Misión" },
        { id: "vision", label: "Visión" },
        { id: "valores", label: "Valores" },
        { id: "promesa", label: "Promesa pública" },
      ]}
    >
      <Section id="mision" title="Misión">
        <p>
          Construir, desde el centro de Latinoamérica, una <strong>infraestructura pública
          digital</strong> que devuelva a las personas, comunidades y territorios el control
          sobre su identidad, su conocimiento y su economía, mediante software federado,
          gobernanza ética verificable y documentación abierta de grado canónico.
        </p>
      </Section>

      <Section id="vision" title="Visión">
        <p>
          Que en 2030 el Atlas TAMV sea reconocido como una de las plataformas de referencia
          mundial en <strong>identidad soberana territorial</strong> y en
          <strong> ética operativa de inteligencia artificial</strong>, con federaciones
          activas en al menos veinte territorios de habla hispana, y con una wiki técnica
          de calidad equivalente a la documentación de Python o GitLab.
        </p>
      </Section>

      <Section id="valores" title="Valores">
        <ul>
          <li><strong>Dignidad territorial.</strong> Lo local no es folclore: es estructura.</li>
          <li><strong>Verdad verificable.</strong> Si no se puede auditar, no es ética: es marketing.</li>
          <li><strong>Apertura con responsabilidad.</strong> Código abierto, contratos abiertos, decisiones explicadas.</li>
          <li><strong>Cuidado sobre velocidad.</strong> Preferimos congelar bien a publicar rápido.</li>
          <li><strong>Hospitalidad.</strong> Cualquier persona que aporte con honestidad encuentra lugar.</li>
          <li><strong>Humanismo en el código.</strong> La técnica sirve a la vida, no al revés.</li>
        </ul>
      </Section>

      <Section id="promesa" title="Promesa pública">
        <blockquote>
          Nada de lo que el Atlas TAMV publique como canónico estará indocumentado, sin
          auditoría o sin posibilidad de ser revertido por quienes confían en él.
        </blockquote>
      </Section>
    </WikiShell>
  );
}
