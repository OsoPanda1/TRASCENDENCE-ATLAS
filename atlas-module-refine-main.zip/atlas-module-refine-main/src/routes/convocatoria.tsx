import { createFileRoute } from "@tanstack/react-router";
import { WikiShell, Section } from "@/components/wiki/WikiShell";

export const Route = createFileRoute("/convocatoria")({
  head: () => ({
    meta: [
      { title: "Convocatoria abierta — Atlas TAMV" },
      { name: "description", content: "Súmate al Atlas TAMV: perfiles que buscamos, cómo aportar y cómo usar el servicio." },
    ],
  }),
  component: Convocatoria,
});

function Convocatoria() {
  return (
    <WikiShell
      title="Convocatoria abierta"
      subtitle="Si lo que leíste resuena, hay un lugar para ti en el Atlas."
      toc={[
        { id: "para-sumar", label: "Para sumar esfuerzos" },
        { id: "para-usar", label: "Para usar el servicio" },
        { id: "perfiles", label: "Perfiles que buscamos" },
        { id: "como", label: "Cómo dar el primer paso" },
        { id: "principios", label: "Principios de convivencia" },
      ]}
    >
      <Section id="para-sumar" title="Para sumar esfuerzos">
        <p>
          El Atlas TAMV no es propiedad de nadie y, al mismo tiempo, es responsabilidad de
          quienes lo construyen. Buscamos personas que entiendan que <em>congelar bien un
          módulo es más valioso que abrir tres nuevos</em>, y que el rigor documental es
          una forma concreta de respeto por quien viene después.
        </p>
      </Section>

      <Section id="para-usar" title="Para usar el servicio">
        <p>
          Si representas un comercio, una institución, una comunidad o un gobierno local,
          puedes solicitar acceso al Atlas y conectar tu territorio a la federación. El
          proceso es transparente y los términos están publicados.
        </p>
      </Section>

      <Section id="perfiles" title="Perfiles que buscamos">
        <ul>
          <li><strong>Ingeniería</strong> — backend, frontend, infra, contratos, seguridad.</li>
          <li><strong>Editorial wiki</strong> — redactores, revisores, editores de canon.</li>
          <li><strong>Ética y gobernanza</strong> — políticas, RFCs, auditoría.</li>
          <li><strong>Antropología y memoria local</strong> — curaduría de saberes territoriales.</li>
          <li><strong>Diseño</strong> — sistema visual, accesibilidad, comunicación.</li>
          <li><strong>Vinculación territorial</strong> — puentes con comunidades, comercios e instituciones.</li>
        </ul>
      </Section>

      <Section id="como" title="Cómo dar el primer paso">
        <ol>
          <li>Lee la <a href="/auditoria">Auditoría canónica v1.0</a> para entender el estado real del proyecto.</li>
          <li>Identifica un módulo en estado <em>beta</em> o un artículo wiki en estado <em>draft</em> donde puedas aportar.</li>
          <li>Abre un issue o un RFC en el repositorio público.</li>
          <li>Preséntate: quién eres, qué territorio representas, qué quieres construir o usar.</li>
        </ol>
        <blockquote>
          No pedimos CV. Pedimos un primer aporte concreto, por pequeño que sea.
        </blockquote>
      </Section>

      <Section id="principios" title="Principios de convivencia">
        <ul>
          <li>Respeto explícito por el origen territorial del proyecto.</li>
          <li>Discusión técnica argumentada, no opiniones de pasillo.</li>
          <li>Cero tolerancia a extracción de datos, plagio o uso comercial encubierto.</li>
          <li>Toda decisión relevante queda documentada.</li>
        </ul>
      </Section>
    </WikiShell>
  );
}
