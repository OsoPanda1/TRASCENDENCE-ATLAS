import { createFileRoute } from "@tanstack/react-router";
import { WikiShell, Section } from "@/components/wiki/WikiShell";

export const Route = createFileRoute("/objetivos")({
  head: () => ({
    meta: [
      { title: "Objetivos — Atlas TAMV" },
      { name: "description", content: "Objetivos del Atlas TAMV a corto, mediano y largo plazo." },
    ],
  }),
  component: Objetivos,
});

function Objetivos() {
  return (
    <WikiShell
      title="Objetivos"
      subtitle="Lo que queremos lograr, en horizontes verificables."
      toc={[
        { id: "corto", label: "Corto plazo (12 meses)" },
        { id: "mediano", label: "Mediano plazo (3 años)" },
        { id: "largo", label: "Largo plazo (10 años)" },
        { id: "kpis", label: "Indicadores"},
      ]}
    >
      <Section id="corto" title="Corto plazo · próximos 12 meses">
        <ul>
          <li>Congelar v1.0 de los módulos núcleo: <code>backend-core</code>, <code>civilizational-compiler</code>, <code>constitutional-layer</code>, <code>isabella-ethics</code>, <code>protocol-core</code>.</li>
          <li>Publicar la wiki canónica con al menos 30 artículos en estado <em>canon</em>.</li>
          <li>Consolidar las 28 edge functions duplicadas en una sola versión por capacidad.</li>
          <li>Activar el gate de CI <code>freeze-gate.yml</code> para bloquear cambios sin RFC.</li>
        </ul>
      </Section>

      <Section id="mediano" title="Mediano plazo · 3 años">
        <ul>
          <li>Federar el Atlas con al menos 5 territorios piloto en Latinoamérica.</li>
          <li>Emitir credenciales verificables (VC) reconocidas por instituciones locales.</li>
          <li>Operar una economía de visibilidad para comercios bajo reglas públicas y auditables.</li>
          <li>Publicar el primer reporte anual de transparencia algorítmica de Isabella.</li>
        </ul>
      </Section>

      <Section id="largo" title="Largo plazo · 10 años">
        <ul>
          <li>Estándar de referencia en identidad digital territorial para Latinoamérica.</li>
          <li>Universidad TAMV (UTAMV) reconocida como espacio formal de formación.</li>
          <li>Interoperabilidad real con redes globales (ORCID, DOI, ISNI, SSI/DID).</li>
          <li>Memoria cultural digital permanente para los territorios federados.</li>
        </ul>
      </Section>

      <Section id="kpis" title="Indicadores que importan">
        <p>No medimos vanidad. Medimos:</p>
        <ul>
          <li>Número de módulos congelados con documentación canónica completa.</li>
          <li>Cobertura de tests sobre contratos públicos.</li>
          <li>Tiempo medio entre detección y reversión de un incidente ético.</li>
          <li>Personas, comercios e instituciones con identidad activa en el Atlas.</li>
          <li>Territorios federados con gobernanza local funcional.</li>
        </ul>
      </Section>
    </WikiShell>
  );
}
