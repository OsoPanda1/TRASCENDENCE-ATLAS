import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";

import Index from "./pages/Index";
import MetaverseHome from "./pages/MetaverseHome";
import Documentation from "./pages/Documentation";
import Membership from "./pages/Membership";
import NotFound from "./pages/NotFound";
import Register from "./pages/Register";
import Login from "./pages/Login";
import Auth from "./pages/Auth";

import UniversityTAMV from "./components/modules/UniversityTAMV";
import BancoTAMV from "./components/modules/BancoTAMV";
import GaleriaArte from "./components/modules/GaleriaArte";
import Marketplace from "./components/modules/Marketplace";
import IsabellaChat from "./components/isabella/IsabellaChat";

/**
 * TAMV ONLINE - El Metaverso Destructor
 * Aplicación unificada: fusión de tamv-core-atlas, tamv-atlas-nextgen,
 * tamv-digital-nexus, ecosistema-nextgen-tamv y TAMV-ONLINE-NEXTGEN-1.0
 */
const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          {/* Home oficial: Metaverso */}
          <Route path="/" element={<MetaverseHome />} />
          <Route path="/legacy" element={<Index />} />

          {/* Auth */}
          <Route path="/auth" element={<Auth />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* Módulos núcleo */}
          <Route path="/universidad" element={<UniversityTAMV />} />
          <Route path="/banco" element={<BancoTAMV />} />
          <Route path="/galeria" element={<GaleriaArte />} />
          <Route path="/marketplace" element={<Marketplace />} />
          <Route path="/isabella" element={<IsabellaChat />} />

          {/* Documentación y membresías */}
          <Route path="/documentation" element={<Documentation />} />
          <Route path="/membership" element={<Membership />} />

          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
