
-- ===== 1) PROFILES =====
DROP POLICY IF EXISTS "Profiles are viewable by everyone" ON public.profiles;
DROP POLICY IF EXISTS "Public profiles are viewable" ON public.profiles;
DROP POLICY IF EXISTS "Anyone can view profiles" ON public.profiles;
CREATE POLICY "Authenticated users can view profiles" ON public.profiles
  FOR SELECT TO authenticated USING (true);
REVOKE SELECT ON public.profiles FROM anon;

DROP POLICY IF EXISTS "Users insert own profile" ON public.profiles;
CREATE POLICY "Users insert own profile" ON public.profiles
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "Users update own profile" ON public.profiles;
CREATE POLICY "Users update own profile" ON public.profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ===== 2) FEDERATION_REGISTRY =====
DROP POLICY IF EXISTS "Federation registry viewable" ON public.federation_registry;
DROP POLICY IF EXISTS "Federation registry is viewable by everyone" ON public.federation_registry;
CREATE POLICY "Federation registry viewable by authenticated" ON public.federation_registry
  FOR SELECT TO authenticated USING (true);
REVOKE SELECT ON public.federation_registry FROM anon;

-- ===== 3) USER_ROLES — bloquear escalamiento =====
DROP POLICY IF EXISTS "Users can insert their own roles" ON public.user_roles;
DROP POLICY IF EXISTS "Users can update their own roles" ON public.user_roles;
DROP POLICY IF EXISTS "Users can delete their own roles" ON public.user_roles;
CREATE POLICY "Only admins can insert roles" ON public.user_roles
  FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Only admins can update roles" ON public.user_roles
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'))
  WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Only admins can delete roles" ON public.user_roles
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- ===== 4) ANUBIS_RECOGNITION =====
CREATE POLICY "Users can insert own anubis records" ON public.anubis_recognition
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own anubis records" ON public.anubis_recognition
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete own anubis records" ON public.anubis_recognition
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ===== 5) Funciones trigger: revocar ejecución pública =====
REVOKE EXECUTE ON FUNCTION public.generate_federation_hash() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.update_updated_at() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;

-- ===== 6) Políticas owner-write para módulos =====
DO $$
DECLARE
  t TEXT;
  c TEXT;
BEGIN
  FOR t, c IN
    SELECT * FROM (VALUES
      ('social_posts','author_id'),
      ('dream_spaces','creator_id'),
      ('sensory_concerts','creator_id'),
      ('groups_channels','creator_id'),
      ('art_gallery','artist_id'),
      ('marketplace_products','seller_id'),
      ('university_courses','instructor_id')
    ) AS v(tn, cn)
  LOOP
    EXECUTE format(
      'DROP POLICY IF EXISTS "Owners insert own %1$s" ON public.%1$I;
       CREATE POLICY "Owners insert own %1$s" ON public.%1$I FOR INSERT TO authenticated
         WITH CHECK (auth.uid() = %2$I);', t, c);
    EXECUTE format(
      'DROP POLICY IF EXISTS "Owners update own %1$s" ON public.%1$I;
       CREATE POLICY "Owners update own %1$s" ON public.%1$I FOR UPDATE TO authenticated
         USING (auth.uid() = %2$I) WITH CHECK (auth.uid() = %2$I);', t, c);
    EXECUTE format(
      'DROP POLICY IF EXISTS "Owners delete own %1$s" ON public.%1$I;
       CREATE POLICY "Owners delete own %1$s" ON public.%1$I FOR DELETE TO authenticated
         USING (auth.uid() = %2$I);', t, c);
  END LOOP;
END $$;

-- ===== 7) ISABELLA_CONVERSATIONS =====
DROP POLICY IF EXISTS "Users insert own conversations" ON public.isabella_conversations;
CREATE POLICY "Users insert own conversations" ON public.isabella_conversations
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users update own conversations" ON public.isabella_conversations;
CREATE POLICY "Users update own conversations" ON public.isabella_conversations
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users delete own conversations" ON public.isabella_conversations;
CREATE POLICY "Users delete own conversations" ON public.isabella_conversations
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ===== 8) NOTIFICATIONS: usuario sólo update/delete propios =====
DROP POLICY IF EXISTS "Users update own notifications" ON public.notifications;
CREATE POLICY "Users update own notifications" ON public.notifications
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users delete own notifications" ON public.notifications;
CREATE POLICY "Users delete own notifications" ON public.notifications
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- ===== 9) REALTIME: autorización por usuario en messages =====
DO $$
BEGIN
  BEGIN
    EXECUTE 'ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY';
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
  BEGIN
    EXECUTE 'DROP POLICY IF EXISTS "Users subscribe to own channels" ON realtime.messages';
    EXECUTE 'CREATE POLICY "Users subscribe to own channels" ON realtime.messages
             FOR SELECT TO authenticated
             USING (topic LIKE (''user:'' || auth.uid()::text || '':%'') OR topic LIKE ''public:%'')';
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
  BEGIN
    EXECUTE 'DROP POLICY IF EXISTS "Users broadcast to own channels" ON realtime.messages';
    EXECUTE 'CREATE POLICY "Users broadcast to own channels" ON realtime.messages
             FOR INSERT TO authenticated
             WITH CHECK (topic LIKE (''user:'' || auth.uid()::text || '':%'') OR topic LIKE ''public:%'')';
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
END $$;
