// fusion-kernel.ts
import { promisify } from "node:util";
import { execFile } from "node:child_process";
import { resolve, dirname } from "node:path";
import {
  readFile,
  writeFile,
  mkdir,
  access,
  constants,
  appendFile,
  rename,
  rm,
  stat,
  watch,
} from "node:fs/promises";
import crypto from "node:crypto";

// TAMV ecosystem imports
import {
  emitLocalEliteBookPiEvent,
  projectBookPiLedger,
  type BookPiEvent,
} from "./elite-bookpi.mjs";
import { ELITE_HEHEP_MANIFEST } from "./elite-manifest.mjs";
import {
  stableHash,
  publishEvent,
  createEvent,
  onEvent, // asumimos un watcher simple en federation-bus
} from "./federation-bus.mjs";
import {
  buildAndAuditNodo001,
  type Nodo001AuditResult,
} from "./nodo001Dossier.mjs";

const execFileAsync = promisify(execFile);

const ROOT = process.cwd();

const PATHS = {
  script: resolve(ROOT, "scripts/unify_osopanda_repos.sh"),
  manifest: resolve(ROOT, "docs/repo-unification-manifest.json"),
  audit: resolve(ROOT, "logs/fusion-audit.log"),
  snapshots: resolve(ROOT, "snapshots"),
  lockDir: resolve(ROOT, "logs/.fusion.lock"),
  lockMeta: resolve(ROOT, "logs/.fusion.lock/meta.json"),
  msrLedger: resolve(ROOT, "logs/msr-blockchain.jsonl"),
  eoctRegistry: resolve(ROOT, "logs/eoct-protocol-registry.jsonl"),
  fusionEventLog: resolve(ROOT, "logs/federation-fusion-events.jsonl"),
} as const;

const DEFAULT_TIMEOUT_MS = 1000 * 60 * 30; // 30 min
const DISCOVERY_TIMEOUT_MS = 1000 * 60 * 5; // 5 min
const DEFAULT_MAX_BUFFER_BYTES = 1024 * 1024 * 32; // 32 MB
const LOCK_WAIT_TIMEOUT_MS = 1000 * 60 * 35; // 35 min
const LOCK_POLL_INTERVAL_MS = 500;
const LOCK_STALE_MS = 1000 * 60 * 60; // 1 hora

// Reintentos
const MAX_RETRIES = 3;
const BASE_BACKOFF_MS = 2_000;
const MAX_BACKOFF_MS = 60_000;

// ============================================================================
// TIPOS
// ============================================================================

type HexagonId =
  | "HE-Ingest"
  | "HE-Transform"
  | "HE-Publish"
  | "HE-Science"
  | "HE-Economy"
  | "HE-Identity";

type HeDomainId =
  | "HEP-1"
  | "HEP-2"
  | "HEP-3"
  | "HEP-4"
  | "HEP-5"
  | "HEP-6"
  | "HEP-7";

type HeHepContext = {
  hexagon: HexagonId;
  domain: HeDomainId;
};

type RepoManifestEntry = {
  name: string;
  url: string;
  branch?: string;
  commit?: string;
  [key: string]: unknown;
};

type RepoManifest = {
  version: string;
  owner: string;
  repositories: RepoManifestEntry[];
  discoveredAt?: string;
  [key: string]: unknown;
};

type AuditLogEntry = {
  timestamp: string;
  traceId: string;
  type: string;
  he_hep_context: HeHepContext;
  [key: string]: unknown;
};

type MSRBlockchainEntry = {
  id: string;
  traceId: string;
  eventType: string;
  manifestHash: string;
  previousHash: string;
  blockHash: string;
  timestamp: string;
  signature?: string;
  he_hep_context: HeHepContext;
};

type EOCTProtocolEntry = {
  id: string;
  traceId: string;
  protocolType: "FUSION" | "DISCOVERY";
  ethicalScore: number;
  ontologicalIntegrity: boolean;
  collapsedAt: string;
  validatedBy: string;
  he_hep_context: HeHepContext;
};

type FusionDiscoveryResult = {
  ok: true;
  mode: "DISCOVERY";
  owner: string;
  traceId: string;
  manifest: RepoManifest;
  manifestHash: string;
  snapshotPath: string;
  stdout: string;
  stderr: string;
  elapsedMs: number;
  bookpiEventId: string;
  msrBlockId: string;
  eoctValidationId: string;
  epistemicState: FusionEpistemicState;
};

type FusionExecutionResultSuccess = {
  ok: true;
  mode: "FUSION";
  owner: string;
  traceId: string;
  executedAt: string;
  elapsedMs: number;
  manifestHashBefore: string;
  manifestHashAfter: string;
  manifestChanged: boolean;
  epistemicState: FusionEpistemicState;
  repositories: number;
  manifestPath: string;
  snapshotPath: string;
  stdout: string;
  stderr: string;
  bookpiEventId: string;
  msrBlockId: string;
  eoctValidationId: string;
  nodo001Audit?: Nodo001AuditResult;
};

type FusionExecutionResultFailure = {
  ok: false;
  owner: string;
  traceId: string;
  error: string;
  executedAt: string;
  bookpiEventId: string;
};

export type FusionExecutionResult =
  | FusionExecutionResultSuccess
  | FusionExecutionResultFailure;

// Estado epistémico de FUSION / DISCOVERY
export type FusionEpistemicState = {
  certaintyScore: number; // 0..1
  complexityPenalty: number; // 0..1
  ethicalScore: number; // 0..1
  ontologicalIntegrity: boolean;
  transientFailureCount: number;
};

// Esquema conceptual de FUSION_DISCOVERY_COMPLETED (para validación)
export type FusionDiscoveryCompletedPayload = {
  owner: string;
  manifestHash: string;
  repositories: number;
  elapsedMs: number;
  eoctId: string;
  ethicalScore: number;
  ontologicalIntegrity: boolean;
  epistemicState: FusionEpistemicState;
};

// ============================================================================
// CONTEXTOS HE-HEP ESTÁNDAR
// ============================================================================

const HE_FUSION_INGEST: HeHepContext = {
  hexagon: "HE-Ingest",
  domain: "HEP-1",
};

const HE_FUSION_TRANSFORM: HeHepContext = {
  hexagon: "HE-Transform",
  domain: "HEP-2",
};

const HE_FUSION_SCIENCE: HeHepContext = {
  hexagon: "HE-Science",
  domain: "HEP-1",
};

const HE_FUSION_ECONOMY: HeHepContext = {
  hexagon: "HE-Economy",
  domain: "HEP-1",
};

// ============================================================================
// ERRORES
// ============================================================================

class ScriptExecutionError extends Error {
  stdout?: string;
  stderr?: string;
  code?: number | string;
  signal?: NodeJS.Signals | null;

  constructor(
    message: string,
    details?: {
      stdout?: string;
      stderr?: string;
      code?: number | string;
      signal?: NodeJS.Signals | null;
    },
  ) {
    super(message);
    this.name = "ScriptExecutionError";
    this.stdout = details?.stdout;
    this.stderr = details?.stderr;
    this.code = details?.code;
    this.signal = details?.signal;
  }
}

// ============================================================================
// HELPERS
// ============================================================================

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function nowISO(): string {
  return new Date().toISOString();
}

function generateTraceId(context: string): string {
  const now = Date.now().toString(36);
  const rand = crypto.randomBytes(6).toString("hex");
  return `${context}-${now}-${rand}`;
}

function generateId(prefix: string): string {
  return `${prefix}_${crypto.randomBytes(8).toString("hex")}`;
}

function normalizeOwner(owner: string): string {
  const value = String(owner ?? "").trim();
  if (!/^[a-zA-Z0-9-_]+$/.test(value)) {
    throw new Error(
      `TAMV-CRITICAL: Invalid repository owner format: ${owner}`,
    );
  }
  return value;
}

function stableStringify(value: unknown): string {
  if (value === undefined) return "__undefined__";
  if (value === null) return "null";
  if (typeof value === "boolean") return value ? "true" : "false";
  if (typeof value === "number") return JSON.stringify(value);
  if (typeof value === "string") return JSON.stringify(value);

  if (Array.isArray(value)) {
    return `[${value.map((item) => stableStringify(item)).join(",")}]`;
  }

  if (typeof value === "object") {
    const obj = value as Record<string, unknown>;
    const keys = Object.keys(obj).sort();
    const entries = keys.map((key) => {
      const v = obj[key];
      return `${JSON.stringify(key)}:${stableStringify(v)}`;
    });
    return `{${entries.join(",")}}`;
  }

  return JSON.stringify(value);
}

function sha256(data: unknown): string {
  return crypto.createHash("sha256").update(stableStringify(data)).digest("hex");
}

function safeJsonParse<T>(raw: string, label: string): T {
  try {
    return JSON.parse(raw) as T;
  } catch {
    throw new Error(`TAMV-CRITICAL: ${label} is not valid JSON`);
  }
}

function validateManifest(manifest: unknown): asserts manifest is RepoManifest {
  if (!manifest || typeof manifest !== "object") {
    throw new Error("TAMV-CRITICAL: Manifest is missing or not an object");
  }

  const m = manifest as Partial<RepoManifest>;

  if (typeof m.version !== "string" || !m.version.trim()) {
    throw new Error("TAMV-CRITICAL: Manifest.version is invalid");
  }

  if (typeof m.owner !== "string" || !m.owner.trim()) {
    throw new Error("TAMV-CRITICAL: Manifest.owner is invalid");
  }

  if (!Array.isArray(m.repositories)) {
    throw new Error("TAMV-CRITICAL: Manifest.repositories is not an array");
  }

  if (m.repositories.length === 0) {
    throw new Error("TAMV-CRITICAL: No repositories discovered in manifest");
  }

  for (const repo of m.repositories) {
    if (!repo || typeof repo !== "object") {
      throw new Error("TAMV-CRITICAL: Invalid repository entry");
    }

    const entry = repo as RepoManifestEntry;

    if (typeof entry.name !== "string" || !entry.name.trim()) {
      throw new Error("TAMV-CRITICAL: Manifest repository entry missing name");
    }

    if (typeof entry.url !== "string" || !entry.url.trim()) {
      throw new Error("TAMV-CRITICAL: Manifest repository entry missing url");
    }

    if (entry.commit !== undefined) {
      const commit = String(entry.commit);
      if (!/^[0-9a-fA-F]{40}$|^[0-9a-fA-F]{64}$/.test(commit)) {
        throw new Error(
          `TAMV-CRITICAL: Invalid commit hash for ${entry.name}: ${commit}`,
        );
      }
    }
  }
}

async function ensureEnvironment(): Promise<void> {
  await mkdir(dirname(PATHS.manifest), { recursive: true });
  await mkdir(dirname(PATHS.audit), { recursive: true });
  await mkdir(PATHS.snapshots, { recursive: true });
  await mkdir(dirname(PATHS.msrLedger), { recursive: true });
  await mkdir(dirname(PATHS.eoctRegistry), { recursive: true });
  await mkdir(dirname(PATHS.fusionEventLog), { recursive: true });

  try {
    await access(PATHS.script, constants.X_OK);
  } catch {
    throw new Error(
      `TAMV-CRITICAL: Fusion script is missing or not executable: ${PATHS.script}`,
    );
  }
}

async function appendAuditLog(entry: AuditLogEntry): Promise<void> {
  const line = JSON.stringify(entry) + "\n";
  await appendFile(PATHS.audit, line, { encoding: "utf-8" });
}

async function atomicWriteSnapshot(filePath: string, value: unknown): Promise<void> {
  const tmpPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  const json = JSON.stringify(value);
  const buf = Buffer.from(json, "utf-8");
  await writeFile(tmpPath, buf);
  await rename(tmpPath, filePath);
}

async function acquireLock(
  traceId: string,
  owner: string,
): Promise<() => Promise<void>> {
  await mkdir(dirname(PATHS.lockDir), { recursive: true });

  const started = Date.now();

  while (true) {
    try {
      await mkdir(PATHS.lockDir);

      await writeFile(
        PATHS.lockMeta,
        JSON.stringify(
          {
            traceId,
            owner,
            pid: process.pid,
            startedAt: nowISO(),
          },
          null,
          2,
        ) + "\n",
        { encoding: "utf-8" },
      );

      return async () => {
        await rm(PATHS.lockDir, { recursive: true, force: true });
      };
    } catch {
      let stale = false;

      try {
        const dirStat = await stat(PATHS.lockDir);
        const age = Date.now() - dirStat.mtimeMs;
        stale = age > LOCK_STALE_MS;
      } catch {
        stale = false;
      }

      if (stale) {
        await rm(PATHS.lockDir, { recursive: true, force: true });
        continue;
      }

      const elapsed = Date.now() - started;
      if (elapsed > LOCK_WAIT_TIMEOUT_MS) {
        throw new Error(
          `TAMV-CRITICAL: Fusion lock timeout exceeded for owner=${owner} after ${Math.round(elapsed / 1000)}s`,
        );
      }

      await delay(LOCK_POLL_INTERVAL_MS);
    }
  }
}

// ============================================================================
// EXEC + RETRY CON BACKOFF EXPONENCIAL
// ============================================================================

function isTransientError(error: any): boolean {
  if (!error) return false;
  if (error instanceof ScriptExecutionError) {
    // Podrías refinar esto: códigos de salida, señales, etc.
    if (error.code === "ETIMEDOUT" || error.signal === "SIGTERM") return true;
  }
  return false;
}

async function executeScriptWithRetry(
  args: string[],
  traceId: string,
  timeoutMs: number,
): Promise<{ stdout: string; stderr: string; transientFailures: number }> {
  let attempt = 0;
  let transientFailures = 0;

  while (true) {
    try {
      const result = await execFileAsync(PATHS.script, args, {
        cwd: ROOT,
        timeout: timeoutMs,
        maxBuffer: DEFAULT_MAX_BUFFER_BYTES,
        windowsHide: true,
        shell: false,
        killSignal: "SIGTERM",
        env: {
          ...process.env,
          LANG: "C",
          LC_ALL: "C",
          TAMV_FUSION_MODE: "ACTIVE",
          TAMV_TRACE_ID: traceId,
        },
      });
      return { stdout: result.stdout, stderr: result.stderr, transientFailures };
    } catch (err: any) {
      const wrapped = new ScriptExecutionError(
        `TAMV-CRITICAL: Fusion script failed: ${err?.message ?? "unknown error"}`,
        {
          stdout: err?.stdout,
          stderr: err?.stderr,
          code: err?.code,
          signal: err?.signal,
        },
      );

      if (!isTransientError(wrapped) || attempt >= MAX_RETRIES) {
        throw wrapped;
      }

      transientFailures += 1;
      attempt += 1;
      const base = BASE_BACKOFF_MS * 2 ** (attempt - 1);
      const jitter = Math.random() * BASE_BACKOFF_MS;
      const delayMs = Math.min(base + jitter, MAX_BACKOFF_MS);

      await appendAuditLog({
        timestamp: nowISO(),
        traceId,
        type: "FUSION_RETRY",
        attempt,
        delayMs,
        error: wrapped.message,
        he_hep_context: HE_FUSION_TRANSFORM,
      });

      await delay(delayMs);
    }
  }
}

// ============================================================================
// INTEGRACIÓN BOOKPI (+ auditoría de claims Nodo 001)
// ============================================================================

async function emitBookPiEvent(
  traceId: string,
  eventType: string,
  payload: Record<string, unknown>,
  context: HeHepContext,
): Promise<string> {
  const event: BookPiEvent = {
    id: generateId("bkpi"),
    traceId,
    eventType,
    payload,
    he_hep_context: context,
    timestamp: nowISO(),
    hash: sha256({ traceId, eventType, payload, context }),
  };

  await emitLocalEliteBookPiEvent(event);

  return event.id;
}

async function emitNodo001AuditToBookPi(
  traceId: string,
  audit: Nodo001AuditResult,
): Promise<string> {
  const event: BookPiEvent = {
    id: generateId("bkpi"),
    traceId,
    eventType: "NODO001_ECOSYSTEM_AUDIT",
    payload: {
      dossierId: audit.dossierId,
      version: audit.version,
      confidenceGlobal: audit.confidenceGlobal,
      blockingClaims: audit.blockingClaims,
      warnings: audit.warnings,
    },
    he_hep_context: HE_FUSION_SCIENCE,
    timestamp: nowISO(),
    hash: sha256(audit),
  };

  await emitLocalEliteBookPiEvent(event);
  return event.id;
}

// ============================================================================
// INTEGRACIÓN MSR BLOCKCHAIN
// ============================================================================

let msrLastHash =
  "0000000000000000000000000000000000000000000000000000000000000000";

async function appendMSRBlock(
  traceId: string,
  eventType: string,
  manifestHash: string,
  context: HeHepContext,
): Promise<string> {
  const block: MSRBlockchainEntry = {
    id: generateId("msr"),
    traceId,
    eventType,
    manifestHash,
    previousHash: msrLastHash,
    blockHash: "",
    timestamp: nowISO(),
    he_hep_context: context,
  };

  block.blockHash = sha256(block);
  msrLastHash = block.blockHash;

  const line = JSON.stringify(block) + "\n";
  await appendFile(PATHS.msrLedger, line, { encoding: "utf-8" });

  return block.id;
}

// ============================================================================
// INTEGRACIÓN EOCT
// ============================================================================

async function validateEOCT(
  traceId: string,
  protocolType: "FUSION" | "DISCOVERY",
  manifest: RepoManifest,
  context: HeHepContext,
): Promise<EOCTProtocolEntry> {
  const ethicalScore = calculateEthicalScore(manifest);
  const ontologicalIntegrity = validateOntologicalIntegrity(manifest);

  const entry: EOCTProtocolEntry = {
    id: generateId("eoct"),
    traceId,
    protocolType,
    ethicalScore,
    ontologicalIntegrity,
    collapsedAt: nowISO(),
    validatedBy: "TAMV-EOCT-V1",
    he_hep_context: context,
  };

  const line = JSON.stringify(entry) + "\n";
  await appendFile(PATHS.eoctRegistry, line, { encoding: "utf-8" });

  if (!ontologicalIntegrity) {
    throw new Error(
      `TAMV-EOCT-CRITICAL: Ontological integrity violation detected in ${protocolType}`,
    );
  }

  if (ethicalScore < 50) {
    throw new Error(
      `TAMV-EOCT-CRITICAL: Ethical score too low (${ethicalScore}) for ${protocolType}`,
    );
  }

  return entry;
}

function calculateEthicalScore(manifest: RepoManifest): number {
  let score = 100;

  if (manifest.repositories.length > 50) {
    score -= 10;
  }

  const withCommit = manifest.repositories.filter((r) => r.commit).length;
  const commitRatio = withCommit / manifest.repositories.length;

  score += commitRatio * 20;

  return Math.max(0, Math.min(100, score));
}

function validateOntologicalIntegrity(manifest: RepoManifest): boolean {
  const names = new Set<string>();

  for (const repo of manifest.repositories) {
    if (!repo.url.startsWith("http://") && !repo.url.startsWith("https://")) {
      return false;
    }

    if (names.has(repo.name)) {
      return false;
    }

    names.add(repo.name);
  }

  return true;
}

function buildFusionEpistemicState(
  manifest: RepoManifest,
  eoct: EOCTProtocolEntry,
  transientFailures: number,
): FusionEpistemicState {
  const repoCount = manifest.repositories.length;
  const complexityPenalty = Math.min(1, repoCount / 100);
  const ethicalScoreNorm = eoct.ethicalScore / 100;
  const certaintyBase = Math.max(
    0,
    ethicalScoreNorm - complexityPenalty * 0.3 - transientFailures * 0.05,
  );

  return {
    certaintyScore: Number(certaintyBase.toFixed(4)),
    complexityPenalty: Number(complexityPenalty.toFixed(4)),
    ethicalScore: Number(ethicalScoreNorm.toFixed(4)),
    ontologicalIntegrity: eoct.ontologicalIntegrity,
    transientFailureCount: transientFailures,
  };
}

// ============================================================================
// FEDERATION BUS – esquema y watch mode
// ============================================================================

function validateFusionDiscoveryCompletedPayload(
  payload: any,
): payload is FusionDiscoveryCompletedPayload {
  if (!payload || typeof payload !== "object") return false;
  if (typeof payload.owner !== "string") return false;
  if (typeof payload.manifestHash !== "string") return false;
  if (typeof payload.repositories !== "number") return false;
  if (typeof payload.elapsedMs !== "number") return false;
  if (typeof payload.eoctId !== "string") return false;
  if (typeof payload.ethicalScore !== "number") return false;
  if (typeof payload.ontologicalIntegrity !== "boolean") return false;
  if (!payload.epistemicState || typeof payload.epistemicState !== "object")
    return false;
  return true;
}

async function publishFusionEvent(
  traceId: string,
  kind: "DISCOVERY_COMPLETED" | "FUSION_COMPLETED" | "FUSION_FAILED",
  payload: Record<string, unknown>,
) {
  const event = createEvent({
    id: generateId("fusion_evt"),
    traceId,
    kind,
    payload,
    hehep: ELITE_HEHEP_MANIFEST,
    createdAt: nowISO(),
  });

  await publishEvent(event);

  // Persistimos también en un log dedicado para observabilidad
  await appendFile(PATHS.fusionEventLog, JSON.stringify(event) + "\n", {
    encoding: "utf-8",
  });
}

export function watchFusionEvents(onFusionEvent: (event: any) => void) {
  // Si federation-bus expone onEvent, lo usamos directamente
  onEvent((event: any) => {
    if (
      event.kind === "DISCOVERY_COMPLETED" ||
      event.kind === "FUSION_COMPLETED" ||
      event.kind === "FUSION_FAILED"
    ) {
      onFusionEvent(event);
    }
  });
}

// ============================================================================
// NÚCLEO DE DISCOVERY
// ============================================================================

async function runDiscoveryCore(
  owner: string,
  traceId: string,
): Promise<FusionDiscoveryResult> {
  const args = [
    "--owner",
    owner,
    "--import-mode",
    "none",
    "--manifest",
    PATHS.manifest,
  ];

  const startedAt = performance.now();

  const { stdout, stderr, transientFailures } = await executeScriptWithRetry(
    args,
    traceId,
    DISCOVERY_TIMEOUT_MS,
  );

  let manifestRaw: string;
  try {
    manifestRaw = await readFile(PATHS.manifest, "utf-8");
  } catch {
    throw new Error("TAMV-CRITICAL: Manifest file not created by fusion script");
  }

  const manifest = safeJsonParse<RepoManifest>(manifestRaw, "Manifest file");
  validateManifest(manifest);

  const manifestHash = sha256(manifest);

  const snapshotPath = resolve(
    PATHS.snapshots,
    `manifest-${traceId}-${manifestHash.slice(0, 16)}.bin`,
  );

  await atomicWriteSnapshot(snapshotPath, {
    traceId,
    owner,
    mode: "DISCOVERY",
    manifestHash,
    manifest,
    capturedAt: nowISO(),
  });

  const elapsedMs = Math.round(performance.now() - startedAt);

  const eoct = await validateEOCT(
    traceId,
    "DISCOVERY",
    manifest,
    HE_FUSION_SCIENCE,
  );

  const epistemicState = buildFusionEpistemicState(
    manifest,
    eoct,
    transientFailures,
  );

  const bookpiEventId = await emitBookPiEvent(
    traceId,
    "FUSION_DISCOVERY_SUCCESS",
    {
      owner,
      manifestHash,
      repositories: manifest.repositories.length,
      elapsedMs,
      epistemicState,
    },
    HE_FUSION_INGEST,
  );

  const msrBlockId = await appendMSRBlock(
    traceId,
    "DISCOVERY",
    manifestHash,
    HE_FUSION_SCIENCE,
  );

  const busPayload: FusionDiscoveryCompletedPayload = {
    owner,
    manifestHash,
    repositories: manifest.repositories.length,
    elapsedMs,
    eoctId: eoct.id,
    ethicalScore: eoct.ethicalScore,
    ontologicalIntegrity: eoct.ontologicalIntegrity,
    epistemicState,
  };

  if (!validateFusionDiscoveryCompletedPayload(busPayload)) {
    throw new Error("TAMV-CRITICAL: Invalid payload for FUSION_DISCOVERY_COMPLETED");
  }

  await appendAuditLog({
    timestamp: nowISO(),
    traceId,
    type: "DISCOVERY_SUCCESS",
    owner,
    elapsedMs,
    manifestHash,
    repositories: manifest.repositories.length,
    snapshotPath,
    bookpiEventId,
    msrBlockId,
    eoctValidationId: eoct.id,
    epistemicState,
    he_hep_context: HE_FUSION_INGEST,
  });

  await publishFusionEvent(traceId, "DISCOVERY_COMPLETED", busPayload);

  return {
    ok: true,
    mode: "DISCOVERY",
    owner,
    traceId,
    manifest,
    manifestHash,
    snapshotPath,
    stdout,
    stderr,
    elapsedMs,
    bookpiEventId,
    msrBlockId,
    eoctValidationId: eoct.id,
    epistemicState,
  };
}

// ============================================================================
// NÚCLEO DE FUSION
// ============================================================================

async function runFusionCore(
  owner: string,
  traceId: string,
): Promise<FusionExecutionResult> {
  const startedAt = performance.now();

  const discovery = await runDiscoveryCore(owner, `${traceId}.pre`);
  const manifestHashBefore = discovery.manifestHash;

  const args = [
    "--owner",
    owner,
    "--import-mode",
    "squash",
    "--manifest",
    PATHS.manifest,
  ];

  const { stdout, stderr, transientFailures } = await executeScriptWithRetry(
    args,
    traceId,
    DEFAULT_TIMEOUT_MS,
  );

  let finalManifestRaw: string;
  try {
    finalManifestRaw = await readFile(PATHS.manifest, "utf-8");
  } catch {
    throw new Error("TAMV-CRITICAL: Post-fusion manifest file not found");
  }

  const finalManifest = safeJsonParse<RepoManifest>(
    finalManifestRaw,
    "Post-fusion manifest",
  );
  validateManifest(finalManifest);

  const manifestHashAfter = sha256(finalManifest);
  const manifestChanged = manifestHashBefore !== manifestHashAfter;

  const snapshotPath = resolve(
    PATHS.snapshots,
    `post-fusion-${traceId}-${manifestHashAfter.slice(0, 16)}.bin`,
  );

  await atomicWriteSnapshot(snapshotPath, {
    traceId,
    owner,
    mode: "FUSION",
    manifestHashBefore,
    manifestHashAfter,
    manifestChanged,
    manifest: finalManifest,
    capturedAt: nowISO(),
  });

  const elapsedMs = Math.round(performance.now() - startedAt);

  const eoct = await validateEOCT(
    traceId,
    "FUSION",
    finalManifest,
    HE_FUSION_SCIENCE,
  );

  const epistemicState = buildFusionEpistemicState(
    finalManifest,
    eoct,
    transientFailures,
  );

  // Auditoría de claims Nodo 001, enlazada a esta corrida
  const { dossier, audit } = buildAndAuditNodo001();

  const bookpiEventId = await emitBookPiEvent(
    traceId,
    "FUSION_EXECUTION_SUCCESS",
    {
      owner,
      manifestHashBefore,
      manifestHashAfter,
      manifestChanged,
      repositories: finalManifest.repositories.length,
      elapsedMs,
      epistemicState,
      nodo001Audit: {
        confidenceGlobal: audit.confidenceGlobal,
        blockingClaims: audit.blockingClaims,
      },
    },
    HE_FUSION_TRANSFORM,
  );

  await emitNodo001AuditToBookPi(traceId, audit);

  const msrBlockId = await appendMSRBlock(
    traceId,
    "FUSION",
    manifestHashAfter,
    HE_FUSION_ECONOMY,
  );

  await appendAuditLog({
    timestamp: nowISO(),
    traceId,
    type: "FUSION_SUCCESS",
    owner,
    elapsedMs,
    manifestHashBefore,
    manifestHashAfter,
    manifestChanged,
    repositories: finalManifest.repositories.length,
    snapshotPath,
    bookpiEventId,
    msrBlockId,
    eoctValidationId: eoct.id,
    epistemicState,
    nodo001Audit: audit,
    he_hep_context: HE_FUSION_TRANSFORM,
  });

  await publishFusionEvent(traceId, "FUSION_COMPLETED", {
    owner,
    manifestHashBefore,
    manifestHashAfter,
    manifestChanged,
    repositories: finalManifest.repositories.length,
    elapsedMs,
    eoctId: eoct.id,
    ethicalScore: eoct.ethicalScore,
    ontologicalIntegrity: eoct.ontologicalIntegrity,
    epistemicState,
    nodo001Confidence: audit.confidenceGlobal,
    nodo001BlockingClaims: audit.blockingClaims.length,
  });

  return {
    ok: true,
    mode: "FUSION",
    owner,
    traceId,
    executedAt: nowISO(),
    elapsedMs,
    manifestHashBefore,
    manifestHashAfter,
    manifestChanged,
    epistemicState,
    repositories: finalManifest.repositories.length,
    manifestPath: PATHS.manifest,
    snapshotPath,
    stdout,
    stderr,
    bookpiEventId,
    msrBlockId,
    eoctValidationId: eoct.id,
    nodo001Audit: audit,
  };
}

// ============================================================================
// API PÚBLICA
// ============================================================================

export async function discoverFusionPlan(
  owner = "OsoPanda1",
): Promise<FusionDiscoveryResult> {
  await ensureEnvironment();

  const normalizedOwner = normalizeOwner(owner);
  const traceId = generateTraceId("fusion.discovery");
  const release = await acquireLock(traceId, normalizedOwner);

  try {
    return await runDiscoveryCore(normalizedOwner, traceId);
  } catch (error: any) {
    const bookpiEventId = await emitBookPiEvent(
      traceId,
      "FUSION_DISCOVERY_FAILURE",
      {
        owner: normalizedOwner,
        error: error?.message ?? "unknown",
      },
      HE_FUSION_INGEST,
    );

    await appendAuditLog({
      timestamp: nowISO(),
      traceId,
      type: "DISCOVERY_FAILURE",
      owner: normalizedOwner,
      error: error?.message ?? "unknown",
      stdout: error?.stdout,
      stderr: error?.stderr,
      code: error?.code,
      signal: error?.signal,
      bookpiEventId,
      he_hep_context: HE_FUSION_INGEST,
    });

    await publishFusionEvent(traceId, "FUSION_FAILED", {
      stage: "DISCOVERY",
      owner: normalizedOwner,
      error: error?.message ?? "unknown",
    });

    throw error;
  } finally {
    await release();
  }
}

export async function executeFusion(
  owner = "OsoPanda1",
): Promise<FusionExecutionResult> {
  await ensureEnvironment();

  const normalizedOwner = normalizeOwner(owner);
  const traceId = generateTraceId("fusion.execute");
  const release = await acquireLock(traceId, normalizedOwner);

  try {
    return await runFusionCore(normalizedOwner, traceId);
  } catch (error: any) {
    const bookpiEventId = await emitBookPiEvent(
      traceId,
      "FUSION_EXECUTION_FAILURE",
      {
        owner: normalizedOwner,
        error: error?.message ?? "unknown",
      },
      HE_FUSION_TRANSFORM,
    );

    await appendAuditLog({
      timestamp: nowISO(),
      traceId,
      type: "FUSION_FAILURE",
      owner: normalizedOwner,
      error: error?.message ?? "unknown",
      stdout: error?.stdout,
      stderr: error?.stderr,
      code: error?.code,
      signal: error?.signal,
      bookpiEventId,
      he_hep_context: HE_FUSION_TRANSFORM,
    });

    await publishFusionEvent(traceId, "FUSION_FAILED", {
      stage: "FUSION",
      owner: normalizedOwner,
      error: error?.message ?? "Fusion execution failed",
    });

    return {
      ok: false,
      owner: normalizedOwner,
      traceId,
      error: error?.message ?? "Fusion execution failed",
      executedAt: nowISO(),
      bookpiEventId,
    };
  } finally {
    await release();
  }
}
