// nodo001Dossier.ts
// Dossier y auditoría epistémica del Nodo 001 (TAMV Online Network / Isabella / Realmontense)

export type VerificationLevel =
  | "self_reported"
  | "externally_visible"
  | "externally_verified"
  | "not_verified";

export type ClaimRisk = "low" | "medium" | "high" | "critical";

export interface Claim {
  claim: string;
  source: string;
  verification: VerificationLevel;
  notes?: string;
  risk?: ClaimRisk;
  evidenceUrls?: string[];
  lastCheckedAt?: string;
}

export interface PendingCheck {
  priority: "high" | "medium" | "low";
  task: string;
  owner?: string;
  dueDate?: string;
  status?: "open" | "in_progress" | "blocked" | "done";
}

export interface Nodo001ResearchDossier {
  id: string;
  version: string;
  title: string;
  scope: {
    project: string;
    founder: string;
    location: string;
    territoryAnchor?: string;
  };
  executiveSummary: string;
  claims: Claim[];
  pendingChecks: PendingCheck[];
  recommendations: string[];
  metadata?: {
    createdAt?: string;
    updatedAt?: string;
    jurisdiction?: string;
    language?: string;
    canonicalStatus?: "draft" | "review" | "canonical" | "archived";
  };
}

// Resultado de la auditoría, pensado para integrarse con IsabellaEngine / AKAE

export interface ClaimAuditSummary {
  claim: string;
  verification: VerificationLevel;
  risk: ClaimRisk;
  confidence: number; // 0..1
  blocking: boolean;
}

export interface RiskHeatmap {
  low: number;
  medium: number;
  high: number;
  critical: number;
}

export interface Nodo001AuditResult {
  dossierId: string;
  version: string;
  timestamp: string;
  totalClaims: number;
  confidenceGlobal: number; // 0..1
  claimsByVerification: {
    self_reported: number;
    externally_visible: number;
    externally_verified: number;
    not_verified: number;
  };
  riskHeatmap: RiskHeatmap;
  blockingClaims: ClaimAuditSummary[];
  warnings: string[];
  humanReviewRequired: boolean;
  blockOperation: boolean;
}

// =========================================================
// Dossier base (declarativo)
// =========================================================

export function buildNodo001ResearchDossier(): Nodo001ResearchDossier {
  return {
    id: "tamv-rd-nodo-001-genesis",
    version: "2026-04-18",
    title: "Informe de investigación: TAMV Online Network y Nodo 001 (Génesis)",
    scope: {
      project: "TAMV Online Network",
      founder: "Edwin Oswaldo Castillo Trejo (Anubis Villaseñor)",
      location: "Mineral del Monte, Hidalgo, México",
      territoryAnchor: "Nodo 001",
    },
    executiveSummary:
      "El dossier mezcla afirmaciones auto-reportadas con algunas señales externamente visibles; varias afirmaciones críticas siguen sin verificación técnica reproducible y requieren evidencia pública auditable.",
    claims: [
      {
        claim: "Ecosistema civilizatorio TAMV Online",
        source: "Sitio oficial TAMV",
        verification: "self_reported",
        risk: "low",
        notes: "Descripción institucional disponible públicamente.",
        evidenceUrls: [],
        lastCheckedAt: "2026-06-14",
      },
      {
        claim: "Fundador único: Edwin O. Castillo Trejo",
        source: "Sitio oficial TAMV / perfiles públicos",
        verification: "self_reported",
        risk: "medium",
        notes: "Consistencia entre perfiles institucionales, pero falta corroboración independiente fuerte.",
        evidenceUrls: [],
        lastCheckedAt: "2026-06-14",
      },
      {
        claim: "Afiliación en Frontiers/Loop",
        source: "Perfil público Frontiers Loop",
        verification: "externally_visible",
        risk: "low",
        notes:
          "Existe señal pública de afiliación, pero no equivale a validación independiente del ecosistema completo.",
        evidenceUrls: [],
        lastCheckedAt: "2026-06-14",
      },
      {
        claim: "Red de 195 nodos + hashes cuánticos",
        source: "Materiales internos TAMV (blog/docs)",
        verification: "not_verified",
        risk: "critical",
        notes:
          "No se encontró verificación técnica externa reproducible ni evidencia operativa pública suficiente.",
        evidenceUrls: [],
        lastCheckedAt: "2026-06-14",
      },
      {
        claim: "IA Isabella de gobernanza ética",
        source: "Materiales TAMV",
        verification: "not_verified",
        risk: "high",
        notes: "Se requiere demo auditable, trazabilidad de decisiones y/o repositorio público.",
        evidenceUrls: [],
        lastCheckedAt: "2026-06-14",
      },
    ],
    pendingChecks: [
      {
        priority: "high",
        task: "Validar ORCID 0009-0008-5050-1539 y DOI 10.5281/zenodo.19411506.",
        owner: "research",
        status: "open",
      },
      {
        priority: "high",
        task: "Auditar instancia Supabase (tablas nodes_ring, financial_ledger, etc.).",
        owner: "engineering",
        status: "open",
      },
      {
        priority: "medium",
        task: "Identificar repos de Edge Functions en GitHub OsoPanda1.",
        owner: "engineering",
        status: "open",
      },
      {
        priority: "medium",
        task: "Revisar Groups.io y LinkedIn para evidencia de despliegues.",
        owner: "research",
        status: "open",
      },
      {
        priority: "low",
        task: "Buscar menciones externas en academia/prensa de TAMV y RDM Digital.",
        owner: "research",
        status: "open",
      },
    ],
    recommendations: [
      "Publicar repositorios auditables bajo licencia abierta.",
      "Distinguir claramente visión/roadmap versus funcionalidades verificadas.",
      "Aportar PoCs públicas para validar métricas 20/30/50 e identidad soberana.",
      "Fortalecer evaluación legal y de ciberseguridad antes de operación comercial.",
    ],
    metadata: {
      createdAt: "2026-06-14",
      updatedAt: "2026-06-14",
      jurisdiction: "MX-HID",
      language: "es",
      canonicalStatus: "review",
    },
  };
}

// =========================================================
// Lógica de auditoría epistémica / operativa del dossier
// =========================================================

function verificationWeight(level: VerificationLevel): number {
  switch (level) {
    case "externally_verified":
      return 1.0;
    case "externally_visible":
      return 0.8;
    case "self_reported":
      return 0.6;
    case "not_verified":
      return 0.3;
    default:
      return 0.5;
  }
}

function riskPenalty(risk: ClaimRisk): number {
  switch (risk) {
    case "low":
      return 0;
    case "medium":
      return 0.1;
    case "high":
      return 0.25;
    case "critical":
      return 0.4;
    default:
      return 0.2;
  }
}

function isBlockingClaim(claim: Claim, confidence: number): boolean {
  const risk = claim.risk ?? "medium";
  // Regla simple: critical siempre bloquea; high bloquea si confianza < 0.6
  if (risk === "critical") return true;
  if (risk === "high" && confidence < 0.6) return true;
  return false;
}

export function auditNodo001ResearchDossier(
  dossier: Nodo001ResearchDossier,
): Nodo001AuditResult {
  const timestamp = new Date().toISOString();

  const countsByVerification = {
    self_reported: 0,
    externally_visible: 0,
    externally_verified: 0,
    not_verified: 0,
  };

  const riskHeatmap: RiskHeatmap = {
    low: 0,
    medium: 0,
    high: 0,
    critical: 0,
  };

  let totalConfidence = 0;

  const claimSummaries: ClaimAuditSummary[] = [];

  for (const c of dossier.claims) {
    const v = c.verification;
    const risk = c.risk ?? "medium";
    const weight = verificationWeight(v);
    const penalty = riskPenalty(risk);
    const confidence = Math.max(0, Math.min(1, weight - penalty));

    countsByVerification[v] += 1;
    riskHeatmap[risk] += 1;
    totalConfidence += confidence;

    claimSummaries.push({
      claim: c.claim,
      verification: v,
      risk,
      confidence,
      blocking: isBlockingClaim(c, confidence),
    });
  }

  const totalClaims = dossier.claims.length || 0;
  const confidenceGlobal =
    totalClaims > 0 ? totalConfidence / totalClaims : 0;

  const blockingClaims = claimSummaries.filter((c) => c.blocking);

  const warnings: string[] = [];

  if (confidenceGlobal < 0.4) {
    warnings.push(
      "Confianza global muy baja: operación comercial sin auditoría externa sería temeraria.",
    );
  } else if (confidenceGlobal < 0.6) {
    warnings.push(
      "Confianza global moderada: se requiere revisión humana antes de cualquier operación crítica.",
    );
  }

  if (blockingClaims.length > 0) {
    warnings.push(
      `Existen ${blockingClaims.length} claims de riesgo alto/critical que requieren evidencia antes de avanzar.`,
    );
  }

  const humanReviewRequired =
    confidenceGlobal >= 0.4 && confidenceGlobal < 0.6;
  const blockOperation =
    confidenceGlobal < 0.4 || blockingClaims.length > 0;

  return {
    dossierId: dossier.id,
    version: dossier.version,
    timestamp,
    totalClaims,
    confidenceGlobal,
    claimsByVerification: countsByVerification,
    riskHeatmap,
    blockingClaims,
    warnings,
    humanReviewRequired,
    blockOperation,
  };
}

// =========================================================
// Helper rápido para usar en otros módulos (ej. IsabellaEngine)
// =========================================================

export function buildAndAuditNodo001() {
  const dossier = buildNodo001ResearchDossier();
  const audit = auditNodo001ResearchDossier(dossier);
  return { dossier, audit };
}
