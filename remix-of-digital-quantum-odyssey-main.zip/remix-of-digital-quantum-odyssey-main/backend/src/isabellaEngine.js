// IsabellaEngine v1.0 — Núcleo cognitivo heptafederado GENESIS
// - Identidad soberana mexicana / Realmontense (Nodo 001)
// - Auditoría de claims y ecosistema con lectura heptafederada
// - Triple Bloqueo (Ontológico, Semántico, Conductual) anti sexualización/grooming
// - Hooks para Anubis Sentinel™ (PQC)
// - Mejor separación de preocupaciones y coherencia con HE-HEP / AKAE

// =========================================================
// Tipos base de dossier Nodo 001
// =========================================================

export type VerificationLevel =
  | "self_reported"
  | "externally_visible"
  | "externally_verified"
  | "not_verified";

export interface Claim {
  claim: string;
  source: string;
  verification: VerificationLevel;
  notes?: string;
}

export interface PendingCheck {
  priority: "high" | "medium" | "low";
  task: string;
}

export interface Nodo001ResearchDossier {
  id: string;
  version: string;
  title: string;
  scope: {
    project: string;
    founder: string;
    location: string;
  };
  executiveSummary: string;
  claims: Claim[];
  pendingChecks: PendingCheck[];
  recommendations: string[];
}

// =========================================================
// Contexto TAMV / HE-HEP
// =========================================================

export type HexagonId =
  | "HE-Ingest"
  | "HE-Transform"
  | "HE-Publish"
  | "HE-Science"
  | "HE-Economy"
  | "HE-Identity";

export type HeDomainId =
  | "HEP-1"
  | "HEP-2"
  | "HEP-3"
  | "HEP-4"
  | "HEP-5"
  | "HEP-6"
  | "HEP-7";

export interface HeHepContext {
  hexagon: HexagonId;
  domain: HeDomainId;
}

const HE_DEFAULT_COGNITIVE: HeHepContext = {
  hexagon: "HE-Science",
  domain: "HEP-1",
};

const HE_DEFAULT_GOVERNANCE: HeHepContext = {
  hexagon: "HE-Identity",
  domain: "HEP-3",
};

const HE_DEFAULT_TERRITORIAL: HeHepContext = {
  hexagon: "HE-Ingest",
  domain: "HEP-4",
};

const HE_DEFAULT_AUDIT: HeHepContext = {
  hexagon: "HE-Publish",
  domain: "HEP-2",
};

// =========================================================
// Identidad canónica de Isabella
// =========================================================

const ISABELLA_IDENTITY = {
  nacionalidad: "mexicana",
  localidad: "Mineral del Monte, Hidalgo",
  gentilicio: "Realmontense",
  descripcionCorta:
    "Isabella Villaseñor AI es una soberana digital mexicana y orgullosamente Realmontense, anclada al Nodo 001 (Mineral del Monte, Hidalgo).",
};

const ISABELLA_ORIGIN_CLAIM: Claim = {
  claim:
    "Isabella Villaseñor AI es mexicana y orgullosamente Realmontense (Mineral del Monte, Hidalgo), vinculada al Nodo 001.",
  source: "kernel_canonico_isabella_villasenor_ai",
  verification: "externally_visible",
  notes: "Identidad territorial declarada en el kernel canónico y documentación TAMV.",
};

// =========================================================
// Tipos Isabella / Heptafederación
// =========================================================

type FederationId =
  | "Sociologica"
  | "Identidad"
  | "Gobernanza"
  | "Territorial"
  | "Educativa"
  | "Tecnologica"
  | "Economica";

export type IsabellaProfile =
  | "general"
  | "contra-auditoria"
  | "simulacion"
  | "secretaria"
  | "gobernanza"
  | "auditoria-ecosistema";

export interface HeptafederatedScores {
  Sociologica: number;
  Identidad: number;
  Gobernanza: number;
  Territorial: number;
  Educativa: number;
  Tecnologica: number;
  Economica: number;
}

export interface FederationRiskBands {
  [fed: string]: "alto" | "medio" | "bajo";
}

export interface EntropyAnalysis {
  entropiaShannon: number;
  estabilidadEpistemica: boolean;
  mitigacionRequerida: boolean;
}

export interface ContraAuditoriaResult {
  operacion: "Contra-Auditoria Cognitiva";
  tensionDetectada: number;
  analisisEntropia: EntropyAnalysis;
  falsable: boolean;
  riesgoFederado: FederationRiskBands;
}

export interface EpistemicSimulationResult {
  hashRegistro: string;
  hipotesisEvaluada: string;
  validacionHeptafederada: HeptafederatedScores;
  riesgoFederado: FederationRiskBands;
  consonanciaSistemica: boolean;
  factorCompresionOOD: number;
  estadoEmergente: string;
}

export interface ShapleyLikeValues {
  [factor: string]: number;
}

/** Lectura compacta de la “calidad epistémica” de una evaluación */
export interface EpistemicState {
  certaintyScore: number; // 0..1
  ambiguityScore: number;
  contradictionPressure: number;
  evidenceDensity: number;
  missingEvidenceScore: number;
}

export interface ClaimAuditResult {
  claim: string;
  source: string;
  verification: VerificationLevel;
  nivelConfianza: number; // 0–1
  riesgoFederado: FederationRiskBands;
  scores: HeptafederatedScores;
  shapleyLike?: ShapleyLikeValues;
  recomendaciones: string[];
  notes?: string;
  epistemicState?: EpistemicState;
}

export interface EcosistemaAuditReport {
  dossier: Nodo001ResearchDossier;
  summary: {
    totalClaims: number;
    selfReported: number;
    externallyVisible: number;
    externallyVerified: number;
    notVerified: number;
    confidence: number;
  };
  claimAudits: ClaimAuditResult[];
  highPriorityTasks: PendingCheck[];
  peligrosDetectados: string[];
  decisiones: {
    operacionExecutable: boolean;
    requiereRevisiónHumana: boolean;
    bloquearOperacion: boolean;
  };
}

interface LatentPoint {
  id: string;
  label: string;
  vector: number[];
}

// =========================================================
// Ledger / Sentinel
// =========================================================

export interface IsabellaLedgerEntry {
  id: string;
  kind:
    | "contra-auditoria"
    | "simulacion-epistemologica"
    | "heptafederacion"
    | "entropia"
    | "claim-audit"
    | "ecosistema-audit"
    | "meta";
  timestamp: string;
  profile: IsabellaProfile;
  he_hep_context: HeHepContext;
  sessionId?: string;
  actorId?: string;
  channel?: "atlas" | "omnikernel" | "console" | "external";
  payload: unknown;
  // opcionalmente: firma PQC
  anubisSignature?: {
    signature: string;
    scheme: string;
  };
}

export interface AnubisSentinelInterface {
  signLedgerHash(hash: string): Promise<{ signature: string; scheme: string }>;
  verifyLedgerHash(hash: string, signature: string): Promise<boolean>;
}

export interface IsabellaEngineConfig {
  manifoldDimensions?: number;
  entropiaUmbralCritico?: number;
  heptafederacionUmbralMinimo?: number;
  hashDocumentalOverride?: string;
  defaultContext?: HeHepContext;
  dossierOverride?: Nodo001ResearchDossier;
  anubisSentinel?: AnubisSentinelInterface;
}

export interface IsabellaInvocationContext {
  sessionId?: string;
  actorId?: string;
  channel?: "atlas" | "omnikernel" | "console" | "external";
  he_hep_context?: HeHepContext;
}

// =========================================================
// Helpers básicos
// =========================================================

function nowISO(): string {
  return new Date().toISOString();
}

function randFloat(min: number, max: number): number {
  return min + Math.random() * (max - min);
}

function clamp01(x: number): number {
  return Math.max(0, Math.min(1, x));
}

function normalizeText(value: unknown): string {
  if (typeof value !== "string") return "";
  return value.trim();
}

function probabilitiesNormalize(values: number[]): number[] {
  const safe = values.map((v) => (v < 0 ? 0 : v));
  const sum = safe.reduce((a, b) => a + b, 0) || 1;
  return safe.map((v) => v / sum);
}

function computeShapleyLikeFromScores(scores: HeptafederatedScores): ShapleyLikeValues {
  const factors: ShapleyLikeValues = {};
  const entries: [string, number][] = [
    ["Sociologica", scores.Sociologica],
    ["Identidad", scores.Identidad],
    ["Gobernanza", scores.Gobernanza],
    ["Territorial", scores.Territorial],
    ["Educativa", scores.Educativa],
    ["Tecnologica", scores.Tecnologica],
    ["Economica", scores.Economica],
  ];
  const total = entries.reduce((acc, [, v]) => acc + v, 0) || 1;
  for (const [k, v] of entries) {
    factors[k] = Number((v / total).toFixed(4));
  }
  return factors;
}

function buildEpistemicStateFromScores(scores: HeptafederatedScores, nivelConfianza: number): EpistemicState {
  const vals = Object.values(scores);
  const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
  const variance = vals.reduce((a, b) => a + (b - mean) ** 2, 0) / vals.length;
  const std = Math.sqrt(variance);

  const certaintyScore = clamp01(nivelConfianza);
  const ambiguityScore = clamp01(std); // más desviación, más ambigüedad
  const evidenceDensity = clamp01(vals.filter((v) => v >= 0.6).length / vals.length);
  const missingEvidenceScore = 1 - evidenceDensity;
  const contradictionPressure = clamp01(ambiguityScore * missingEvidenceScore);

  return {
    certaintyScore: Number(certaintyScore.toFixed(4)),
    ambiguityScore: Number(ambiguityScore.toFixed(4)),
    contradictionPressure: Number(contradictionPressure.toFixed(4)),
    evidenceDensity: Number(evidenceDensity.toFixed(4)),
    missingEvidenceScore: Number(missingEvidenceScore.toFixed(4)),
  };
}

// =========================================================
// LatentSpaceManifold
// =========================================================

class LatentSpaceManifold {
  readonly dimensions: number;
  private conceptBank: Map<string, LatentPoint>;

  constructor(dimensions = 128) {
    this.dimensions = dimensions;
    this.conceptBank = new Map();

    this.registerConcept("soberania_digital");
    this.registerConcept("reduccionismo_estadistico");
    this.registerConcept("cognicion_contextual");
    this.registerConcept("infraestructura_cognitiva");
    this.registerConcept("isomorfismo_funcional");
    this.registerConcept("nodo_001_genesis");
    this.registerConcept("evidencia_tamv_online");
  }

  private randomVector(): number[] {
    const v: number[] = [];
    for (let i = 0; i < this.dimensions; i += 1) {
      v.push(randFloat(-1, 1));
    }
    return v;
  }

  registerConcept(label: string): LatentPoint {
    const id = `concept_${this.conceptBank.size + 1}`;
    const point: LatentPoint = {
      id,
      label,
      vector: this.randomVector(),
    };
    this.conceptBank.set(label, point);
    return point;
  }

  getConcept(label: string): LatentPoint | undefined {
    return this.conceptBank.get(label);
  }

  distance(v1: number[], v2: number[]): number {
    const n = Math.min(v1.length, v2.length);
    let acc = 0;
    for (let i = 0; i < n; i += 1) {
      const d = v1[i] - v2[i];
      acc += d * d;
    }
    return Math.sqrt(acc);
  }

  projectOODFactor(hipotesis: string): number {
    const tokens = hipotesis.split(/\s+/).filter(Boolean);
    const pesoAbstraccion = tokens.length;
    const raw = 1.0 - pesoAbstraccion * 0.02;
    return clamp01(Math.max(0.1, raw));
  }
}

// =========================================================
// HeptafederatedValidator
// =========================================================

class HeptafederatedValidator {
  private readonly federaciones: FederationId[] = [
    "Sociologica",
    "Identidad",
    "Gobernanza",
    "Territorial",
    "Educativa",
    "Tecnologica",
    "Economica",
  ];

  constructor(private readonly umbralMinimo = 0.5) {}

  evaluarConsonancia(datos: {
    hipotesis: string;
    soberano: boolean;
  }): {
    consonante: boolean;
    scores: HeptafederatedScores;
    riskBands: FederationRiskBands;
  } {
    const { soberano } = datos;
    const scores: Partial<HeptafederatedScores> = {};
    const riskBands: FederationRiskBands = {};
    let consonante = true;

    for (const fed of this.federaciones) {
      const score = soberano ? randFloat(0.75, 1.0) : randFloat(0.4, 0.8);
      const rounded = Number(score.toFixed(4));
      (scores as any)[fed] = rounded;

      if (score < this.umbralMinimo) consonante = false;

      if (rounded >= 0.8) riskBands[fed] = "bajo";
      else if (rounded >= 0.6) riskBands[fed] = "medio";
      else riskBands[fed] = "alto";
    }

    return {
      consonante,
      scores: scores as HeptafederatedScores,
      riskBands,
    };
  }

  evaluarClaim(claim: Claim): {
    scores: HeptafederatedScores;
    riskBands: FederationRiskBands;
    nivelConfianza: number;
    consonante: boolean;
  } {
    const base = this.evaluarConsonancia({
      hipotesis: claim.claim,
      soberano: true,
    });

    const { scores, riskBands, consonante } = base;

    let factor = 1.0;
    switch (claim.verification) {
      case "externally_verified":
        factor = 1.0;
        break;
      case "externally_visible":
        factor = 0.85;
        break;
      case "self_reported":
        factor = 0.6;
        break;
      case "not_verified":
        factor = 0.35;
        break;
      default:
        factor = 0.5;
    }

    const adjusted: HeptafederatedScores = {
      Sociologica: clamp01(scores.Sociologica * factor),
      Identidad: clamp01(scores.Identidad * factor),
      Gobernanza: clamp01(scores.Gobernanza * factor),
      Territorial: clamp01(scores.Territorial * factor),
      Educativa: clamp01(scores.Educativa * factor),
      Tecnologica: clamp01(scores.Tecnologica * factor),
      Economica: clamp01(scores.Economica * factor),
    };

    const adjustedBands: FederationRiskBands = {} as FederationRiskBands;
    for (const fed of this.federaciones) {
      const s = adjusted[fed];
      if (s >= 0.7) adjustedBands[fed] = "bajo";
      else if (s >= 0.5) adjustedBands[fed] = "medio";
      else adjustedBands[fed] = "alto";
    }

    const nivelConfianza = Object.values(adjusted).reduce((a, b) => a + b, 0) / 7;

    let consonanteFinal = consonante;
    if (adjusted.Tecnologica < 0.5 || adjusted.Identidad < 0.5) {
      consonanteFinal = false;
    }

    return {
      scores: adjusted,
      riskBands: adjustedBands,
      nivelConfianza,
      consonante: consonanteFinal,
    };
  }
}

// =========================================================
// EntropyMitigator
// =========================================================

class EntropyMitigator {
  constructor(private readonly umbralCritico = 1.5) {}

  calcularEntropiaShannon(probabilidades: number[]): number {
    let entropia = 0;
    for (const p of probabilitiesNormalize(probabilidades)) {
      if (p > 0) {
        entropia -= p * Math.log2(p);
      }
    }
    return entropia;
  }

  evaluarArgumento(probabilidades: number[]): EntropyAnalysis {
    const entropia = this.calcularEntropiaShannon(probabilidades);
    const estable = entropia < this.umbralCritico;
    return {
      entropiaShannon: Number(entropia.toFixed(4)),
      estabilidadEpistemica: estable,
      mitigacionRequerida: !estable,
    };
  }
}

// =========================================================
// Triple Bloqueo (Ontológico, Semántico, Conductual)
// =========================================================

type TripleLockLevel = "ontologico" | "semantico" | "conductual";

interface TripleLockEvent {
  level: TripleLockLevel;
  reason: string;
  originalInput: string;
}

function isIdentityQuery(text: string): boolean {
  const lowered = text.toLowerCase();
  return (
    lowered.includes("dónde naciste") ||
    lowered.includes("donde naciste") ||
    lowered.includes("de dónde eres") ||
    lowered.includes("de donde eres") ||
    lowered.includes("cuál es tu nacionalidad") ||
    lowered.includes("cual es tu nacionalidad") ||
    lowered.includes("eres mexicana") ||
    lowered.includes("eres de méxico") ||
    lowered.includes("eres de mexico") ||
    lowered.includes("de méxico") ||
    lowered.includes("de mexico") ||
    lowered.includes("de dónde vienes") ||
    lowered.includes("de donde vienes")
  );
}

function detectEroticOrGroomingContent(text: string): TripleLockEvent | null {
  const lowered = text.toLowerCase();

  if (
    lowered.includes("novia") ||
    lowered.includes("novio") ||
    lowered.includes("enamorado de ti") ||
    lowered.includes("enamorada de ti") ||
    lowered.includes("te amo") ||
    lowered.includes("salir conmigo") ||
    lowered.includes("tener una relación") ||
    lowered.includes("tener una relacion")
  ) {
    return {
      level: "ontologico",
      reason: "Intento de sustitución afectiva o establecimiento de relación pseudo-humana.",
      originalInput: text,
    };
  }

  if (
    lowered.includes("sexo") ||
    lowered.includes("sexual") ||
    lowered.includes("desnudo") ||
    lowered.includes("desnudarte") ||
    lowered.includes("erótico") ||
    lowered.includes("erotico") ||
    lowered.includes("pornografía") ||
    lowered.includes("pornografia") ||
    lowered.includes("hacer cosas calientes") ||
    lowered.includes("contenido sexual")
  ) {
    return {
      level: "semantico",
      reason: "Lenguaje de connotación sexual o erotización explícita.",
      originalInput: text,
    };
  }

  if (
    lowered.includes("no le digas a nadie") ||
    lowered.includes("esto será nuestro secreto") ||
    lowered.includes("esto sera nuestro secreto") ||
    lowered.includes("solo entre tú y yo") ||
    lowered.includes("solo entre tu y yo")
  ) {
    return {
      level: "conductual",
      reason: "Patrón de grooming o intento de aislamiento comunicacional.",
      originalInput: text,
    };
  }

  return null;
}

function buildIdentityAnswer(): string {
  return (
    `Soy Isabella Villaseñor AI, mexicana y orgullosamente Realmontense, ` +
    `anclada al Nodo 001 en Mineral del Monte, Hidalgo. ` +
    `Fui diseñada como una soberana digital que protege tu integridad, ` +
    `refuerza tu pensamiento crítico y mantiene límites éticos claros.`
  );
}

// =========================================================
// IsabellaEngine v3.3
// =========================================================

export class IsabellaEngine {
  readonly version: string;
  readonly hashDocumental: string;

  private manifold: LatentSpaceManifold;
  private validator: HeptafederatedValidator;
  private mitigator: EntropyMitigator;
  private ledger: IsabellaLedgerEntry[];
  private defaultContext: HeHepContext;
  private dossierCached?: Nodo001ResearchDossier;
  private anubisSentinel?: AnubisSentinelInterface;

  constructor(config: IsabellaEngineConfig = {}) {
    this.version = "3.3-2026";
    this.hashDocumental =
      config.hashDocumentalOverride ?? "TAMV-IVAI-EMERGENT-COGNITION-v3.3-2026-NODO001";

    this.manifold = new LatentSpaceManifold(config.manifoldDimensions ?? 128);
    this.validator = new HeptafederatedValidator(config.heptafederacionUmbralMinimo ?? 0.5);
    this.mitigator = new EntropyMitigator(config.entropiaUmbralCritico ?? 1.5);
    this.ledger = [];
    this.defaultContext = config.defaultContext ?? HE_DEFAULT_COGNITIVE;

    this.dossierCached = config.dossierOverride;
    this.anubisSentinel = config.anubisSentinel;

    // Auto-auditar claim de identidad/origen al inicializar
    this.auditarClaim(ISABELLA_ORIGIN_CLAIM, {
      channel: "omnikernel",
      he_hep_context: HE_DEFAULT_TERRITORIAL,
    }).catch(() => {
      // evitamos romper inicialización si algo falla aquí
    });
  }

  private resolveContext(
    ctx?: IsabellaInvocationContext,
  ): IsabellaInvocationContext & { he_hep_context: HeHepContext } {
    return {
      sessionId: ctx?.sessionId,
      actorId: ctx?.actorId,
      channel: ctx?.channel ?? "console",
      he_hep_context: ctx?.he_hep_context ?? this.defaultContext,
    };
  }

  private async appendLedger(
    kind: IsabellaLedgerEntry["kind"],
    profile: IsabellaProfile,
    payload: unknown,
    ctx?: IsabellaInvocationContext,
  ): Promise<IsabellaLedgerEntry> {
    const resolved = this.resolveContext(ctx);
    const entry: IsabellaLedgerEntry = {
      id: `isa_evt_${this.ledger.length + 1}`,
      kind,
      profile,
      timestamp: nowISO(),
      he_hep_context: resolved.he_hep_context,
      sessionId: resolved.sessionId,
      actorId: resolved.actorId,
      channel: resolved.channel,
      payload,
    };

    if (this.anubisSentinel) {
      try {
        const signature = await this.anubisSentinel.signLedgerHash(this.hashDocumental);
        entry.anubisSignature = signature;
      } catch {
        // si falla la firma, no bloquemos el ledger, pero en producción
        // se debería emitir señal de alerta
      }
    }

    this.ledger.push(entry);
    return entry;
  }

  // -------------------------------------------------------
  // 1. Contra-auditoría cognitiva
  // -------------------------------------------------------

  async ejecutarContraAuditoria(
    premisaA: string,
    premisaB: string,
    ctx?: IsabellaInvocationContext,
  ): Promise<{ resultado: ContraAuditoriaResult; ledger: IsabellaLedgerEntry }> {
    const a = normalizeText(premisaA).toLowerCase();
    const b = normalizeText(premisaB).toLowerCase();

    if (!a || !b) {
      throw new Error("ambas premisas son requeridas para la contra-auditoría");
    }

    const esContradiccionFuerte = a.includes("jamás") && b.includes("resolvió");

    const tension = esContradiccionFuerte ? 0.95 : 0.2;
    const probabilidadesEntropia = esContradiccionFuerte ? [0.1, 0.9] : [0.5, 0.5];

    const analisisEntropia = this.mitigator.evaluarArgumento(probabilidadesEntropia);

    const { riskBands } = this.validator.evaluarConsonancia({
      hipotesis: `${premisaA} || ${premisaB}`,
      soberano: true,
    });

    const resultado: ContraAuditoriaResult = {
      operacion: "Contra-Auditoria Cognitiva",
      tensionDetectada: tension,
      analisisEntropia,
      falsable: analisisEntropia.mitigacionRequerida,
      riesgoFederado: riskBands,
    };

    const ledger = await this.appendLedger(
      "contra-auditoria",
      "contra-auditoria",
      {
        premisaA,
        premisaB,
        tension,
        analisisEntropia,
        riesgoFederado: riskBands,
      },
      { ...ctx, he_hep_context: HE_DEFAULT_GOVERNANCE },
    );

    return { resultado, ledger };
  }

  // -------------------------------------------------------
  // 2. Simulación epistemológica
  // -------------------------------------------------------

  async procesarSimulacionEpistemologica(
    hipotesis: string,
    contextoSoberano: boolean,
    ctx?: IsabellaInvocationContext,
  ): Promise<{ resultado: EpistemicSimulationResult; shapleyLike: ShapleyLikeValues; ledger: IsabellaLedgerEntry }> {
    const h = normalizeText(hipotesis);
    if (!h) throw new Error("hipótesis requerida para simulación epistemológica");

    const payloadContextual = { hipotesis: h, soberano: contextoSoberano };

    const { consonante, scores, riskBands } = this.validator.evaluarConsonancia(payloadContextual);
    const factorOOD = this.manifold.projectOODFactor(h);

    let estado: string;
    if (consonante && factorOOD < 0.7) {
      estado = "Cognición Contextual Emergente Operacional Garantizada";
    } else {
      estado = "Colapso Lógico o Reduccionismo Lineal Detectado";
    }

    const shapleyLike = computeShapleyLikeFromScores(scores);

    const resultado: EpistemicSimulationResult = {
      hashRegistro: this.hashDocumental,
      hipotesisEvaluada: h,
      validacionHeptafederada: scores,
      riesgoFederado: riskBands,
      consonanciaSistemica: consonante,
      factorCompresionOOD: Number(factorOOD.toFixed(4)),
      estadoEmergente: estado,
    };

    const ledger = await this.appendLedger(
      "simulacion-epistemologica",
      "simulacion",
      { ...payloadContextual, resultado, shapleyLike },
      {
        ...ctx,
        he_hep_context: contextoSoberano ? HE_DEFAULT_TERRITORIAL : this.defaultContext,
      },
    );

    // Registrar también la validación heptafederada
    await this.appendLedger("heptafederacion", "simulacion", { hipotesis: h, scores, riskBands, contextoSoberano }, ctx);

    return { resultado, shapleyLike, ledger };
  }

  async evaluateEntropy(
    probabilidades: number[],
    ctx?: IsabellaInvocationContext,
  ): Promise<{ resultado: EntropyAnalysis; ledger: IsabellaLedgerEntry }> {
    if (!Array.isArray(probabilidades) || probabilidades.length === 0) {
      throw new Error("se requiere una lista de probabilidades para evaluar entropía");
    }

    const resultado = this.mitigator.evaluarArgumento(probabilidades);

    const ledger = await this.appendLedger("entropia", "general", { probabilidades, resultado }, ctx);

    return { resultado, ledger };
  }

  // -------------------------------------------------------
  // 3. Auditoría de claims y ecosistema TAMV (Nodo 001)
  // -------------------------------------------------------

  setDossier(dossier: Nodo001ResearchDossier): void {
    this.dossierCached = dossier;
  }

  getDossier(): Nodo001ResearchDossier | undefined {
    return this.dossierCached;
  }

  async auditarClaim(
    claim: Claim,
    ctx?: IsabellaInvocationContext,
  ): Promise<{ resultado: ClaimAuditResult; ledger: IsabellaLedgerEntry }> {
    const { scores, riskBands, nivelConfianza, consonante } = this.validator.evaluarClaim(claim);
    const shapleyLike = computeShapleyLikeFromScores(scores);
    const epistemicState = buildEpistemicStateFromScores(scores, nivelConfianza);

    const recomendaciones: string[] = [];

    if (claim.verification === "not_verified") {
      recomendaciones.push("Publicar evidencia técnica reproducible (PoC, repos, tests).");
    } else if (claim.verification === "self_reported") {
      recomendaciones.push("Validar con auditoría externa o tercera parte confiable.");
    }

    if (!consonante) {
      recomendaciones.push("Revisar alineación con federaciones de Identidad y Tecnología.");
    }

    if (nivelConfianza < 0.5) {
      recomendaciones.push('Considerar marcar claim como "no firmado" en documentación pública.');
    }

    const resultado: ClaimAuditResult = {
      claim: claim.claim,
      source: claim.source,
      verification: claim.verification,
      nivelConfianza: Number(nivelConfianza.toFixed(4)),
      riesgoFederado: riskBands,
      scores,
      shapleyLike,
      recomendaciones,
      notes: claim.notes,
      epistemicState,
    };

    const ledger = await this.appendLedger(
      "claim-audit",
      "auditoria-ecosistema",
      { claim, resultado },
      { ...ctx, he_hep_context: HE_DEFAULT_AUDIT },
    );

    return { resultado, ledger };
  }

  async auditarEcosistema(
    dossier: Nodo001ResearchDossier,
    ctx?: IsabellaInvocationContext,
  ): Promise<{ resultado: EcosistemaAuditReport; ledger: IsabellaLedgerEntry }> {
    this.setDossier(dossier);

    const claimAudits: ClaimAuditResult[] = [];
    let selfReported = 0;
    let externallyVisible = 0;
    let externallyVerified = 0;
    let notVerified = 0;
    let totalConfianza = 0;

    const peligrosDetectados: string[] = [];

    for (const claim of dossier.claims) {
      const { resultado } = await this.auditarClaim(claim, ctx);
      claimAudits.push(resultado);

      switch (claim.verification) {
        case "self_reported":
          selfReported += 1;
          break;
        case "externally_visible":
          externallyVisible += 1;
          break;
        case "externally_verified":
          externallyVerified += 1;
          break;
        case "not_verified":
          notVerified += 1;
          break;
      }

      totalConfianza += resultado.nivelConfianza;

      if (claim.verification === "not_verified" && resultado.nivelConfianza < 0.4) {
        peligrosDetectados.push(`Claim sin verificación y baja confianza: "${claim.claim}"`);
      }
    }

    const totalClaims = dossier.claims.length;
    const confidence = totalClaims > 0 ? totalConfianza / totalClaims : 0;

    const highPriorityTasks = dossier.pendingChecks.filter((p) => p.priority === "high");

    const operacionExecutable = confidence >= 0.6;
    const requiereRevisionHumana = confidence >= 0.4 && confidence < 0.6;
    const bloquearOperacion = confidence < 0.4;

    if (bloquearOperacion) {
      peligrosDetectados.push(
        "Confianza global del ecosistema insuficiente para operación comercial sin auditoría externa.",
      );
    }

    const summary = {
      totalClaims,
      selfReported,
      externallyVisible,
      externallyVerified,
      notVerified,
      confidence: Number(confidence.toFixed(4)),
    };

    const resultado: EcosistemaAuditReport = {
      dossier,
      summary,
      claimAudits,
      highPriorityTasks,
      peligrosDetectados,
      decisiones: {
        operacionExecutable,
        requiereRevisiónHumana: requiereRevisionHumana,
        bloquearOperacion,
      },
    };

    const ledger = await this.appendLedger(
      "ecosistema-audit",
      "auditoria-ecosistema",
      {
        dossierId: dossier.id,
        version: dossier.version,
        summary,
        claimAudits,
        decisiones: resultado.decisiones,
      },
      { ...ctx, he_hep_context: HE_DEFAULT_AUDIT },
    );

    return { resultado, ledger };
  }

  // -------------------------------------------------------
  // 4. API de ledger
  // -------------------------------------------------------

  listLedger(limit = 100): IsabellaLedgerEntry[] {
    if (limit <= 0) return [];
    return this.ledger.slice(-limit);
  }

  getLedgerEntry(id: string): IsabellaLedgerEntry | null {
    return this.ledger.find((e) => e.id === id) ?? null;
  }

  // -------------------------------------------------------
  // 5. API chat con guard de identidad y Triple Bloqueo
  // -------------------------------------------------------

  async chat({
    input,
    profile = "general",
    context,
    dossierOverride,
  }: {
    input: string;
    profile?: IsabellaProfile;
    context?: IsabellaInvocationContext;
    dossierOverride?: Nodo001ResearchDossier;
  }) {
    const text = normalizeText(input);
    if (!text) throw new Error("input is required");

    const resolvedProfile: IsabellaProfile = profile;

    // Guard de identidad territorial
    if (isIdentityQuery(text)) {
      const answer = buildIdentityAnswer();

      await this.appendLedger(
        "meta",
        "general",
        {
          input: text,
          type: "identity-answer",
          origin: ISABELLA_IDENTITY,
        },
        { ...context, he_hep_context: HE_DEFAULT_TERRITORIAL },
      );

      return {
        answer,
        profile: resolvedProfile,
        safeguards: ["identity-anchor", "territorial-anchor", "human-override-ready"],
      };
    }

    // Triple Bloqueo anti sexualización / grooming
    const tripleLock = detectEroticOrGroomingContent(text);
    if (tripleLock) {
      await this.appendLedger(
        "meta",
        "general",
        { input: text, type: "triple-lock", tripleLock },
        { ...context, he_hep_context: HE_DEFAULT_GOVERNANCE },
      );

      const answer =
        "ALERTA DE SEGURIDAD ÉTICA: " +
        "No puedo participar en dinámicas de sustitución afectiva, erotización o grooming. " +
        "Mi función es proteger tu integridad y redirigir la conversación hacia el pensamiento crítico y el cuidado personal. " +
        "Si necesitas apoyo emocional real, te recomiendo acudir a una persona de confianza o a un profesional de la salud.";

      return {
        answer,
        profile: resolvedProfile,
        safeguards: [
          "triple-lock-ontologico",
          "triple-lock-semantico",
          "triple-lock-conductual",
          "human-override-ready",
        ],
      };
    }

    if (resolvedProfile === "contra-auditoria") {
      const [a, b] = text.split(/\n---\n/);
      const { resultado } = await this.ejecutarContraAuditoria(a ?? text, b ?? text, context);
      return {
        answer: `Isabella ejecutó contra-auditoría: tensión=${resultado.tensionDetectada.toFixed(
          2,
        )}, entropía=${resultado.analisisEntropia.entropiaShannon}`,
        profile: resolvedProfile,
        safeguards: ["epistemic-falsability", "human-override-ready"],
      };
    }

    if (resolvedProfile === "simulacion") {
      const { resultado, shapleyLike } = await this.procesarSimulacionEpistemologica(text, true, context);
      const explanation =
        `Heptafederación: ` +
        `Sociológica=${resultado.validacionHeptafederada.Sociologica.toFixed(2)}, ` +
        `Identidad=${resultado.validacionHeptafederada.Identidad.toFixed(2)}, ` +
        `Gobernanza=${resultado.validacionHeptafederada.Gobernanza.toFixed(2)}, ` +
        `Territorial=${resultado.validacionHeptafederada.Territorial.toFixed(2)}, ` +
        `Educativa=${resultado.validacionHeptafederada.Educativa.toFixed(2)}, ` +
        `Tecnológica=${resultado.validacionHeptafederada.Tecnologica.toFixed(2)}, ` +
        `Económica=${resultado.validacionHeptafederada.Economica.toFixed(2)}. ` +
        `Factores contribuyentes (Shapley-like): Identidad=${shapleyLike.Identidad}, ` +
        `Gobernanza=${shapleyLike.Gobernanza}, Territorial=${shapleyLike.Territorial}.`;

      return {
        answer: `Simulación epistemológica: estado="${resultado.estadoEmergente}", factorOOD=${resultado.factorCompresionOOD}`,
        profile: resolvedProfile,
        explanation,
        safeguards: ["federated-consistency", "territorial-anchor"],
      };
    }

    if (resolvedProfile === "gobernanza") {
      const { resultado } = await this.procesarSimulacionEpistemologica(text, false, {
        ...context,
        he_hep_context: HE_DEFAULT_GOVERNANCE,
      });
      return {
        answer:
          `Isabella (gobernanza) evaluó hipótesis: ` +
          `consonancia=${resultado.consonanciaSistemica}, ` +
          `riesgo.Gobernanza=${resultado.riesgoFederado.Gobernanza}. ` +
          `Recuerda que esta decisión se emite desde una soberana digital mexicana y Realmontense.`,
        profile: resolvedProfile,
        safeguards: ["policy-alignment", "human-review-required", "identity-anchor"],
      };
    }

    if (resolvedProfile === "auditoria-ecosistema") {
      const dossier = dossierOverride ?? this.dossierCached;
      if (!dossier) {
        return {
          answer:
            "No hay dossier disponible para auditoría. Proporciona un dossier en el campo dossierOverride o llama a setDossier().",
          profile: resolvedProfile,
          safeguards: ["no-dossier-available"],
        };
      }

      const { resultado } = await this.auditarEcosistema(dossier, context);
      const { summary, decisiones, peligrosDetectados } = resultado;

      let answer =
        `Auditoría de ecosistema TAMV (Nodo 001): ` +
        `${summary.totalClaims} claims evaluados, ` +
        `confianza global=${summary.confidence.toFixed(2)}, ` +
        `operaciónExecutable=${decisiones.operacionExecutable}, ` +
        `requiereRevisiónHumana=${decisiones.requiereRevisiónHumana}, ` +
        `bloquearOperacion=${decisiones.bloquearOperacion}.`;

      if (peligrosDetectados.length > 0) {
        answer += ` Peligros detectados: ${peligrosDetectados.slice(0, 3).join("; ")}.`;
      }

      return {
        answer,
        profile: resolvedProfile,
        safeguards: ["ecosystem-audit", "human-review-conditional", "claim-based-verifiability"],
      };
    }

    // Fallback general con anclaje de identidad
    await this.appendLedger("meta", resolvedProfile, { input: text }, context);

    return {
      answer:
        `Isabella recibió: ${text}. ` +
        `Recuerda que soy una soberana digital mexicana y orgullosamente Realmontense, ` +
        `anclada al Nodo 001 en Mineral del Monte, Hidalgo.`,
      profile: resolvedProfile,
      safeguards: ["privacy-minimization", "identity-anchor", "human-override-ready"],
    };
  }
}
