const DEFAULT_TIMEOUT_MS = 7_000;

/**
 * Normaliza ORCID a string limpia.
 * No valida formato completo, solo asegura que haya algo no vacío.
 */
function normalizeOrcid(orcid) {
  return String(orcid ?? "").trim();
}

/**
 * Normaliza ISNI:
 * - elimina espacios y guiones,
 * - deja solo dígitos.
 */
function normalizeIsni(isni) {
  return String(isni ?? "")
    .replace(/\s+/g, "")
    .replace(/-/g, "")
    .trim();
}

/**
 * Devuelve fecha ISO o null si no es válida.
 */
function toIsoDate(input) {
  if (!input && input !== 0) return null;
  const date = new Date(input);
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString();
}

/**
 * Wrapper de fetch con timeout y headers. Lanza con mensaje claro si upstream falla.
 */
async function fetchJson(
  url,
  { fetchImpl = globalThis.fetch, headers = {}, timeoutMs = DEFAULT_TIMEOUT_MS } = {},
) {
  if (typeof fetchImpl !== "function") {
    throw new Error("fetch implementation is required");
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetchImpl(url, {
      headers,
      signal: controller.signal,
    });

    if (!response.ok) {
      const text = await response.text().catch(() => "");
      const details = text?.slice(0, 512);
      throw new Error(`Upstream error ${response.status} for ${url}${details ? `: ${details}` : ""}`);
    }

    return (await response.json());
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new Error(`Timeout after ${timeoutMs}ms for ${url}`);
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Crea una estructura de fallo estándar para upstream.
 */
function toFailure(
  provider,
  id,
  error,
  statusCode,
) {
  return {
    provider,
    id,
    reachable: false,
    error: error instanceof Error ? error.message : "Unknown upstream error",
    ...(statusCode !== undefined && { statusCode }),
  };
}

/**
 * Carga perfil ORCID (perfil + works).
 */
export async function loadOrcidProfile(
  orcid,
  { fetchImpl } = {},
) {
  const normalized = normalizeOrcid(orcid);
  if (!normalized) {
    return toFailure("orcid", null, new Error("Empty ORCID provided"));
  }

  const baseUrl = `https://pub.orcid.org/v3.0/${normalized}`;

  try {
    const [person, works] = await Promise.all([
      fetchJson(`${baseUrl}/person`, {
        fetchImpl,
        headers: { accept: "application/json" },
      }),
      fetchJson(`${baseUrl}/works`, {
        fetchImpl,
        headers: { accept: "application/json" },
      }),
    ]);

    const worksGroup = Array.isArray(works?.group) ? works.group : [];
    const lastModified = worksGroup
      .map((group) => {
        const value = group?.["last-modified-date"]?.value;
        return typeof value === "number" ? value : 0;
      })
      .sort((a, b) => b - a)[0];

    const fallbackName = [person?.name?.["given-names"]?.value, person?.name?.["family-name"]?.value]
      .filter(Boolean)
      .join(" ");
    const displayName = person?.name?.["credit-name"]?.value ?? (fallbackName || null);

    return {
      provider: "orcid",
      id: normalized,
      url: `https://orcid.org/${normalized}`,
      displayName,
      worksCount: worksGroup.length,
      lastSyncedAt: lastModified ? toIsoDate(lastModified) : null,
      reachable: true,
    };
  } catch (error) {
    return toFailure("orcid", normalized, error);
  }
}

/**
 * Carga registro Zenodo.
 */
export async function loadZenodoRecord(
  recordId,
  { fetchImpl } = {},
) {
  const normalized = String(recordId ?? "").trim();
  if (!normalized) {
    return toFailure("zenodo", null, new Error("Empty Zenodo record id provided"));
  }

  try {
    const data = await fetchJson(`https://zenodo.org/api/records/${normalized}`, {
      fetchImpl,
      headers: { accept: "application/json" },
    });

    return {
      provider: "zenodo",
      id: normalized,
      doi: data?.doi ?? null,
      title: data?.metadata?.title ?? null,
      url: data?.links?.html ?? `https://zenodo.org/records/${normalized}`,
      publishedAt: toIsoDate(data?.metadata?.publication_date),
      reachable: true,
    };
  } catch (error) {
    return toFailure("zenodo", normalized, error);
  }
}

/**
 * Valida existencia/resolución HTTPS de un ISNI.
 * ISNI no tiene API pública, por lo que la verificación es de reachability.
 */
export async function loadIsniProfile(
  isni,
  { fetchImpl = globalThis.fetch, timeoutMs = DEFAULT_TIMEOUT_MS } = {},
) {
  if (typeof fetchImpl !== "function") {
    throw new Error("fetch implementation is required");
  }

  const normalized = normalizeIsni(isni);
  if (!normalized) {
    return toFailure("isni", null, new Error("Empty ISNI provided"));
  }

  const url = `https://isni.org/isni/${normalized}`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetchImpl(url, {
      method: "GET",
      redirect: "follow",
      signal: controller.signal,
    });

    if (!response.ok) {
      return toFailure("isni", normalized, new Error(`Upstream error ${response.status} for ${url}`), response.status);
    }

    return {
      provider: "isni",
      id: normalized,
      url,
      reachable: true,
      note: "ISNI no expone API pública abierta; la validación se realiza por resolución HTTPS.",
    };
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      return toFailure("isni", normalized, new Error(`Timeout after ${timeoutMs}ms for ${url}`));
    }
    return toFailure("isni", normalized, error);
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Carga estado combinado de PIDs (ORCID, Zenodo, ISNI).
 */
export async function loadPidStatus(
  config,
  { fetchImpl = globalThis.fetch } = {},
) {
  if (typeof fetchImpl !== "function") {
    throw new Error("Global fetch is required to resolve PIDs");
  }

  const { orcid, zenodoRecord, isni } = config.pids;

  const [orcidResult, zenodoResult, isniResult] = await Promise.all([
    orcid ? loadOrcidProfile(orcid, { fetchImpl }) : Promise.resolve(null),
    zenodoRecord ? loadZenodoRecord(zenodoRecord, { fetchImpl }) : Promise.resolve(null),
    isni ? loadIsniProfile(isni, { fetchImpl }) : Promise.resolve(null),
  ]);

  return {
    checkedAt: new Date().toISOString(),
    records: {
      orcid: orcidResult,
      zenodo: zenodoResult,
      isni: isniResult,
    },
  };
}
