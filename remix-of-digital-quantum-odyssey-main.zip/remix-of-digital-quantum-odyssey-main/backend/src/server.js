import { createServer } from 'node:http';
import { createHash, randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { config } from './config.js';
import { buildSigningEngine } from './pqcHybrid.js';
import { buildDidDocument, buildOrganizationIdentity } from './identityRegistry.js';
import { loadPidStatus } from './pidConnectors.js';
import { createIsabellaEngine } from './isabellaEngine.js';
import { createOmniKernelGateway } from './omniKernelGateway.js';

const signingEngine = buildSigningEngine(config.signing.seed);
const orgIdentity = buildOrganizationIdentity(config, signingEngine.profile);
let atlasKernel;
async function getAtlasKernel() {
  if (!atlasKernel) {
    const { AtlasKernelRuntime } = await import('./atlasKernelRuntime.js');
    atlasKernel = new AtlasKernelRuntime();
  }
  return atlasKernel;
}
const isabellaEngine = createIsabellaEngine();
const omniKernelGateway = createOmniKernelGateway();
const atlasStoreConfig = {
  supabaseUrl: process.env.SUPABASE_URL,
  supabaseServiceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY,
};
const hasPersistence = Boolean(atlasStoreConfig.supabaseUrl && atlasStoreConfig.supabaseServiceRoleKey);
let atlasStore = null;
if (hasPersistence) {
  const { AtlasStore } = await import('./atlasStore.js');
  atlasStore = new AtlasStore(atlasStoreConfig);
  await atlasStore.init();
}

const requestMetrics = {
  startedAt: new Date().toISOString(),
  totalRequests: 0,
  totalErrors: 0,
  byPath: new Map(),
};
const rateLimitBuckets = new Map();
const RATE_LIMIT_WINDOW_MS = Number(process.env.TAMV_RATE_LIMIT_WINDOW_MS ?? 60_000);
const RATE_LIMIT_MAX = Number(process.env.TAMV_RATE_LIMIT_MAX ?? 120);
const ALLOWED_ORIGINS = (process.env.TAMV_ALLOWED_ORIGINS ?? 'https://tamv.online,http://localhost:5173')
  .split(',')
  .map((origin) => origin.trim())
  .filter(Boolean);

function requestIdOf(req) {
  return req.headers['x-request-id']?.toString() || randomUUID();
}

function corsOriginFor(req) {
  const origin = req.headers.origin?.toString();
  if (!origin) return ALLOWED_ORIGINS[0] ?? 'https://tamv.online';
  return ALLOWED_ORIGINS.includes(origin) ? origin : 'null';
}

function recordMetric(pathname, statusCode) {
  requestMetrics.totalRequests += 1;
  if (statusCode >= 500) requestMetrics.totalErrors += 1;
  const current = requestMetrics.byPath.get(pathname) ?? { count: 0, errors: 0 };
  current.count += 1;
  if (statusCode >= 400) current.errors += 1;
  requestMetrics.byPath.set(pathname, current);
}

function isRateLimited(req) {
  const identity = req.headers['x-forwarded-for']?.toString().split(',')[0]?.trim() || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const bucket = rateLimitBuckets.get(identity);
  if (!bucket || now - bucket.windowStart > RATE_LIMIT_WINDOW_MS) {
    rateLimitBuckets.set(identity, { windowStart: now, count: 1 });
    return false;
  }
  bucket.count += 1;
  return bucket.count > RATE_LIMIT_MAX;
}

function metricsSnapshot() {
  return {
    ...requestMetrics,
    byPath: Object.fromEntries(requestMetrics.byPath.entries()),
    checkedAt: new Date().toISOString(),
  };
}

function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 1_000_000) {
        reject(new Error('Payload too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!data) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(data));
      } catch {
        reject(new Error('Invalid JSON payload'));
      }
    });
  });
}



function setupSse(res) {
  res.writeHead(200, {
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-cache, no-transform',
    connection: 'keep-alive',
    'access-control-allow-origin': '*',
  });
  res.write(': connected\n\n');
}

function emitSse(res, event, payload) {
  res.write(`event: ${event}\n`);
  res.write(`data: ${JSON.stringify(payload)}\n\n`);
}

function buildSecurityPosture() {
  const hasStrongSeed = Boolean(config.signing.seed && config.signing.seed.length >= 16);
  const hasPidTriangulation = Boolean(config.pid.orcid && config.pid.zenodoRecord && config.pid.isni);
  const corsMode = process.env.TAMV_CORS_MODE ?? 'open';
  return {
    status: hasStrongSeed && hasPidTriangulation ? 'hardened' : 'degraded',
    antifragilityScore: [hasStrongSeed, hasPidTriangulation, hasPersistence].filter(Boolean).length / 3,
    controls: {
      pqcSigningSeed: hasStrongSeed ? 'ok' : 'weak',
      pidTriangulation: hasPidTriangulation ? 'ok' : 'missing',
      persistenceAuditTrail: hasPersistence ? 'ok' : 'disabled',
      cors: corsMode,
    },
    checkedAt: new Date().toISOString(),
  };
}

async function loadFederationReview() {
  const payload = await readFile('data/federation/osopanda-triple-review-latest.json', 'utf-8');
  return JSON.parse(payload);
}

async function loadMarkdownConsolidationReport() {
  const payload = await readFile('data/knowledge/markdown-consolidation-report.json', 'utf-8');
  return JSON.parse(payload);
}

async function loadReviewCycleReport() {
  const payload = await readFile('data/ops/review-reformulate-cycle-latest.json', 'utf-8');
  return JSON.parse(payload);
}


function requirePersistence(req, res) {
  if (atlasStore) return true;
  writeJson(req, res, 503, { error: 'Persistence backend unavailable. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.' });
  return false;
}

function writeJson(req, res, statusCode, payload) {
  const requestId = requestIdOf(req);
  recordMetric(new URL(req.url ?? '/', `http://${req.headers.host}`).pathname, statusCode);
  res.writeHead(statusCode, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'access-control-allow-origin': corsOriginFor(req),
    'access-control-allow-methods': 'GET,POST,OPTIONS',
    'access-control-allow-headers': 'content-type, authorization, x-request-id',
    'vary': 'Origin',
    'x-request-id': requestId,
    'x-content-type-options': 'nosniff',
    'x-frame-options': 'DENY',
    'referrer-policy': 'no-referrer',
    'permissions-policy': 'camera=(), microphone=(), geolocation=()',
    'content-security-policy': "default-src 'none'; frame-ancestors 'none'; base-uri 'none'",
  });
  console.info(JSON.stringify({ level: statusCode >= 500 ? 'error' : 'info', requestId, method: req.method, path: new URL(req.url ?? '/', `http://${req.headers.host}`).pathname, statusCode }));
  res.end(JSON.stringify({ ...payload, requestId }));
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url ?? '/', `http://${req.headers.host}`);

  if (isRateLimited(req)) {
    return writeJson(req, res, 429, { error: 'Rate limit exceeded' });
  }

  if (req.method === 'OPTIONS') {
    return writeJson(req, res, 200, { ok: true });
  }

  if (req.method === 'GET' && url.pathname === '/metrics') {
    return writeJson(req, res, 200, metricsSnapshot());
  }

  if (req.method === 'GET' && url.pathname === '/healthz') {
    return writeJson(req, res, 200, {
      ok: true,
      service: 'tamv-identity-api',
      environment: config.environment,
      timestamp: new Date().toISOString(),
    });
  }
  if (req.method === 'GET' && url.pathname === '/v1/security/posture') {
    return writeJson(req, res, 200, buildSecurityPosture());
  }
  if (req.method === 'GET' && url.pathname === '/v1/federation/review') {
    try {
      const review = await loadFederationReview();
      return writeJson(req, res, 200, review);
    } catch (error) {
      return writeJson(req, res, 404, { error: 'Federation review not generated yet', detail: error instanceof Error ? error.message : String(error) });
    }
  }

  if (req.method === 'GET' && url.pathname === '/v1/docs/consolidation') {
    try {
      const report = await loadMarkdownConsolidationReport();
      return writeJson(req, res, 200, report);
    } catch (error) {
      return writeJson(req, res, 404, { error: 'Markdown consolidation report not generated yet', detail: error instanceof Error ? error.message : String(error) });
    }
  }

  if (req.method === 'GET' && url.pathname === '/v1/ops/review-cycle') {
    try {
      const report = await loadReviewCycleReport();
      return writeJson(req, res, 200, report);
    } catch (error) {
      return writeJson(req, res, 404, { error: 'Review cycle report not generated yet', detail: error instanceof Error ? error.message : String(error) });
    }
  }

  if (req.method === 'GET' && url.pathname === '/v1/identity/org') {
    return writeJson(req, res, 200, orgIdentity);
  }

  if (req.method === 'GET' && url.pathname.startsWith('/v1/identity/did/')) {
    const suffix = url.pathname.replace('/v1/identity/did/', '');
    const didDocument = buildDidDocument(
      config,
      suffix,
      signingEngine.exportPublicKeyPem(),
    );
    return writeJson(req, res, 200, didDocument);
  }

  if (req.method === 'GET' && url.pathname === '/v1/pids/status') {
    try {
      const data = await loadPidStatus(config);
      return writeJson(req, res, 200, data);
    } catch (error) {
      return writeJson(req, res, 502, {
        error: error instanceof Error ? error.message : 'PID upstream error',
      });
    }
  }


  if (req.method === 'POST' && url.pathname === '/v1/fusion/plan') {
    try {
      const body = await parseJsonBody(req);
      const { discoverFusionPlan } = await import('./repoFusionService.js');
      const plan = await discoverFusionPlan(body.owner ?? 'OsoPanda1');
      return writeJson(req, res, 200, plan);
    } catch (error) {
      return writeJson(req, res, 502, {
        error: error instanceof Error ? error.message : 'Fusion plan failed',
      });
    }
  }

  if (req.method === 'POST' && url.pathname === '/v1/fusion/run') {
    try {
      const body = await parseJsonBody(req);
      const { executeFusion } = await import('./repoFusionService.js');
      const result = await executeFusion(body.owner ?? 'OsoPanda1');
      return writeJson(req, res, 200, result);
    } catch (error) {
      return writeJson(req, res, 502, {
        error: error instanceof Error ? error.message : 'Fusion execution failed',
      });
    }
  }



  if (req.method === 'POST' && url.pathname === '/api/v1/chat') {
    try {
      const body = await parseJsonBody(req);
      return writeJson(req, res, 200, isabellaEngine.chat(body));
    } catch (error) {
      return writeJson(req, res, 400, { error: error instanceof Error ? error.message : 'Invalid request' });
    }
  }

  if (req.method === 'POST' && url.pathname === '/api/v1/vision') {
    const body = await parseJsonBody(req);
    return writeJson(req, res, 200, isabellaEngine.vision(body));
  }

  if (req.method === 'POST' && url.pathname === '/api/v1/audio') {
    const body = await parseJsonBody(req);
    return writeJson(req, res, 200, isabellaEngine.audio(body));
  }

  if (req.method === 'POST' && url.pathname === '/api/v1/haptics') {
    try {
      const body = await parseJsonBody(req);
      return writeJson(req, res, 200, isabellaEngine.haptics(body));
    } catch (error) {
      return writeJson(req, res, 400, { error: error instanceof Error ? error.message : 'Invalid request' });
    }
  }

  if (req.method === 'POST' && url.pathname === '/api/v1/ledger/events') {
    const body = await parseJsonBody(req);
    return writeJson(req, res, 201, { event: isabellaEngine.registerLedgerEvent(body) });
  }

  if (req.method === 'GET' && url.pathname.startsWith('/api/v1/ledger/events/')) {
    const id = url.pathname.replace('/api/v1/ledger/events/', '');
    const event = isabellaEngine.getLedgerEvent(id);
    if (!event) {
      return writeJson(req, res, 404, { error: 'Ledger event not found', id });
    }
    return writeJson(req, res, 200, { event });
  }

  if (req.method === 'GET' && url.pathname === '/api/v1/plugins') {
    return writeJson(req, res, 200, { plugins: isabellaEngine.listPlugins() });
  }

  if (req.method === 'POST' && url.pathname === '/api/v1/plugins/install') {
    try {
      const body = await parseJsonBody(req);
      return writeJson(req, res, 201, { plugin: isabellaEngine.installPlugin(body.id) });
    } catch (error) {
      return writeJson(req, res, 400, { error: error instanceof Error ? error.message : 'Invalid request' });
    }
  }

  if (req.method === 'POST' && url.pathname === '/v1/signature/sign') {
    try {
      const body = await parseJsonBody(req);
      const payload = {
        id: randomUUID(),
        type: body.type ?? 'tamv.block',
        issuedAt: new Date().toISOString(),
        data: body.data ?? {},
      };
      const signature = signingEngine.signPayload(payload);
      return writeJson(req, res, 201, {
        payload,
        signature,
        profile: signingEngine.profile,
      });
    } catch (error) {
      return writeJson(req, res, 400, {
        error: error instanceof Error ? error.message : 'Unknown error',
      });
    }
  }

  if (req.method === 'POST' && url.pathname === '/v1/signature/verify') {
    try {
      const body = await parseJsonBody(req);
      const valid = signingEngine.verifyPayload(body.payload, body.signature);
      return writeJson(req, res, 200, {
        valid,
        checkedAt: new Date().toISOString(),
      });
    } catch (error) {
      return writeJson(req, res, 400, {
        error: error instanceof Error ? error.message : 'Unknown error',
      });
    }
  }


  if (req.method === 'GET' && url.pathname === '/v1/auth/profile') {
    return writeJson(req, res, 200, {
      ok: true,
      issuer: config.organization.name,
      didMethod: config.did.method,
      profile: signingEngine.profile,
    });
  }

  if (req.method === 'GET' && url.pathname === '/v1/users') {
    if (!requirePersistence(req, res)) return;
    try {
      const users = await atlasStore.listUsers();
      return writeJson(req, res, 200, { users });
    } catch (error) {
      return writeJson(req, res, 500, { error: error instanceof Error ? error.message : 'Failed to list users' });
    }
  }

  if (req.method === 'POST' && url.pathname === '/v1/users') {
    if (!requirePersistence(req, res)) return;
    try {
      const body = await parseJsonBody(req);
      const kernel = await getAtlasKernel();
      const user = kernel.createUser(body.handle, body.displayName);
      const persisted = await atlasStore.createUser({ handle: user.handle, displayName: user.displayName });
      return writeJson(req, res, 201, { user: persisted, kernelId: user.id });
    } catch (error) {
      return writeJson(req, res, 400, { error: error instanceof Error ? error.message : 'Create user failed' });
    }
  }

  if (req.method === 'POST' && url.pathname === '/v1/protocols/execute') {
    if (!requirePersistence(req, res)) return;
    try {
      const body = await parseJsonBody(req);
      const kernel = await getAtlasKernel();
      const execution = kernel.executeProtocol(body.protocolId, body.actorId, body.paths ?? []);
      const persisted = await atlasStore.recordProtocolExecution(execution);
      await atlasStore.publishXrEvent('guardian.protocol.collapsed', { execution });
      return writeJson(req, res, 201, { execution, persisted });
    } catch (error) {
      return writeJson(req, res, 400, { error: error instanceof Error ? error.message : 'Protocol execution failed' });
    }
  }

  if (req.method === 'POST' && url.pathname === '/v1/economy/ledger') {
    if (!requirePersistence(req, res)) return;
    try {
      const body = await parseJsonBody(req);
      const kernel = await getAtlasKernel();
      const entry = kernel.postLedger(body.userId, Number(body.amount), body.reason);
      const persisted = await atlasStore.recordEconomyEntry({ userId: body.userId, amount: Number(body.amount), reason: body.reason, kind: entry.kind });
      return writeJson(req, res, 201, { entry: persisted });
    } catch (error) {
      return writeJson(req, res, 400, { error: error instanceof Error ? error.message : 'Ledger post failed' });
    }
  }

  if (req.method === 'GET' && url.pathname === '/v1/xr/stream') {
    if (!requirePersistence(req, res)) return;
    setupSse(res);
    const unsubscribe = atlasStore.onXrEvent((event) => emitSse(res, 'guardian', event));
    req.on('close', () => unsubscribe());
    return;
  }

  if (req.method === 'POST' && url.pathname === '/v1/xr/events') {
    if (!requirePersistence(req, res)) return;
    try {
      const body = await parseJsonBody(req);
      const event = await atlasStore.publishXrEvent(body.eventType ?? 'xr.event', body.payload ?? {});
      return writeJson(req, res, 201, { event });
    } catch (error) {
      return writeJson(req, res, 400, { error: error instanceof Error ? error.message : 'Publish XR event failed' });
    }
  }

  if (req.method === 'GET' && url.pathname === '/v1/xr/webrtc/stream') {
    if (!requirePersistence(req, res)) return;
    setupSse(res);
    const roomId = url.searchParams.get('roomId');
    const target = url.searchParams.get('targetId');
    const unsubscribe = atlasStore.onSignal((signal) => {
      if (roomId && signal.room_id !== roomId) return;
      if (target && signal.target_id && signal.target_id !== target) return;
      emitSse(res, 'signal', signal);
    });
    req.on('close', () => unsubscribe());
    return;
  }

  if (req.method === 'POST' && url.pathname === '/v1/xr/webrtc/signal') {
    if (!requirePersistence(req, res)) return;
    try {
      const body = await parseJsonBody(req);
      const signal = await atlasStore.createSignal({
        roomId: body.roomId,
        senderId: body.senderId,
        targetId: body.targetId,
        signalType: body.signalType,
        payload: body.payload ?? {},
      });
      return writeJson(req, res, 201, { signal });
    } catch (error) {
      return writeJson(req, res, 400, { error: error instanceof Error ? error.message : 'Signal publish failed' });
    }
  }

  return writeJson(req, res, 404, {
    error: 'Not found',
    path: url.pathname,
  });
});

export function startServer() {
  server.listen(config.port, config.host, () => {
    // eslint-disable-next-line no-console
    console.log(
      `TAMV Identity API running on http://${config.host}:${config.port} (${config.environment})`,
    );
  });
  return server;
}

if (process.env.NODE_ENV !== 'test') {
  startServer();
}
