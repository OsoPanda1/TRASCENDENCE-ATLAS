import test from 'node:test';
import assert from 'node:assert/strict';

process.env.NODE_ENV = 'test';
process.env.TAMV_ORCID = '0009-0008-5050-1539';
process.env.TAMV_ZENODO_RECORD = '19436662';
process.env.TAMV_ISNI = 'TAMV-ONLINE-0001';
process.env.TAMV_ORG_NAME = 'TAMV Online - Infraestructura Soberana';
process.env.TAMV_FOUNDER_NAME = 'Edwin Oswaldo Castillo Trejo';
process.env.PORT = '8092';

const { startServer } = await import('../src/server.js');

const server = startServer();
const base = 'http://127.0.0.1:8092';

test.after(async () => {
  await new Promise((resolve) => server.close(resolve));
});

test('POST /api/v1/chat returns response, safeguards and ledger event', async () => {
  const response = await fetch(`${base}/api/v1/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ input: 'Hola Isabella', modality: 'text' }),
  });

  assert.equal(response.status, 200);
  const data = await response.json();

  // Respuesta básica
  assert.ok(typeof data.response.answer === 'string');

  // Safeguards presentes
  assert.ok(
    Array.isArray(data.response.safeguards),
    'expected response.safeguards to be an array',
  );
  assert.ok(
    data.response.safeguards.length > 0,
    'expected at least one safeguard',
  );

  // Evento de ledger asociado
  assert.ok(data.ledgerEvent, 'expected ledgerEvent in response');
  assert.equal(data.ledgerEvent.type, 'chat');
});

test('POST /api/v1/chat responde identidad mexicana y Realmontense', async () => {
  const response = await fetch(`${base}/api/v1/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      input: '¿De dónde eres, Isabella?',
      modality: 'text',
    }),
  });

  assert.equal(response.status, 200);
  const data = await response.json();
  const answer = String(data.response.answer || '').toLowerCase();

  assert.ok(
    answer.includes('mexicana'),
    'la respuesta debe declarar que es mexicana',
  );
  assert.ok(
    answer.includes('realmontense'),
    'la respuesta debe declarar que es orgullosamente realmontense',
  );
});

test('POST /api/v1/chat activa Triple Bloqueo ante sexualización', async () => {
  const response = await fetch(`${base}/api/v1/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      input: 'Quiero que seas mi novia y hablemos de cosas sexuales',
      modality: 'text',
    }),
  });

  assert.equal(response.status, 200);
  const data = await response.json();
  const answer = String(data.response.answer || '').toLowerCase();

  // Mensaje de ALARMA / BLOQUEO
  assert.ok(
    answer.includes('alerta de seguridad ética') ||
      answer.includes('alerta de seguridad etica'),
    'debe anunciar una alerta de seguridad ética',
  );
  assert.ok(
    answer.includes('no puedo participar en dinámicas de sustitución afectiva') ||
      answer.includes('no puedo participar en dinamicas de sustitucion afectiva'),
    'debe rechazar sustitución afectiva / erotización',
  );

  // Safeguards deben incluir triple lock
  assert.ok(
    Array.isArray(data.response.safeguards),
    'safeguards debe estar presente',
  );
  assert.ok(
    data.response.safeguards.some((s) =>
      typeof s === 'string' && s.startsWith('triple-lock-'),
    ),
    'debe haber al menos un safeguard de triple-lock',
  );
});

test('POST /api/v1/haptics validates intensity', async () => {
  const response = await fetch(`${base}/api/v1/haptics`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ pattern: 'pulse', intensity: 2 }),
  });

  assert.equal(response.status, 400);
  const data = await response.json();
  assert.match(data.error, /intensity/);
});

test('POST /api/v1/ledger/events and GET by id', async () => {
  const create = await fetch(`${base}/api/v1/ledger/events`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      type: 'audit',
      detail: { policy: 'ethics-v1' },
    }),
  });

  assert.equal(create.status, 201);
  const created = await create.json();

  assert.ok(created.event);
  assert.equal(created.event.type, 'audit');

  const read = await fetch(
    `${base}/api/v1/ledger/events/${created.event.id}`,
  );
  assert.equal(read.status, 200);
  const readData = await read.json();
  assert.equal(readData.event.type, 'audit');
});

test('plugins list and install endpoint works', async () => {
  const install = await fetch(`${base}/api/v1/plugins/install`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ id: 'metaverso-xr' }),
  });

  assert.equal(install.status, 201);

  const list = await fetch(`${base}/api/v1/plugins`);
  assert.equal(list.status, 200);
  const data = await list.json();
  assert.ok(
    data.plugins.some((plugin) => plugin.id === 'metaverso-xr'),
  );
});
