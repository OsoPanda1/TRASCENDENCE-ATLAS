# TAMV ATLAS NEXTGEN — CANONICAL PROJECT MEMORY

Version: 2.0
Classification: Foundational Memory
Status: Active
Authority: TAMV Digital + UTAMV + Atlas Core
Last Updated: 2026-06-09

---

# Vision

TAMV Atlas NextGen is not a conventional software platform.

It is a Sovereign Digital Infrastructure designed to unify:

* Identity
* Knowledge
* Governance
* Scientific Repositories
* Traceability
* Institutional Trust
* Open Science
* Federated Digital Ecosystems

for Latin America and global collaboration.

Mission:

To create a sovereign technological ecosystem where institutions, researchers, governments, communities and citizens can preserve, validate, interconnect and govern knowledge through verifiable digital infrastructure.

---

# Strategic Positioning

Atlas NextGen belongs to the convergence of:

* Digital Sovereignty
* Decentralized Identity
* Knowledge Infrastructure
* Open Science
* Institutional Governance
* Trust Infrastructure

Atlas is NOT:

* A CMS
* A Wiki
* A Traditional ERP
* A Learning Management System

Atlas IS:

* A Federated Knowledge Infrastructure
* An Institutional Trust Layer
* A Sovereign Identity Framework
* A Scientific Repository Federation Engine

---

# Core Architecture

## Layer 0

MD-X Core (HOYO NEGRO)

Purpose:

Foundational operational kernel responsible for orchestration, verification, federation and trust execution.

Responsibilities:

* orchestration
* execution
* policy enforcement
* trust validation
* federation management

---

## Layer 1

Atlas Kernel

Purpose:

Knowledge and identity runtime.

Capabilities:

* semantic operations
* institutional memory
* repository federation
* DID operations
* PID operations
* verification workflows

---

## Layer 2

Isabella Intelligence Layer

Role:

Ethical mediator and institutional cognitive assistant.

Functions:

* tutoring
* contextual guidance
* mediation
* semantic reasoning
* educational support
* governance assistance

Canonical Reference:

Korimakodex v1

Hash:

8ce80485

Status:

Locked Canon

---

# Identity Infrastructure

Identity Model:

ISNI-Centric Sovereign Identity Graph

Supported Elements:

* ISNI
* ORCID
* DOI
* did:tamv
* PID
* institutional identifiers

Purpose:

Create a verifiable and federated identity infrastructure for academic and institutional ecosystems.

---

# Knowledge Graph

Model:

JSON-LD Semantic Graph

Purpose:

Represent entities, institutions, publications, projects, repositories and relationships.

Storage:

* PostgreSQL
* pgvector
* semantic indexing

Embeddings:

1536 dimensions

Collections:

* canon_entities
* isabella_memory

RPC:

* match_entities
* match_memory
* semantic retrieval

---

# Federation Layer

Federation Objective:

Interconnect repositories and institutional nodes without centralizing ownership.

Supported Concepts:

* Repository Federation
* Open Science
* Knowledge Synchronization
* Provenance Validation
* Institutional Sovereignty

Future:

Regional LATAM Federation Network

---

# Trust Infrastructure

Trust Model:

CLEI Chain

Characteristics:

* append-only
* immutable
* auditable
* verifiable

Components:

* clei_chain_guard
* audit registry
* trust verification

Audit Portal:

/atlas-core/audit

Capabilities:

* verification
* export
* CSV evidence
* integrity review

---

# Security Architecture

Current:

* Ed25519
* signed payloads
* trust registry
* audit logs

Planned:

* ML-DSA-65
* PQC hybrid mode
* quantum readiness

Status:

Transition Phase

---

# Economic Layer

Platform:

Odoo

Responsibilities:

* institutional administration
* finances
* subscriptions
* governance operations
* service management

Purpose:

Separate operational governance from sovereign infrastructure.

---

# Atlas Public Narrative

Message:

Atlas NextGen is building the trust infrastructure required for the next generation of scientific, educational and institutional ecosystems.

Tagline:

Humanismo en Código.

---

# Long-Term Objectives

2026

* Production hardening
* Institutional pilots
* Federation validation

2027

* Regional university adoption
* Sovereign identity deployment

2028

* LATAM federation network

2030

* Global trust infrastructure for open knowledge ecosystems

---

# Canonical Principles

1. Humanism before automation.
2. Trust before scale.
3. Sovereignty before dependency.
4. Knowledge before monetization.
5. Transparency before authority.

---

# Memory Rules

Every strategic architectural decision MUST generate an ADR.

Every security decision MUST generate an ADR.

Every governance change MUST generate an ADR.

Every federation protocol modification MUST generate an ADR.

Documentation and memory are part of the system itself.

---

# AKAE — Knowledge Absorption Engine (added 2026-06-14)

Atlas no almacena datos, los transmuta. Pipeline canónico:

ingest → classify(type,domain_v2) → canonize(hash,score_integridad,score_confianza) → upsert canon_entities + canon_relations CONTAINS → bookpi_events AKAE_ABSORB.

Dominios v2: `infra | cognitivo | educativo | economico | xr | urbano | canon`.
Riesgo: `PUBLIC | INTERNAL | CROWN_JEWEL` (Asistente bloquea CROWN_JEWEL).

Endpoints: `atlas-akae-absorb`, `atlas-shell-exec`.
UI: `/atlas-core/shell`, `/atlas-core/graph`, `/atlas-core/assistant`.

Ver detalle en [AKAE](mem://akae).
