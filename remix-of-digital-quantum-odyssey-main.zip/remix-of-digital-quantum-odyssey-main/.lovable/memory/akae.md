---
name: AKAE v1.0 — Autonomous Knowledge Assimilation & Epistemic Engine
description: Canonical Sovereign Specification del motor de asimilación y canonización epistemológica del Atlas TAMV GENESIS
type: feature
status: rfc-genesis-draft
---

# 0. LEY SOBERANA AKAE

AKAE no es un pipeline de ingestión.
Es el **motor de asimilación cognitiva y canonización epistemológica soberana** del Atlas TAMV GENESIS.

> Atlas no almacena datos: **transmuta datos en conocimiento canónico, verificable, trazable, alineado éticamente y resistente a censura, sabotaje e inferencias maliciosas**.

---

# 1. DESCOMPOSICIÓN EN MÓDULOS

AKAE se compone de módulos normativos acoplados por eventos, no por llamadas directas:

- `AKAE-CORE`          — orquestación, lifecycle, Canonization Bus.
- `AKAE-ONTOLOGY`      — ontología formal, tipos canónicos, consistencia semántica.
- `AKAE-TRUST`         — trust vector, estado epistémico, robustez adversarial.
- `AKAE-CRYPTO`        — integridad, hashes, firmas, SBOM, verificación.
- `AKAE-TEMPORAL`      — validez, versiones, ramas temporales y escenarios.
- `AKAE-CONTRADICTION` — contradicción, impacto epistémico, resolución.
- `AKAE-ASSISTANT`     — contrato del Asistente Atlas, evidencia, políticas.
- `AKAE-GOVERNANCE`    — aprobación canónica, quorum, veto soberano.
- `AKAE-OBSERVABILITY` — logs, métricas, trazas, eventos de conocimiento.
- `AKAE-ANTIFRAGILITY` — aprendizaje por conflicto, mejora contínua del canon.

Cada módulo puede evolucionar versionado sin romper los invariantes globales.

---

# 2. AKAE-ONTOLOGY — Ontología y tipos canónicos

## 2.1. Dominios canónicos

```yaml
domain: <infra|cognitivo|educativo|economico|xr|urbano|canon>
```

- `infra`      → código, infra-as-code, pipelines, despliegues.
- `cognitivo`  → IA, EOCT, GEMET, razonamiento, modelos internos.
- `educativo`  → UTAMV, currículum, cursos, materiales.
- `economico`  → créditos, modelos de negocio, métricas financieras.
- `xr`         → MD‑X4, escenas, assets 4D, experiencias.
- `urbano`     → gemelo territorial, datos cívicos, tejido social.
- `canon`      → manifiestos, tratados, DOIs, contratos fundacionales.

Regla: una entidad tiene un solo dominio primario; las relaciones cubren las intersecciones.

## 2.2. Tipos canónicos

```yaml
canonical_type:
  family:
    - executable
    - documentary
    - governance
    - metric
    - policy
    - territorial
    - educational
    - xr

  artifact_type:
    - source_code
    - deployment
    - ontology
    - paper
    - treaty
    - conversation
    - telemetry
    - curriculum
```

- `family` refleja la función ontológica macro.
- `artifact_type` distingue granularidad epistemológica (paper ≠ treaty ≠ policy).

## 2.3. Ontology Class

```yaml
ontology_class:
  domain: <dominio>
  category: <string>      # p.ej. code, eoct, policy, metric, dataset
  subclass: <string|null> # p.ej. eoct_chain, antifraud_rule, utamv_course
  semantic_vector: <enabled|disabled>
  canonical_schema_version: akae-genesis-v1.0
```

AKAE-ONTOLOGY valida que `domain+category+subclass` sea coherente con las reglas declaradas. Si hay violación, la canonización se bloquea.

---

# 3. AKAE-CRYPTO — Integridad y verificabilidad

## 3.1. Identidad canónica soberana

```yaml
canonical_identity:
  cid: atlas:<domain>:<category>:<numeric_id>  # ej. atlas:cognitivo:eoct:000000193
  did_owner: <did:tamv:...>                   # identidad soberana del autor/institución
  namespace: <infra|cognitivo|educativo|...>
  federation: <f1..f7|null>
```

## 3.2. Integridad criptográfica

```yaml
integrity:
  content_hash:
    algorithm: blake3
    value: <hex>
  semantic_hash:
    algorithm: embedding_sha256
    value: <hex>
  signature:
    algorithm: ML-DSA-65     # esquema poscuántico
    fallback: Ed25519
    signer_id: <did>
  sbom_verified: <true|false>
  tamper_score: <0.0..1.0>   # 0 = intacto, 1 = altamente sospechoso
```

- `content_hash` protege bytes.
- `semantic_hash` protege significado.
- `signature` registra autoría soberana y positivamente verificable.
- `sbom_verified` se exige para artefactos ejecutables.
- `tamper_score` aumenta si hay signos de manipulación no autorizada.

---

# 4. AKAE-TRUST — Confianza y estado epistémico

## 4.1. Trust Vector ampliado

```yaml
trust_vector:
  provenance:              <0.0..1.0>
  reproducibility:         <0.0..1.0>
  peer_review:             <0.0..1.0>
  cryptographic_integrity: <0.0..1.0>
  eoct_alignment:          <0.0..1.0>
  gemet_consistency:       <0.0..1.0>
  recency:                 <0.0..1.0>
  adversarial_resistance:  <0.0..1.0>
  contradiction_stability: <0.0..1.0>
  territorial_relevance:   <0.0..1.0>
  execution_validity:      <0.0..1.0>
```

## 4.2. Estado epistémico

```yaml
epistemic_state:
  certainty_score:         <0.0..1.0>
  ambiguity_score:         <0.0..1.0>
  contradiction_pressure:  <0.0..1.0>
  evidence_density:        <0.0..1.0>
  missing_evidence_score:  <0.0..1.0>
```

## 4.3. Score agregado de confianza

```yaml
score_confianza_aggregate: <0.0..1.0>
```

- Calculado a partir del `trust_vector` según políticas AKAE-GOVERNANCE.
- Solo aumenta con nueva evidencia; nunca por uso repetido sin verificación.

---

# 5. AKAE-TEMPORAL — Tiempo y escenarios

```yaml
temporal:
  created_at:    <ISO8601>
  valid_from:    <ISO8601|null>
  valid_until:   <ISO8601|null>
  superseded_by: <canonical_id|null>
  observed_at:   <ISO8601|null>
```

## 5.1. Ramas de futuro

```yaml
timeline:
  branch_id: <string>        # ej. branch_2032_high_utamv
  probability: <0.0..1.0>
  scenario: <string>         # descripción breve del escenario
```

Permite a GENESIS operar con líneas temporales alternativas y predicciones.

---

# 6. AKAE-CONTRADICTION — Contradicciones y linaje

## 6.1. Contradicción tipificada

```yaml
contradiction:
  type:
    - semantic
    - logical
    - policy
    - ethical
    - empirical
    - deployment
    - territorial
  resolution_state:
    - pending
    - contested
    - resolved
    - archived
  epistemic_impact: <0.0..1.0>
```

## 6.2. Linaje epistemológico

```yaml
lineage:
  upstream:
    - canonical_id   # fuentes (papers, policies, diseños)
  downstream:
    - canonical_id   # impactos (code, deployments, métricas, outcomes)
  causality_strength: <0.0..1.0>
```

AKAE-CONTRADICTION usa este linaje para rastrear la cadena “idea → política → código → despliegue → resultado”.

---

# 7. AKAE-GOVERNANCE — Gobierno canónico

```yaml
governance:
  canonical_approval:
    required: true
  approval_policy:
    - human_review
    - sovereign_committee
    - automated_validation
  quorum:
    minimum_approvers: 3
  veto_power:
    sovereign: true
```

- Ninguna entidad se canoniza sin cumplir la política de aprobación.
- Ciertas categorías (`policy`, `treaty`, `governance`, `ethical`) requieren quorum y posible veto soberano.

---

# 8. AKAE-SECURITY — Sensibilidad y guardas

## 8.1. Clasificación de sensibilidad

```yaml
sensitivity:
  classification:
    level: <PUBLIC|INTERNAL|RESTRICTED|SOVEREIGN|CROWN_JEWEL>
  conversational_exposure:
    forbidden: <true|false>
  exportable: <true|false>
  inference_visibility:
    aggregate_only: <true|false>
```

## 8.2. Sensitivity Guard

```yaml
sensitivity_guard:
  anti_reconstruction: true
  anti_correlation_leakage: true
  anti_embedding_exposure: true
  semantic_redaction: enabled
```

- Protege contra model inversion, filtrado por correlación, reconstrucción semántica a partir de embeddings y fuga indirecta de secretos.

---

# 9. AKAE-ASSISTANT — Contrato del Asistente Atlas

```yaml
assistant_response:
  answer: <string|structured>
  confidence: <0.0..1.0>
  uncertainty:
    certainty_score: <0.0..1.0>
    ambiguity_score: <0.0..1.0>
    contradiction_pressure: <0.0..1.0>
  evidence:
    - canonical_id
  conflicting_evidence:
    - canonical_id
  policy_enforcement:
    blocked_reason: <string|null>
    confidence_threshold_met: <true|false>
    required_evidence_count: <int>
  reasoning_trace: <optional string|graph_ref>
  sensitivity_guard:
    triggered: <true|false>
    reason: <string|null>
  canonical_version: akae-rfc-0001-genesis
```

Reglas:

- Toda respuesta incluye `evidence[]` y `uncertainty`.
- Si hay `conflicting_evidence`, debe mencionarse.
- Si se dispara `sensitivity_guard.triggered`, se limita contenido.
- Si no se cumplen umbrales de evidencia o confianza, la respuesta debe explicitar sus límites.

---

# 10. AKAE-CORE — Pipeline y ejecución distribuida

## 10.1. Arquitectura event-driven

AKAE-CORE orquesta un flujo distribuido:

```text
INGEST
 ├── STRUCTURAL_PARSER        (AKAE-ONTOLOGY)
 ├── SEMANTIC_PARSER          (AKAE-ONTOLOGY)
 ├── TRUST_EVALUATOR          (AKAE-TRUST)
 ├── RISK_ENGINE              (AKAE-SECURITY)
 ├── CONTRADICTION_ENGINE     (AKAE-CONTRADICTION)
 └── ONTOLOGY_ENGINE          (AKAE-ONTOLOGY)
        ↓
CANONIZATION_BUS
        ↓
SIGNING                       (AKAE-CRYPTO)
        ↓
GRAPH_UPDATE                  (AKAE-ONTOLOGY / core graph)
        ↓
AUDIT_LOG                     (AKAE-OBSERVABILITY)
        ↓
KNOWLEDGE_PROPAGATION         (AKAE-ANTIFRAGILITY / caches / vistas)
```

Cada módulo escucha eventos y emite eventos, evitando acoplamiento fuerte.

---

# 11. AKAE-OBSERVABILITY — Trazabilidad

- Todo paso de AKAE emite:
  - `akae_event` con:
    - `canonical_id`
    - `stage` (INGEST, PARSE, TRUST_EVAL, etc.)
    - `timestamp`
    - `status`
    - `actor` (servicio, humano)
- Todos los comandos del Atlas Shell se registran en `atlas_shell_commands` con:
  - `user_id`, `command`, `params`, `timestamp`, `status`, `affected_canonical_ids[]`.

---

# 12. AKAE-ANTIFRAGILITY — Aprendizaje por conflicto

```yaml
antifragility:
  contradiction_resolutions_count: <int>
  last_resolution_at: <ISO8601|null>
  learning_gain: <0.0..1.0>
```

- Cada contradicción resuelta incrementa `learning_gain`.
- Los resultados se retroalimentan a:
  - pesos del `trust_vector`,
  - reglas de ONTOLOGY_ALIGNMENT,
  - políticas EOCT/GEMET,
  - umbrales de contradicción.

---

# 13. INVARIANTES SOBERANOS AKAE

1. Ninguna entidad entra al canon sin:
   - `canonical_identity`
   - `ontology_class` coherente
   - `integrity` completo
   - `trust_vector` inicial
   - `sensitivity` definido
   - `temporal.created_at`

2. Ningún artefacto ejecutable se canoniza sin:
   - `sbom_verified: true`
   - firma válida de AKAE-CRYPTO

3. Ningún conocimiento se canoniza si contradice EOCT/GEMET **sin explicación explícita** y estado `contradiction.resolution_state` distinto de `pending`.

4. Toda contradicción crítica (`epistemic_impact` alto) requiere revisión humana.

5. Toda respuesta IA debe ser reproducible:
   - mismo input + mismo estado del canon → mismo output (salvo cambios documentados).

6. Ninguna entidad `CROWN_JEWEL` se expone directamente en conversación; solo agregados.

---

# 14. VERSIÓN

```yaml
akae_spec_version: akae-genesis-v1.0
rfc_id: akae-rfc-0001-genesis
```

Este archivo es el **registro canónico Lovable** de AKAE para TAMV GENESIS / ATLAS NEXTGEN. Cualquier implementación debe honrar estos contratos como base mínima.
