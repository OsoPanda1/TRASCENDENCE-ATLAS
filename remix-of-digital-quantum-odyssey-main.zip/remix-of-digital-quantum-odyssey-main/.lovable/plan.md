## TAMV Atlas MVP 1.0 — Unificación Canónica (AKAE)

Voy a unificar `kernel-tamv-main` y `tamv-core-atlas-main` dentro del Atlas actual SIN romper lo existente, siguiendo la ley canónica: **REUSE → CONSOLIDATE → EXTEND → BUILD NEW** y `FUNCTIONAL > EXECUTABLE > STABLE > SECURE > PRETTY`. No se crearán kernels duplicados.

### Estrategia de absorción (no sobreescritura)

Los dos zips contienen otro proyecto Lovable completo. Copiarlos sobre `/dev-server` rompería el Atlas vivo (duplicaría App.tsx, vite config, supabase client, etc.) y viola la Single Source of Truth Law. En lugar de eso, los trato como **fuentes canónicas a ingerir** vía AKAE.

```text
/mnt/user-uploads/*.zip  ──►  /tmp/akae-staging/  ──►  AKAE parser
                                                       │
                                                       ▼
                                              canon_entities (DB existente)
                                              canon_relations
                                              bookpi_events (trace)
```

### Entregables del MVP 1.0

**1. AKAE Edge Function (`atlas-akae-absorb`)**
- Lee árbol de un zip ya extraído en Storage o un repo Git
- Clasifica archivos (código/doc/config/manifest/canon) reusando `atlas-ingest`
- Calcula `id_canonico`, `hash`, `score_integridad`, `score_confianza`
- Inserta en `canon_entities` + `canon_relations` + `bookpi_events`
- Soporta dominios: `infra | cognitivo | educativo | economico | xr | urbano | canon`

**2. Migración mínima (extensión de tablas existentes)**
- Añadir `score_integridad`, `score_confianza`, `domain_v2`, `subdomain`, `risk_level` a `canon_entities`
- Nueva tabla `akae_jobs` (cola de ingesta con estado: queued/running/done/error)
- Nueva tabla `atlas_shell_commands` (log de comandos ejecutados, RBAC `admin|gobierno`)

**3. Atlas Shell Web (`/atlas-core/shell`)**
- Consola estilo terminal con comandos: `status`, `ingest <url>`, `search "<q>"`, `node <id>`, `absorb <storage_path>`
- Invoca edge functions, persiste log firmado en `atlas_shell_commands`
- Protegido por `ProtectedRoute minRole="gobierno"`

**4. Atlas Graph View mejorada (`/atlas-core/graph`)**
- Vista de grafo (react-force-graph-2d) sobre `canon_entities` + `canon_relations`
- Filtros por dominio/federación, panel de detalle de nodo con scores
- Búsqueda integrada (reusa `match_canon_entities` semántico ya existente)

**5. Asistente IA Atlas con evidencia (`/atlas-core/assistant`)**
- Reusa `isabella-chat` + RAG sobre `match_canon_entities`
- Respuesta SIEMPRE incluye `evidence: canonical_id[]` y `confidence`
- Guardrails: bloquea entidades con `risk_level='CROWN_JEWEL'`

**6. Carga inicial de los dos zips como corpus canónico**
- Script único `scripts/akae_bootstrap.mjs` que extrae ambos zips a `/tmp`, llama `atlas-akae-absorb` por carpeta raíz, y deja un reporte en `data/akae/bootstrap-report.json`
- También ingiere los `.md` sueltos relevantes (kernel_canonico_isabella, OsoPanda1-*.md, PRD adjunto) como `type=canon_document`

**7. Memoria del proyecto actualizada**
- `mem://akae` con la ley AKAE y el contrato de scores
- Index actualizado

### Fuera de alcance (explícito, según el propio PRD)

- TAMV Créditos en producción
- Despliegues multi‑ciudad
- IA con acceso irrestricto
- NO se migran a Neo4j/NestJS — el stack canónico ya es Supabase+React+Edge Functions (cambiar el stack rompe la Architectural Immutability Law). El "grafo" se materializa sobre Postgres usando `canon_relations` ya existente, lo cual cumple el objetivo funcional del PRD.

### Archivos nuevos / editados (~14)

- `supabase/migrations/<ts>_akae.sql` (1)
- `supabase/functions/atlas-akae-absorb/index.ts` (1)
- `supabase/functions/atlas-shell-exec/index.ts` (1)
- `src/pages/AtlasShell.tsx`, `AtlasGraph.tsx`, `AtlasAssistant.tsx` (3)
- `src/components/atlas/GraphCanvas.tsx`, `NodeInspector.tsx`, `ShellTerminal.tsx` (3)
- `scripts/akae_bootstrap.mjs` + reporte (2)
- `src/App.tsx` rutas + sidebar (1)
- `.lovable/memory/akae.md` + index (2)

### Criterios de éxito (PRD §7)

- ≥3 corpus ingeridos (los 2 zips + .md sueltos) → ✓ via bootstrap
- Grafo navegable con scores → ✓ AtlasGraph
- IA responde con evidencia → ✓ AtlasAssistant
- 0 secretos en repo, JWT obligatorio en shell → ✓ por diseño

¿Procedo con la implementación completa?