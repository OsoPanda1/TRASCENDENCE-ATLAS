export const TAMVAI_MANUAL = {
  roles: {
    isabella: "Orquestadora emocional y de contexto (Isabella Villaseñor AI).",
    tamvaiCore: "Backend de orquestación IA (modelos, rutas, sesiones).",
    aiGuardians: "Filtros, detección de abuso, explicabilidad y cumplimiento.",
  },
  lifecycle: {
    steps: [
      "Registro de modelo en AI Registry (ID, versión, licencia, ámbito).",
      "Evaluación ética y de sesgos (pruebas automatizadas + revisión humana).",
      "Deployment canary (1–5% tráfico) con observabilidad reforzada.",
      "Promoción a estable si cumple SLO/SLA y KPIs de seguridad/ética.",
      "Retiro o rollback automático ante incidentes o degradación.",
    ],
  },
  guardrails: {
    safetyLayers: [
      "Moderación de contenido (texto/imagen/audio).",
      "Rate limiting sensible al riesgo e identidad.",
      "Filtros de prompts críticos (autolesiones, violencia, desinformación).",
    ],
    logging:
      "Decisiones IA de alto impacto se registran en log inmutable (append-only) con anonimización selectiva.",
    dataRetention: { maxMessagesPerSession: 50, fullConversationStorage: false, retentionDays: 30 },
  },
} as const;
