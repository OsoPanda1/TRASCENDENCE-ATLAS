export const TAMV_ARCH = {
  pipelines: {
    A: {
      name: "Pipeline A – Experiencias (Social + XR)",
      stages: ["Ingesta de eventos", "Enriquecimiento IA (Isabella / TAMVAI)", "Renderizado XR/3D/4D", "Entrega en tiempo real"],
    },
    B: {
      name: "Pipeline B – Economía + DAO",
      stages: ["Onboarding de creador/a", "Emisión de activos (NFT, tickets, licencias)", "Liquidación y reparto", "Auditoría on/off-chain"],
    },
    CCP: {
      name: "Civilization Control Plane (CCP)",
      stages: [
        "Observabilidad total (logs, métricas, trazas, eventos, perfiles)",
        "Gobernanza de modelos IA (registry, versionado, ética)",
        "Gestión de riesgos y cambios (RFC + ADR + AI-assisted)",
      ],
    },
  },
  runtimeTopology: {
    apiGateway: "TAMV UNIFIED API (REST / GraphQL / WebSocket / gRPC)",
    domains: ["identity", "social", "xr", "economy", "governance", "ai-core"],
    dataPlane: ["Postgres/Prisma", "TimeSeries (Prometheus)", "Object Storage (S3/IPFS)"],
    controlPlane: ["Identity & Policy", "Telemetry & Observability (OTel + Prometheus + Grafana + Loki + Tempo)", "Security & Federation Control"],
  },
} as const;
