export const TAMV_BLUEPRINT = {
  stack: {
    frontend: ["React + Vite", "TanStack Router", "react-three-fiber + @react-three/xr", "shadcn/ui + lucide-react"],
    backend: ["Node 20", "tRPC/Express", "Apollo GraphQL Gateway", "WebSocket/WS"],
    data: ["Postgres + Prisma", "Redis", "IPFS"],
  },
  services: ["identity-service", "social-service", "xr-world-service", "economy-service", "dao-service", "ai-orchestrator (TAMVAI Core)"],
  infra: {
    deployment: ["Kubernetes", "GitHub Actions CI/CD", "ArgoCD / Flux", "Terraform"],
    observability: ["OpenTelemetry", "Prometheus", "Grafana", "Loki", "Tempo"],
  },
} as const;
