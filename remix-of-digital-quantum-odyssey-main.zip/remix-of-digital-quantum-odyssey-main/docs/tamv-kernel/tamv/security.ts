export const TAMV_SECURITY = {
  auth: { oidc: true, jwt: true, mfa: ["TOTP", "Biometría opcional"] },
  crypto: {
    quantumSafe: ["ML-KEM", "ML-DSA", "SLH-DSA"],
    transport: ["TLS 1.3", "mTLS interno"],
  },
  guardians: {
    types: ["Guardian técnico", "Guardian ético-jurídico", "Guardian comunitario"],
    responsibilities: [
      "Revisar cambios críticos de IA y de gobernanza.",
      "Auditar incidentes de seguridad o abuso.",
      "Velar por coherencia con la Constitución TAMV y el Omega Principle.",
    ],
  },
  supplyChain: { sbom: true, slsaLevelTarget: 2 },
} as const;
