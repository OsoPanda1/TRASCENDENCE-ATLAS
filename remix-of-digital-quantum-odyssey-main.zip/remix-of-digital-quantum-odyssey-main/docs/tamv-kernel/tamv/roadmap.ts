export const TAMV_ROADMAP = {
  apiVersions: [
    { name: "v1", status: "stable", deprecationDate: null },
    { name: "v2", status: "designing", deprecationDate: null },
  ],
  milestones: [
    { id: "m1", title: "TAMV UNIFIED API v1", scope: ["Social", "XR", "DAO", "IsabellaAI Recommendation"], quarter: "2026-Q2" },
    { id: "m2", title: "TAMV MD-X5 Full Observability", scope: ["Tracing completo", "Dashboards XR/DAO/Economía", "OTel→Prom/Loki/Tempo"], quarter: "2026-Q3" },
    { id: "m3", title: "TAMV MD-X6 Quantum / 5D (Experimentos)", scope: ["5D XR experimental", "Neuromorphic AI laboratorio"], quarter: "2027-Q1" },
  ],
  governance: {
    process: [
      "RFC público (Repositorio GitHub TAMV – proposals/)",
      "Revisión técnica y ética",
      "Votación DAO (on/off-chain)",
      "Implementación incremental con feature flags",
    ],
  },
} as const;
