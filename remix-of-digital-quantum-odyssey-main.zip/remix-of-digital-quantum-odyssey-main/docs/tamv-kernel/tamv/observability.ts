export const TAMV_OBSERVABILITY = {
  telemetry: {
    metrics: [
      "latencia por endpoint",
      "errores 4xx/5xx",
      "cola de eventos XR",
      "tiempos de respuesta IA (Isabella, TAMVAI)",
      "hit rate de caches (TTS, recomendación)",
    ],
    traces: "OpenTelemetry distribuido en todas las llamadas entre servicios y TAMVAI Gateway.",
    logs: "Estructurados en JSON, enviados a Loki / Elasticsearch.",
  },
  dashboards: {
    grafana: [
      "TAMV Overview (SLOs globales)",
      "XR/4D Render Performance",
      "Economía Creativa (volumen, fallos liquidación)",
      "DAO Governance (participación, vetos, propuestas)",
      "TAMVAI / Isabella Health (latencias, errores, fallback TTS)",
    ],
  },
  audits: {
    apiAuditLog: "Colección dedicada con request/response mínimamente necesarios para trazabilidad.",
    aiDecisionsLog: "Eventos de alto impacto (sanciones, recomendaciones masivas, decisiones de moderación).",
  },
} as const;
