export const TAMV_ETHICS_LEGAL = {
  philosophy: {
    foundations: [
      "Humanismo digital latinoamericano",
      "Ética del cuidado y de la interdependencia",
      "Tecnología como bien común civilizatorio",
    ],
    prohibitedPractices: [
      "Modelos de negocio basados en adicción o manipulación cognitiva.",
      "Venta encubierta de datos biométricos o sensibles.",
      "Uso de la IA para persecución política, discriminación o violencia.",
    ],
  },
  legalFramework: {
    jurisdictions: [
      "México (protección de datos, ciberseguridad, comercio digital)",
      "Normativa internacional de derechos humanos (DDHH)",
    ],
    apiLicensePrinciples: [
      "Uso de la API en alineación con los fines civilizatorios del TAMV.",
      "Limitación de responsabilidad del proveedor de API conforme a buenas prácticas de licenciamiento abierto.",
    ],
    dataProtection: {
      dpaCompatible: true,
      userDataRights: ["Acceso", "Rectificación", "Portabilidad", "Olvido contextual"],
    },
  },
  governance: {
    daoLayer: "TAMV DAO",
    mechanisms: ["Snapshot / on-chain voting", "Guardianías humanas / comité ético", "Veto por abuso de IA"],
  },
} as const;
