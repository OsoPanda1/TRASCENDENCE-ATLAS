export const TAMV_CONSTITUTION = {
  preamble: {
    title:
      "Constitución Técnica del Territorio Autónomo de Metarrealidad Viva (TAMV)",
    version: "MD-X5 / MD-X6 · Canonical Enterprise Edition",
    principles: [
      "Primacía de la dignidad humana y la protección integral de la persona usuaria.",
      "Neutralidad algorítmica orientada al bien común y al fortalecimiento comunitario.",
      "Soberanía digital desde México para el mundo, con carácter de infraestructura de interés público.",
      "Dominio de los datos en manos de las personas usuarias, comunidades y/o instituciones.",
      "Evolución asistida por IA siempre bajo marcos éticos, jurídicos y de auditoría observables.",
    ],
    scope: [
      "Red Social TAMV",
      "Metaverso XR/VR/3D/4D",
      "Economía creativa y DAO Governance",
      "Infraestructura MD-X5/MD-X6 Backend Quantum Híbrido",
      "TAMV UNIFIED API & TAMVAI API",
    ],
  },
  omega: {
    principle:
      "Atlas/TAMV no son software ni plataformas; son Infraestructura Soberana de Confianza.",
    mission: [
      "Preservar conocimiento, identidad, confianza, gobernanza y continuidad intergeneracional.",
      "Priorizar continuidad sobre crecimiento.",
    ],
  },
} as const;
