# Auditoría TAMV Atlas Trascendencia · plan de absorción y remediación

## Alcance inmediato

Se incorporó una ruta operacional para absorber los repositorios indicados por la auditoría:

- `DOCUMENTACION-TAMV-DM-X4-e-ISABELLA-AI`
- `tamvweb-fb822252`
- `genesis-digytamv-nexus-927b1ee8`
- `tamv-core-atlas`
- `tamv-documentacion`

El manifiesto canónico de ingesta queda en `docs/repo-unification-manifest.json` y el importador multiplataforma queda en `scripts/unify_osopanda_repos.mjs`.

> Nota de ejecución: el entorno actual bloqueó el túnel HTTPS hacia GitHub con HTTP 403 al intentar clonar los repositorios. Por ello esta iteración deja preparado el manifiesto, el comando reproducible y las primeras correcciones locales sin importar contenido externo incompleto.

## Checklist corregido en esta iteración

### Estructura y CI/CD

- [x] Sustituir el flujo Bash principal de unificación por un script Node.js multiplataforma.
- [x] Declarar `engines` para Node/NPM y preparar `workspaces` para federación.
- [x] Generar manifiesto explícito de los cinco repositorios solicitados.

### Seguridad

- [x] Restringir CORS por lista de orígenes configurables en backend.
- [x] Agregar encabezados HTTP de hardening en backend: `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy` y CSP defensiva.
- [x] Agregar rate limiting básico por IP/forwarded IP.
- [x] Forzar HTTPS/HSTS y encabezados de seguridad en Ingress NGINX.

### Criptografía

- [x] Cambiar derivación de identificador de llave del backend a SHA-512.
- [x] Marcar explícitamente el modo Ed25519 como `Ed25519-bridge`, no como PQC real.
- [x] Añadir bloqueo `TAMV_REQUIRE_PQC=true` para impedir firma clásica cuando producción exija PQC.

### Observabilidad

- [x] Agregar endpoint `/metrics` con contadores de solicitudes, errores y desglose por ruta.
- [x] Emitir logs estructurados JSON con `requestId`, método, ruta y estado.
- [x] Propagar `x-request-id` en cada respuesta JSON.

### Interfaz de usuario

- [x] Corregir la ruta visible `/fusion` que ya estaba enlazada desde navegación pero no registrada en React Router.
- [x] Mantener las rutas wiki `/wiki/:sectionId/:slug`, incluida `/wiki/modulo-cero/introduccion`, como ruta canónica de Introducción.

## Pendientes de siguiente fase

- [ ] Ejecutar `npm run unify:import` en una red con acceso a GitHub para importar los cinco repositorios como subárboles squash.
- [ ] Revisar y fusionar conflictos semánticos del contenido importado en las páginas wiki canónicas.
- [ ] Implementar firmas ML-DSA/FIPS 204 en backend Node con llaves custodiadas por KMS/HSM.
- [ ] Centralizar trazas distribuidas con OpenTelemetry/OTLP.
- [ ] Segmentar CI por workspaces y carpetas modificadas.
- [ ] Completar pruebas Lighthouse/Axe y optimización de lazy loading de visualizaciones pesadas.
