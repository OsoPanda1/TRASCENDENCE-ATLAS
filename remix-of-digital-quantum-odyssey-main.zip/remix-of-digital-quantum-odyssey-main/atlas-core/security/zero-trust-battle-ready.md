# Zero Trust Battle Ready — Atlas

Traducción operativa de NIST SP 800-207 + buenas prácticas de industria al contexto Atlas Trascendence.

## Principios
1. **Default deny** entre cualquier par de servicios o federaciones.
2. **Verificación continua** por request (no por sesión).
3. **Identidad de workload** (SPIFFE) para todo lo que se comunica.
4. **Microsegmentación real** por federación.
5. **Cifrado de tránsito y reposo** sin excepciones.
6. **Observabilidad obligatoria** en cada decisión de policy.

## Inventario duro (BP1)
Catálogo exhaustivo y versionado en `security/inventory/`:
- Aplicaciones, APIs, datos, servicios, dispositivos, pipelines.
- HVAs marcados con etiqueta `criticality: critical|high|medium|low`.
- Relación con federación (F1–F7) y plano (00–07).

## Policies de acceso por defecto
Ningún recurso accesible sin:
- Identidad verificada (SPIFFE SVID + token firmado).
- Policy aplicada (`security/service-policies.yaml`).
- Logging activado (LTOS).

## Microsegmentación
Segmentos lógicos:
- **Seguridad**: Anubis, Horus, Dekateotl, Aztek Gods, Ojo de Ra, Quetzalcóatl
- **Núcleo Atlas**: EOCT, GEMET, CITEMESH, KORIMA, 4L, SDMD-7
- **Kernels**: métricas, tracing, audit, economía
- **IA**: Isabella y servicios cognitivos
- **Front/Edge**: frontends, gateways públicos
- **Infra**: orquestadores, pipelines, CI/CD

Comunicación entre segmentos: sólo por policies explícitas a través de gateways/brokers controlados.

## Defensa activa en bordes
- Proxy de terminación dura: inspecciona tráfico cifrado, aplica policies, oculta red interna (ZTNA).
- No exponer redes; sólo aplicaciones declaradas.

## Ciclo gobernanza-riesgo
1. Definir → 2. Aprobar → 3. Versionar → 4. Evaluar riesgo → 5. Postmortem → loop.
Anclado en KORIMA + BookPI/MSR.
