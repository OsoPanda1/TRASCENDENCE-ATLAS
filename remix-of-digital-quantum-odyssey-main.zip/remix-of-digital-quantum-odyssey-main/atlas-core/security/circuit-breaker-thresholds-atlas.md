# Circuit Breaker Thresholds — Atlas

## Principios
- Romper conexiones a tiempo antes que entrar en cascada de fallos.
- Umbrales iniciales conservadores; ajuste posterior con datos reales.
- Exponer estado de cada breaker como métrica de primera clase.

## Parámetros base (ajustables por servicio)
| Parámetro | Valor inicial |
|---|---|
| Ventana de muestreo | 10–30 s |
| Failure threshold | >5 fallos en 10 s **o** tasa de error >50% en ventana |
| Open timeout | 30–60 s antes de half-open |
| Half-open trial requests | 1–3 |
| Success threshold para close | 3–5 requests consecutivas OK |

## Perfiles
- **Servicios de frontera** (API Gateway, edge): umbrales más sensibles.
- **Servicios internos**: más tolerancia, pero con fallback/cola.
- **IA**: ventana corta + límite por identidad para mitigar abuso.

## Métricas expuestas
- `circuit_breaker_state{service,route}` (closed=0, half_open=1, open=2)
- `circuit_breaker_trips_total{service,route}`
- `circuit_breaker_open_seconds{service,route}`
- `circuit_breaker_blocked_requests_total{service,route}`

Alertas: trips repetidos, tiempo en open > umbral, % de tráfico bloqueado.
