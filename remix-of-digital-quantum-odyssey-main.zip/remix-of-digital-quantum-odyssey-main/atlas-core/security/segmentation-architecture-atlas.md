# Segmentation Architecture — Atlas

## Topología de segmentos
| Segmento | Contenido | Comunicación |
|---|---|---|
| `seg-security` | Anubis, Horus, Dekateotl, Aztek Gods, Ojo de Ra, Quetzalcóatl | Ingreso desde todos vía broker auditado; egreso a KMS |
| `seg-core` | EOCT, GEMET, CITEMESH, KORIMA, 4L, SDMD-7 | Inter-core por mTLS + policy; expone a kernels/IA |
| `seg-kernels` | Metrics, tracing, audit, economy | Recibe de todos; egreso BookPI/MSR |
| `seg-ai` | Isabella, servicios cognitivos | Sólo invoca core por gateway con guardianía IA |
| `seg-edge` | Frontends, gateways públicos | Único expuesto a internet; ZTNA |
| `seg-infra` | Orquestadores, pipelines, CI/CD | Aislado; nunca expuesto |

## Reglas
- **Default deny** entre cualquier par de segmentos.
- Policies en términos de **identidad de workload** (SPIFFE) + contexto, no IP.
- Conexiones bloqueadas se loguean (source, destino, puerto, identidad, motivo).
- Cada segmento puede degradarse y operar en modo reducido sin colapsar otros.

## Conexiones permitidas (resumen)
```
seg-edge      → seg-core    (gateway, rutas declaradas)
seg-edge      → seg-ai      (gateway con guardianía IA)
seg-ai        → seg-core    (rutas read-only + append eventos)
seg-core      → seg-kernels (telemetría + anclaje)
seg-security  → *           (control plane, audit)
seg-infra     → *           (deploy, sólo plane de control)
```

## Bordes
- Único ingreso público a `seg-edge`, terminación dura, WAF + rate limit.
- ZTNA: sólo apps declaradas, nunca la red.
