# KMS Hybrid Architecture — Atlas

## Objetivo
KMS central que provee a Atlas operaciones criptográficas con perfil **híbrido clásico + post-cuántico**, política unificada y auditoría completa.

## Componentes
- **KMS API interna** (`/v1/kms/*`): generar claves, cifrar, descifrar, firmar, verificar, rotar.
- **Almacén raíz**: HSM o equivalente con quórum de operadores.
- **Conector SPIRE**: clientes autenticados por SPIFFE SVID, no por API key.
- **Audit pipeline**: cada operación → EOCT + LTOS + BookPI.

## Clases de claves
| Clase | Uso | Algoritmo |
|---|---|---|
| Transporte | TLS/mTLS híbrido | X25519 + Kyber |
| Datos (por dominio) | Cifrado de campo | AES-256-GCM |
| Anclaje | Bookpi/MSR/HEHEP | Ed25519 + firma PQ (dual) |
| Maestra | KEK por dominio | AES-256 wrap, custodia HSM |

## Hybrid key exchange
1. Ejecutar X25519 (clásico) → `ss_classic`.
2. Ejecutar Kyber KEM (PQ) → `ss_pq`.
3. `session_key = HKDF(ss_classic || ss_pq, info=context)`.
4. Documentar `context` por canal (servicio origen, destino, propósito).

## Rotación
- Programada por clase (transporte: horas; datos: días; anclaje: meses).
- Por evento (compromiso, cambio de política, rotación de operador).
- Versionado: cada cifrado lleva `key_id@version`.

## Auditoría
Cada operación KMS registra: caller SPIFFE ID, clase/clave/versión, propósito, timestamp, resultado, hash de payload. Enlazada a EOCT y trazas.
