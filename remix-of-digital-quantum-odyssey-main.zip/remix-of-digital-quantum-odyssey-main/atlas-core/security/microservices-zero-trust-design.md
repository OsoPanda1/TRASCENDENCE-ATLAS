# Microservices Zero Trust — SPIFFE/SPIRE

## SPIFFE ID convention
Formato:

```
spiffe://atlas.local/ns/<namespace>/sa/<service-account>/svc/<service-name>
```

Ejemplos:
- `spiffe://atlas.local/ns/core/sa/eoct/svc/eoct-api`
- `spiffe://atlas.local/ns/core/sa/gemet/svc/gemet-api`
- `spiffe://atlas.local/ns/security/sa/anubis/svc/anubis-guardian`
- `spiffe://atlas.local/ns/ai/sa/isabella/svc/isabella-cognitive`

## Topología SPIRE
- **SPIRE Server** por dominio de confianza (cluster).
- **SPIRE Agent** en cada nodo worker.
- **Workload attestation** por service account + pod labels + node selector.

## mTLS obligatorio
Cada microservicio:
- Obtiene SVID X.509 de SPIRE (vida corta: horas, no meses).
- Usa SVID como client cert (al invocar) y valida server cert (al recibir).
- Policies expresadas por SPIFFE ID, **no por IP**.

Ejemplo de policy:
> `eoct-api` sólo acepta peers cuyo SPIFFE ID coincida con `spiffe://atlas.local/ns/core/sa/gemet/*` en el puerto interno `8443`.

## Service policies
Archivo canónico `security/service-policies.yaml`:

```yaml
services:
  eoct-api:
    spiffe_id: spiffe://atlas.local/ns/core/sa/eoct/svc/eoct-api
    allowed_inbound:
      - peer: spiffe://atlas.local/ns/core/sa/gemet/*
        routes: ["/v1/events:append", "/v1/events:read"]
      - peer: spiffe://atlas.local/ns/security/sa/anubis/*
        routes: ["/v1/audit/*"]
    allowed_outbound:
      - peer: spiffe://atlas.local/ns/economy/sa/bookpi/*
        purpose: anchor
```

## Rotación y revocación
- SVIDs de vida corta (1–8 h).
- Revocación inmediata si Anubis/Horus marcan un servicio comprometido → SPIRE corta emisión → tráfico se cae.
- Eventos de revocación se anclan en BookPI.

## Observabilidad
Loguear y graficar:
- SVIDs emitidos (issuer, SPIFFE ID, TTL, expiración).
- Handshakes mTLS fallidos, SVID expirados, rechazos de policy.
- Métricas por par `(source_spiffe_id → target_spiffe_id, route)`.
