# Hybrid Encryption Strategy — Atlas

## Clasificación de datos
| Nivel | Ejemplos | Cifrado tránsito | Cifrado reposo | Anclaje |
|---|---|---|---|---|
| Público | Landing, whitepaper, sitemap | TLS estándar | Volumen | — |
| Sensible | Identidades, sesiones, audit común | TLS híbrido | Volumen + campo (KMS) | BookPI |
| Crítico | KORIMA, políticas, decisiones críticas, secretos maestros | TLS híbrido + doble envoltura | Volumen + campo + envoltura PQ | BookPI + MSR + HEHEP |

## Cifrado en tránsito
- **KEM híbrido**: X25519 + Kyber (o KEM PQC vigente).
- Shared secrets concatenados → **HKDF** → session key única.
- Firma de certificados: Ed25519 hoy + firma PQ cuando se estandarice (perfil dual).

## Cifrado en reposo
- Volúmenes cifrados a nivel plataforma.
- Campos sensibles: AES-256-GCM con clave de datos solicitada al KMS central.
- Rotación programada y por evento (compromiso, cambio de política).

## Anclaje de estados críticos
Para Bookpi / MSR Blockchain / ELITE HEHEP, registrar:
- `hash` del payload canónico
- `timestamp` UTC ISO-8601
- `algorithm` (incluido perfil PQ)
- `policy_version`
- `atlas_schema_ref` (entidad/evento)
- `signed_by` (SPIFFE ID)

## Estrategia PQC
1. Hoy: TLS híbrido + claves dimensionadas para PQ.
2. Cuando NIST estabilice firmas PQ: emisión dual (clásica + PQ).
3. Migración: deprecación clásica por familia, validación cruzada vía HEHEP.

## Reglas
- **Ningún servicio reimplementa crypto.** Todo pasa por el KMS central.
- Logs de operaciones KMS anclados en EOCT + BookPI.
