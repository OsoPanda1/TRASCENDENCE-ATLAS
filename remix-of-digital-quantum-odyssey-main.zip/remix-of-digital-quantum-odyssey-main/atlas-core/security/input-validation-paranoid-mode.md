# Input Validation — Paranoid Mode

Todos los inputs (incluyendo internos) se validan contra schema fuerte. Zero Trust sobre cualquier dato que entre a un servicio Atlas.

## 7 capas de validación

### Capa 1 — Infraestructural (WAF / Gateway)
- Bloquea payloads obvios y firmas conocidas.
- Limita tamaño de request (config por endpoint).

### Capa 2 — Protocolo
- Verifica método HTTP esperado, content-type estricto, headers requeridos.

### Capa 3 — Schema fuerte (Zod)
- Tipos, rangos, patrones, enumeraciones.
- Rechazo, no normalización silenciosa.

### Capa 4 — Semántica de dominio (TAMV)
- Validación contra ontologías Atlas, reglas 4L, SDMD-7, KORIMA Codex.

### Capa 5 — Seguridad contextual
- Detección de cadenas con pinta de código/SQL/script/prompt malicioso.
- Escapado / normalización donde aplique.

### Capa 6 — Cuotas e identidad
- Rate limit por SPIFFE ID / user ID / tenant, incluso si la validación pasa.
- Detección de patrones de abuso.

### Capa 7 — Guardianía de IA
- Filtros específicos contra prompt injection, extracción de secretos y manipulación de contexto.
- Audit obligatorio en EOCT cuando dispara.

## 7 anillos de cifrado (activos ultracríticos)
Aplica solo a constituciones, cambios de política, registros máximos y secretos maestros.

1. AES-256-GCM de campo
2. AES-256-GCM con clave independiente (doble envoltura)
3. TLS clásico (transporte)
4. PQ KEM (transporte híbrido)
5. Firma digital clásica (Ed25519/ECDSA)
6. Firma digital PQ (cuando esté estandarizada)
7. Anclaje en MSR + HEHEP (hash + referencia inmutable)

Documentar por activo: qué se cifra con qué, en qué orden, dónde viven las claves y cómo se combinan vía HKDF.
