# Atlas Doctrine v1 — Modo Guerra

> **TAMV ATLAS TRASCENDENCE**
> Preservando aquello que las personas consideran digno de ser recordado.

Versión: v1 (modo guerra) · Estado: canónica · Predecesor: `atlas-doctrine-v0.md`

---

## 0. Postura mental

Atlas nace en **zona hostil**. La AI y todo desarrollador deben asumir por diseño:

- **Assume breach** — actuamos como si ya hubiera un atacante dentro.
- **Federated security** — cada módulo se endurece y aísla independientemente.
- No existe "modo hobby", "modo demo" ni "fase beta segura" en producción.
- Mercado, competidores y actores maliciosos van a intentar tumbar Atlas el día 1.

---

## 1. Seis axiomas blindados

### Axioma 1 — Superficie mínima y segmentada
Ningún servicio, puerto, endpoint o feature se expone al exterior sin:
- Proxy de **terminación dura** (termina la conexión y analiza, no passthrough).
- Política de acceso **explícita**.
- Telemetría **activada**.

Cada servicio = **HVA potencial** → se segmenta para limitar movimiento lateral.

### Axioma 2 — Identidad fuerte y control de acceso extremo
Todo (usuarios, servicios, pipelines, radares, gemelos, guardianías) tiene **identidad fuerte** (SPIFFE para workloads).
Acceso gobernado por **RBAC estricto + ABAC contextual** y **JIT / JEA** para tareas sensibles.

Prohibido: cuentas compartidas, secrets en código, permisos globales "temporales" sin expiración.

### Axioma 3 — Telemetría como sistema nervioso
Sin telemetría, un módulo **no es producción**. Todo acceso, cambio de estado, error y decisión de IA genera:
- Evento **EOCT**.
- Span con IDs completos (W3C trace context).
- Al menos una métrica crítica.

La observabilidad sirve para: detección de ataques, forense post-incidente y verificación de cumplimiento de políticas.

### Axioma 4 — Criptografía híbrida y migración PQC planificada
Desde el día 1:
- Canales críticos usan cripto **híbrida** (clásica + PQ).
- Estados críticos (constitución, políticas, evidencias) anclados a **MSR Blockchain** y **ELITE HEHEP**.
- Claves y protocolos diseñados pensando en migración PQC, **no como parche futuro**.

### Axioma 5 — Gobernanza y riesgo integrados al diseño
Zero Trust no es solo técnico:
- Inventario exhaustivo de datos, apps, assets, servicios, workflows, con **HVAs marcados**.
- Ciclo formal: definir → aprobar → versionar políticas → evaluar riesgo → postmortem.

Sin este ciclo, cualquier blindaje envejece rápido.

### Axioma 6 — Automatización defensiva y resiliencia federada
Seguridad y respuesta basadas en **automatización, orquestación y policies ejecutables** — no en héroes.
Cada federación puede **aislar, degradar y operar en modo reducido** sin colapsar el sistema.

> Atlas prefiere **degradarse de forma controlada** antes que quedar expuesta.

---

## 2. Protect Surface

Antes de listar lo atacable, definimos **lo valioso**:

| Activo | Federación | Criticidad | Modo degradado |
|---|---|---|---|
| Constitución KORIMA | Gobernanza | Crítico | Read-only, anclaje MSR obligatorio |
| Identidades AKAÉ | Identidad | Crítico | Sesiones existentes, no emisión nueva |
| EOCT (eventos canónicos) | Conocimiento | Crítico | Append-only, sin reescritura |
| GEMET (grafo) | Conocimiento | Alto | Lectura desde réplica |
| CITEMESH (citaciones) | Conocimiento | Alto | Lectura desde caché firmada |
| BookPI / MSR / HEHEP | Economía + Seguridad | Crítico | Quórum reducido, sin escritura |
| Kernels LTOS (obs) | Infraestructura | Alto | Sampling reducido, alertas vivas |
| Anubis / Horus | Seguridad | Crítico | Modo bloqueo agresivo |
| Isabella AI | IA cognitiva | Medio | Respuestas con guardrails reforzados |

---

## 3. Escenarios de ataque y estrategia de defensa

| Escenario | Reducción superficie | Segmentación | Detección | Respuesta | Recuperación |
|---|---|---|---|---|---|
| **DDoS** | ZTNA en borde, sólo apps expuestas | Edge ≠ kernels | Anomalías de tráfico, rate spikes | Rate limit + 429/503 + circuit breakers | Escalado horizontal + cierre de IPs |
| **Ransomware** | Volúmenes inmutables | Backups en segmento aislado | Cambios masivos en filesystem | Aislar nodo, revocar SVIDs | Restaurar desde BookPI anclado a MSR |
| **Compromiso de claves** | KMS central, SVIDs cortos | Cripto por dominio | Uso anómalo de claves, geo/horario | Rotación + revocación inmediata | Re-emisión SPIRE, re-anclaje HEHEP |
| **Abuso de IA / prompt injection** | Guardianía IA en frontera | IA en segmento propio | Patrones de extracción / jailbreak | Bloqueo de sesión, downgrade de permisos | Auditoría EOCT, ajuste de guardrails |
| **Inyección de inputs** | WAF + schema Zod | Default deny entre servicios | Logs estructurados de intento | Rechazo, conteo por identidad | Patch + test de regresión |

---

## 4. Mapeo de sistemas críticos

| Sistema | Federación | Criticidad | Depende de | Modo degradado |
|---|---|---|---|---|
| EOCT | F1 Conocimiento | Crítico | KMS, BookPI | Append-only sin compactación |
| GEMET | F1 | Alto | EOCT | Lectura de réplica |
| CITEMESH | F1 | Alto | GEMET, BookPI | Caché firmada |
| 4L / SDMD-7 | F3 Gobernanza | Crítico | EOCT, KORIMA | Read-only |
| KORIMA Codex | F3 | Crítico | MSR, HEHEP | Read-only |
| BookPI | F4 Economía | Crítico | MSR | Sin escritura |
| MSR Blockchain | F4 | Crítico | HEHEP | Quórum reducido |
| ELITE HEHEP | F4 + F5 | Crítico | KMS PQ | Sólo verificación |
| Kernels LTOS | F6 Infra | Alto | — | Sampling reducido |
| Anubis | F5 Seguridad | Crítico | Identidad, LTOS | Bloqueo agresivo |
| Horus | F5 | Crítico | Anubis | Modo alarma |
| Dekateotl | F5 | Alto | KORIMA | Policy freeze |
| Aztek Gods | F5 | Medio | Anubis | Auditoría diferida |
| Ojo de Ra | F6 + F5 | Alto | LTOS | Alertas básicas |
| Quetzalcóatl | F7 + F1 | Medio | Ojo de Ra, IA | Correlación batch |

---

## 5. Reglas de comportamiento de la AI (blindaje)

1. **Rechazar diseños inseguros**. Si un diseño propone secrets en texto, servicios sin segmentación, tablas/APIs sin telemetría → la AI lo marca **inválido** y propone alternativa.
2. **Priorizar defensa sobre feature** en planos 01–03.
3. **Nunca asumir entorno benigno** — no hay "solo para pruebas" en componentes con ruta a producción.
4. **Conectar todo con los sistemas de defensa**: EOCT, GEMET, CITEMESH, 4L, SDMD-7, KORIMA y kernels siempre pasan por Anubis / Horus / Dekateotl / Ojo de Ra / Quetzalcóatl en diseño.

---

## 6. Condición de avance

La AI **no puede pasar al Plano 01** si este documento no contiene:
- Análisis de amenaza concreto.
- Protect surface declarada.
- Tabla de criticidad y modo degradado.
- Estrategia de defensa por escenario.

Documentos hermanos obligatorios antes de Plano 02:
- `security/zero-trust-battle-ready.md`
- `security/microservices-zero-trust-design.md` (SPIFFE/SPIRE)
- `security/hybrid-encryption-strategy.md`
- `security/kms-hybrid-architecture-atlas.md`
- `security/segmentation-architecture-atlas.md`
- `security/circuit-breaker-thresholds-atlas.md`
- `security/input-validation-paranoid-mode.md`
- `observability/security-signals-spec.md`
- `observability/anomaly-detection-spec-kernel03.md`
- `tests/security/atlas-injection-and-stress-plan.md`
