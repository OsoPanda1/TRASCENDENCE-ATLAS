
-- ============================================================
-- Atlas Trascendence · Roles & Admin Whitelist (Plano 01)
-- ============================================================

CREATE TYPE public.app_role AS ENUM (
  'atlas_supreme',
  'federation_admin',
  'security_officer',
  'auditor',
  'contributor',
  'citizen',
  'guest'
);

CREATE TYPE public.atlas_federation AS ENUM (
  'F1','F2','F3','F4','F5','F6','F7','ALL'
);

-- ---------- user_roles ----------
CREATE TABLE public.user_roles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  federation public.atlas_federation NOT NULL DEFAULT 'ALL',
  granted_by UUID REFERENCES auth.users(id),
  reason TEXT,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role, federation)
);

GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own roles"
ON public.user_roles FOR SELECT TO authenticated
USING (auth.uid() = user_id);

-- ---------- has_role (SECURITY DEFINER, no recursion) ----------
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
      AND (expires_at IS NULL OR expires_at > now())
  );
$$;

-- Auditors / supremes can read everything
CREATE POLICY "Supremes and auditors can view all roles"
ON public.user_roles FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'atlas_supreme')
  OR public.has_role(auth.uid(), 'auditor')
);

-- ---------- admin_whitelist ----------
CREATE TABLE public.admin_whitelist (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  role public.app_role NOT NULL DEFAULT 'atlas_supreme',
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT ON public.admin_whitelist TO authenticated;
GRANT ALL ON public.admin_whitelist TO service_role;

ALTER TABLE public.admin_whitelist ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only supremes can view whitelist"
ON public.admin_whitelist FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'atlas_supreme'));

-- Seed canonical supreme admins
INSERT INTO public.admin_whitelist (email, role, reason) VALUES
  ('tamvonlinenetwork@outlook.es', 'atlas_supreme', 'Custodia institucional TAMV ONLINE NETWORK'),
  ('ecastillotrejo1983@gmail.com', 'atlas_supreme', 'Arquitecto fundador Atlas Trascendence')
ON CONFLICT (email) DO NOTHING;

-- ---------- trigger: auto-grant on signup if email is whitelisted ----------
CREATE OR REPLACE FUNCTION public.handle_new_atlas_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _wl public.admin_whitelist%ROWTYPE;
BEGIN
  -- always grant baseline citizen
  INSERT INTO public.user_roles (user_id, role, federation, reason)
  VALUES (NEW.id, 'citizen', 'ALL', 'baseline on signup')
  ON CONFLICT DO NOTHING;

  -- if whitelisted, grant declared role
  SELECT * INTO _wl FROM public.admin_whitelist WHERE lower(email) = lower(NEW.email);
  IF FOUND THEN
    INSERT INTO public.user_roles (user_id, role, federation, reason)
    VALUES (NEW.id, _wl.role, 'ALL', COALESCE(_wl.reason, 'admin whitelist'))
    ON CONFLICT DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created_atlas ON auth.users;
CREATE TRIGGER on_auth_user_created_atlas
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_atlas_user();

-- Backfill: if these admins already signed up, grant them now
INSERT INTO public.user_roles (user_id, role, federation, reason)
SELECT u.id, w.role, 'ALL', COALESCE(w.reason, 'admin whitelist backfill')
FROM auth.users u
JOIN public.admin_whitelist w ON lower(u.email) = lower(w.email)
ON CONFLICT DO NOTHING;
