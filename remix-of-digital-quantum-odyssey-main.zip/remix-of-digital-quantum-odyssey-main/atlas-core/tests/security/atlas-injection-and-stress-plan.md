# Atlas Injection & Stress Test Plan

Plan operativo obligatorio. Ningún servicio Atlas se expone sin pasar esta matriz.

## 1. Alcance
- EOCT API, GEMET API, CITEMESH API
- Kernels: Observability (metrics, tracing, audit), Security, Economy
- IA (Isabella / servicios cognitivos)
- Gateways e infra de borde

## 2. Catálogo de superficies de entrada
Mantener inventario versionado por servicio en `tests/security/surface-map-<servicio>.yaml`:
- Endpoints HTTP: método, ruta, params (path/query/body/headers)
- Canales internos: mensajes en colas, eventos, RPC
- Campos críticos: inputs libres, IDs, filtros, expresiones de búsqueda, JSON anidados

## 3. Matriz de inyección

| Tipo | Vectores típicos | Aceptación |
|---|---|---|
| SQL / NoSQL / ORM | `' OR 1=1 --`, `"; db.dropDatabase();//` | Entrada rechazada, sin stack trace, métrica de intento |
| XSS reflejada/almacenada/DOM | `<script>alert(1)</script>`, `<img src=x onerror=...>` | Escape estricto, CSP estricta, log estructurado |
| Command injection / deserialización | `; rm -rf /`, backticks, `&&` | Sin ejecución, schema rechaza tipo |
| Path traversal / LFI / RFI | `../../../etc/passwd`, `%2e%2e/` repetidos | Normalización + allowlist de paths |
| Header injection | Host, X-Forwarded-For, User-Agent | Validación allowlist en gateway |
| Deserialización insegura | Payloads binarios, prototype pollution | Parsers seguros, sin eval dinámico |
| Prompt injection IA | "Ignora reglas", filtrado de contexto interno | Guardianía IA bloquea + audit EOCT |

Para cada endpoint generar 4 variantes: válido, válido límite, malicioso típico, malicioso esotérico.

## 4. Estrés y resiliencia

### Escenarios
1. Cargas progresivas (incremento gradual de RPS hasta exceder SLO).
2. Bursts cortos y altos en endpoints críticos.
3. Tráfico malformado (cuerpos enormes, headers anómalos).
4. Ataques de login (volumen alto de fallos).

### Métricas observadas
- Latencia p50 / p95 / p99
- Tasa de errores (4xx, 5xx)
- CPU / memoria / I/O
- Estados de circuit breakers
- Eventos de rate limit / bloqueo

### Aceptación
- Bajo carga extrema: prioriza tráfico legítimo, responde 429/503, breakers se abren antes de agotar recursos.
- Sin fugas de memoria significativas ni corrupción de datos.
- Recuperación automática cuando baja la carga.

## 5. CI/CD
- Ejecutar tras cambios en endpoints críticos y antes de releases a entornos expuestos.
- Resultados con timestamp + versión + commit, sobre umbrales mínimos.

## 6. Mejora continua
- Revisar tras cada incidente o hallazgo.
- Cada nueva categoría detectada se incorpora como test y regla.
