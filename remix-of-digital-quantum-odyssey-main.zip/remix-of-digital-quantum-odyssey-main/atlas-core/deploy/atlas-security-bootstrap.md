# Atlas Security Bootstrap · Playbook maestro

Orden canónico de aplicación. Cada paso es **gate**: sin verificación verde, no se avanza.

## Fase A · Doctrina y políticas (Plano 00–01)
1. `docs/atlas-doctrine-v1.md` ratificada (hash anclado en MSR).
2. `security/zero-trust-battle-ready.md` + `security/microservices-zero-trust-design.md` aprobados.
3. `security/service-policies.yaml` cargado en PDP central (OPA o equivalente).
4. SPIFFE/SPIRE desplegado; cada workload con SVID rotativo (≤ 12 h).

## Fase B · KMS y criptografía híbrida (Plano 02)
5. `security/kms-hybrid-architecture-atlas.md` materializado.
6. TLS híbrido (X25519 + Kyber) activo en gateways y mesh.
7. Anclaje Bookpi/MSR/ELITE HEHEP probado contra `eoct.audit_log`.

## Fase C · Resiliencia (Plano 02)
8. Circuit breakers (`config/circuit-breakers/*.yaml`) desplegados.
9. Modo ataque (overrides en `edge-gateway.yaml`) probado en staging.

## Fase D · Validación paranoica (Plano 02)
10. `security/input-validation-paranoid-mode.md` aplicado a todo endpoint.
11. Schemas Zod por endpoint; rechazo + log en cada violación.

## Fase E · Observabilidad y detección (Plano 03)
12. `observability/security-signals-spec.md` + `observability/anomaly-detection-spec-kernel03.md` instrumentados.
13. EOCT recibe eventos `abac.decision`, `ai.decision`, `circuit_breaker.state_changed`.

## Fase F · Pruebas (Plano 03)
14. `tests/security/atlas-injection-and-stress-plan.md` ejecutado en CI.
15. Simulación end-to-end: DDoS / ransomware / compromiso de claves — pasar checklist.

## Condiciones para marcar un servicio "exponible"
- SPIFFE ID emitido y atestiguado.
- Entrada en `service-policies.yaml` con `allowed_inbound`/`outbound`.
- Surface map `tests/security/surface-map-<svc>.yaml` versionado.
- Circuit breaker config presente.
- Cobertura mínima del plan de inyección/estrés ≥ 90%.
- Eventos EOCT visibles en Ojo de Ra durante 24h sin anomalías abiertas.
- Firma de Anubis + cuórum de 2 administradores supremos.

## Administradores supremos (semilla)
- `tamvonlinenetwork@outlook.es`
- `ecastillotrejo1983@gmail.com`

Ambos heredan rol `atlas_supreme` vía `admin_whitelist` + trigger en alta de usuario.
