# Anomaly Detection Spec — Kernel 03

## Qué es anomalía en Atlas

### Métricas
- Picos en error rate, latencia, tasa de login fallida.
- Tráfico inusual por servicio (volumen, geo, horario, identidad).

### Logs
- Patrones de errores desconocidos.
- Intentos repetidos a recursos restringidos.
- Cambios repetitivos de configuración o policies.

### Trazas
- Flujos inesperados entre servicios (rutas no contempladas).
- Cambios bruscos en path típicos de ejecución.

## Estrategias

### Estadísticas
- Umbrales, desviación estándar, z-score, percentiles.
- Baseline por servicio + por ventana horaria.

### Time series / ML
- Modelos de cambio de patrón por (servicio, métrica).
- Detección de drift en distribuciones.

### Reglas específicas
- Firmas de ataques conocidos (scanning, fuzz, credential stuffing).
- Correlación de eventos con allowlist conocida.

## Integración con radares y guardianías

| Radar | Rol |
|---|---|
| **Ojo de Ra** | Anomalías técnicas (errores, latencia, tráfico). |
| **Quetzalcóatl** | Correlación técnica ↔ semántica (decisiones IA extrañas, cambios de conocimiento). |
| **Guardianías** | Acciones automáticas: bloqueo, degradación, notificación, protocolo de emergencia. |

## Severidad y acciones automáticas
| Nivel | Trigger | Acción |
|---|---|---|
| Info | Desviación leve | Log enriquecido |
| Low | Anomalía aislada | Alerta a panel |
| Medium | Anomalía sostenida | Notificación on-call + inspección |
| High | Patrón hostil claro | Bloqueo + degradación controlada |
| Critical | Compromiso probable | Aislar segmento + revocación SVIDs + postmortem |

## Pipeline mínimo
1. Ingesta LTOS → almacenamiento métricas/logs/traces.
2. Reglas estáticas + detectores estadísticos en streaming.
3. Modelos batch para drift / pattern change.
4. Salida → Ojo de Ra → guardianías → audit EOCT + BookPI.
