# Security Signals Spec — Kernel 03

Señales de observabilidad con prioridad máxima para detección temprana de ataques.

## Logs prioritarios
- Autenticación / autorización (éxito y fallo, con identidad y route).
- Cambios de policies y de configuración.
- Accesos a recursos restringidos (allowed + denied).
- Errores no esperados en endpoints públicos.
- Rechazos de mTLS / SVID expirado / SPIFFE mismatch.

## Métricas prioritarias
- `auth_failed_total{service,reason,identity}`
- `policy_denied_total{service,route,identity}`
- `mtls_handshake_failed_total{peer_spiffe_id,reason}`
- `request_error_rate{service,route,status}`
- `request_latency_seconds_bucket{service,route}` (p95, p99 con alertas)
- `traffic_anomaly_score{service,route}` (alimenta detección)
- `rate_limit_blocked_total{service,route,identity}`
- `circuit_breaker_state{...}` (ver `circuit-breaker-thresholds-atlas.md`)

## Trazas con foco seguridad
Cada span incluye: SPIFFE ID origen, SPIFFE ID destino, route, policy aplicada, decisión, latencia.
Permite reconstruir ruta de un atacante atravesando segmentos.

## Forense
Cada incidente entrega:
- Hilo de EOCT correlacionado.
- Spans completos del periodo.
- Snapshot de policies vigentes.
- Anclaje BookPI/MSR del informe.

## Reglas de severidad (mínimas)
| Señal | Severidad | Acción |
|---|---|---|
| `auth_failed_total` >50/min para misma identidad | High | Bloqueo + alerta a Anubis |
| `policy_denied_total` con patrón scanning | High | Bloqueo IP + audit |
| `mtls_handshake_failed_total` >umbral por par | Critical | Revocación SVID, escalado Horus |
| `request_error_rate` >10% en 5 min en HVA | Critical | Activar circuit breaker + alerta on-call |
| `traffic_anomaly_score` >threshold | Medium → High | Inspección Ojo de Ra + Quetzalcóatl |
