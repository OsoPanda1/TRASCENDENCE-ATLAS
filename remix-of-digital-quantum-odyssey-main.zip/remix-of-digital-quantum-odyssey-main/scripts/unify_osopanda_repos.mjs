#!/usr/bin/env node
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import { spawnSync } from 'node:child_process';

const DEFAULT_REPOS = [
  'DOCUMENTACION-TAMV-DM-X4-e-ISABELLA-AI',
  'tamvweb-fb822252',
  'genesis-digytamv-nexus-927b1ee8',
  'tamv-core-atlas',
  'tamv-documentacion',
];

const args = new Map();
for (let i = 2; i < process.argv.length; i += 2) {
  const key = process.argv[i];
  const value = process.argv[i + 1];
  if (!key?.startsWith('--')) continue;
  args.set(key.slice(2), value ?? 'true');
}

const owner = args.get('owner') ?? 'OsoPanda1';
const prefixRoot = args.get('prefix-root') ?? 'federation';
const manifestPath = args.get('manifest') ?? 'docs/repo-unification-manifest.json';
const importMode = args.get('import-mode') ?? 'none';
const repos = (args.get('repos')?.split(',') ?? DEFAULT_REPOS).map((repo) => repo.trim()).filter(Boolean);

if (!['none', 'squash'].includes(importMode)) {
  throw new Error('--import-mode debe ser none o squash');
}

const manifest = {
  generated_at_utc: new Date().toISOString(),
  owner,
  prefix_root: prefixRoot,
  import_mode: importMode,
  repo_count: repos.length,
  repos: repos.map((name) => ({
    name,
    clone_url: `https://github.com/${owner}/${name}.git`,
    html_url: `https://github.com/${owner}/${name}`,
    import_prefix: `${prefixRoot}/${name}`,
  })),
};

await mkdir(dirname(manifestPath), { recursive: true });
await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
console.log(`Manifiesto generado en ${manifestPath}`);

if (importMode === 'none') process.exit(0);

for (const repo of manifest.repos) {
  const exists = spawnSync('git', ['ls-tree', '-d', '--name-only', 'HEAD', repo.import_prefix], { encoding: 'utf8' });
  if (exists.stdout.trim() === repo.import_prefix) {
    console.log(`[SKIP] ${repo.name} ya existe en ${repo.import_prefix}`);
    continue;
  }
  const remote = `tmp-${repo.name}-${Date.now()}`;
  for (const cmd of [
    ['remote', 'add', remote, repo.clone_url],
    ['fetch', remote, 'HEAD'],
    ['subtree', 'add', '--prefix', repo.import_prefix, remote, 'HEAD', '--squash', '-m', `chore(unify): importar ${repo.name} en ${repo.import_prefix}`],
    ['remote', 'remove', remote],
  ]) {
    const result = spawnSync('git', cmd, { stdio: 'inherit' });
    if (result.status !== 0) process.exit(result.status ?? 1);
  }
}
