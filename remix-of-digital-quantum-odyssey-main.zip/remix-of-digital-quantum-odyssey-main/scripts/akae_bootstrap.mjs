#!/usr/bin/env node
/**
 * AKAE Bootstrap — extrae los dos zips canónicos y los absorbe vía atlas-akae-absorb.
 * Uso: node scripts/akae_bootstrap.mjs
 * Requiere VITE_SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY (o un JWT de gobierno) en env.
 */
import { execSync } from "node:child_process";
import { readFileSync, readdirSync, statSync, mkdirSync, writeFileSync } from "node:fs";
import { join, relative } from "node:path";

const UPLOAD_DIR = "/mnt/user-uploads";
const STAGING = "/tmp/akae-staging";
const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
const KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_PUBLISHABLE_KEY;

const ZIPS = ["kernel-tamv-main_1.zip", "tamv-core-atlas-main-2.zip"];
const EXTRA_MD = ["kernel_canonico_isabella_villasenor_ai.md", "pasted-2026-06-14T07-37-40-774Z.txt"];

const ALLOWED = /\.(md|mdx|ts|tsx|js|jsx|json|yaml|yml|toml|sql|py|rs)$/i;
const MAX_BYTES = 80_000;

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    if (name === "node_modules" || name === ".git" || name === "dist") continue;
    const p = join(dir, name);
    const s = statSync(p);
    if (s.isDirectory()) walk(p, out);
    else if (ALLOWED.test(name) && s.size < 500_000) out.push(p);
  }
  return out;
}

async function absorb(sourceLabel, files) {
  const payload = {
    source_label: sourceLabel,
    source_type: "zip",
    default_domain: "atlas",
    default_risk: "INTERNAL",
    files: files.map((p) => ({
      path: p.relative,
      content: readFileSync(p.full, "utf8").slice(0, MAX_BYTES),
      source: `upload://${sourceLabel}`,
    })),
  };
  const r = await fetch(`${SUPABASE_URL}/functions/v1/atlas-akae-absorb`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${KEY}` },
    body: JSON.stringify(payload),
  });
  return await r.json();
}

async function main() {
  if (!SUPABASE_URL || !KEY) throw new Error("Faltan SUPABASE_URL/SERVICE_ROLE_KEY");
  mkdirSync(STAGING, { recursive: true });
  mkdirSync("data/akae", { recursive: true });
  const report = { started_at: new Date().toISOString(), corpora: [] };

  for (const zip of ZIPS) {
    const src = join(UPLOAD_DIR, zip);
    const dest = join(STAGING, zip.replace(/\.zip$/, ""));
    mkdirSync(dest, { recursive: true });
    console.log(`[akae] unzip ${zip}`);
    execSync(`unzip -oq "${src}" -d "${dest}"`, { stdio: "inherit" });
    const all = walk(dest).map((full) => ({ full, relative: relative(dest, full) }));
    // Process in chunks of 50
    let entities = 0, relations = 0;
    for (let i = 0; i < all.length; i += 50) {
      const chunk = all.slice(i, i + 50);
      const res = await absorb(`${zip}#${i}`, chunk);
      console.log(`  chunk ${i}: ${JSON.stringify(res)}`);
      entities += res.entities ?? 0;
      relations += res.relations ?? 0;
    }
    report.corpora.push({ zip, files: all.length, entities, relations });
  }

  // Extra .md / .txt seeds
  const extras = EXTRA_MD
    .map((n) => join(UPLOAD_DIR, n))
    .filter((p) => { try { return statSync(p).isFile(); } catch { return false; } })
    .map((p) => ({ full: p, relative: p.split("/").pop() }));
  if (extras.length) {
    const res = await absorb("seeds-canon-md", extras);
    report.corpora.push({ zip: "seeds-canon-md", files: extras.length, ...res });
  }

  report.finished_at = new Date().toISOString();
  writeFileSync("data/akae/bootstrap-report.json", JSON.stringify(report, null, 2));
  console.log("[akae] reporte: data/akae/bootstrap-report.json");
}

main().catch((e) => { console.error(e); process.exit(1); });
