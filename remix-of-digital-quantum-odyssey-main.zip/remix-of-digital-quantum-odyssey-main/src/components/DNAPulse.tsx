import { useEffect, useRef } from "react";

interface DNAPulseProps {
  /** Velocidad base de la animación, 1 = default */
  speed?: number;
  /** Intensidad del pulso, 0–1 */
  intensity?: number;
}

/**
 * DNAPulse – doble hélice dinámica con pulso y microchispas,
 * pensada como firma visual viva del kernel Isabella / Atlas.
 */
export default function DNAPulse({ speed = 1, intensity = 1 }: DNAPulseProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = (canvas.width = canvas.parentElement?.clientWidth ?? 320);
    let h = (canvas.height = canvas.parentElement?.clientHeight ?? 480);

    let rafId: number;
    let t = 0;
    let lastTime = performance.now();

    const strandBaseAmplitude = 34;
    const strandRadius = 2.4;
    const strandCount = 56;
    const basePairEvery = 2;
    const pulseRadiusBase = 6;
    const maxGlowRadius = 22;

    // Pequeñas chispas que suben y bajan por la hélice
    const sparks = Array.from({ length: 6 }).map(() => ({
      phase: Math.random() * Math.PI * 2,
      offset: Math.random(),
      side: Math.random() > 0.5 ? 1 : -1,
    }));

    const resize = () => {
      w = canvas.width = canvas.parentElement?.clientWidth ?? 320;
      h = canvas.height = canvas.parentElement?.clientHeight ?? 480;
    };

    const drawBackground = () => {
      const gradient = ctx.createLinearGradient(0, 0, 0, h);
      gradient.addColorStop(0, "rgba(15,23,42,0.05)");
      gradient.addColorStop(0.4, "rgba(15,23,42,0.35)");
      gradient.addColorStop(1, "rgba(15,23,42,0.9)");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, w, h);

      // Línea vertical sutil (columna vertebral)
      ctx.beginPath();
      ctx.moveTo(w / 2, 0);
      ctx.lineTo(w / 2, h);
      ctx.strokeStyle = "rgba(15,118,110,0.12)"; // teal-700
      ctx.lineWidth = 0.6;
      ctx.stroke();
    };

    const drawDNA = (time: number) => {
      const centerX = w / 2;

      // Ligero sway lateral de toda la hélice
      const sway = Math.sin(time * 0.4) * 8;

      for (let i = 0; i < strandCount; i++) {
        const progress = i / strandCount;
        const y = progress * h;

        // Amplitud modulada (respiración)
        const amplitude =
          strandBaseAmplitude *
          (1 + 0.12 * Math.sin(time * 0.8 + progress * Math.PI * 2));

        const baseFreq = 0.55 * speed;
        const phase = time * baseFreq + progress * Math.PI * 2;
        const xCenter = centerX + sway * (1 - progress * 0.4);

        const x1 = xCenter + Math.sin(phase) * amplitude;
        const x2 = xCenter + Math.sin(phase + Math.PI) * amplitude;

        const alpha1 = 0.38 + Math.sin(phase) * 0.25;
        const alpha2 = 0.26 + Math.cos(phase) * 0.2;

        // Strand A (Isabella – cyan)
        ctx.beginPath();
        ctx.fillStyle = `rgba(56,189,248,${alpha1 * intensity})`; // cyan-400
        ctx.arc(x1, y, strandRadius, 0, Math.PI * 2);
        ctx.fill();

        // Strand B (Atlas – slate)
        ctx.beginPath();
        ctx.fillStyle = `rgba(148,163,184,${alpha2 * intensity})`; // slate-400
        ctx.arc(x2, y, strandRadius, 0, Math.PI * 2);
        ctx.fill();

        // Base pairs
        if (i % basePairEvery === 0) {
          ctx.beginPath();
          ctx.moveTo(x1, y);
          ctx.lineTo(x2, y);
          const bridgeAlpha = 0.18 + Math.sin(time * 0.7 + i * 0.35) * 0.08;
          ctx.strokeStyle = `rgba(96,165,250,${bridgeAlpha * intensity})`; // blue-400
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }
    };

    const drawPulse = (time: number) => {
      const centerX = w / 2;
      const pulseSpeed = 48 * speed;

      // Pulso principal
      const pulseY = (time * pulseSpeed) % h;

      // Micro-ruido vertical para que no sea perfectamente periódico
      const jitter = Math.sin(time * 2.3) * 4 * (1 - pulseY / h);
      const effectiveY = pulseY + jitter;

      const beat = 1 + Math.sin(time * 1.4) * 0.25;
      const innerRadius = pulseRadiusBase * beat;
      const outerRadius = Math.min(
        maxGlowRadius,
        pulseRadiusBase * 2.4 * beat * intensity,
      );

      // Glow exterior
      ctx.beginPath();
      const radial = ctx.createRadialGradient(
        centerX,
        effectiveY,
        innerRadius * 0.3,
        centerX,
        effectiveY,
        outerRadius,
      );
      radial.addColorStop(0, "rgba(56,189,248,0.38)");
      radial.addColorStop(1, "rgba(56,189,248,0.0)");
      ctx.fillStyle = radial;
      ctx.arc(centerX, effectiveY, outerRadius, 0, Math.PI * 2);
      ctx.fill();

      // Núcleo del pulso
      ctx.beginPath();
      ctx.arc(centerX, effectiveY, innerRadius, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(56,189,248,0.85)";
      ctx.fill();

      // Contorno
      ctx.beginPath();
      ctx.arc(centerX, effectiveY, innerRadius + 2, 0, Math.PI * 2);
      ctx.strokeStyle = "rgba(56,189,248,0.4)";
      ctx.lineWidth = 1;
      ctx.stroke();
    };

    const drawSparks = (time: number) => {
      const centerX = w / 2;
      const baseFreq = 0.55 * speed;

      sparks.forEach((spark, idx) => {
        // Movimiento arriba/abajo
          const baseY = ((time * 20 * speed + spark.offset * h) % (h + 40)) - 20;

        if (baseY < 0 || baseY > h) return;

        const progress = baseY / h;
        const amplitude =
          strandBaseAmplitude *
          (1 + 0.1 * Math.sin(time * 0.9 + progress * Math.PI * 2));

        const phase = time * baseFreq + progress * Math.PI * 2 + spark.phase;
        const x =
          centerX +
          spark.side *
            Math.sin(phase) *
            amplitude *
            (0.75 + 0.25 * Math.sin(time * 0.5 + idx));

        const alpha = 0.25 + 0.2 * Math.sin(time * 1.1 + idx);

        ctx.beginPath();
        ctx.arc(x, baseY, 2, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(251,191,36,${alpha})`; // amber-400
        ctx.fill();
      });
    };

    const animate = (now: number) => {
      const delta = (now - lastTime) / 1000;
      lastTime = now;
      t += delta * speed;

      drawBackground();
      drawDNA(t);
      drawPulse(t);
      drawSparks(t);

      rafId = requestAnimationFrame(animate);
    };

    // Primer render
    drawBackground();
    lastTime = performance.now();
    rafId = requestAnimationFrame(animate);

    const handleResize = () => {
      resize();
    };

    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener("resize", handleResize);
    };
  }, [speed, intensity]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      aria-hidden="true"
    />
  );
}
