import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ShieldCheck, XCircle, Loader2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export default function AdminKYC() {
  const { user, roles } = useAuth();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [notes, setNotes] = useState<Record<string, string>>({});

  const isAdmin = roles?.includes("admin");

  useEffect(() => { if (isAdmin) load(); else setLoading(false); }, [isAdmin]);

  async function load() {
    setLoading(true);
    const { data, error } = await supabase.functions.invoke("kyc-service", { body: { intent: "list_pending" } });
    if (error) toast.error(error.message);
    setItems(data?.records ?? []);
    setLoading(false);
  }

  async function decide(kyc_id: string, decision: "verified" | "rejected") {
    const { error } = await supabase.functions.invoke("kyc-service", {
      body: { intent: "verify", kyc_id, decision, notes: notes[kyc_id] ?? "" },
    });
    if (error) { toast.error(error.message); return; }
    toast.success(`KYC ${decision}`);
    load();
  }

  if (!user) return <div className="p-12 text-center text-slate-400">Inicia sesión.</div>;
  if (!isAdmin) return <div className="p-12 text-center text-slate-400">Solo administradores pueden ver esta página.</div>;

  return (
    <div className="min-h-[calc(100vh-40px)] bg-slate-950 p-6">
      <div className="max-w-5xl mx-auto space-y-4">
        <header className="rounded-xl border border-emerald-500/20 bg-slate-900/60 p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-8 h-8 text-emerald-400" />
            <div>
              <h1 className="text-xl font-bold text-slate-100">Panel KYC — Admin</h1>
              <p className="text-sm text-slate-400">{items.length} solicitudes pendientes</p>
            </div>
          </div>
          <Button onClick={load} variant="outline" size="sm">Refrescar</Button>
        </header>

        {loading ? (
          <div className="text-center py-12"><Loader2 className="w-6 h-6 animate-spin mx-auto text-slate-400" /></div>
        ) : items.length === 0 ? (
          <Card className="bg-slate-900/60 border-slate-800 p-12 text-center text-slate-400">No hay KYC pendientes.</Card>
        ) : (
          items.map((it) => (
            <Card key={it.id} className="bg-slate-900/60 border-slate-800 p-5 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-mono text-slate-300">user: {it.user_id.slice(0, 8)}...</p>
                  <p className="text-xs text-slate-500">{new Date(it.created_at).toLocaleString()}</p>
                </div>
                <Badge className="bg-amber-500/20 text-amber-300">{it.status}</Badge>
              </div>
              <dl className="text-xs text-slate-400 grid grid-cols-2 md:grid-cols-4 gap-1">
                <dt>Doc</dt><dd className="text-slate-200">{it.document_type}</dd>
                <dt>Jur</dt><dd className="text-slate-200">{it.jurisdiction}</dd>
                <dt className="col-span-2">Hash</dt><dd className="col-span-2 font-mono text-[10px] break-all">{it.document_hash}</dd>
              </dl>
              <Textarea placeholder="Notas (opcional)"
                value={notes[it.id] ?? ""} onChange={(e) => setNotes({ ...notes, [it.id]: e.target.value })}
                className="bg-slate-950 border-slate-700 min-h-[60px]" />
              <div className="flex gap-2">
                <Button onClick={() => decide(it.id, "verified")} className="flex-1 bg-emerald-600 hover:bg-emerald-500">
                  <ShieldCheck className="w-4 h-4 mr-1" /> Aprobar
                </Button>
                <Button onClick={() => decide(it.id, "rejected")} variant="destructive" className="flex-1">
                  <XCircle className="w-4 h-4 mr-1" /> Rechazar
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
