import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle2, XCircle, Lock, KeyRound } from "lucide-react";

async function sha256Hex(s: string) {
  const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return Array.from(new Uint8Array(d)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

export default function CleiAudit() {
  const [items, setItems] = useState<any[]>([]);
  const [keys, setKeys] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [verification, setVerification] = useState<{ valid: number; invalid: number; checked: number } | null>(null);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    const [{ data: c }, { data: k }] = await Promise.all([
      supabase.from("clei_audit").select("*").order("sequence", { ascending: false }).limit(50),
      supabase.from("pqc_keys").select("*").order("created_at", { ascending: false }).limit(20),
    ]);
    setItems(c ?? []);
    setKeys(k ?? []);
    setLoading(false);
  }

  async function verifyChain() {
    // Verify hash chain integrity client-side
    const sorted = [...items].sort((a, b) => a.sequence - b.sequence);
    let valid = 0, invalid = 0;
    for (const it of sorted) {
      const expected = await sha256Hex((it.prev_hash ?? "") + (await sha256Hex(JSON.stringify(it.payload))) + it.signature);
      if (expected === it.hash) valid++;
      else invalid++;
    }
    setVerification({ valid, invalid, checked: sorted.length });
  }

  return (
    <div className="min-h-[calc(100vh-40px)] bg-slate-950 p-6">
      <div className="max-w-6xl mx-auto space-y-4">
        <header className="rounded-xl border border-violet-500/20 bg-slate-900/60 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Lock className="w-8 h-8 text-violet-400" />
              <div>
                <h1 className="text-xl font-bold text-slate-100">CLEI · Cadena Ética Inmutable</h1>
                <p className="text-sm text-slate-400">Constitutional Layer Ethical Immutable Audit · firmas PQC + hash chain tipo merkle</p>
              </div>
            </div>
            <Button onClick={verifyChain} variant="outline" size="sm" disabled={!items.length}>
              Verificar integridad
            </Button>
          </div>
          {verification && (
            <div className="mt-4 flex gap-2">
              <Badge className="bg-emerald-500/20 text-emerald-300">
                <CheckCircle2 className="w-3 h-3 mr-1" /> {verification.valid} válidos
              </Badge>
              {verification.invalid > 0 && (
                <Badge className="bg-red-500/20 text-red-300">
                  <XCircle className="w-3 h-3 mr-1" /> {verification.invalid} alterados
                </Badge>
              )}
              <span className="text-xs text-slate-500 self-center">de {verification.checked} entradas verificadas</span>
            </div>
          )}
        </header>

        {/* PQC keys */}
        <Card className="bg-slate-900/60 border-slate-800 p-5">
          <div className="flex items-center gap-2 mb-3">
            <KeyRound className="w-5 h-5 text-cyan-400" />
            <h2 className="text-sm font-semibold text-slate-200">Claves PQC activas</h2>
            <Badge className="bg-cyan-500/20 text-cyan-300 text-[10px]">{keys.length}</Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {keys.length === 0 && <p className="text-xs text-slate-500">Ninguna clave generada aún.</p>}
            {keys.map((k) => (
              <div key={k.id} className="border border-slate-700 rounded p-3 text-xs">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono text-slate-300">{k.key_id}</span>
                  <Badge className={k.is_pqc_ready ? "bg-emerald-500/20 text-emerald-300" : "bg-amber-500/20 text-amber-300"}>
                    {k.algorithm}
                  </Badge>
                </div>
                <p className="text-slate-500">Status: {k.status} · Creada: {new Date(k.created_at).toLocaleDateString()}</p>
                {!k.is_pqc_ready && (
                  <p className="text-amber-400/80 text-[10px] mt-1">⚠ Fallback Ed25519 (PQC bridge). Activar ML-DSA para producción.</p>
                )}
              </div>
            ))}
          </div>
        </Card>

        {/* Chain */}
        <Card className="bg-slate-900/60 border-slate-800 p-5">
          <h2 className="text-sm font-semibold text-slate-200 mb-3">Últimas 50 entradas CLEI</h2>
          {loading ? (
            <Loader2 className="w-6 h-6 animate-spin mx-auto text-slate-400" />
          ) : items.length === 0 ? (
            <p className="text-xs text-slate-500 text-center py-6">Cadena vacía. Genera una clave PQC y firma un payload para iniciar.</p>
          ) : (
            <div className="space-y-2">
              {items.map((it) => (
                <div key={it.id} className="border border-slate-800 rounded p-3 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-slate-300">#{it.sequence} · {it.event_type}</span>
                    <span className="text-slate-500">{new Date(it.created_at).toLocaleString()}</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-1 text-[10px] text-slate-500 font-mono">
                    <span>hash: {it.hash.slice(0, 20)}...</span>
                    <span>prev: {(it.prev_hash ?? "—").slice(0, 20)}{it.prev_hash ? "..." : ""}</span>
                    <span>key: {it.signing_key_id}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
