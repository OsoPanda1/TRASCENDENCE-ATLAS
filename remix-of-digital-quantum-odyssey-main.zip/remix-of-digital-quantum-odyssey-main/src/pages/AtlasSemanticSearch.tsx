import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Sparkles } from "lucide-react";
import { toast } from "sonner";

interface Match {
  canonical_id: string; type: string; federation: string;
  title: string; description: string | null; similarity: number;
}

export default function AtlasSemanticSearch() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Match[]>([]);
  const [loading, setLoading] = useState(false);
  const [reindexing, setReindexing] = useState(false);

  const search = async () => {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const { data: embed, error: eerr } = await supabase.functions.invoke("embeddings-index", {
        body: { target: "canon_entities", query_text: query },
      });
      if (eerr || !embed?.ok) throw new Error(eerr?.message ?? "Embedding failed");
      const { data, error } = await supabase.rpc("match_canon_entities", {
        query_embedding: embed.embedding,
        match_count: 15,
        filter_federation: null,
        min_similarity: 0.3,
      });
      if (error) throw new Error(error.message);
      setResults((data ?? []) as Match[]);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  };

  const reindex = async () => {
    setReindexing(true);
    try {
      const { data, error } = await supabase.functions.invoke("embeddings-index", {
        body: { target: "canon_entities", batch_size: 50 },
      });
      if (error || !data?.ok) throw new Error(error?.message ?? "reindex failed");
      toast.success(`Indexadas ${data.processed} entidades (${data.failed} fallos)`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : String(e));
    } finally {
      setReindexing(false);
    }
  };

  return (
    <div className="px-6 py-8 space-y-6">
      <header className="rounded-xl border border-cyan-500/20 bg-slate-950/80 p-6">
        <p className="text-[11px] font-mono uppercase tracking-[0.25em] text-cyan-300">Atlas · Semantic Search</p>
        <h1 className="text-2xl font-semibold text-slate-100 mt-1 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-cyan-300" /> Búsqueda vectorial (pgvector + Gemini 1536d)
        </h1>
        <p className="text-sm text-slate-400 mt-2">
          Encuentra entidades canónicas por significado, no por palabras exactas. Usa la cadena CLEI como anclaje.
        </p>
      </header>

      <section className="rounded-xl border border-slate-800 bg-slate-950/60 p-5 space-y-3">
        <div className="flex flex-wrap gap-2">
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Ej: gobernanza ética en metaverso XR"
            onKeyDown={(e) => e.key === "Enter" && search()}
            className="flex-1 min-w-[280px] bg-slate-900 border-slate-700 text-slate-100" />
          <Button onClick={search} disabled={loading}>
            <Search className="w-4 h-4 mr-2" /> Buscar
          </Button>
          <Button variant="outline" onClick={reindex} disabled={reindexing}>
            {reindexing ? "Indexando…" : "Reindexar pendientes"}
          </Button>
        </div>

        <ul className="divide-y divide-slate-800 mt-3">
          {results.map((m) => (
            <li key={m.canonical_id} className="py-3 flex items-start gap-3">
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-mono">
                {(m.similarity * 100).toFixed(1)}%
              </span>
              <div className="flex-1">
                <p className="text-sm text-slate-100">{m.title}</p>
                <p className="text-[11px] text-slate-500 font-mono">
                  {m.federation} · {m.type} · {m.canonical_id}
                </p>
                {m.description && (
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">{m.description}</p>
                )}
              </div>
            </li>
          ))}
          {results.length === 0 && !loading && (
            <li className="py-8 text-center text-slate-500 text-sm">Sin resultados aún</li>
          )}
        </ul>
      </section>
    </div>
  );
}
