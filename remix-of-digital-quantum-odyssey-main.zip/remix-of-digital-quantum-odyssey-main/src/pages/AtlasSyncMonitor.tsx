import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, PlayCircle, Activity, Database, Github } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

interface OrgRun {
  id: string; trace_id: string; owner: string; status: string;
  total_repos: number | null; new_repos: number | null; updated_repos: number | null;
  failed_repos: number | null; started_at: string; finished_at: string | null; error: string | null;
}
interface IngRun {
  id: string; status: string; repo_url: string | null; started_at: string;
  finished_at: string | null; entities_created: number | null; relations_created: number | null; error: string | null;
}
interface ReindexRun {
  id: string; trace_id: string; mode: string; status: string;
  total_candidates: number; processed: number; failed: number;
  started_at: string; finished_at: string | null;
}

export default function AtlasSyncMonitor() {
  const { hasMinRole } = useAuth();
  const isAdmin = hasMinRole("admin");

  const [orgRuns, setOrgRuns] = useState<OrgRun[]>([]);
  const [ingRuns, setIngRuns] = useState<IngRun[]>([]);
  const [reindexRuns, setReindexRuns] = useState<ReindexRun[]>([]);
  const [loading, setLoading] = useState(false);
  const [triggering, setTriggering] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: org }, { data: ing }, { data: rdx }] = await Promise.all([
      supabase.from("org_sync_runs").select("*").order("started_at", { ascending: false }).limit(20),
      supabase.from("ingestion_runs").select("id,status,repo_url,started_at,finished_at,entities_created,relations_created,error").order("started_at", { ascending: false }).limit(30),
      supabase.from("embedding_reindex_runs").select("*").order("started_at", { ascending: false }).limit(20),
    ]);
    setOrgRuns((org ?? []) as OrgRun[]);
    setIngRuns((ing ?? []) as IngRun[]);
    setReindexRuns((rdx ?? []) as ReindexRun[]);
    setLoading(false);
  }, []);

  useEffect(() => { void load(); }, [load]);

  // Realtime channels — push new rows to top, update existing.
  useEffect(() => {
    const ch = supabase.channel("atlas-sync-monitor")
      .on("postgres_changes", { event: "*", schema: "public", table: "org_sync_runs" }, (p) => {
        setOrgRuns((prev) => {
          const next = prev.filter((r) => r.id !== (p.new as OrgRun)?.id);
          if (p.eventType !== "DELETE") next.unshift(p.new as OrgRun);
          return next.slice(0, 20);
        });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "ingestion_runs" }, (p) => {
        setIngRuns((prev) => {
          const next = prev.filter((r) => r.id !== (p.new as IngRun)?.id);
          if (p.eventType !== "DELETE") next.unshift(p.new as IngRun);
          return next.slice(0, 30);
        });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "embedding_reindex_runs" }, (p) => {
        setReindexRuns((prev) => {
          const next = prev.filter((r) => r.id !== (p.new as ReindexRun)?.id);
          if (p.eventType !== "DELETE") next.unshift(p.new as ReindexRun);
          return next.slice(0, 20);
        });
      })
      .subscribe();
    return () => { void supabase.removeChannel(ch); };
  }, []);

  const trigger = async (fn: string, body: Record<string, unknown>, label: string) => {
    if (!isAdmin) return toast.error("Requiere rol admin");
    setTriggering(fn);
    const { data, error } = await supabase.functions.invoke(fn, { body });
    setTriggering(null);
    if (error) return toast.error(`${label}: ${error.message}`);
    toast.success(`${label} disparado · trace=${(data as { trace_id?: string })?.trace_id ?? "—"}`);
    void load();
  };

  const statusBadge = (s: string) => {
    const cls = s === "completed" ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
      : s === "running" ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/40"
      : s === "error" ? "bg-rose-500/20 text-rose-300 border-rose-500/40"
      : "bg-slate-700/40 text-slate-300 border-slate-600";
    return <Badge className={cls}>{s.toUpperCase()}</Badge>;
  };

  const throughput = (r: OrgRun) => {
    if (!r.finished_at || !r.total_repos) return "—";
    const secs = (new Date(r.finished_at).getTime() - new Date(r.started_at).getTime()) / 1000;
    if (secs <= 0) return "—";
    return `${(r.total_repos / secs).toFixed(2)} repos/s`;
  };

  const activeIng = ingRuns.filter((r) => r.status === "running").length;
  const activeOrg = orgRuns.filter((r) => r.status === "running").length;
  const dirtyTotal = reindexRuns[0]?.total_candidates ?? 0;

  return (
    <div className="px-6 py-8 space-y-6">
      <header className="rounded-xl border border-cyan-500/20 bg-slate-950/80 p-6">
        <p className="text-[11px] font-mono uppercase tracking-[0.25em] text-cyan-300">Atlas · Live Sync Monitor</p>
        <h1 className="text-2xl font-semibold text-slate-100 mt-1">Sincronización OsoPanda1 · runtime en vivo</h1>
        <p className="text-sm text-slate-400 mt-2 max-w-3xl">
          Telemetría en tiempo real de federación, ingesta y reindexado incremental de embeddings. Disparadores
          restringidos por rol; observabilidad abierta a auditores.
        </p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4">
          <p className="text-[10px] uppercase text-slate-500">Sync runs activos</p>
          <p className="text-2xl text-cyan-300 font-mono">{activeOrg}</p>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4">
          <p className="text-[10px] uppercase text-slate-500">Ingest runs en curso</p>
          <p className="text-2xl text-cyan-300 font-mono">{activeIng}</p>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4">
          <p className="text-[10px] uppercase text-slate-500">Candidatos a reindex</p>
          <p className="text-2xl text-violet-300 font-mono">{dirtyTotal}</p>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4 flex flex-wrap items-center gap-2">
          <Button size="sm" disabled={!isAdmin || triggering !== null}
            onClick={() => trigger("github-org-sync", { owner: "OsoPanda1", trigger_ingest: true }, "Org sync")}>
            <Github className="w-3 h-3 mr-1" /> Sync OsoPanda1
          </Button>
          <Button size="sm" variant="outline" disabled={!isAdmin || triggering !== null}
            onClick={() => trigger("embeddings-reindex-incremental", { mode: "incremental", max_batches: 4 }, "Reindex")}>
            <Database className="w-3 h-3 mr-1" /> Reindex Δ
          </Button>
          <Button size="sm" variant="ghost" onClick={load} disabled={loading}>
            <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-950/60 p-5 space-y-3">
        <div className="flex items-center gap-2">
          <Github className="w-4 h-4 text-cyan-300" />
          <h2 className="text-sm uppercase tracking-wider text-slate-200">Org sync runs</h2>
        </div>
        <div className="overflow-auto">
          <table className="w-full text-[11px] font-mono">
            <thead className="text-left text-slate-500 border-b border-slate-800">
              <tr>
                <th className="py-2 pr-3">OWNER</th><th className="pr-3">STATUS</th>
                <th className="pr-3">TOTAL</th><th className="pr-3">NEW</th>
                <th className="pr-3">UPDATED</th><th className="pr-3">FAILED</th>
                <th className="pr-3">THROUGHPUT</th><th className="pr-3">START</th>
              </tr>
            </thead>
            <tbody className="text-slate-300">
              {orgRuns.map((r) => (
                <tr key={r.id} className="border-b border-slate-900 hover:bg-slate-900/40">
                  <td className="py-1.5 pr-3 text-cyan-300">{r.owner}</td>
                  <td className="pr-3">{statusBadge(r.status)}</td>
                  <td className="pr-3">{r.total_repos ?? "—"}</td>
                  <td className="pr-3 text-emerald-300">{r.new_repos ?? "—"}</td>
                  <td className="pr-3">{r.updated_repos ?? "—"}</td>
                  <td className="pr-3 text-rose-300">{r.failed_repos ?? "—"}</td>
                  <td className="pr-3 text-slate-400">{throughput(r)}</td>
                  <td className="pr-3 text-slate-500">{new Date(r.started_at).toISOString().slice(11, 19)}</td>
                </tr>
              ))}
              {orgRuns.length === 0 && <tr><td colSpan={8} className="py-6 text-center text-slate-500">Sin runs registrados</td></tr>}
            </tbody>
          </table>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-950/60 p-5 space-y-3">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-violet-300" />
          <h2 className="text-sm uppercase tracking-wider text-slate-200">Reindex incremental (canon_entities)</h2>
        </div>
        <div className="overflow-auto">
          <table className="w-full text-[11px] font-mono">
            <thead className="text-left text-slate-500 border-b border-slate-800">
              <tr>
                <th className="py-2 pr-3">TRACE</th><th className="pr-3">MODE</th><th className="pr-3">STATUS</th>
                <th className="pr-3">CANDIDATES</th><th className="pr-3">PROCESSED</th><th className="pr-3">FAILED</th>
                <th className="pr-3">DURATION</th>
              </tr>
            </thead>
            <tbody className="text-slate-300">
              {reindexRuns.map((r) => {
                const dur = r.finished_at
                  ? `${((new Date(r.finished_at).getTime() - new Date(r.started_at).getTime()) / 1000).toFixed(1)}s`
                  : "live";
                return (
                  <tr key={r.id} className="border-b border-slate-900 hover:bg-slate-900/40">
                    <td className="py-1.5 pr-3 text-violet-300">{r.trace_id.slice(-10)}</td>
                    <td className="pr-3">{r.mode}</td>
                    <td className="pr-3">{statusBadge(r.status)}</td>
                    <td className="pr-3">{r.total_candidates}</td>
                    <td className="pr-3 text-emerald-300">{r.processed}</td>
                    <td className="pr-3 text-rose-300">{r.failed}</td>
                    <td className="pr-3 text-slate-400">{dur}</td>
                  </tr>
                );
              })}
              {reindexRuns.length === 0 && <tr><td colSpan={7} className="py-6 text-center text-slate-500">Sin runs</td></tr>}
            </tbody>
          </table>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-950/60 p-5 space-y-3">
        <div className="flex items-center gap-2">
          <PlayCircle className="w-4 h-4 text-emerald-300" />
          <h2 className="text-sm uppercase tracking-wider text-slate-200">Ingest runs (últimos 30)</h2>
        </div>
        <div className="overflow-auto max-h-[420px]">
          <table className="w-full text-[11px] font-mono">
            <thead className="text-left text-slate-500 border-b border-slate-800 sticky top-0 bg-slate-950">
              <tr>
                <th className="py-2 pr-3">REPO</th><th className="pr-3">STATUS</th>
                <th className="pr-3">ENTITIES</th><th className="pr-3">RELATIONS</th>
                <th className="pr-3">DURATION</th><th className="pr-3">ERROR</th>
              </tr>
            </thead>
            <tbody className="text-slate-300">
              {ingRuns.map((r) => {
                const dur = r.finished_at
                  ? `${((new Date(r.finished_at).getTime() - new Date(r.started_at).getTime()) / 1000).toFixed(1)}s`
                  : "live";
                return (
                  <tr key={r.id} className="border-b border-slate-900 hover:bg-slate-900/40">
                    <td className="py-1.5 pr-3 text-slate-200">{r.repo_url ?? "—"}</td>
                    <td className="pr-3">{statusBadge(r.status)}</td>
                    <td className="pr-3 text-emerald-300">{r.entities_created ?? 0}</td>
                    <td className="pr-3">{r.relations_created ?? 0}</td>
                    <td className="pr-3 text-slate-400">{dur}</td>
                    <td className="pr-3 text-rose-300 truncate max-w-[260px]" title={r.error ?? ""}>{r.error ?? ""}</td>
                  </tr>
                );
              })}
              {ingRuns.length === 0 && <tr><td colSpan={6} className="py-6 text-center text-slate-500">Sin ingest runs</td></tr>}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
