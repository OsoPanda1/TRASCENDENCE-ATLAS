import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";

export default function UTAMVCampus() {
  const [zones, setZones] = useState<any[]>([]);
  useEffect(() => { supabase.from("utamv_campus_zones").select("*").order("ordering").then(({ data }) => setZones(data ?? [])); }, []);
  return (
    <div className="px-6 py-8 space-y-4">
      <header>
        <h1 className="text-2xl font-semibold text-slate-100">Campus Meta-Virtual UTAMV</h1>
        <p className="text-sm text-slate-400">Zonas operativas del campus. Próximamente con escenarios XR navegables.</p>
      </header>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {zones.map(z => (
          <Card key={z.code} className="border-violet-500/20 bg-gradient-to-br from-violet-950/30 to-slate-950">
            <CardContent className="p-5">
              <p className="text-[10px] font-mono uppercase text-violet-300">{z.zone_type}</p>
              <p className="text-lg text-slate-100 font-semibold mt-1">{z.name}</p>
              <p className="text-xs text-slate-400 mt-2">{z.description}</p>
              <div className="mt-4 h-32 rounded bg-gradient-to-br from-violet-500/10 to-cyan-500/10 border border-slate-800 flex items-center justify-center text-xs text-slate-500">
                XR scene · placeholder
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
