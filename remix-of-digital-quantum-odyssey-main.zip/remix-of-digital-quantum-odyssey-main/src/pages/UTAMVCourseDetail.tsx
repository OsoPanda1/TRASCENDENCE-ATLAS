import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/sonner";
import { useAuth } from "@/contexts/AuthContext";

export default function UTAMVCourseDetail() {
  const { code } = useParams();
  const { user } = useAuth();
  const [course, setCourse] = useState<any>(null);
  const [lessons, setLessons] = useState<any[]>([]);
  const [enrolled, setEnrolled] = useState(false);

  useEffect(() => {
    if (!code) return;
    (async () => {
      const { data: c } = await supabase.from("utamv_courses").select("*").eq("code", code).maybeSingle();
      setCourse(c);
      if (c) {
        const { data: l } = await supabase.from("utamv_lessons").select("*").eq("course_id", c.id).order("ordering");
        setLessons(l ?? []);
        if (user) {
          const { data: e } = await supabase.from("utamv_enrollments").select("id").eq("user_id", user.id).eq("course_id", c.id).maybeSingle();
          setEnrolled(!!e);
        }
      }
    })();
  }, [code, user]);

  const enroll = async () => {
    if (!user) return toast.error("Inicia sesión para inscribirte");
    const { error } = await supabase.functions.invoke("utamv-enroll", { body: { course_id: course.id } });
    if (error) toast.error(error.message); else { setEnrolled(true); toast.success("Inscripción confirmada"); }
  };

  if (!course) return <div className="p-8 text-sm text-slate-500">Cargando…</div>;
  return (
    <div className="px-6 py-8 space-y-4 max-w-4xl">
      <header>
        <p className="text-xs font-mono text-cyan-300">{course.code}</p>
        <h1 className="text-2xl text-slate-100 font-semibold">{course.title}</h1>
        <p className="text-sm text-slate-400 mt-2">{course.summary}</p>
      </header>
      <Button onClick={enroll} disabled={enrolled} className="bg-cyan-600 hover:bg-cyan-700">
        {enrolled ? "Ya inscrito" : "Inscribirme"}
      </Button>
      <Card className="border-slate-800 bg-slate-950/60">
        <CardHeader><CardTitle className="text-slate-100 text-base">Lecciones</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {lessons.length === 0 && <p className="text-xs text-slate-500">No hay lecciones publicadas todavía.</p>}
          {lessons.map(l => (
            <div key={l.id} className="text-sm border-b border-slate-800 pb-2">
              <p className="text-slate-200">{l.ordering}. {l.title}</p>
              <p className="text-xs text-slate-500">{l.duration_minutes} min</p>
            </div>
          ))}
        </CardContent>
      </Card>
      {course.learning_outcomes?.length > 0 && (
        <Card className="border-slate-800 bg-slate-950/60">
          <CardHeader><CardTitle className="text-slate-100 text-base">Resultados de aprendizaje</CardTitle></CardHeader>
          <CardContent>
            <ul className="text-sm text-slate-300 list-disc pl-5">{course.learning_outcomes.map((o: string, i: number) => <li key={i}>{o}</li>)}</ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
