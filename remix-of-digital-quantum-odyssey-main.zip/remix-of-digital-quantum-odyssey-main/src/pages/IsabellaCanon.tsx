import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, BookLock, Sparkles, Cpu, Network, Lock } from "lucide-react";

type AnyRow = Record<string, any>;

export default function IsabellaCanon() {
  const [canon, setCanon] = useState<AnyRow | null>(null);
  const [identity, setIdentity] = useState<AnyRow | null>(null);
  const [pillars, setPillars] = useState<AnyRow[]>([]);
  const [functions, setFunctions] = useState<AnyRow[]>([]);
  const [policies, setPolicies] = useState<AnyRow[]>([]);
  const [agents, setAgents] = useState<AnyRow[]>([]);
  const [blueprint, setBlueprint] = useState<AnyRow[]>([]);

  useEffect(() => {
    (async () => {
      const [c, i, p, f, po, a, b] = await Promise.all([
        supabase.from("isabella_canon").select("*").order("created_at", { ascending: false }).limit(1).maybeSingle(),
        supabase.from("isabella_identity").select("*").limit(1).maybeSingle(),
        supabase.from("isabella_pillars").select("*").order("ordering"),
        supabase.from("isabella_functions").select("*").order("category"),
        supabase.from("isabella_policies").select("*").order("priority"),
        supabase.from("isabella_agent_registry").select("*").order("ordering"),
        supabase.from("isabella_blueprint").select("*").order("endpoint"),
      ]);
      setCanon(c.data); setIdentity(i.data); setPillars(p.data ?? []); setFunctions(f.data ?? []);
      setPolicies(po.data ?? []); setAgents(a.data ?? []); setBlueprint(b.data ?? []);
    })();
  }, []);

  return (
    <div className="px-6 py-8 space-y-6 max-w-7xl">
      <header className="rounded-xl border border-violet-500/30 bg-gradient-to-br from-violet-950/40 to-slate-950 p-6">
        <div className="flex items-center gap-3 mb-2">
          <BookLock className="w-6 h-6 text-violet-300" />
          <h1 className="text-2xl font-semibold text-slate-100">Registro Canónico · Isabella Villaseñor AI</h1>
        </div>
        <p className="text-sm text-slate-400">
          Kernel cognitivo, ético, documental y orquestador del ecosistema TAMV. Firmado, versionado e inmutable.
        </p>
        {canon && (
          <div className="mt-4 flex flex-wrap gap-3 text-xs">
            <Badge variant="outline" className="border-violet-500/40 text-violet-300">{canon.version}</Badge>
            <Badge variant="outline" className={canon.locked ? "border-emerald-500/40 text-emerald-300" : "border-amber-500/40 text-amber-300"}>
              <Lock className="w-3 h-3 mr-1" /> {canon.locked ? "LOCKED" : "UNLOCKED"}
            </Badge>
            <span className="font-mono text-slate-500 truncate max-w-md">hash: {canon.hash}</span>
          </div>
        )}
      </header>

      {identity && (
        <Card className="border-slate-800 bg-slate-950/60">
          <CardHeader><CardTitle className="text-slate-100 flex items-center gap-2"><Sparkles className="w-4 h-4 text-violet-300" /> Identidad canónica</CardTitle></CardHeader>
          <CardContent className="grid md:grid-cols-2 gap-4 text-sm text-slate-300">
            <Field label="Nombre canónico" value={identity.canonical_name} />
            <Field label="Alias" value={identity.alias} />
            <Field label="Rol" value={identity.role} />
            <Field label="Dominio" value={identity.domain} />
            <Field label="Naturaleza" value={identity.nature} />
            <Field label="Principio rector" value={identity.guiding_principle} />
            <div className="md:col-span-2"><Field label="Definición técnica" value={identity.technical_definition} /></div>
          </CardContent>
        </Card>
      )}

      <Card className="border-slate-800 bg-slate-950/60">
        <CardHeader><CardTitle className="text-slate-100 flex items-center gap-2"><Shield className="w-4 h-4 text-emerald-300" /> Cinco Pilares</CardTitle></CardHeader>
        <CardContent className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
          {pillars.map(p => (
            <div key={p.code} className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3">
              <p className="text-xs font-mono text-emerald-300">{p.ordering}. {p.code}</p>
              <p className="text-sm text-slate-100 font-medium mt-1">{p.name}</p>
              <p className="text-xs text-slate-400 mt-1">{p.description}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="border-slate-800 bg-slate-950/60">
          <CardHeader><CardTitle className="text-slate-100 flex items-center gap-2"><Cpu className="w-4 h-4 text-cyan-300" /> Funciones</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {functions.map(f => (
              <div key={f.code} className="flex items-start justify-between gap-2 text-xs border-b border-slate-800 pb-2">
                <div>
                  <p className="font-mono text-cyan-300">{f.code}</p>
                  <p className="text-slate-200">{f.name}</p>
                  <p className="text-slate-500">{f.description}</p>
                </div>
                <Badge variant="outline" className="border-slate-700 text-slate-400">{f.category}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-slate-800 bg-slate-950/60">
          <CardHeader><CardTitle className="text-slate-100 flex items-center gap-2"><Network className="w-4 h-4 text-pink-300" /> Micro-agentes</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {agents.map(a => (
              <div key={a.code} className="text-xs border-b border-slate-800 pb-2">
                <p className="font-mono text-pink-300">{a.ordering}. {a.code}</p>
                <p className="text-slate-200">{a.name}</p>
                <p className="text-slate-500">{a.description}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card className="border-slate-800 bg-slate-950/60">
        <CardHeader><CardTitle className="text-slate-100 flex items-center gap-2"><Shield className="w-4 h-4 text-red-300" /> Políticas éticas en runtime</CardTitle></CardHeader>
        <CardContent className="space-y-1">
          {policies.map(p => (
            <div key={p.code} className="flex items-center gap-3 text-xs py-1.5 border-b border-slate-800">
              <Badge variant="outline" className={
                p.decision === "deny" ? "border-red-500/40 text-red-300" :
                p.decision === "escalate" ? "border-amber-500/40 text-amber-300" :
                p.decision === "filter" ? "border-cyan-500/40 text-cyan-300" :
                "border-emerald-500/40 text-emerald-300"
              }>{p.decision.toUpperCase()}</Badge>
              <span className="font-mono text-slate-300 w-48 truncate">{p.code}</span>
              <span className="text-slate-400 flex-1">{p.description}</span>
              <span className="text-slate-500 font-mono">prio {p.priority}</span>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-slate-800 bg-slate-950/60">
        <CardHeader><CardTitle className="text-slate-100">Blueprint API canónico</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {blueprint.map(b => (
            <div key={b.endpoint} className="text-xs border-b border-slate-800 pb-2">
              <p><span className="font-mono text-emerald-300">{b.method}</span> <span className="font-mono text-slate-200">{b.endpoint}</span> <Badge variant="outline" className="ml-2 border-slate-700 text-slate-400">{b.version}</Badge></p>
              <p className="text-slate-500 mt-1">{b.description}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      {canon && (
        <Card className="border-slate-800 bg-slate-950/60">
          <CardHeader><CardTitle className="text-slate-100">Kernel completo (MD)</CardTitle></CardHeader>
          <CardContent>
            <pre className="whitespace-pre-wrap text-xs text-slate-300 font-mono max-h-96 overflow-auto">{canon.content_md}</pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Field({ label, value }: { label: string; value: any }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wider text-slate-500">{label}</p>
      <p className="text-sm text-slate-200">{value ?? "—"}</p>
    </div>
  );
}
