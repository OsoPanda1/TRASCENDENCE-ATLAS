import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ShieldCheck, FileText, Loader2, CheckCircle2, XCircle, Clock } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export default function KYC() {
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [docType, setDocType] = useState("INE");
  const [docNumber, setDocNumber] = useState("");
  const [fullName, setFullName] = useState("");
  const [jurisdiction, setJurisdiction] = useState("MX");
  const [record, setRecord] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (user) load(); }, [user]);

  async function load() {
    const { data } = await supabase.functions.invoke("kyc-service", { body: { intent: "status" } });
    if (data?.record) { setRecord(data.record); setStep(4); }
  }

  async function submit() {
    if (!docNumber || !fullName) { toast.error("Completa los campos"); return; }
    setLoading(true);
    try {
      const payload = `${docType}|${docNumber}|${fullName}|${jurisdiction}`;
      const { data, error } = await supabase.functions.invoke("kyc-service", {
        body: {
          intent: "submit", document_type: docType, document_payload: payload,
          jurisdiction, metadata: { full_name_hint: fullName.slice(0, 3) + "***" },
        },
      });
      if (error) throw error;
      setRecord(data.record); setStep(4);
      toast.success("KYC enviado, en revisión");
    } catch (e: any) { toast.error(e.message); } finally { setLoading(false); }
  }

  const statusBadge = (s: string) => {
    const map: any = {
      pending: { c: "bg-amber-500/20 text-amber-300", i: <Clock className="w-3 h-3" /> },
      in_review: { c: "bg-blue-500/20 text-blue-300", i: <Loader2 className="w-3 h-3 animate-spin" /> },
      verified: { c: "bg-emerald-500/20 text-emerald-300", i: <CheckCircle2 className="w-3 h-3" /> },
      rejected: { c: "bg-red-500/20 text-red-300", i: <XCircle className="w-3 h-3" /> },
      expired: { c: "bg-slate-500/20 text-slate-300", i: <Clock className="w-3 h-3" /> },
    };
    const v = map[s] ?? map.pending;
    return <Badge className={v.c}>{v.i}<span className="ml-1">{s}</span></Badge>;
  };

  if (!user) {
    return <div className="p-12 text-center text-slate-400">Inicia sesión para acceder al KYC.</div>;
  }

  return (
    <div className="min-h-[calc(100vh-40px)] bg-slate-950 p-6">
      <div className="max-w-3xl mx-auto space-y-6">
        <header className="rounded-xl border border-emerald-500/20 bg-slate-900/60 p-6 flex items-center gap-4">
          <ShieldCheck className="w-10 h-10 text-emerald-400" />
          <div>
            <h1 className="text-2xl font-bold text-slate-100">Verificación KYC</h1>
            <p className="text-sm text-slate-400">Identidad verificada por TAMV con firma PQC y registro inmutable.</p>
          </div>
        </header>

        <div className="flex gap-2">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className={`flex-1 h-1 rounded ${step >= s ? "bg-emerald-500" : "bg-slate-800"}`} />
          ))}
        </div>

        {step === 1 && (
          <Card className="bg-slate-900/60 border-slate-800 p-6 space-y-4">
            <h2 className="text-lg font-semibold text-slate-100">Paso 1 · Datos personales</h2>
            <Input placeholder="Nombre completo legal" value={fullName} onChange={(e) => setFullName(e.target.value)}
              className="bg-slate-950 border-slate-700" />
            <select value={jurisdiction} onChange={(e) => setJurisdiction(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-100">
              <option value="MX">México</option><option value="AR">Argentina</option><option value="CO">Colombia</option>
              <option value="CL">Chile</option><option value="PE">Perú</option><option value="ES">España</option>
            </select>
            <Button onClick={() => setStep(2)} disabled={!fullName} className="w-full">Siguiente</Button>
          </Card>
        )}

        {step === 2 && (
          <Card className="bg-slate-900/60 border-slate-800 p-6 space-y-4">
            <h2 className="text-lg font-semibold text-slate-100">Paso 2 · Documento</h2>
            <select value={docType} onChange={(e) => setDocType(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-100">
              <option value="INE">INE / Identificación oficial</option>
              <option value="PASSPORT">Pasaporte</option>
              <option value="DNI">DNI</option>
              <option value="CURP">CURP</option>
            </select>
            <Input placeholder="Número de documento" value={docNumber} onChange={(e) => setDocNumber(e.target.value)}
              className="bg-slate-950 border-slate-700" />
            <p className="text-xs text-slate-500">Solo se almacena el hash SHA-256 del documento, nunca el número en claro.</p>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setStep(1)} className="flex-1">Atrás</Button>
              <Button onClick={() => setStep(3)} disabled={!docNumber} className="flex-1">Siguiente</Button>
            </div>
          </Card>
        )}

        {step === 3 && (
          <Card className="bg-slate-900/60 border-slate-800 p-6 space-y-4">
            <h2 className="text-lg font-semibold text-slate-100">Paso 3 · Revisión</h2>
            <div className="text-sm text-slate-300 space-y-1">
              <p><span className="text-slate-500">Nombre:</span> {fullName}</p>
              <p><span className="text-slate-500">Jurisdicción:</span> {jurisdiction}</p>
              <p><span className="text-slate-500">Documento:</span> {docType} ····{docNumber.slice(-4)}</p>
            </div>
            <p className="text-xs text-amber-400">Al enviar aceptas el procesamiento conforme a GDPR/UNESCO y el blindaje constitucional TAMV.</p>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setStep(2)} className="flex-1">Atrás</Button>
              <Button onClick={submit} disabled={loading} className="flex-1 bg-emerald-600 hover:bg-emerald-500">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Enviar KYC"}
              </Button>
            </div>
          </Card>
        )}

        {step === 4 && record && (
          <Card className="bg-slate-900/60 border-slate-800 p-6 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-slate-100">Estado de tu KYC</h2>
              {statusBadge(record.status)}
            </div>
            <dl className="text-sm text-slate-300 grid grid-cols-2 gap-2">
              <dt className="text-slate-500">Tipo</dt><dd>{record.document_type}</dd>
              <dt className="text-slate-500">Jurisdicción</dt><dd>{record.jurisdiction}</dd>
              <dt className="text-slate-500">Hash documento</dt><dd className="font-mono text-[10px] break-all">{record.document_hash}</dd>
              <dt className="text-slate-500">Enviado</dt><dd>{new Date(record.created_at).toLocaleString()}</dd>
              {record.verified_at && (<><dt className="text-slate-500">Verificado</dt><dd>{new Date(record.verified_at).toLocaleString()}</dd></>)}
              {record.rejection_reason && (<><dt className="text-slate-500">Motivo rechazo</dt><dd className="text-red-300">{record.rejection_reason}</dd></>)}
            </dl>
          </Card>
        )}
      </div>
    </div>
  );
}
