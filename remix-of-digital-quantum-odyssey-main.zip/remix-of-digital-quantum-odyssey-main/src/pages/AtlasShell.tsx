import { useState, useRef, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

type Line = { kind: "in" | "out" | "err"; text: string };

const HELP = `Comandos disponibles:
  status                    Resumen del Atlas
  search "<consulta>"       Búsqueda textual en canon_entities
  node <canonical_id>       Inspecciona un nodo
  ingest <repo_url>         Ingesta un repo GitHub vía atlas-ingest
  help                      Esta ayuda`;

function parse(input: string): { command: string; args: any } | null {
  const t = input.trim();
  if (!t) return null;
  if (t === "help") return { command: "help", args: {} };
  if (t === "status") return { command: "status", args: {} };
  const search = t.match(/^search\s+"([^"]+)"$/) || t.match(/^search\s+(.+)$/);
  if (search) return { command: "search", args: { q: search[1] } };
  const node = t.match(/^node\s+(\S+)$/);
  if (node) return { command: "node", args: { id: node[1] } };
  const ing = t.match(/^ingest\s+(\S+)$/);
  if (ing) return { command: "ingest", args: { url: ing[1] } };
  return null;
}

export default function AtlasShell() {
  const [lines, setLines] = useState<Line[]>([
    { kind: "out", text: "TAMV Atlas Shell v1.0 — AKAE active. Escribe `help`." },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), [lines]);

  async function run() {
    if (!input.trim() || busy) return;
    const echo: Line = { kind: "in", text: `atlas> ${input}` };
    const parsed = parse(input);
    setInput("");
    if (!parsed) {
      setLines((l) => [...l, echo, { kind: "err", text: "Comando no reconocido. `help` para ayuda." }]);
      return;
    }
    if (parsed.command === "help") {
      setLines((l) => [...l, echo, { kind: "out", text: HELP }]);
      return;
    }
    setBusy(true);
    setLines((l) => [...l, echo]);
    try {
      const { data, error } = await supabase.functions.invoke("atlas-shell-exec", { body: parsed });
      if (error) throw error;
      setLines((l) => [...l, { kind: data?.status === "ok" ? "out" : "err", text: JSON.stringify(data?.result ?? data, null, 2) }]);
    } catch (e: any) {
      setLines((l) => [...l, { kind: "err", text: e.message ?? String(e) }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="p-6 space-y-4">
      <header>
        <h1 className="text-xl font-semibold text-slate-100">Atlas Shell</h1>
        <p className="text-xs text-slate-500 mt-1">Consola gobernada. Cada comando se firma y registra en <code>atlas_shell_commands</code>.</p>
      </header>
      <div className="rounded-lg border border-cyan-500/20 bg-slate-950/90 font-mono text-[12px] h-[60vh] overflow-y-auto p-4 space-y-1">
        {lines.map((l, i) => (
          <pre key={i} className={`whitespace-pre-wrap ${l.kind === "in" ? "text-cyan-300" : l.kind === "err" ? "text-rose-400" : "text-slate-300"}`}>{l.text}</pre>
        ))}
        <div ref={bottomRef} />
      </div>
      <div className="flex gap-2">
        <span className="text-cyan-400 font-mono text-sm self-center">atlas&gt;</span>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && run()}
          placeholder='status | search "isabella" | node tamv://... | ingest https://github.com/...'
          disabled={busy}
          className="flex-1 bg-slate-900 border border-slate-700 rounded px-3 py-2 text-sm text-slate-100 font-mono focus:border-cyan-500 outline-none"
        />
        <button onClick={run} disabled={busy} className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 rounded text-sm text-white">
          {busy ? "..." : "exec"}
        </button>
      </div>
    </div>
  );
}
