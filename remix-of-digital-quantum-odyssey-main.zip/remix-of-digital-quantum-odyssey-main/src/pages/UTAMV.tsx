import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, BookOpen, MapPin, Award } from "lucide-react";

export default function UTAMV() {
  const [faculties, setFaculties] = useState<any[]>([]);
  const [tracks, setTracks] = useState<any[]>([]);
  const [zones, setZones] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const [f, t, z] = await Promise.all([
        supabase.from("utamv_faculties").select("*").order("ordering"),
        supabase.from("utamv_tracks").select("*"),
        supabase.from("utamv_campus_zones").select("*").order("ordering"),
      ]);
      setFaculties(f.data ?? []); setTracks(t.data ?? []); setZones(z.data ?? []);
    })();
  }, []);

  return (
    <div className="px-6 py-8 space-y-6 max-w-7xl">
      <header className="rounded-xl border border-cyan-500/30 bg-gradient-to-br from-cyan-950/40 to-slate-950 p-6">
        <div className="flex items-center gap-3 mb-2">
          <GraduationCap className="w-7 h-7 text-cyan-300" />
          <h1 className="text-2xl font-semibold text-slate-100">UTAMV · Universidad Tecnológica Meta Virtual</h1>
        </div>
        <p className="text-sm text-slate-400 max-w-3xl">
          Campus meta-virtual para la formación soberana en tecnología, ética algorítmica, XR, bio-información y economía comunitaria.
          Certificados firmados con PQC y anclados en cadena CLEI.
        </p>
        <div className="mt-4 flex gap-3 flex-wrap">
          <Link to="/utamv/courses" className="text-xs px-3 py-1.5 rounded bg-cyan-500/20 border border-cyan-500/40 text-cyan-200 hover:bg-cyan-500/30">📚 Catálogo de cursos</Link>
          <Link to="/utamv/campus" className="text-xs px-3 py-1.5 rounded bg-violet-500/20 border border-violet-500/40 text-violet-200 hover:bg-violet-500/30">🌐 Campus virtual</Link>
          <Link to="/utamv/dashboard" className="text-xs px-3 py-1.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 hover:bg-emerald-500/30">🎓 Mi panel</Link>
        </div>
      </header>

      <Card className="border-slate-800 bg-slate-950/60">
        <CardHeader><CardTitle className="text-slate-100 flex items-center gap-2"><BookOpen className="w-4 h-4" /> Facultades</CardTitle></CardHeader>
        <CardContent className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
          {faculties.map(f => (
            <div key={f.code} className="rounded-lg border p-4" style={{ borderColor: `${f.color_token}40`, background: `${f.color_token}0a` }}>
              <p className="text-xs font-mono" style={{ color: f.color_token }}>{f.code}</p>
              <p className="text-sm text-slate-100 font-medium mt-1">{f.name}</p>
              <p className="text-xs text-slate-400 mt-1">{f.description}</p>
              <div className="mt-2 text-[10px] text-slate-500">
                Tracks: {tracks.filter(t => t.faculty_code === f.code).length}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-slate-800 bg-slate-950/60">
        <CardHeader><CardTitle className="text-slate-100 flex items-center gap-2"><Award className="w-4 h-4 text-amber-300" /> Itinerarios formativos (tracks)</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {tracks.map(t => (
            <div key={t.code} className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
              <div>
                <p className="font-mono text-amber-300">{t.code}</p>
                <p className="text-slate-200">{t.name}</p>
                <p className="text-slate-500">{t.description}</p>
              </div>
              <Badge variant="outline" className="border-amber-500/30 text-amber-200">{t.duration_weeks} sem</Badge>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-slate-800 bg-slate-950/60">
        <CardHeader><CardTitle className="text-slate-100 flex items-center gap-2"><MapPin className="w-4 h-4 text-violet-300" /> Zonas del campus virtual</CardTitle></CardHeader>
        <CardContent className="grid md:grid-cols-3 gap-3">
          {zones.map(z => (
            <div key={z.code} className="rounded-lg border border-violet-500/20 bg-violet-500/5 p-3">
              <p className="text-xs font-mono text-violet-300">{z.code}</p>
              <p className="text-sm text-slate-100 font-medium mt-1">{z.name}</p>
              <p className="text-xs text-slate-400 mt-1">{z.description}</p>
              <Badge variant="outline" className="mt-2 text-[10px] border-violet-500/30 text-violet-200">{z.zone_type}</Badge>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
