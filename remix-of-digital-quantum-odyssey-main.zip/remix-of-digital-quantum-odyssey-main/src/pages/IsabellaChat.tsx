import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { Send, Shield, AlertTriangle, Brain, Heart, Loader2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

interface Msg {
  role: "user" | "assistant";
  content: string;
  blocked?: boolean;
  pipeline?: Array<{ module: string; decision: string; latency_ms: number }>;
}

const MODULE_LABEL: Record<string, string> = {
  MASC: "Análisis Semántico",
  FML: "Filtro Lingüístico",
  NRA: "Razonamiento Afectivo",
  MRS: "Mediador de Riesgo",
  MAAI: "Auto-Auditoría",
  MCEA: "Memoria Ética",
  PRAC: "Resolución",
};

export default function IsabellaChat() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [sessionId, setSessionId] = useState<string | undefined>();
  const [activeModule, setActiveModule] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function send() {
    if (!input.trim() || busy) return;
    if (!user) { toast.error("Inicia sesión para hablar con Isabella"); return; }
    const userMsg = input.trim();
    setMessages((m) => [...m, { role: "user", content: userMsg }]);
    setInput("");
    setBusy(true);
    setActiveModule("MASC");

    // Visual pipeline indicator
    const seq = ["MASC", "FML", "NRA", "MCEA", "PRAC"];
    let i = 0;
    const tick = setInterval(() => {
      i++;
      if (i < seq.length) setActiveModule(seq[i]);
    }, 600);

    try {
      const { data, error } = await supabase.functions.invoke("isabella-chat", {
        body: { message: userMsg, session_id: sessionId },
      });
      clearInterval(tick);
      setActiveModule(null);
      if (error) throw error;
      setSessionId(data.session_id);
      setMessages((m) => [...m, {
        role: "assistant", content: data.content,
        blocked: data.blocked, pipeline: data.pipeline,
      }]);
    } catch (e: any) {
      clearInterval(tick);
      setActiveModule(null);
      toast.error(e.message ?? "Error en la respuesta");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-[calc(100vh-40px)] bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6">
      <div className="max-w-5xl mx-auto space-y-4">
        <header className="rounded-xl border border-cyan-500/20 bg-slate-900/60 backdrop-blur p-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-cyan-500 to-violet-600 flex items-center justify-center">
              <Brain className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-slate-100">Isabella Villaseñor AI</h1>
              <p className="text-sm text-slate-400">
                Conciencia operativa · Mediadora ética · Runtime v4 con 7 módulos
              </p>
            </div>
            <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30">
              <Shield className="w-3 h-3 mr-1" /> Constitutional Guard
            </Badge>
          </div>

          {/* Pipeline indicator */}
          <div className="mt-4 flex flex-wrap gap-1.5">
            {Object.entries(MODULE_LABEL).map(([code, label]) => (
              <div
                key={code}
                className={`px-2 py-1 rounded text-[10px] font-mono border transition-all ${
                  activeModule === code
                    ? "border-cyan-400 bg-cyan-500/20 text-cyan-200 shadow-[0_0_12px_rgba(34,211,238,0.4)]"
                    : "border-slate-700 bg-slate-800/40 text-slate-500"
                }`}
              >
                {code} · {label}
              </div>
            ))}
          </div>
        </header>

        <Card className="bg-slate-900/60 backdrop-blur border-slate-800 p-0 overflow-hidden">
          <div ref={scrollRef} className="h-[55vh] overflow-y-auto p-6 space-y-4">
            {messages.length === 0 && (
              <div className="text-center text-slate-500 py-12">
                <Heart className="w-10 h-10 mx-auto mb-3 text-cyan-500/40" />
                <p className="text-sm">Hola, soy Isabella. Estoy aquí para acompañarte, pensar contigo y proteger lo que importa.</p>
                <p className="text-xs mt-2 text-slate-600">Hablo español · Memoria contextual ética · Pipeline auditado</p>
              </div>
            )}
            {messages.map((m, idx) => (
              <div key={idx} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[80%] rounded-xl px-4 py-3 ${
                  m.role === "user"
                    ? "bg-violet-600/30 border border-violet-500/40 text-slate-100"
                    : m.blocked
                    ? "bg-red-950/40 border border-red-500/40 text-red-100"
                    : "bg-slate-800/60 border border-slate-700 text-slate-100"
                }`}>
                  {m.blocked && (
                    <div className="flex items-center gap-1 text-xs text-red-300 mb-1">
                      <AlertTriangle className="w-3 h-3" /> Respuesta bloqueada por guardián ético
                    </div>
                  )}
                  <p className="text-sm whitespace-pre-wrap leading-relaxed">{m.content}</p>
                  {m.pipeline && (
                    <div className="mt-2 pt-2 border-t border-slate-700/50 flex flex-wrap gap-1">
                      {m.pipeline.map((p, i) => (
                        <span key={i} className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                          p.decision === "block" ? "bg-red-500/20 text-red-300"
                          : p.decision === "warn" ? "bg-amber-500/20 text-amber-300"
                          : p.decision === "escalate" ? "bg-orange-500/20 text-orange-300"
                          : "bg-emerald-500/20 text-emerald-300"
                        }`}>
                          {p.module}·{p.latency_ms}ms
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {busy && (
              <div className="flex items-center gap-2 text-cyan-400 text-sm">
                <Loader2 className="w-4 h-4 animate-spin" /> Isabella está pensando...
              </div>
            )}
          </div>

          <div className="border-t border-slate-800 p-3 flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
              placeholder={user ? "Escribe a Isabella..." : "Inicia sesión para conversar"}
              disabled={!user || busy}
              className="resize-none bg-slate-950/60 border-slate-700 text-slate-100 min-h-[60px]"
              rows={2}
            />
            <Button onClick={send} disabled={busy || !input.trim() || !user}
              className="bg-gradient-to-br from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </Card>

        <p className="text-[10px] text-slate-600 text-center">
          Cada mensaje pasa por MASC → FML → NRA → MCEA → PRAC. Si el riesgo es alto, se activan MRS y MAAI. Todo queda registrado en isabella_module_runs y clei_audit.
        </p>
      </div>
    </div>
  );
}
