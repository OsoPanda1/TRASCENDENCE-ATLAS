import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, Download, RefreshCw, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

interface CleiRow {
  id: string; sequence: number; event_type: string; prev_hash: string | null;
  hash: string; signature: string; signing_key_id: string; actor_id: string | null;
  created_at: string; payload: Record<string, unknown>;
}
interface MdxRow {
  id: string; action: string; domain: string; actor_id: string | null;
  hash: string; created_at: string; payload: Record<string, unknown>;
}

const PAGE_SIZE = 50;

export default function AtlasAudit() {
  const [tab, setTab] = useState<"clei" | "mdx">("clei");
  const [clei, setClei] = useState<CleiRow[]>([]);
  const [mdx, setMdx] = useState<MdxRow[]>([]);
  const [page, setPage] = useState(0);
  const [total, setTotal] = useState(0);
  const [eventFilter, setEventFilter] = useState("");
  const [domainFilter, setDomainFilter] = useState("");
  const [loading, setLoading] = useState(false);
  const [chainOk, setChainOk] = useState<boolean | null>(null);

  const load = async () => {
    setLoading(true);
    const from = page * PAGE_SIZE;
    const to = from + PAGE_SIZE - 1;
    if (tab === "clei") {
      let q = supabase.from("clei_audit")
        .select("id,sequence,event_type,prev_hash,hash,signature,signing_key_id,actor_id,created_at,payload", { count: "exact" })
        .order("sequence", { ascending: false }).range(from, to);
      if (eventFilter) q = q.ilike("event_type", `%${eventFilter}%`);
      const { data, count, error } = await q;
      if (error) toast.error(error.message);
      setClei((data ?? []) as CleiRow[]);
      setTotal(count ?? 0);
    } else {
      let q = supabase.from("mdx_audit_log")
        .select("id,action,domain,actor_id,hash,created_at,payload", { count: "exact" })
        .order("created_at", { ascending: false }).range(from, to);
      if (domainFilter) q = q.ilike("domain", `%${domainFilter}%`);
      const { data, count, error } = await q;
      if (error) toast.error(error.message);
      setMdx((data ?? []) as MdxRow[]);
      setTotal(count ?? 0);
    }
    setLoading(false);
  };

  useEffect(() => { void load(); /* eslint-disable-next-line */ }, [tab, page, eventFilter, domainFilter]);

  const verifyChain = async () => {
    setChainOk(null);
    const { data } = await supabase.from("clei_audit")
      .select("sequence, prev_hash, hash").order("sequence", { ascending: true }).limit(1000);
    if (!data?.length) { setChainOk(true); return; }
    let prev: string | null = null; let ok = true;
    for (const e of data) {
      if (prev !== null && e.prev_hash !== prev) { ok = false; break; }
      prev = e.hash;
    }
    setChainOk(ok);
    toast[ok ? "success" : "error"](ok ? "Cadena CLEI íntegra" : "Ruptura detectada en la cadena CLEI");
  };

  const exportCsv = () => {
    const rows = tab === "clei" ? clei : mdx;
    if (!rows.length) return toast.info("Nada que exportar");
    const headers = Object.keys(rows[0]).filter((k) => k !== "payload");
    const csv = [headers.join(",")].concat(
      rows.map((r) => headers.map((h) => JSON.stringify((r as Record<string, unknown>)[h] ?? "")).join(",")),
    ).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${tab}_audit_${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const signedExport = async (format: "json" | "csv") => {
    toast.info(`Generando export firmado (${format.toUpperCase()})…`);
    const { data, error } = await supabase.functions.invoke("audit-export", {
      body: { export_type: tab, format, limit: 1000 },
    });
    if (error) return toast.error(error.message);
    const res = data as {
      ok: boolean; trace_id: string; signature: string; signing_key_id: string;
      algorithm: string; is_pqc_ready: boolean; schema_version: string;
      content_hash: string; total_events: number; content: string;
    };
    if (!res?.ok) return toast.error("Export firmado falló");
    const mime = format === "csv" ? "text/csv" : "application/json";
    const blob = new Blob([res.content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${tab}_${res.trace_id}.${format}`; a.click();
    URL.revokeObjectURL(url);

    const sidecar = JSON.stringify({
      schema_version: res.schema_version, trace_id: res.trace_id,
      content_hash: res.content_hash, signature: res.signature,
      signing_key_id: res.signing_key_id, algorithm: res.algorithm,
      is_pqc_ready: res.is_pqc_ready, total_events: res.total_events,
    }, null, 2);
    const sb = new Blob([sidecar], { type: "application/json" });
    const su = URL.createObjectURL(sb);
    const sa = document.createElement("a");
    sa.href = su; sa.download = `${tab}_${res.trace_id}.sig.json`; sa.click();
    URL.revokeObjectURL(su);
    toast.success(`Firmado · ${res.total_events} eventos · ${res.algorithm}`);
  };

  const metrics = useMemo(() => {
    const topEvents = new Map<string, number>();
    for (const r of clei) topEvents.set(r.event_type, (topEvents.get(r.event_type) ?? 0) + 1);
    return Array.from(topEvents.entries()).sort((a, b) => b[1] - a[1]).slice(0, 6);
  }, [clei]);

  const totalPages = Math.ceil(total / PAGE_SIZE);

  return (
    <div className="px-6 py-8 space-y-6">
      <header className="rounded-xl border border-violet-500/20 bg-slate-950/80 p-6">
        <p className="text-[11px] font-mono uppercase tracking-[0.25em] text-violet-300">Atlas · Audit & Compliance</p>
        <h1 className="text-2xl font-semibold text-slate-100 mt-1">Panel de auditoría canónica</h1>
        <p className="text-sm text-slate-400 mt-2 max-w-3xl">
          Trazabilidad inmutable de canon, políticas y decisiones por usuario y por ejecución. Verificación
          cliente-side de la cadena CLEI y métricas de cumplimiento.
        </p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4">
          <p className="text-[10px] uppercase text-slate-500">Eventos CLEI</p>
          <p className="text-2xl text-violet-300 font-mono">{tab === "clei" ? total : "—"}</p>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4">
          <p className="text-[10px] uppercase text-slate-500">Integridad cadena</p>
          <div className="flex items-center gap-2">
            {chainOk === null ? (
              <Button size="sm" variant="outline" onClick={verifyChain} className="h-7">
                <ShieldCheck className="w-3 h-3 mr-1" /> Verificar
              </Button>
            ) : chainOk ? (
              <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/40">ÍNTEGRA</Badge>
            ) : (
              <Badge className="bg-rose-500/20 text-rose-300 border-rose-500/40">
                <AlertTriangle className="w-3 h-3 mr-1" /> RUPTURA
              </Badge>
            )}
          </div>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-4 md:col-span-2">
          <p className="text-[10px] uppercase text-slate-500 mb-2">Top event types (página actual)</p>
          <div className="flex flex-wrap gap-1.5">
            {metrics.map(([k, v]) => (
              <span key={k} className="text-[10px] px-2 py-0.5 rounded border border-violet-500/30 bg-violet-500/10 text-violet-200">
                {k} <span className="text-slate-400">×{v}</span>
              </span>
            ))}
            {metrics.length === 0 && <span className="text-[10px] text-slate-500">sin datos</span>}
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-950/60 p-5 space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex gap-1">
            {(["clei", "mdx"] as const).map((t) => (
              <button key={t} onClick={() => { setTab(t); setPage(0); }}
                className={`text-[11px] px-3 py-1.5 rounded-md uppercase tracking-wider ${
                  tab === t ? "bg-violet-500/20 text-violet-200 border border-violet-500/40" : "text-slate-400 border border-slate-800"
                }`}>
                {t === "clei" ? "CLEI Chain" : "MDX Audit"}
              </button>
            ))}
          </div>
          {tab === "clei" ? (
            <Input value={eventFilter} onChange={(e) => { setEventFilter(e.target.value); setPage(0); }}
              placeholder="Filtrar por event_type" className="max-w-xs h-8 bg-slate-900 border-slate-700 text-slate-200 text-xs" />
          ) : (
            <Input value={domainFilter} onChange={(e) => { setDomainFilter(e.target.value); setPage(0); }}
              placeholder="Filtrar por domain" className="max-w-xs h-8 bg-slate-900 border-slate-700 text-slate-200 text-xs" />
          )}
          <Button size="sm" variant="outline" onClick={load} disabled={loading} className="h-8">
            <RefreshCw className={`w-3 h-3 mr-1 ${loading ? "animate-spin" : ""}`} /> Refrescar
          </Button>
          <Button size="sm" variant="outline" onClick={exportCsv} className="h-8">
            <Download className="w-3 h-3 mr-1" /> CSV
          </Button>
          <Button size="sm" variant="outline" onClick={() => signedExport("json")} className="h-8">
            <Download className="w-3 h-3 mr-1" /> JSON firmado
          </Button>
          <Button size="sm" variant="outline" onClick={() => signedExport("csv")} className="h-8">
            <Download className="w-3 h-3 mr-1" /> CSV firmado
          </Button>
          <div className="ml-auto text-[11px] text-slate-400 flex items-center gap-2">
            <span>{total.toLocaleString()} eventos</span>
            <Button size="sm" variant="ghost" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0} className="h-7">
              ←
            </Button>
            <span>{page + 1}/{Math.max(1, totalPages)}</span>
            <Button size="sm" variant="ghost" onClick={() => setPage((p) => p + 1)} disabled={page + 1 >= totalPages} className="h-7">
              →
            </Button>
          </div>
        </div>

        <div className="overflow-auto">
          {tab === "clei" ? (
            <table className="w-full text-[11px] font-mono">
              <thead className="text-left text-slate-500 border-b border-slate-800">
                <tr>
                  <th className="py-2 pr-3">SEQ</th>
                  <th className="pr-3">EVENT</th>
                  <th className="pr-3">HASH</th>
                  <th className="pr-3">PREV</th>
                  <th className="pr-3">KEY</th>
                  <th className="pr-3">WHEN</th>
                </tr>
              </thead>
              <tbody className="text-slate-300">
                {clei.map((r) => (
                  <tr key={r.id} className="border-b border-slate-900 hover:bg-slate-900/40">
                    <td className="py-1.5 pr-3 text-violet-300">{r.sequence}</td>
                    <td className="pr-3">{r.event_type}</td>
                    <td className="pr-3 text-slate-500" title={r.hash}>{r.hash.slice(0, 12)}…</td>
                    <td className="pr-3 text-slate-600" title={r.prev_hash ?? ""}>{r.prev_hash ? r.prev_hash.slice(0, 10) + "…" : "—"}</td>
                    <td className="pr-3 text-slate-500">{r.signing_key_id?.slice(0, 12)}</td>
                    <td className="pr-3 text-slate-400">{new Date(r.created_at).toISOString().slice(0, 19)}</td>
                  </tr>
                ))}
                {clei.length === 0 && <tr><td colSpan={6} className="py-6 text-center text-slate-500">Sin eventos</td></tr>}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-[11px] font-mono">
              <thead className="text-left text-slate-500 border-b border-slate-800">
                <tr>
                  <th className="py-2 pr-3">DOMAIN</th>
                  <th className="pr-3">ACTION</th>
                  <th className="pr-3">ACTOR</th>
                  <th className="pr-3">HASH</th>
                  <th className="pr-3">WHEN</th>
                </tr>
              </thead>
              <tbody className="text-slate-300">
                {mdx.map((r) => (
                  <tr key={r.id} className="border-b border-slate-900 hover:bg-slate-900/40">
                    <td className="py-1.5 pr-3 text-cyan-300">{r.domain}</td>
                    <td className="pr-3">{r.action}</td>
                    <td className="pr-3 text-slate-500">{r.actor_id?.slice(0, 8) ?? "system"}</td>
                    <td className="pr-3 text-slate-500" title={r.hash}>{r.hash?.slice(0, 12)}…</td>
                    <td className="pr-3 text-slate-400">{new Date(r.created_at).toISOString().slice(0, 19)}</td>
                  </tr>
                ))}
                {mdx.length === 0 && <tr><td colSpan={5} className="py-6 text-center text-slate-500">Sin eventos</td></tr>}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </div>
  );
}
