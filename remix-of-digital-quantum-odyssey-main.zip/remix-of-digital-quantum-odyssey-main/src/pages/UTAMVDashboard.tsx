import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function UTAMVDashboard() {
  const { user } = useAuth();
  const [enrollments, setEnrollments] = useState<any[]>([]);
  const [certs, setCerts] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;
    supabase.from("utamv_enrollments").select("*, utamv_courses(*)" as any).eq("user_id", user.id)
      .then(({ data }) => setEnrollments(data ?? []));
    supabase.from("utamv_certificates").select("*").eq("user_id", user.id)
      .then(({ data }) => setCerts(data ?? []));
  }, [user]);

  if (!user) return <div className="p-8 text-sm text-slate-500">Inicia sesión para ver tu panel.</div>;

  return (
    <div className="px-6 py-8 space-y-4 max-w-5xl">
      <h1 className="text-2xl font-semibold text-slate-100">Mi panel UTAMV</h1>
      <Card className="border-slate-800 bg-slate-950/60">
        <CardHeader><CardTitle className="text-base text-slate-100">Cursos inscritos</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {enrollments.length === 0 && <p className="text-xs text-slate-500">No estás inscrito a ningún curso aún.</p>}
          {enrollments.map((e: any) => (
            <div key={e.id} className="text-sm border-b border-slate-800 pb-2 flex items-center justify-between">
              <div>
                <p className="text-slate-200">{e.utamv_courses?.title}</p>
                <p className="text-xs text-slate-500">{e.utamv_courses?.code}</p>
              </div>
              <Badge variant="outline" className="border-cyan-500/30 text-cyan-300">{Math.round((e.progress || 0) * 100)}%</Badge>
            </div>
          ))}
        </CardContent>
      </Card>
      <Card className="border-slate-800 bg-slate-950/60">
        <CardHeader><CardTitle className="text-base text-slate-100">Mis certificados</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {certs.length === 0 && <p className="text-xs text-slate-500">Aún no has emitido certificados.</p>}
          {certs.map(c => (
            <div key={c.id} className="text-xs border-b border-slate-800 pb-2">
              <p className="font-mono text-amber-300">{c.certificate_code}</p>
              <p className="text-slate-300">{new Date(c.issued_at).toLocaleString()}</p>
              <p className="text-slate-500 font-mono truncate">hash: {c.hash}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
