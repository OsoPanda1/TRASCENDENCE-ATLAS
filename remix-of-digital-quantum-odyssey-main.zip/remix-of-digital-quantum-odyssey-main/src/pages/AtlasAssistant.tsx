import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";

type Evidence = { canonical_id: string; title: string; similarity: number };
type Turn = { q: string; a: string; evidence: Evidence[]; confidence: number };

export default function AtlasAssistant() {
  const [history, setHistory] = useState<Turn[]>([]);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);

  async function ask() {
    if (!q.trim() || busy) return;
    setBusy(true);
    const query = q;
    setQ("");
    try {
      // RAG: semantic search → return answer with evidence (no LLM call needed for evidence list).
      // We embed the question via embeddings-index and match against canon_entities.
      const { data: emb } = await supabase.functions.invoke("embeddings-index", {
        body: { texts: [query], one_off: true },
      });
      const vector = emb?.embeddings?.[0];
      let evidence: Evidence[] = [];
      let confidence = 0;
      if (vector) {
        const { data: matches } = await (supabase as any).rpc("match_canon_entities", {
          query_embedding: vector,
          match_count: 6,
          min_similarity: 0.4,
        });
        evidence = (matches ?? [])
          .map((m: any) => ({ canonical_id: m.canonical_id, title: m.title, similarity: m.similarity }));
        confidence = evidence.length ? evidence[0].similarity : 0;
      }

      // Chat completion with grounded context
      const { data: chat } = await supabase.functions.invoke("isabella-chat", {
        body: {
          message: query,
          context: { atlas_evidence: evidence },
          system_addendum: "Responde citando solo los IDs canónicos provistos como evidencia. Si no hay evidencia suficiente, dilo explícitamente.",
        },
      });

      setHistory((h) => [...h, {
        q: query,
        a: chat?.response ?? chat?.message ?? "(sin respuesta)",
        evidence,
        confidence,
      }]);
    } catch (e: any) {
      setHistory((h) => [...h, { q: query, a: `Error: ${e.message}`, evidence: [], confidence: 0 }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="p-6 space-y-4">
      <header>
        <h1 className="text-xl font-semibold text-slate-100">Asistente Atlas</h1>
        <p className="text-xs text-slate-500 mt-1">RAG sobre canon. Respuestas con <em>evidence</em> y <em>confidence</em>. Sin acceso a CROWN_JEWEL.</p>
      </header>

      <div className="space-y-3 max-h-[60vh] overflow-y-auto">
        {history.map((t, i) => (
          <div key={i} className="rounded-lg border border-slate-800 bg-slate-900/40 p-4 space-y-2">
            <div className="text-xs text-cyan-300 font-mono">› {t.q}</div>
            <div className="text-sm text-slate-200 whitespace-pre-wrap">{t.a}</div>
            <div className="flex items-center justify-between text-[10px] text-slate-500 pt-2 border-t border-slate-800">
              <span>confianza: {t.confidence.toFixed(3)}</span>
              <span>{t.evidence.length} fuentes</span>
            </div>
            {t.evidence.length > 0 && (
              <ul className="text-[11px] text-slate-400 space-y-1">
                {t.evidence.map((e) => (
                  <li key={e.canonical_id} className="font-mono">
                    [{e.similarity.toFixed(2)}] {e.title} <span className="text-slate-600">— {e.canonical_id}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && ask()}
          placeholder="¿Dónde se usa el módulo Isabella? ¿Qué repos están conectados a RDM Digital?"
          disabled={busy}
          className="flex-1 bg-slate-900 border border-slate-700 rounded px-3 py-2 text-sm text-slate-100 focus:border-cyan-500 outline-none"
        />
        <button onClick={ask} disabled={busy} className="px-4 py-2 bg-violet-600 hover:bg-violet-500 disabled:opacity-50 rounded text-sm text-white">
          {busy ? "..." : "preguntar"}
        </button>
      </div>
    </div>
  );
}
