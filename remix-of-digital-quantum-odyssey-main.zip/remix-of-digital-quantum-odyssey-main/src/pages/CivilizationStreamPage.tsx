import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { CivilizationStream } from "@/components/atlas/CivilizationStream";
import { wikiStructure } from "@/data/wikiStructure";
import type {
  ArticleSummary,
  Depth,
  ModuleMeta,
  RoleKey,
  DomainTag,
} from "@/components/atlas/types";

const modulePalette = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
  "hsl(var(--primary))",
];

// Dominios conceptuales básicos para mapear secciones al Atlas civilizatorio
const inferDomainTag = (sectionId: string): DomainTag => {
  if (sectionId.includes("infra")) return "infra";
  if (sectionId.includes("cognitivo") || sectionId.includes("isabella")) return "cognitivo";
  if (sectionId.includes("utamv") || sectionId.includes("educacion")) return "educativo";
  if (sectionId.includes("economia") || sectionId.includes("credito")) return "economico";
  if (sectionId.includes("xr") || sectionId.includes("mdx4")) return "xr";
  if (sectionId.includes("rdm") || sectionId.includes("urbano")) return "urbano";
  if (sectionId.includes("canon") || sectionId.includes("manifiesto") || sectionId.includes("gobernanza")) return "canon";
  return "infra";
};

const mapDepth = (moduleIndex: number): Depth => {
  if (moduleIndex <= 2) return "intro";
  if (moduleIndex <= 8) return "tecnico";
  return "constitucional";
};

// Estado civilizatorio sintético por módulo (MVP dummy, luego lo puedes alimentar con AKAE/BookPI)
const computeModuleHealth = (moduleIndex: number) => {
  if (moduleIndex <= 2) return { health: 0.76, risk: "low" as const };
  if (moduleIndex <= 8) return { health: 0.68, risk: "medium" as const };
  return { health: 0.82, risk: "low" as const };
};

const modules: ModuleMeta[] = wikiStructure.map((section, moduleIndex) => {
  const domain = inferDomainTag(section.id);
  const { health, risk } = computeModuleHealth(moduleIndex);

  return {
    id: moduleIndex,
    slug: section.id,
    title: section.title,
    level: moduleIndex,
    icon: section.icon,
    color: modulePalette[moduleIndex % modulePalette.length],
    articleCount: section.children.length,
    domain,
    depth: mapDepth(moduleIndex),
    healthScore: health,
    riskLevel: risk,
    // marcador para futuras integraciones de federación / timeline
    federationHint:
      moduleIndex <= 3 ? "f1-humana" : moduleIndex <= 7 ? "f3-infra" : "f5-gobernanza",
  };
});

const baseArticles: ArticleSummary[] = wikiStructure.flatMap((section, moduleIndex) =>
  section.children.map((page, pageIndex) => {
    const domain = inferDomainTag(section.id);
    const depth = mapDepth(moduleIndex);

    return {
      id: moduleIndex * 100 + pageIndex,
      slug: page.slug,
      title: page.title,
      summary: `Nodo del flujo civilizatorio en ${section.title}, alineado al dominio ${domain} y preparado para lectura por rol.`,
      tags: [
        section.id.replace(/-/g, " "),
        domain,
        moduleIndex >= 10 ? "gobernanza" : "arquitectura",
      ],
      moduleId: moduleIndex,
      moduleSlug: section.id,
      moduleTitle: section.title,
      isCritical:
        pageIndex === 0 ||
        section.id === "ssi-did" ||
        section.id.includes("gobernanza") ||
        section.id.includes("canon"),
      readTimeMinutes: 4 + (pageIndex % 5),
      roleWeight: {
        ciudadano: moduleIndex < 3 ? 3 : 1,
        dev: moduleIndex >= 6 ? 4 : 2,
        empresario: moduleIndex === 7 || moduleIndex === 12 ? 4 : 1,
        academia: moduleIndex === 1 || moduleIndex === 11 ? 4 : 2,
        gobierno: moduleIndex >= 9 ? 4 : 1,
      },
      depth,
      domain,
      // marcador temporal sintético; más adelante se alimenta de AKAE-TEMPORAL
      firstSeenAt: new Date(2024, 0, 1 + moduleIndex).toISOString(),
    };
  }),
);

export default function CivilizationStreamPage() {
  const [selectedRole, setSelectedRole] = useState<RoleKey | "all">("all");
  const [selectedDepth, setSelectedDepth] = useState<Depth | "all">("all");
  const [selectedDomain, setSelectedDomain] = useState<DomainTag | "all">("all");
  const [viewMode, setViewMode] = useState<"stream" | "timeline">("stream");

  const filteredArticles = useMemo(() => {
    return baseArticles.filter((article) => {
      if (selectedRole !== "all") {
        const weight = article.roleWeight[selectedRole];
        if (!weight || weight <= 1) return false;
      }
      if (selectedDepth !== "all" && article.depth !== selectedDepth) return false;
      if (selectedDomain !== "all" && article.domain !== selectedDomain) return false;
      return true;
    });
  }, [selectedRole, selectedDepth, selectedDomain]);

  return (
    <div className="px-4 py-6 md:px-8 lg:px-10 space-y-5 bg-background text-foreground min-h-full">
      {/* Header civilizatorio */}
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-[11px] font-mono text-primary tracking-[0.18em] uppercase">
            ATLAS / CIVILIZATION STREAM / GENESIS
          </p>
          <h1 className="text-2xl md:text-3xl font-semibold text-foreground">
            Flujo civilizatorio, por roles, dominios y profundidad
          </h1>
          <p className="mt-1 text-xs text-muted-foreground max-w-xl">
            Esta vista no es un listado de páginas: es una lente del sistema nervioso territorial.
            Filtra el conocimiento por rol, dominio y nivel de profundidad para navegar TAMV GENESIS
            como un **Atlas vivo**.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setViewMode("stream")}
            className={`text-xs border px-3 py-1.5 rounded transition-colors ${
              viewMode === "stream"
                ? "border-primary text-primary"
                : "border-border text-muted-foreground hover:border-primary/60 hover:text-primary"
            }`}
          >
            Modo Stream
          </button>
          <button
            type="button"
            onClick={() => setViewMode("timeline")}
            className={`text-xs border px-3 py-1.5 rounded transition-colors ${
              viewMode === "timeline"
                ? "border-primary text-primary"
                : "border-border text-muted-foreground hover:border-primary/60 hover:text-primary"
            }`}
          >
            Modo Timeline
          </button>

          <Link
            to="/resumen"
            className="text-xs border border-border px-3 py-1.5 rounded text-muted-foreground hover:border-primary hover:text-primary transition-colors"
          >
            Volver a Resumen
          </Link>
        </div>
      </div>

      {/* Filtros civilizatorios */}
      <div className="flex flex-wrap items-center gap-3 text-[11px] md:text-xs">
        <div className="flex items-center gap-1.5">
          <span className="font-mono text-muted-foreground">ROL</span>
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value as RoleKey | "all")}
            className="bg-card border border-border rounded px-2 py-1 text-xs"
          >
            <option value="all">Todos</option>
            <option value="ciudadano">Ciudadano</option>
            <option value="dev">Dev</option>
            <option value="empresario">Empresario</option>
            <option value="academia">Academia</option>
            <option value="gobierno">Gobierno</option>
          </select>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="font-mono text-muted-foreground">PROFUNDIDAD</span>
          <select
            value={selectedDepth}
            onChange={(e) => setSelectedDepth(e.target.value as Depth | "all")}
            className="bg-card border border-border rounded px-2 py-1 text-xs"
          >
            <option value="all">Todas</option>
            <option value="intro">Introductoria</option>
            <option value="tecnico">Técnica</option>
            <option value="constitucional">Constitucional</option>
          </select>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="font-mono text-muted-foreground">DOMINIO</span>
          <select
            value={selectedDomain}
            onChange={(e) => setSelectedDomain(e.target.value as DomainTag | "all")}
            className="bg-card border border-border rounded px-2 py-1 text-xs"
          >
            <option value="all">Todos</option>
            <option value="infra">Infra</option>
            <option value="cognitivo">Cognitivo</option>
            <option value="educativo">Educativo</option>
            <option value="economico">Económico</option>
            <option value="xr">XR</option>
            <option value="urbano">Urbano</option>
            <option value="canon">Canon</option>
          </select>
        </div>
      </div>

      {/* Stream principal */}
      <CivilizationStream
        modules={modules}
        articles={filteredArticles}
        viewMode={viewMode}
      />
    </div>
  );
}
