import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

type Node = {
  canonical_id: string;
  title: string | null;
  type: string | null;
  domain_v2: string | null;
  federation: string | null;
  score_confianza: number | null;
  risk_level: string | null;
};

const DOMAIN_COLORS: Record<string, string> = {
  canon: "bg-violet-500/20 border-violet-500/50 text-violet-200",
  cognitivo: "bg-cyan-500/20 border-cyan-500/50 text-cyan-200",
  educativo: "bg-emerald-500/20 border-emerald-500/50 text-emerald-200",
  economico: "bg-amber-500/20 border-amber-500/50 text-amber-200",
  xr: "bg-pink-500/20 border-pink-500/50 text-pink-200",
  urbano: "bg-orange-500/20 border-orange-500/50 text-orange-200",
  infra: "bg-slate-500/20 border-slate-500/50 text-slate-200",
};

export default function AtlasGraph() {
  const [nodes, setNodes] = useState<Node[]>([]);
  const [filter, setFilter] = useState<string>("");
  const [selected, setSelected] = useState<Node | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("canon_entities")
        .select("canonical_id,title,type,domain_v2,federation,score_confianza,risk_level")
        .order("score_confianza", { ascending: false })
        .limit(300);
      setNodes((data as Node[]) ?? []);
      setLoading(false);
    })();
  }, []);

  const filtered = filter ? nodes.filter((n) => n.domain_v2 === filter) : nodes;
  const domains = Array.from(new Set(nodes.map((n) => n.domain_v2).filter(Boolean))) as string[];

  return (
    <div className="p-6 space-y-4">
      <header>
        <h1 className="text-xl font-semibold text-slate-100">Atlas · Grafo Canónico</h1>
        <p className="text-xs text-slate-500 mt-1">Nodos materializados desde <code>canon_entities</code> · {nodes.length} cargados</p>
      </header>

      <div className="flex flex-wrap gap-2">
        <button onClick={() => setFilter("")} className={`px-3 py-1 rounded text-xs border ${!filter ? "border-cyan-400 text-cyan-200" : "border-slate-700 text-slate-400"}`}>
          Todos
        </button>
        {domains.map((d) => (
          <button key={d} onClick={() => setFilter(d)} className={`px-3 py-1 rounded text-xs border ${filter === d ? "border-cyan-400 text-cyan-200" : "border-slate-700 text-slate-400"}`}>
            {d}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-12 gap-4">
        <div className="col-span-12 lg:col-span-8">
          {loading ? (
            <div className="text-slate-500 text-sm">Cargando grafo…</div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-h-[70vh] overflow-y-auto pr-2">
              {filtered.map((n) => (
                <button
                  key={n.canonical_id}
                  onClick={() => setSelected(n)}
                  className={`text-left p-3 rounded-lg border ${DOMAIN_COLORS[n.domain_v2 ?? "infra"] ?? DOMAIN_COLORS.infra} hover:opacity-90`}
                >
                  <div className="text-[10px] font-mono opacity-70">{n.type}</div>
                  <div className="text-xs font-semibold line-clamp-2 mt-1">{n.title ?? n.canonical_id}</div>
                  <div className="text-[10px] mt-2 flex justify-between opacity-80">
                    <span>conf {Number(n.score_confianza ?? 0).toFixed(2)}</span>
                    <span>{n.risk_level}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
        <aside className="col-span-12 lg:col-span-4 rounded-lg border border-slate-800 bg-slate-900/40 p-4 text-sm">
          {selected ? (
            <div className="space-y-2">
              <div className="text-[10px] font-mono text-slate-500 break-all">{selected.canonical_id}</div>
              <h2 className="text-base font-semibold text-slate-100">{selected.title}</h2>
              <dl className="text-xs grid grid-cols-2 gap-1 text-slate-400">
                <dt>Tipo</dt><dd className="text-slate-200">{selected.type}</dd>
                <dt>Dominio</dt><dd className="text-slate-200">{selected.domain_v2}</dd>
                <dt>Federación</dt><dd className="text-slate-200">{selected.federation}</dd>
                <dt>Confianza</dt><dd className="text-slate-200">{Number(selected.score_confianza ?? 0).toFixed(3)}</dd>
                <dt>Riesgo</dt><dd className="text-slate-200">{selected.risk_level}</dd>
              </dl>
            </div>
          ) : (
            <p className="text-slate-500 text-xs">Selecciona un nodo para ver su ficha canónica.</p>
          )}
        </aside>
      </div>
    </div>
  );
}
