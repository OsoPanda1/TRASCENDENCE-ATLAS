import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

export default function UTAMVCourses() {
  const [courses, setCourses] = useState<any[]>([]);
  const [q, setQ] = useState("");
  useEffect(() => {
    supabase.from("utamv_courses").select("*").eq("is_published", true).then(({ data }) => setCourses(data ?? []));
  }, []);
  const filtered = courses.filter(c => !q || (c.title + c.code + (c.summary || "")).toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="px-6 py-8 space-y-4 max-w-7xl">
      <h1 className="text-2xl font-semibold text-slate-100">Catálogo de cursos UTAMV</h1>
      <Input placeholder="Buscar curso…" value={q} onChange={e => setQ(e.target.value)} className="max-w-md bg-slate-900 border-slate-800" />
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map(c => (
          <Link key={c.id} to={`/utamv/course/${c.code}`}>
            <Card className="border-slate-800 bg-slate-950/60 hover:border-cyan-500/40 transition">
              <CardContent className="p-4">
                <p className="text-xs font-mono text-cyan-300">{c.code}</p>
                <p className="text-sm text-slate-100 font-medium mt-1">{c.title}</p>
                <p className="text-xs text-slate-400 mt-1 line-clamp-3">{c.summary || "—"}</p>
                <div className="mt-2 flex gap-2 flex-wrap">
                  <Badge variant="outline" className="text-[10px] border-slate-700 text-slate-400">{c.level}</Badge>
                  <Badge variant="outline" className="text-[10px] border-slate-700 text-slate-400">{c.credits} cr</Badge>
                  {c.faculty && <Badge variant="outline" className="text-[10px] border-cyan-500/30 text-cyan-300">{c.faculty}</Badge>}
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
        {filtered.length === 0 && <p className="text-sm text-slate-500">Aún no hay cursos publicados. Académicos pueden crearlos desde el panel.</p>}
      </div>
    </div>
  );
}
