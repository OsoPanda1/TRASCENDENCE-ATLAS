# TAMV Atlas Trascendence
# *Preservando aquello que las personas consideran digno de ser recordado*
*Orgullosamente Realmontenses | TAMV ONLINE NETWORK*

---

> Proyecto dedicado a Reyna Trejo Serrano. Gracias por nunca rendirte, por cada noche en vela y sufrimiento en silencio, por nunca rendirte este proyecto es el resultado a tu lucha y sacrificio, Te amo Madre.

---

Plataforma full‑stack para operar el **Atlas TAMV**: una base de conocimiento/operación con frontend React, backend Node, integración de identidad (DID/PID), firma criptográfica, eventos XR y pipeline de federación de repositorios.


> Este README describe el **estado real actual del repo** (no roadmap idealizado), incluyendo nivel de madurez para producción y despliegue.

---

## 1) ¿Qué es este repositorio?

`tamv-atlas` es un monorepo operativo que combina:

- **Frontend web** (Vite + React + TypeScript) para Atlas/Wiki y módulos TAMV.
- **Backend API** (Node HTTP nativo + ESM) con endpoints de identidad, firmas, fusión de repos y eventos.
- **Núcleo federado** (`AtlasKernel`) con contratos y lógica de protocolos/economía/eventos.
- **Integración opcional con Supabase** como persistencia y señalización SSE/WebRTC.
- **Scripts de unificación** para descubrir/importar repos de `OsoPanda1` vía GitHub API + `git subtree`.

En resumen: este repo sirve como **plataforma base de operación del Atlas** (contenido + identidad + protocolos + telemetría).

---

## 2) ¿Qué hace hoy, de forma funcional?

### Frontend

- Renderiza páginas y rutas wiki/módulos TAMV.
- Consume backend para firmas, investigación/fusión y métricas (según configuración `VITE_TAMV_BACKEND_URL`).

### Backend

Expone endpoints funcionales para:

- Salud del servicio (`/healthz`).
- Identidad organizacional y DID (`/v1/identity/*`).
- Estado de PIDs (ORCID/Zenodo/ISNI) (`/v1/pids/status`).
- Firma y verificación de payloads (`/v1/signature/sign`, `/v1/signature/verify`).
- Chat/visión/audio/háptica y ledger de Isabella (`/api/v1/*`).
- Usuarios, protocolos, economía y stream XR con persistencia opcional (`/v1/users`, `/v1/protocols/execute`, `/v1/economy/ledger`, `/v1/xr/*`).
- Postura de seguridad/antifragilidad (`/v1/security/posture`).

### Federación de repos

- Descubre repos del owner en GitHub.
- Genera manifiesto consolidado.
- Puede importar repos por `subtree --squash` en `federation/`.

---

## 3) ¿Cómo lo hace? (arquitectura real)

```text
[React/Vite Frontend]
         |
         | HTTP (REST)
         v
[Node API Server]
  |      |         |
  |      |         +--> [Repo Fusion Service -> Bash script -> GitHub API/git subtree]
  |      +------------> [Identity/PQC/PID modules]
  +-------------------> [AtlasKernelRuntime]
                           |
                           +--> [Supabase persistence/events/signals] (opcional por env)
```

Principio operativo real:

- Si no hay `SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY`, la API sigue viva pero desactiva rutas que requieren persistencia (responde `503` con mensaje explícito).

---

## 4) ¿Para qué sirve?

- **Orquestación de Atlas TAMV**: identidad, protocolos y ledger básico en un solo backend.
- **Base de producto digital**: wiki + operación API para iterar producto real.
- **Núcleo de integración**: puente entre narrativa/canon TAMV y ejecución técnica verificable.
- **Preparación de ecosistema federado**: consolidación de repositorios y estructura común.

---

## 5) ¿Para quién sirve?

- **Equipo núcleo TAMV (producto/arquitectura/operaciones)**: para consolidar stack y despliegue.
- **Desarrolladores full‑stack**: para extender frontend, API y kernel federado.
- **Investigación/estrategia digital**: para auditar madurez y planificar evolución a producción.
- **Socios técnicos**: para integración con identidades, señales XR y flujos antifragilidad.

---

## 6) Importancia y posicionamiento global (honesto)

### Importancia

- Resuelve un punto clave: pasar de documentación dispersa a **base ejecutable** con API+frontend.
- Ya ofrece componentes diferenciales (identidad soberana, firma, eventos y federación de repos).

### Posicionamiento global actual

- **Etapa:** pre‑producción avanzada / consolidación.
- **Ventaja:** visión transversal (frontend + backend + protocolos + identidad + repos).
- **Brecha:** hardening operativo (seguridad, observabilidad, CI/CD robusto, cumplimiento, SLAs).

No está en nivel “enterprise global listo” todavía; está en nivel “plataforma técnicamente prometedora con piezas funcionales”.

---

## 7) Porcentaje real de avance para producción y despliegue

> Estimación técnica basada en lo implementado visible en código, scripts y pruebas actuales.

| Área | Estado real | % avance |
|---|---|---:|
| Frontend funcional (rutas, páginas, build) | Sólido para iteración | **78%** |
| Backend funcional (endpoints core operativos) | Funcional, aún monolítico | **72%** |
| Persistencia real (Supabase opcional) | Integrada pero dependiente de env y endurecimiento | **58%** |
| Seguridad operativa (controles, posture endpoint) | Base creada, faltan controles enterprise | **46%** |
| Observabilidad y monitoreo | Parcial (sin stack integral de tracing/alerting) | **38%** |
| Calidad/QA automatizada | Existe test suite, pero con señales de estabilidad pendientes en runner | **52%** |
| CI/CD y despliegue productivo | Parcial, requiere pipeline endurecido y gates | **44%** |
| Gobernanza de APIs/contratos | Buena base, falta versionado y políticas formales | **55%** |
| Federación de repos OsoPanda1 | Descubrimiento/importación funcional | **68%** |

### Promedio ponderado de readiness

- **Readiness producción (global): 56%**
- **Readiness despliegue controlado (staging/partners): 67%**

Interpretación:

- Ya puede desplegarse en **entornos controlados** (demo, staging, pilotos).
- Aún no recomendable para **producción crítica a gran escala** sin hardening adicional.

---

# Núcleo Civilizatorio (Capa 1)
# Enfocado en la persistencia inmutable del conocimiento, registros evolutivos e identidad atómica.

```mermaid
graph LR
    classDef capa fill:#0d1b2a,stroke:#48cae4,stroke-width:2px,color:#fff,font-weight:bold;
    classDef submodulo fill:#1b263b,stroke:#00b4d8,stroke-width:1px,color:#e0e1dd;

    subgraph C1 ["1. NÚCLEO CIVILIZATORIO"]
        A1["<b>ATLAS KERNEL</b><br>• atlasKernelRuntime<br>• atlasStore<br>• omniKernelGateway<br>• identityRegistry<br>• server & config"]
        A2["<b>AKAÉ CORE</b><br>• akae.md<br>• plan.md<br>• Ecosystem Vision<br>• Civilizational Engine"]
        A3["<b>BOOKPI MEMORY</b><br>• bookpi-block-latest.json<br>• Consolidated Memory<br>• Immutable Knowledge<br>• Evolutionary Ledger"]
        A4["<b>RESEARCH DOSSIERS</b><br>• researchDossier<br>• Expedientes de Investigación<br>• Conocimiento Verificable"]
        A5["<b>KNOWLEDGE RECONCILIATION</b><br>• pidReconciler<br>• pidConnectors<br>• pidReconcileJob<br>• Identity Resolution<br>• Cross-System Sync"]
    end
    
    A1 --> A5
    A2 --> A3
    A3 --> A4
    A4 --> A5

    class C1 capa;
    class A1,A2,A3,A4,A5 submodulo;
```

## 8) Qué falta para llegar a producción global (prioridad)

1. **Estabilizar pruebas y ejecución concurrente** (eliminar cuelgues/handles abiertos, separar puertos y lifecycles por suite).
2. **Seguridad enterprise**: authn/authz robusta, rate limiting, CORS estricto por entorno, secrets rotation, auditoría firmada.
3. **Observabilidad total**: métricas, logs estructurados, tracing distribuido, alertas y SLOs.
4. **CI/CD con quality gates**: lint, test, typecheck, build, security scans, release strategy.
5. **Contrato API formal** (OpenAPI/versionado/deprecación).
6. **Runbooks operativos** y recuperación (backup/restore, incident response, chaos drills).

   ---

# Inteligencia Cognitiva - Isabella (Capa 2)
# Mapea la ingesta de conocimiento, procesamiento semántico y el motor de IA generativa.

```mermaid
graph TB
    classDef capa fill:#0d1b2a,stroke:#48cae4,stroke-width:2px,color:#fff,font-weight:bold;
    classDef submodulo fill:#1b263b,stroke:#00b4d8,stroke-width:1px,color:#e0e1dd;

    subgraph C2 ["2. INTELIGENCIA COGNITIVA (ISABELLA)"]
        B3["<b>KNOWLEDGE ABSORPTION</b><br>• AKAÉ Absorb<br>• Ingesta Inteligente<br>• Unificación de Fuentes<br>• Normalización"]
        B4["<b>SEMANTIC PROCESSING</b><br>• Procesamiento Semántico<br>• Embeddings<br>• Relaciones de Conocimiento<br>• Grafos de Conocimiento"]
        B2["<b>MEMORY SYSTEMS</b><br>• Memoria a Largo Plazo<br>• Memoria Semántica<br>• Contexto Persistente<br>• Episódica y Operativa"]
        B1["<b>ISABELLA ENGINE</b><br>• Motor de IA Generativa<br>• Cognitiva Integrada<br>• Razonamiento Avanzado<br>• Multi-Modelo"]
        B5["<b>ANALYTICS & REASONING</b><br>• Analítica Avanzada<br>• Razonamiento<br>• Inferencias<br>• Generación de Insights"]
    end

    B3 --> B4
    B4 --> B2
    B2 --> B1
    B1 --> B5

    class C2 capa;
    class B1,B2,B3,B4,B5 submodulo;
```

## 9) Ejecución local

### Frontend

```bash
npm install
npm run dev
```

### Checks

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

### API local

```bash
npm run api:start
```

Variables clave:

- `VITE_TAMV_BACKEND_URL`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `TAMV_ORCID`, `TAMV_ZENODO_RECORD`, `TAMV_ISNI`

---

# Servicios Federados e Interoperables (Capa 3)
# Estructura de la identidad digital (RDM), el entorno académico (UTAMV) y la economía distribuida.

```mermaid
graph TB
    classDef capa fill:#0d1b2a,stroke:#48cae4,stroke-width:2px,color:#fff,font-weight:bold;
    classDef submodulo fill:#1b263b,stroke:#00b4d8,stroke-width:1px,color:#e0e1dd;

    subgraph C3 ["3. SERVICIOS FEDERADOS"]
        direction LR
        D1["<b>IDENTIDAD DIGITAL (RDM)</b><br>• Perfiles<br>• Credenciales<br>• Membresías<br>• Reputación<br>• Verificación KYC<br>• Identidad Atómica"]
        D2["<b>UTAMV</b><br>• Universidad Autónoma Metaversal<br>• Certificaciones<br>• Cursos y Programas<br>• Investigación<br>• Aprendizaje Continuo"]
        D3["<b>CERTIFICACIONES</b><br>• Emisión<br>• Verificación<br>• Credibilidad<br>• Trazabilidad<br>• Reconocimiento Global"]
        D4["<b>GOBERNANZA DIGITAL</b><br>• Propuestas<br>• Votaciones<br>• Delegaciones<br>• Participación<br>• Transparencia"]
        D5["<b>ECONOMÍA DIGITAL</b><br>• Wallets<br>• Pagos<br>• Transacciones<br>• Contratos<br>• Economía Federada<br>• Tokens / Activos"]
        D6["<b>SEGURIDAD Y CONFIANZA</b><br>• Anubis Security<br>• Dekateotl Security<br>• PQC Hybrid<br>• Zero Trust<br>• Privacidad"]
    end

    D1 --> D4
    D2 --> D3
    D5 --> D4
    D6 --> D1

    class C3 capa;
    class D1,D2,D3,D4,D5,D6 submodulo;
```

# 4. Experiencia Federada - Frontier (Capa 4)
# La capa de interacción del usuario, portales de acceso, ecosistemas inmersivos XR y entornos Wiki.

```mermaid
graph TD
    classDef capa fill:#0d1b2a,stroke:#48cae4,stroke-width:2px,color:#fff,font-weight:bold;
    classDef submodulo fill:#1b263b,stroke:#00b4d8,stroke-width:1px,color:#e0e1dd;

    subgraph C4 ["4. EXPERIENCIA FEDERADA (FRONTIER)"]
        E1["<b>TAMV FRONTIER</b><br>• Portal Principal<br>• Acceso Universal<br>• Navegación Inteligente<br>• Personalización"]
        E2["<b>WIKI CIVILIZATORIA</b><br>• Conocimiento Abierto<br>• Colaborativo<br>• Estructura Federada<br>• Versionado<br>• Curaduría"]
        E3["<b>ATLAS EXPLORER</b><br>• Explorador de Conocimiento<br>• Relaciones<br>• Dossiers<br>• Mapas de Conocimiento"]
        E4["<b>DASHBOARDS</b><br>• Métricas Clave<br>• Indicadores<br>• Inteligencia en Tiempo Real<br>• Alertas y Monitoreo"]
        E5["<b>XR SYSTEMS</b><br>• Experiencias Inmersivas<br>• Educación XR<br>• Simulaciones<br>• Metaverso Civilizatorio"]
        E6["<b>APLICACIONES FEDERADAS</b><br>• Apps Modulares<br>• Conectadas<br>• Interoperables<br>• Descentralizadas"]
    end

    E1 --> E3 & E4
    E2 --> E3
    E5 & E6 --> E1

    class C4 capa;
    class E1,E2,E3,E4,E5,E6 submodulo;
```

# 5. Confianza, Seguridad y Cumplimiento (Capa 5)
# Criptografía post-cuántica, resguardo perimetral autónomo mediante guardianes de IA y auditorías inmutables.

```mermaid
    graph LR
    classDef capa fill:#0d1b2a,stroke:#48cae4,stroke-width:2px,color:#fff,font-weight:bold;
    classDef submodulo fill:#1b263b,stroke:#00b4d8,stroke-width:1px,color:#e0e1dd;

    subgraph C5 ["5. CONFIANZA, SEGURIDAD Y CUMPLIMIENTO"]
        F1["<b>ANUBIS SECURITY</b><br>• Operaciones de Seguridad<br>• Monitoreo Continuo<br>• Protección del Ecosistema<br>• Respuesta a Incidentes"]
        F2["<b>DEKATEOTL SECURITY</b><br>• Seguridad Avanzada<br>• Protección Proactiva<br>• Inteligencia de Amenazas<br>• Respuesta Automática"]
        F3["<b>PQC CRYPTOGRAPHY</b><br>• Criptografía Híbrida Post-Cuántica<br>• Identidad y Datos<br>• Firma y Cifrado"]
        F4["<b>CONSTITUTIONAL GUARDS</b><br>• Guardianes de IA<br>• Cumplimiento Constitucional<br>• Ética y Responsabilidad<br>• Supervisión Autónoma"]
        F5["<b>AUDIT & COMPLIANCE</b><br>• Logs Inmutables<br>• Auditoría Continua<br>• Trazabilidad Completa<br>• Informes y Evidencia"]
        F6["<b>PRIVACIDAD Y SOBERANÍA</b><br>• Protección de Datos<br>• Privacidad por Diseño<br>• Soberanía Digital<br>• Control del Usuario"]
    end

    F3 --> F6
    F1 & F2 --> F4
    F4 --> F5

    class C5 capa;
    class F1,F2,F3,F4,F5,F6 submodulo;
```

# 6. Infraestructura Digital Federada (Capa 6)
# La base tecnológica del ecosistema. Orquestación, alta disponibilidad y automatización del código.

```mermaid
graph TB
    classDef capa fill:#0d1b2a,stroke:#48cae4,stroke-width:2px,color:#fff,font-weight:bold;
    classDef submodulo fill:#1b263b,stroke:#00b4d8,stroke-width:1px,color:#e0e1dd;

    subgraph C6 ["6. INFRAESTRUCTURA DIGITAL FEDERADA"]
        direction TB
        subgraph Compute_Data ["Cómputo y Datos"]
            G1["<b>KUBERNETES</b><br>• Orquestación / Escalabilidad"]
            G2["<b>POSTGRESQL</b><br>• Base de Datos Relacional"]
            G3["<b>REDIS</b><br>• Caché y Colas de Alto Rendimiento"]
        end
        subgraph Integration_Delivery ["Integración y Despliegue"]
            G4["<b>OPENAPI</b><br>• APIs Documentadas e Interoperables"]
            G5["<b>CI/CD CONSTITUCIONAL</b><br>• Despliegue Continuo Auditado"]
            G8["<b>NETWORK & APIs</b><br>• Gateways y Conectores Federados"]
        end
        subgraph Operations ["Operaciones y Resiliencia"]
            G6["<b>MONITORING & OBSERVABILITY</b><br>• Métricas, Logs y Trazas"]
            G7["<b>CLOUD & EDGE</b><br>• Despliegue Híbrido y Multi-Cloud"]
        end
    end

    Compute_Data --> Integration_Delivery
    Integration_Delivery --> Operations

    class C6 capa;
    class G1,G2,G3,G4,G5,G6,G7,G8 submodulo;
```

# 7. Gobernanza, Constitución y Métricas (Paneles Laterales)
# El núcleo ético-político de la plataforma acompañado de sus principios inquebrantables y telemetría de avance.

```mermaid
graph TB
    classDef lateral fill:#14213d,stroke:#fca311,stroke-width:1.5px,color:#fff;
    classDef datos fill:#000814,stroke:#ffb703,stroke-width:1px,color:#ffb703;
    classDef base fill:#03071e,stroke:#370617,stroke-width:1px,color:#faa307;

    subgraph GOV ["GOBERNANZA Y CONSTITUCIÓN"]
        H1["<b>CONSTITUTIONAL RUNTIME</b><br>Reglas, límites y derechos."]
        H2["<b>POLICY ENGINE</b><br>Evaluación de políticas y cumplimiento."]
        H3["<b>AI GUARDIANS</b><br>Alineación ética y seguridad civilizatoria."]
        H4["<b>AUDIT FRAMEWORK</b><br>Logs inmutables y auditoría continua."]
        H5["<b>SOVEREIGN GOVERNANCE</b><br>Gobernanza federada distribuida."]
    end

    subgraph PRINCIPIOS ["PRINCIPIOS SOBERANOS"]
        P1["Soberanía Digital"]
        P2["Apertura e Interoperabilidad"]
        P3["Verificabilidad"]
        P4["Ética e Inclusión"]
        P5["Evolución Continua"]
    end

    subgraph METRICAS ["DATOS CLAVE & AVANCE"]
        M1["<b>+200</b> Repositorios Conectados<br><b>+3.5 TB</b> Conocimiento Federado<br><b>+120</b> Servicios Activos"]
        M2["<b>ESTADO DE AVANCE:</b><br>• Fundación: 90%<br>• Integración: 75%<br>• Servicios: 60%<br>• Experiencia: 40%<br>• Ecosistema: 25%<br>• Exp. Global: 10%"]
    end

    H1 --> H2 --> H3 --> H4 --> H5
    PRINCIPIOS -.-> GOV
    GOV --> METRICAS

    class GOV,PRINCIPIOS lateral;
    class METRICAS,M1 datos;
    class M2 base;
```

## 10) Estado ejecutivo

**TAMV Atlas hoy es un sistema real funcional en evolución**, con capacidad de operar casos de uso concretos y base suficientemente robusta para pilotos serios. Su siguiente salto no depende de “más idea”, sino de **industrialización técnica** (hardening, observabilidad, CI/CD y seguridad operativa).
