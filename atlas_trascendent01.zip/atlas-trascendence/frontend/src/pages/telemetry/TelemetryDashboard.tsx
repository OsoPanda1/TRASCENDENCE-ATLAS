/**
 * TelemetryDashboard — Metricas de Soberania y Colonialismo
 */
import { Activity, Globe, AlertTriangle, TrendingUp, Shield, Server } from "lucide-react";

export default function TelemetryDashboard() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-orange-500/10">
            <Activity className="w-6 h-6 text-orange-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Telemetry</h1>
            <p className="text-sm text-slate-400">Metricas de soberania, indicadores de colonialismo y salud del ecosistema</p>
          </div>
        </div>
      </div>

      {/* Sovereignty Score */}
      <div className="glass rounded-xl p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-sovereignty" />
            Sovereignty Score
          </h2>
          <span className="text-3xl font-bold text-sovereignty">87.4</span>
        </div>
        <div className="h-3 bg-slate-700 rounded-full overflow-hidden mb-4">
          <div className="h-full bg-gradient-to-r from-emerald-500 to-sovereignty rounded-full" style={{ width: '87.4%' }} />
        </div>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-lg font-bold text-white">92%</p>
            <p className="text-xs text-slate-400">Procesamiento Local</p>
          </div>
          <div>
            <p className="text-lg font-bold text-white">78%</p>
            <p className="text-xs text-slate-400">Integracion Open Science</p>
          </div>
          <div>
            <p className="text-lg font-bold text-white">85%</p>
            <p className="text-xs text-slate-400">Propiedad Infraestructura</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Colonialism Indicators */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            Indicadores de Colonialismo Digital
          </h2>
          <div className="space-y-4">
            {[
              { indicator: "Dependencia Externa", value: 23, threshold: 30, status: "Bajo", detail: "23% de infraestructura en nube extranjera" },
              { indicator: "Exfiltracion de Datos", value: 2, threshold: 5, status: "Muy Bajo", detail: "2 patrones sospechosos detectados" },
              { indicator: "Riesgo Jurisdiccional", value: 15, threshold: 25, status: "Bajo", detail: "15% de datos bajo jurisdiccion extranjera" },
            ].map((ind, i) => (
              <div key={i} className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-300">{ind.indicator}</span>
                  <span className={`text-xs px-2 py-1 rounded-full ${ind.status === 'Muy Bajo' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'}`}>
                    {ind.status}
                  </span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden mb-2">
                  <div className="h-full bg-amber-500 rounded-full" style={{ width: `${(ind.value / ind.threshold) * 100}%` }} />
                </div>
                <p className="text-xs text-slate-500">{ind.detail}</p>
              </div>
            ))}
          </div>
        </div>

        {/* System Health */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Server className="w-5 h-5 text-orange-400" />
            Salud del Sistema
          </h2>
          <div className="space-y-4">
            {[
              { service: "Kernel Atlas", status: "Healthy", uptime: "99.99%", latency: "12ms" },
              { service: "Isabella Engine", status: "Healthy", uptime: "99.97%", latency: "145ms" },
              { service: "Ledger BookPI", status: "Healthy", uptime: "100%", latency: "8ms" },
              { service: "Nexus Graph", status: "Healthy", uptime: "99.95%", latency: "34ms" },
              { service: "Telemetry Mesh", status: "Degraded", uptime: "98.2%", latency: "89ms" },
            ].map((svc, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div>
                  <p className="text-sm text-slate-300">{svc.service}</p>
                  <p className="text-xs text-slate-500">Latencia: {svc.latency}</p>
                </div>
                <div className="text-right">
                  <span className={`text-xs px-2 py-1 rounded-full ${svc.status === 'Healthy' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'}`}>
                    {svc.status}
                  </span>
                  <p className="text-xs text-slate-500 mt-1">{svc.uptime}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
