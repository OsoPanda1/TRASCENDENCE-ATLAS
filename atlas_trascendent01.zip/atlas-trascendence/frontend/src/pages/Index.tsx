/**
 * Index.tsx — Atlas Trascendence Hero Page
 * Pagina de bienvenida con overview del ecosistema
 */

import { Link } from "react-router-dom";
import {
  Shield, Brain, Users, Building2, GraduationCap, Globe, Cpu,
  Activity, BookOpen, ArrowRight, Hexagon, Lock, Eye, Server
} from "lucide-react";

const FEDERATIONS = [
  {
    id: "F1",
    name: "Identidad y Ciudadania",
    path: "/f1",
    icon: Users,
    color: "from-blue-500/20 to-blue-600/5",
    border: "border-blue-500/30",
    iconColor: "text-blue-400",
    description: "DIDs, credenciales verificables, IDNVIDA, KYC y soberania de identidad",
  },
  {
    id: "F2",
    name: "Gobernanza e Instituciones",
    path: "/f2",
    icon: Building2,
    color: "from-emerald-500/20 to-emerald-600/5",
    border: "border-emerald-500/30",
    iconColor: "text-emerald-400",
    description: "Votacion, delegacion, transparencia institucional y auditoria",
  },
  {
    id: "F3",
    name: "Economia y Finanzas",
    path: "/f3",
    icon: Globe,
    color: "from-amber-500/20 to-amber-600/5",
    border: "border-amber-500/30",
    iconColor: "text-amber-400",
    description: "Wallets soberanas, contratos inteligentes, economia federada",
  },
  {
    id: "F4",
    name: "Cognicion e Inteligencia",
    path: "/f4",
    icon: Brain,
    color: "from-purple-500/20 to-purple-600/5",
    border: "border-purple-500/30",
    iconColor: "text-purple-400",
    description: "Isabella Kernel, EOCT, razonamiento etico y explicabilidad",
  },
  {
    id: "F5",
    name: "Infraestructura y Territorio",
    path: "/f5",
    icon: Cpu,
    color: "from-rose-500/20 to-rose-600/5",
    border: "border-rose-500/30",
    iconColor: "text-rose-400",
    description: "Nodos territoriales, telemetria urbana, gemelos digitales",
  },
  {
    id: "F6",
    name: "Educacion y Conocimiento",
    path: "/f6",
    icon: GraduationCap,
    color: "from-cyan-500/20 to-cyan-600/5",
    border: "border-cyan-500/30",
    iconColor: "text-cyan-400",
    description: "UTAMV, credenciales academicas, ciencia abierta",
  },
  {
    id: "F7",
    name: "XR y Experiencias",
    path: "/f7",
    icon: Globe,
    color: "from-pink-500/20 to-pink-600/5",
    border: "border-pink-500/30",
    iconColor: "text-pink-400",
    description: "MD-X4 Quantum, DreamSpaces, metaverso productivo",
  },
];

const PILLARS = [
  { icon: Shield, title: "Soberania", desc: "Control territorial total de datos e infraestructura", color: "text-sovereignty" },
  { icon: Lock, title: "Dignidad", desc: "Etica algoritmica vinculante y derechos digitales", color: "text-dignity" },
  { icon: Eye, title: "Transparencia", desc: "Auditoria completa via ledger inmutable BookPI", color: "text-atlas-400" },
  { icon: Server, title: "Resiliencia", desc: "Operacion continua incluso en modo degradado", color: "text-emerald-400" },
];

export default function Index() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden pt-16 pb-20">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-atlas-900/40 via-slate-950 to-slate-950" />
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-atlas-500/10 rounded-full blur-3xl" />

        <div className="relative max-w-6xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-atlas-500/10 border border-atlas-500/20 text-atlas-300 text-xs font-medium mb-6">
            <Hexagon className="w-3 h-3" />
            v2.0.0-trascendence
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
            <span className="text-white">Atlas</span>
            <span className="text-gradient"> Trascendence</span>
          </h1>

          <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto mb-4 leading-relaxed">
            Infraestructura civilizatoria universal para operar cualquier ecosistema
            con <span className="text-sovereignty font-medium">soberania</span>,{" "}
            <span className="text-dignity font-medium">dignidad</span> y{" "}
            <span className="text-atlas-400 font-medium">auditabilidad total</span>.
          </p>

          <p className="text-sm text-slate-500 max-w-xl mx-auto mb-10">
            De TAMV al universo. Implementacion de referencia del estandar Atlas Trascendence.
            Modelo heptafederado: 7 dominios operativos para la civilizacion digital.
          </p>

          <div className="flex flex-wrap justify-center gap-3 mb-16">
            <Link
              to="/f1"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-atlas-600 hover:bg-atlas-500 text-white rounded-lg font-medium transition-all"
            >
              Explorar Federaciones
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/docs"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-medium transition-all border border-slate-700"
            >
              <BookOpen className="w-4 h-4" />
              Documentacion
            </Link>
            <Link
              to="/sovereignty"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-sovereignty rounded-lg font-medium transition-all border border-sovereignty/30"
            >
              <Shield className="w-4 h-4" />
              Soberania
            </Link>
          </div>

          {/* Pillars */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 max-w-3xl mx-auto">
            {PILLARS.map((pillar) => (
              <div key={pillar.title} className="glass rounded-xl p-4 text-center">
                <pillar.icon className={`w-6 h-6 ${pillar.color} mx-auto mb-2`} />
                <h3 className="text-sm font-semibold text-white mb-1">{pillar.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{pillar.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Federations Grid */}
      <section className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-white mb-2">Las 7 Federaciones</h2>
            <p className="text-slate-400 text-sm">
              Modelo heptafederado: cada federacion es un dominio soberano con gobernanza propia
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {FEDERATIONS.map((fed) => (
              <Link
                key={fed.id}
                to={fed.path}
                className={`group relative rounded-xl border ${fed.border} bg-gradient-to-br ${fed.color} p-5 transition-all hover:scale-[1.02] hover:shadow-lg`}
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg bg-slate-900/50 ${fed.iconColor}`}>
                    <fed.icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-xs font-bold ${fed.iconColor}`}>{fed.id}</span>
                      <h3 className="text-sm font-semibold text-white truncate">{fed.name}</h3>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                      {fed.description}
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-500 absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Tools Section */}
      <section className="py-16 px-6 border-t border-slate-800">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-white mb-2">Herramientas Operativas</h2>
            <p className="text-slate-400 text-sm">
              Monitoreo, inteligencia y gobernanza en tiempo real
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { path: "/nexus", icon: BookOpen, title: "Nexus Graph", desc: "Grafo civilizatorio de conocimiento", color: "text-indigo-400", bg: "border-indigo-500/20" },
              { path: "/telemetry", icon: Activity, title: "Telemetry", desc: "Metricas de soberania y colonialismo", color: "text-orange-400", bg: "border-orange-500/20" },
              { path: "/sovereignty", icon: Shield, title: "Soberania", desc: "Panel de soberania tecnologica", color: "text-sovereignty", bg: "border-sovereignty/20" },
              { path: "/isabella", icon: Brain, title: "Isabella AI", desc: "Consola de inteligencia etica", color: "text-purple-400", bg: "border-purple-500/20" },
            ].map((tool) => (
              <Link
                key={tool.path}
                to={tool.path}
                className={`glass rounded-xl p-5 border ${tool.bg} hover:border-opacity-50 transition-all hover:scale-[1.02]`}
              >
                <tool.icon className={`w-6 h-6 ${tool.color} mb-3`} />
                <h3 className="text-sm font-semibold text-white mb-1">{tool.title}</h3>
                <p className="text-xs text-slate-400">{tool.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-slate-800">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-atlas-400" />
            <span className="text-xs text-slate-500">
              Atlas Trascendence v2.0.0 — Preservando aquello que las personas consideran digno de ser recordado
            </span>
          </div>
          <div className="flex gap-4 text-xs text-slate-500">
            <Link to="/docs" className="hover:text-atlas-400 transition-colors">Documentacion</Link>
            <a href="https://github.com/OsoPanda1/tamv-atlas-trasendencia" className="hover:text-atlas-400 transition-colors">GitHub</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
