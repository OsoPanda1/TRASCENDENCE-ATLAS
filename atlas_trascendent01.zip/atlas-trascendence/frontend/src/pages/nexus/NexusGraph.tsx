/**
 * NexusGraph — Grafo Civilizatorio Atlas Trascendence
 */
import { BookOpen, Network, FileText, Users, Tag, GitBranch } from "lucide-react";

export default function NexusGraph() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-indigo-500/10">
            <Network className="w-6 h-6 text-indigo-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Nexus — Grafo Civilizatorio</h1>
            <p className="text-sm text-slate-400">Conocimiento, relaciones, provenance y malla civilizatoria</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-4 mb-6">
        <div className="glass rounded-xl p-5">
          <Users className="w-5 h-5 text-indigo-400 mb-2" />
          <p className="text-sm text-slate-400">Personas</p>
          <p className="text-2xl font-bold text-white">45,231</p>
        </div>
        <div className="glass rounded-xl p-5">
          <FileText className="w-5 h-5 text-indigo-400 mb-2" />
          <p className="text-sm text-slate-400">Documentos</p>
          <p className="text-2xl font-bold text-white">12,847</p>
        </div>
        <div className="glass rounded-xl p-5">
          <Tag className="w-5 h-5 text-indigo-400 mb-2" />
          <p className="text-sm text-slate-400">Relaciones</p>
          <p className="text-2xl font-bold text-white">89,432</p>
        </div>
        <div className="glass rounded-xl p-5">
          <GitBranch className="w-5 h-5 text-indigo-400 mb-2" />
          <p className="text-sm text-slate-400">Evidencias</p>
          <p className="text-2xl font-bold text-white">34,567</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Civilizational Mesh */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Network className="w-5 h-5 text-indigo-400" />
            Malla Civilizatoria
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Personas", count: 45231, type: "node" },
              { label: "Proyectos", count: 1234, type: "project" },
              { label: "Documentos", count: 12847, type: "document" },
              { label: "Evidencias", count: 34567, type: "evidence" },
              { label: "Fuentes", count: 5678, type: "source" },
              { label: "Federaciones", count: 7, type: "federation" },
            ].map((item, i) => (
              <div key={i} className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/50 text-center">
                <p className="text-lg font-bold text-white">{item.count.toLocaleString()}</p>
                <p className="text-xs text-slate-400">{item.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Provenance */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-400" />
            Provenance Academico
          </h2>
          <div className="space-y-3">
            {[
              { repo: "Zenodo", count: 156, desc: "DOIs asignados a documentos Atlas" },
              { repo: "Figshare", count: 89, desc: "Datasets y figuras academicas" },
              { repo: "OpenAIRE", count: 234, desc: "Publicaciones indexadas" },
              { repo: "ORCID", count: 567, desc: "Investigadores vinculados" },
              { repo: "ISNI", count: 12, desc: "Instituciones identificadas" },
            ].map((prov, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div>
                  <p className="text-sm font-medium text-white">{prov.repo}</p>
                  <p className="text-xs text-slate-500">{prov.desc}</p>
                </div>
                <p className="text-sm font-bold text-indigo-300">{prov.count}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
