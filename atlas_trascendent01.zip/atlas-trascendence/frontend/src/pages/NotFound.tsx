import { Link } from "react-router-dom";
import { Home, AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-[calc(100vh-3.5rem)] flex items-center justify-center px-6">
      <div className="text-center">
        <AlertTriangle className="w-12 h-12 text-amber-400 mx-auto mb-4" />
        <h1 className="text-4xl font-bold text-white mb-2">404</h1>
        <p className="text-slate-400 mb-6">Esta pagina no existe en el Atlas.</p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-atlas-600 hover:bg-atlas-500 text-white rounded-lg font-medium transition-all"
        >
          <Home className="w-4 h-4" />
          Volver al Inicio
        </Link>
      </div>
    </div>
  );
}
