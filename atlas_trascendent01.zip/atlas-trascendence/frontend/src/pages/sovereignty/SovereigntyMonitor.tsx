/**
 * SovereigntyMonitor — Panel de Soberania Tecnologica
 */
import { Shield, Globe, Lock, Server, AlertTriangle, CheckCircle } from "lucide-react";

export default function SovereigntyMonitor() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-emerald-500/10">
            <Shield className="w-6 h-6 text-sovereignty" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Monitor de Soberania</h1>
            <p className="text-sm text-slate-400">Control territorial de datos, infraestructura y jurisdiccion</p>
          </div>
        </div>
      </div>

      {/* Sovereignty Status */}
      <div className="grid lg:grid-cols-4 gap-4 mb-6">
        <div className="glass rounded-xl p-5 border border-sovereignty/20">
          <Server className="w-5 h-5 text-sovereignty mb-2" />
          <p className="text-sm text-slate-400">Infraestructura Local</p>
          <p className="text-2xl font-bold text-white">92%</p>
          <p className="text-xs text-emerald-400">Meta: 85%</p>
        </div>
        <div className="glass rounded-xl p-5 border border-sovereignty/20">
          <Lock className="w-5 h-5 text-sovereignty mb-2" />
          <p className="text-sm text-slate-400">Datos en Territorio</p>
          <p className="text-2xl font-bold text-white">94%</p>
          <p className="text-xs text-emerald-400">Meta: 90%</p>
        </div>
        <div className="glass rounded-xl p-5 border border-sovereignty/20">
          <Globe className="w-5 h-5 text-sovereignty mb-2" />
          <p className="text-sm text-slate-400">Jurisdiccion Local</p>
          <p className="text-2xl font-bold text-white">89%</p>
          <p className="text-xs text-emerald-400">Meta: 80%</p>
        </div>
        <div className="glass rounded-xl p-5 border border-sovereignty/20">
          <Shield className="w-5 h-5 text-sovereignty mb-2" />
          <p className="text-sm text-slate-400">Score Global</p>
          <p className="text-2xl font-bold text-sovereignty">87.4</p>
          <p className="text-xs text-emerald-400">+2.3 vs mes anterior</p>
        </div>
      </div>

      {/* Jurisdiction Mapping */}
      <div className="glass rounded-xl p-6 mb-6">
        <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Globe className="w-5 h-5 text-sovereignty" />
          Mapa de Jurisdiccion de Datos
        </h2>
        <div className="space-y-3">
          {[
            { jurisdiction: "Mexico (Local)", percentage: 78, status: "soberano", detail: "Datos bajo control territorial" },
            { jurisdiction: "Union Europea (GDPR)", percentage: 12, status: "alineado", detail: "Transferencia con salvaguardas adecuadas" },
            { jurisdiction: "Estados Unidos", percentage: 6, status: "riesgo", detail: "Exposicion a CLOUD Act" },
            { jurisdiction: "Otros", percentage: 4, status: "neutral", detail: "Diversificacion menor" },
          ].map((jur, i) => (
            <div key={i} className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-300">{jur.jurisdiction}</span>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold text-white">{jur.percentage}%</span>
                  {jur.status === 'soberano' && <CheckCircle className="w-4 h-4 text-emerald-400" />}
                  {jur.status === 'riesgo' && <AlertTriangle className="w-4 h-4 text-amber-400" />}
                </div>
              </div>
              <div className="h-2 bg-slate-700 rounded-full overflow-hidden mb-1">
                <div className={`h-full rounded-full ${
                  jur.status === 'soberano' ? 'bg-emerald-500' :
                  jur.status === 'riesgo' ? 'bg-amber-500' :
                  'bg-blue-500'
                }`} style={{ width: `${jur.percentage}%` }} />
              </div>
              <p className="text-xs text-slate-500">{jur.detail}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Data Residency Policies */}
      <div className="glass rounded-xl p-6">
        <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Lock className="w-5 h-5 text-sovereignty" />
          Politicas de Residencia de Datos
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { title: "Datos Personales", policy: "Obligatorio local", enforcement: "Estricto", detail: "Identidades, perfiles, credenciales" },
            { title: "Datos de Gobernanza", policy: "Obligatorio local", enforcement: "Estricto", detail: "Votos, decisiones, auditorias" },
            { title: "Datos Economicos", policy: "Preferente local", enforcement: "Moderado", detail: "Transacciones, wallets" },
            { title: "Datos de Telemetria", policy: "Preferente local", enforcement: "Moderado", detail: "Sensores, metricas urbanas" },
            { title: "Datos de IA", policy: "Revisado caso a caso", enforcement: "Flexible", detail: "Modelos, embeddings" },
            { title: "Datos Educativos", policy: "Obligatorio local", enforcement: "Estricto", detail: "Registros UTAMV" },
          ].map((pol, i) => (
            <div key={i} className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
              <h3 className="text-sm font-medium text-white mb-1">{pol.title}</h3>
              <p className="text-xs text-slate-400 mb-2">{pol.detail}</p>
              <div className="flex items-center justify-between">
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  pol.enforcement === 'Estricto' ? 'bg-rose-500/10 text-rose-400' :
                  'bg-amber-500/10 text-amber-400'
                }`}>{pol.enforcement}</span>
                <span className="text-xs text-slate-500">{pol.policy}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
