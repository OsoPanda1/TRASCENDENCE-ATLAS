/**
 * IsabellaConsole — Consola de Inteligencia Etica Atlas Trascendence
 */
import { Brain, Send, TreePine, Eye, Sparkles, MessageSquare } from "lucide-react";
import { useState } from "react";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  eoctResult?: {
    approved: boolean;
    confidence: number;
  };
}

export default function IsabellaConsole() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: "Hola, soy Isabella. Soy el nucleo de inteligencia etica de Atlas Trascendence. Todas mis respuestas pasan por el EOCT (Ethical Operational Cognitive Tree). Como puedo ayudarte hoy?",
    },
  ]);
  const [input, setInput] = useState("");

  const sendMessage = () => {
    if (!input.trim()) return;
    const userMsg: ChatMessage = { role: "user", content: input };
    setMessages(prev => [...prev, userMsg]);
    
    // Simulate Isabella response
    setTimeout(() => {
      const assistantMsg: ChatMessage = {
        role: "assistant",
        content: `He procesado tu solicitud: "${input}". La evaluacion EOCT indica que esta operacion es eticamente viable con un nivel de confianza del 94%. Puedo proceder con el analisis solicitado.`,
        eoctResult: { approved: true, confidence: 0.94 },
      };
      setMessages(prev => [...prev, assistantMsg]);
    }, 800);
    
    setInput("");
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-8 h-[calc(100vh-3.5rem)] flex flex-col">
      <div className="mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-purple-500/10">
            <Brain className="w-6 h-6 text-purple-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Isabella AI</h1>
            <p className="text-sm text-slate-400">Consola de inteligencia etica — EOCT activo</p>
          </div>
        </div>
      </div>

      <div className="flex-1 grid lg:grid-cols-3 gap-6 min-h-0">
        {/* Chat */}
        <div className="lg:col-span-2 glass rounded-xl flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
            {messages.map((msg, i) => (
              <div key={i} className={`flex gap-3 ${msg.role === "user" ? "justify-end" : ""}`}>
                {msg.role === "assistant" && (
                  <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center shrink-0">
                    <Brain className="w-4 h-4 text-purple-400" />
                  </div>
                )}
                <div className={`max-w-[80%] p-3 rounded-xl ${
                  msg.role === "user" 
                    ? "bg-atlas-600 text-white" 
                    : "bg-slate-800 border border-slate-700"
                }`}>
                  <p className="text-sm">{msg.content}</p>
                  {msg.eoctResult && (
                    <div className="mt-2 flex items-center gap-2 text-xs">
                      <TreePine className="w-3 h-3 text-emerald-400" />
                      <span className="text-emerald-400">EOCT: APROBADO</span>
                      <span className="text-slate-500">{(msg.eoctResult.confidence * 100).toFixed(0)}% conf</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          <div className="p-3 border-t border-slate-700 flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              placeholder="Pregunta a Isabella..."
              className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
            />
            <button
              onClick={sendMessage}
              className="p-2 bg-purple-600 hover:bg-purple-500 rounded-lg text-white transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          <div className="glass rounded-xl p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Eye className="w-4 h-4 text-purple-400" />
              Explicabilidad
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Cada respuesta de Isabella incluye un factor de explicabilidad que detalla
              los factores que influyeron en la decision.
            </p>
          </div>
          <div className="glass rounded-xl p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              Memoria
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Isabella mantiene memoria de contexto a largo plazo con recuperacion
              semantica de conversaciones previas.
            </p>
            <p className="text-xs text-purple-400 mt-2">1,247 entradas en memoria</p>
          </div>
          <div className="glass rounded-xl p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-purple-400" />
              Estadisticas
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between"><span className="text-slate-400">Consultas hoy</span><span className="text-white">847</span></div>
              <div className="flex justify-between"><span className="text-slate-400">Tasa de aprobacion EOCT</span><span className="text-emerald-400">99.2%</span></div>
              <div className="flex justify-between"><span className="text-slate-400">Revisiones humanas</span><span className="text-amber-400">12</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
