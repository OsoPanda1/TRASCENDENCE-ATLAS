/**
 * F2 Governance & Institutions Federation
 */
import { Building2, Vote, Gavel, FileText, Users, Activity } from "lucide-react";

export default function F2Governance() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-emerald-500/10">
            <Building2 className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">F2 — Gobernanza e Instituciones</h1>
            <p className="text-sm text-slate-400">Modelos de decision, transparencia institucional y auditoria</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Active Proposals */}
        <div className="lg:col-span-2 glass rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white flex items-center gap-2">
              <Vote className="w-5 h-5 text-emerald-400" />
              Propuestas Activas
            </h2>
            <button className="text-xs px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors">
              Nueva Propuesta
            </button>
          </div>
          <div className="space-y-3">
            {[
              { title: "Ampliar nodos mesh a zonas rurales", votes: { for: 847, against: 123, abstain: 45 }, status: "En votacion", deadline: "3 dias" },
              { title: "Integrar nuevo proveedor de identidad", votes: { for: 623, against: 201, abstain: 89 }, status: "En votacion", deadline: "5 dias" },
              { title: "Actualizar politica de retencion de datos", votes: { for: 912, against: 34, abstain: 12 }, status: "Aprobada", deadline: "Cerrada" },
            ].map((prop, i) => (
              <div key={i} className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium text-white">{prop.title}</h3>
                  <span className={`text-xs px-2 py-1 rounded-full ${prop.status === 'Aprobada' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'}`}>
                    {prop.status}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-xs">
                  <span className="text-emerald-400">{prop.votes.for} a favor</span>
                  <span className="text-rose-400">{prop.votes.against} en contra</span>
                  <span className="text-slate-500">{prop.votes.abstain} abstenciones</span>
                  <span className="text-slate-500 ml-auto">{prop.deadline}</span>
                </div>
                <div className="mt-2 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${(prop.votes.for / (prop.votes.for + prop.votes.against + prop.votes.abstain)) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="space-y-4">
          <div className="glass rounded-xl p-5">
            <Users className="w-5 h-5 text-emerald-400 mb-2" />
            <p className="text-sm text-slate-400">Participacion Ciudadana</p>
            <p className="text-2xl font-bold text-white">67.3%</p>
          </div>
          <div className="glass rounded-xl p-5">
            <Gavel className="w-5 h-5 text-emerald-400 mb-2" />
            <p className="text-sm text-slate-400">Decisiones este mes</p>
            <p className="text-2xl font-bold text-white">24</p>
          </div>
          <div className="glass rounded-xl p-5">
            <FileText className="w-5 h-5 text-emerald-400 mb-2" />
            <p className="text-sm text-slate-400">Transparencia</p>
            <p className="text-2xl font-bold text-white">100%</p>
            <p className="text-xs text-slate-500">Todas las decisiones publicas</p>
          </div>
          <div className="glass rounded-xl p-5">
            <Activity className="w-5 h-5 text-emerald-400 mb-2" />
            <p className="text-sm text-slate-400">Tiempo promedio de decision</p>
            <p className="text-2xl font-bold text-white">4.2 dias</p>
          </div>
        </div>
      </div>
    </div>
  );
}
