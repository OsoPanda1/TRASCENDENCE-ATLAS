/**
 * F7 XR & Experiences Federation
 */
import { Globe, Box, Glasses, Layers, Zap, Palette } from "lucide-react";

export default function F7XR() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-pink-500/10">
            <Globe className="w-6 h-6 text-pink-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">F7 — XR y Experiencias</h1>
            <p className="text-sm text-slate-400">MD-X4 Quantum, XR4D, DreamSpaces, gemelos XR, metaverso productivo</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-4 mb-6">
        <div className="glass rounded-xl p-5">
          <Glasses className="w-5 h-5 text-pink-400 mb-2" />
          <p className="text-sm text-slate-400">Espacios XR Activos</p>
          <p className="text-2xl font-bold text-white">23</p>
        </div>
        <div className="glass rounded-xl p-5">
          <Box className="w-5 h-5 text-pink-400 mb-2" />
          <p className="text-sm text-slate-400">Gemelos Digitales</p>
          <p className="text-2xl font-bold text-white">12</p>
        </div>
        <div className="glass rounded-xl p-5">
          <Zap className="w-5 h-5 text-pink-400 mb-2" />
          <p className="text-sm text-slate-400">Sesiones 24h</p>
          <p className="text-2xl font-bold text-white">1,847</p>
        </div>
        <div className="glass rounded-xl p-5">
          <Palette className="w-5 h-5 text-pink-400 mb-2" />
          <p className="text-sm text-slate-400">Experiencias Creadas</p>
          <p className="text-2xl font-bold text-white">156</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* DreamSpaces */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Layers className="w-5 h-5 text-pink-400" />
            DreamSpaces
          </h2>
          <div className="space-y-3">
            {[
              { name: "Plaza Principal RDM", type: "Espacio Publico", visitors: 1240, status: "Online" },
              { name: "Museo de Mineria Virtual", type: "Cultural", visitors: 567, status: "Online" },
              { name: "Campus UTAMV XR", type: "Educativo", visitors: 892, status: "Online" },
              { name: "Centro de Gobernanza 3D", type: "Institucional", visitors: 234, status: "Online" },
              { name: "Mercado Digital Federado", type: "Comercial", visitors: 456, status: "Beta" },
            ].map((space, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div>
                  <p className="text-sm font-medium text-white">{space.name}</p>
                  <p className="text-xs text-slate-500">{space.type}</p>
                </div>
                <div className="text-right">
                  <span className={`text-xs px-2 py-1 rounded-full ${space.status === 'Online' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'}`}>
                    {space.status}
                  </span>
                  <p className="text-xs text-slate-500 mt-1">{space.visitors} visitas</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* MD-X4 Quantum */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-pink-400" />
            MD-X4 Quantum
          </h2>
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
              <h3 className="text-sm font-medium text-white mb-2">Motor de Observabilidad Civilizatoria</h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-3">
                MD-X4 es el nucleo de observabilidad de Atlas Trascendence. Visualiza en tiempo real
                el estado de todas las federaciones, nodos, metricas de soberania y eventos del ecosistema.
              </p>
              <div className="flex gap-2">
                <span className="text-xs px-2 py-1 rounded bg-pink-500/10 text-pink-400">Real-time</span>
                <span className="text-xs px-2 py-1 rounded bg-pink-500/10 text-pink-400">3D/VR</span>
                <span className="text-xs px-2 py-1 rounded bg-pink-500/10 text-pink-400">WebXR</span>
              </div>
            </div>
            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
              <h3 className="text-sm font-medium text-white mb-2">XR4D — Experiencias Inmersivas</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Framework de experiencias XR para educacion, gobernanza, comercio y cultura.
                Compatible con WebXR, OpenXR y dispositivos standalone.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
