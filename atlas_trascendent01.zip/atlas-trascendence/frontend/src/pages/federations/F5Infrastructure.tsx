/**
 * F5 Infrastructure & Territory Federation
 */
import { Cpu, MapPin, Radio, Server, Wifi, HardDrive } from "lucide-react";

export default function F5Infrastructure() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-rose-500/10">
            <Cpu className="w-6 h-6 text-rose-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">F5 — Infraestructura y Territorio</h1>
            <p className="text-sm text-slate-400">Nodos territoriales, telemetria urbana, gemelos digitales, redes mesh</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-4 mb-6">
        <div className="glass rounded-xl p-5">
          <Server className="w-5 h-5 text-rose-400 mb-2" />
          <p className="text-sm text-slate-400">Nodos Activos</p>
          <p className="text-2xl font-bold text-white">47</p>
        </div>
        <div className="glass rounded-xl p-5">
          <Wifi className="w-5 h-5 text-rose-400 mb-2" />
          <p className="text-sm text-slate-400">Redes Mesh</p>
          <p className="text-2xl font-bold text-white">12</p>
        </div>
        <div className="glass rounded-xl p-5">
          <Radio className="w-5 h-5 text-rose-400 mb-2" />
          <p className="text-sm text-slate-400">Sensores IoT</p>
          <p className="text-2xl font-bold text-white">3,847</p>
        </div>
        <div className="glass rounded-xl p-5">
          <HardDrive className="w-5 h-5 text-emerald-400 mb-2" />
          <p className="text-sm text-slate-400">Uptime Global</p>
          <p className="text-2xl font-bold text-white">99.97%</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Node Map */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-rose-400" />
            Nodos Territoriales
          </h2>
          <div className="space-y-3">
            {[
              { name: "RDM Digital — Real del Monte", type: "Nodo Principal", status: "Online", sensors: 1240, mesh: "Activa" },
              { name: "Pachuca Centro", type: "Nodo Urbano", status: "Online", sensors: 856, mesh: "Activa" },
              { name: "Mineral del Chico", type: "Nodo Rural", status: "Online", sensors: 234, mesh: "Degradada" },
              { name: "Huasca de Ocampo", type: "Nodo Turistico", status: "Online", sensors: 567, mesh: "Activa" },
              { name: "Zimapán", type: "Nodo Fronterizo", status: "Mantenimiento", sensors: 89, mesh: "Inactiva" },
            ].map((node, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div>
                  <p className="text-sm font-medium text-white">{node.name}</p>
                  <p className="text-xs text-slate-500">{node.type} — {node.sensors} sensores</p>
                </div>
                <div className="text-right">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    node.status === 'Online' ? 'bg-emerald-500/10 text-emerald-400' :
                    node.status === 'Mantenimiento' ? 'bg-amber-500/10 text-amber-400' :
                    'bg-rose-500/10 text-rose-400'
                  }`}>
                    {node.status}
                  </span>
                  <p className="text-xs text-slate-500 mt-1">Mesh: {node.mesh}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Telemetry */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Radio className="w-5 h-5 text-rose-400" />
            Telemetria Urbana
          </h2>
          <div className="space-y-4">
            {[
              { metric: "Calidad del Aire", value: "Buena", detail: "PM2.5: 12 ug/m3", trend: "mejorando" },
              { metric: "Trafico Vehicular", value: "Moderado", detail: "45 veh/min promedio", trend: "estable" },
              { metric: "Consumo Electrico", value: "2.4 MW", detail: "97% renovable", trend: "optimo" },
              { metric: "Nivel de Ruido", value: "58 dB", detail: "Dentro de norma", trend: "estable" },
              { metric: "Temperatura", value: "18C", detail: "Promedio diario", trend: "normal" },
            ].map((tel, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div>
                  <p className="text-sm text-slate-300">{tel.metric}</p>
                  <p className="text-xs text-slate-500">{tel.detail}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-white">{tel.value}</p>
                  <span className={`text-xs ${
                    tel.trend === 'mejorando' ? 'text-emerald-400' :
                    tel.trend === 'optimo' ? 'text-emerald-400' :
                    'text-slate-500'
                  }`}>{tel.trend}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
