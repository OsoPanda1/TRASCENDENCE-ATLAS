/**
 * F4 Cognition & Intelligence Federation — Isabella Kernel
 */
import { Brain, TreePine, Eye, MessageSquare, Sparkles, Activity } from "lucide-react";

export default function F4Cognition() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-purple-500/10">
            <Brain className="w-6 h-6 text-purple-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">F4 — Cognicion e Inteligencia</h1>
            <p className="text-sm text-slate-400">Isabella Kernel, EOCT, memoria vectorial, razonamiento etico</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-4 mb-6">
        <div className="glass rounded-xl p-5">
          <Sparkles className="w-5 h-5 text-purple-400 mb-2" />
          <p className="text-sm text-slate-400">Consultas Procesadas</p>
          <p className="text-2xl font-bold text-white">184,392</p>
        </div>
        <div className="glass rounded-xl p-5">
          <TreePine className="w-5 h-5 text-purple-400 mb-2" />
          <p className="text-sm text-slate-400">Evaluaciones EOCT</p>
          <p className="text-2xl font-bold text-white">12,847</p>
        </div>
        <div className="glass rounded-xl p-5">
          <Eye className="w-5 h-5 text-purple-400 mb-2" />
          <p className="text-sm text-slate-400">Explicaciones Generadas</p>
          <p className="text-2xl font-bold text-white">45,231</p>
        </div>
        <div className="glass rounded-xl p-5">
          <Activity className="w-5 h-5 text-emerald-400 mb-2" />
          <p className="text-sm text-slate-400">Precision Etica</p>
          <p className="text-2xl font-bold text-white">99.2%</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* EOCT Panel */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <TreePine className="w-5 h-5 text-purple-400" />
            EOCT — Ethical Operational Cognitive Tree
          </h2>
          <p className="text-xs text-slate-400 mb-4">
            El EOCT evalua cada operacion en 5 dimensiones eticas antes de permitir su ejecucion.
            Solo las operaciones que superan el umbral en todas las dimensiones son aprobadas.
          </p>
          <div className="space-y-3">
            {[
              { dimension: "Dignidad Humana", score: 0.94, threshold: 0.30, color: "bg-blue-500" },
              { dimension: "Autonomia", score: 0.89, threshold: 0.30, color: "bg-emerald-500" },
              { dimension: "Imparcialidad", score: 0.91, threshold: 0.30, color: "bg-amber-500" },
              { dimension: "Transparencia", score: 0.96, threshold: 0.30, color: "bg-purple-500" },
              { dimension: "Responsabilidad", score: 0.93, threshold: 0.30, color: "bg-rose-500" },
            ].map((dim, i) => (
              <div key={i}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">{dim.dimension}</span>
                  <span className="text-slate-400">{(dim.score * 100).toFixed(0)}%</span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div className={`h-full ${dim.color} rounded-full transition-all`} style={{ width: `${dim.score * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Evaluations */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-purple-400" />
            Evaluaciones Recientes
          </h2>
          <div className="space-y-3">
            {[
              { op: "Procesamiento de solicitud KYC", result: "APROBADO", confidence: 0.97, time: "2m ago" },
              { op: "Analisis de datos demograficos", result: "APROBADO", confidence: 0.89, time: "5m ago" },
              { op: "Generacion de perfil de credito", result: "REVISION_HUMANA", confidence: 0.72, time: "12m ago" },
              { op: "Automatizacion de decision gubernamental", result: "BLOQUEADO", confidence: 0.45, time: "15m ago" },
              { op: "Anonimizacion de dataset", result: "APROBADO", confidence: 0.95, time: "23m ago" },
            ].map((eval_, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-300 truncate">{eval_.op}</p>
                  <p className="text-xs text-slate-500">{eval_.time}</p>
                </div>
                <div className="text-right ml-3">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    eval_.result === 'APROBADO' ? 'bg-emerald-500/10 text-emerald-400' :
                    eval_.result === 'BLOQUEADO' ? 'bg-rose-500/10 text-rose-400' :
                    'bg-amber-500/10 text-amber-400'
                  }`}>
                    {eval_.result}
                  </span>
                  <p className="text-xs text-slate-500 mt-1">{(eval_.confidence * 100).toFixed(0)}% conf</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
