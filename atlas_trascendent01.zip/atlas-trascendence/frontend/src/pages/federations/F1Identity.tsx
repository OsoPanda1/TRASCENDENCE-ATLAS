/**
 * F1 Identity & Citizenship Federation
 */
import { Users, Fingerprint, CreditCard, Lock, CheckCircle, AlertTriangle } from "lucide-react";

export default function F1Identity() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-blue-500/10">
            <Users className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">F1 — Identidad y Ciudadania</h1>
            <p className="text-sm text-slate-400">Sistema soberano de identidad digital autosoberana (SSI/DID)</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* DID Registry */}
        <div className="lg:col-span-2 glass rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white flex items-center gap-2">
              <Fingerprint className="w-5 h-5 text-blue-400" />
              Registro DID
            </h2>
            <span className="text-xs px-2 py-1 rounded-full bg-blue-500/10 text-blue-300">Activo</span>
          </div>
          <div className="space-y-3">
            {[
              { did: "did:atlas:rdm:abc123", type: "Ciudadano", status: "Verificado", date: "2026-06-10" },
              { did: "did:atlas:rdm:def456", type: "Empresa", status: "Pendiente", date: "2026-06-15" },
              { did: "did:atlas:rdm:ghi789", type: "Institucion", status: "Verificado", date: "2026-06-12" },
            ].map((entry, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div>
                  <p className="text-sm font-mono text-blue-300">{entry.did}</p>
                  <p className="text-xs text-slate-500">{entry.type} — {entry.date}</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${entry.status === 'Verificado' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'}`}>
                  {entry.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="space-y-4">
          <div className="glass rounded-xl p-5">
            <div className="flex items-center gap-3 mb-3">
              <CheckCircle className="w-5 h-5 text-emerald-400" />
              <span className="text-sm text-slate-400">DIDs Verificados</span>
            </div>
            <p className="text-3xl font-bold text-white">12,847</p>
            <p className="text-xs text-emerald-400 mt-1">+234 esta semana</p>
          </div>
          <div className="glass rounded-xl p-5">
            <div className="flex items-center gap-3 mb-3">
              <CreditCard className="w-5 h-5 text-blue-400" />
              <span className="text-sm text-slate-400">Credenciales Emitidas</span>
            </div>
            <p className="text-3xl font-bold text-white">45,231</p>
            <p className="text-xs text-blue-400 mt-1">+1,892 este mes</p>
          </div>
          <div className="glass rounded-xl p-5">
            <div className="flex items-center gap-3 mb-3">
              <Lock className="w-5 h-5 text-dignity" />
              <span className="text-sm text-slate-400">Consentimientos Activos</span>
            </div>
            <p className="text-3xl font-bold text-white">98.7%</p>
            <p className="text-xs text-slate-500 mt-1">Tasa de retencion de consentimiento</p>
          </div>
        </div>

        {/* Policies */}
        <div className="lg:col-span-3 glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            Politicas de Privacidad y Consentimiento
          </h2>
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { title: "Minimizacion de Datos", desc: "Solo se recolectan los datos estrictamente necesarios para cada proposito", status: "Activa" },
              { title: "Consentimiento Granular", desc: "El ciudadano controla por categoria que datos comparte y con quien", status: "Activa" },
              { title: "Derecho al Olvido", desc: "Mecanismo de eliminacion completa de datos personales bajo solicitud", status: "Activa" },
              { title: "Portabilidad", desc: "Exportacion de identidad y credenciales en formatos estandar abiertos", status: "Activa" },
              { title: "Verificacion KYC", desc: "Proceso de know-your-customer con respeto a la dignidad del solicitante", status: "Activa" },
              { title: "Herencia Digital", desc: "Transmision controlada de identidad digital a beneficiarios designados", status: "Beta" },
            ].map((policy, i) => (
              <div key={i} className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium text-white">{policy.title}</h3>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${policy.status === 'Activa' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'}`}>
                    {policy.status}
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{policy.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
