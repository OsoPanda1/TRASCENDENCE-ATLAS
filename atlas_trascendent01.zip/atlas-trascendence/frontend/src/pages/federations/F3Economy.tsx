/**
 * F3 Economy & Finance Federation
 */
import { Globe, Wallet, TrendingUp, ArrowRightLeft, Shield, DollarSign } from "lucide-react";

export default function F3Economy() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-amber-500/10">
            <Globe className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">F3 — Economia y Finanzas</h1>
            <p className="text-sm text-slate-400">Wallets soberanas, contratos inteligentes auditables, economia federada</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-4 mb-6">
        <div className="glass rounded-xl p-5">
          <Wallet className="w-5 h-5 text-amber-400 mb-2" />
          <p className="text-sm text-slate-400">Wallets Activas</p>
          <p className="text-2xl font-bold text-white">8,432</p>
        </div>
        <div className="glass rounded-xl p-5">
          <ArrowRightLeft className="w-5 h-5 text-amber-400 mb-2" />
          <p className="text-sm text-slate-400">Transacciones 24h</p>
          <p className="text-2xl font-bold text-white">3,847</p>
        </div>
        <div className="glass rounded-xl p-5">
          <TrendingUp className="w-5 h-5 text-emerald-400 mb-2" />
          <p className="text-sm text-slate-400">Volumen Total</p>
          <p className="text-2xl font-bold text-white">$2.4M</p>
        </div>
        <div className="glass rounded-xl p-5">
          <Shield className="w-5 h-5 text-sovereignty mb-2" />
          <p className="text-sm text-slate-400">Contratos Auditados</p>
          <p className="text-2xl font-bold text-white">156</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-amber-400" />
            Modelos de Facturacion Territorial
          </h2>
          <div className="space-y-3">
            {[
              { name: "Gondolas / Puestos", price: "$50-200/mes", type: "Comercio movil", active: 234 },
              { name: "Semifijos / Kioscos", price: "$200-500/mes", type: "Comercio semifijo", active: 156 },
              { name: "Tiendas Fisicas", price: "$500-2000/mes", type: "Retail", active: 89 },
              { name: "Restaurantes", price: "$300-1500/mes", type: "Gastronomia", active: 67 },
              { name: "Hoteles", price: "$1000-5000/mes", type: "Hospedaje", active: 23 },
              { name: "Tours Premium", price: "$2000-10000/mes", type: "Experiencias", active: 12 },
            ].map((model, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div>
                  <p className="text-sm font-medium text-white">{model.name}</p>
                  <p className="text-xs text-slate-500">{model.type}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-mono text-amber-300">{model.price}</p>
                  <p className="text-xs text-slate-500">{model.active} activos</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Shield className="w-5 h-5 text-sovereignty" />
            Economia Federada
          </h2>
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
              <h3 className="text-sm font-medium text-white mb-2">Intercambio entre Nodos</h3>
              <p className="text-xs text-slate-400 mb-3">
                Los nodos Atlas pueden intercambiar valor sin intermediarios externos. 
                Cada transaccion se registra en el ledger federado con trazabilidad completa.
              </p>
              <div className="flex gap-2">
                <span className="text-xs px-2 py-1 rounded bg-emerald-500/10 text-emerald-400">Sin intermediarios</span>
                <span className="text-xs px-2 py-1 rounded bg-emerald-500/10 text-emerald-400">Trazable</span>
                <span className="text-xs px-2 py-1 rounded bg-emerald-500/10 text-emerald-400">Instantaneo</span>
              </div>
            </div>
            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
              <h3 className="text-sm font-medium text-white mb-2">Contratos Inteligentes Auditables</h3>
              <p className="text-xs text-slate-400 mb-3">
                Todo contrato inteligente en Atlas debe pasar por auditoria EOCT antes de despliegue.
                El codigo fuente es publico y verificable.
              </p>
              <div className="flex items-center gap-4 text-xs">
                <span className="text-emerald-400">{156} auditados</span>
                <span className="text-rose-400">{0} vulnerabilidades criticas</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
