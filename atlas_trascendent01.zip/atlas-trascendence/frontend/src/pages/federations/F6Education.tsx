/**
 * F6 Education & Knowledge Federation — UTAMV
 */
import { GraduationCap, BookOpen, Award, Users, FileText, Sparkles } from "lucide-react";

export default function F6Education() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-cyan-500/10">
            <GraduationCap className="w-6 h-6 text-cyan-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">F6 — Educacion y Conocimiento</h1>
            <p className="text-sm text-slate-400">UTAMV, credenciales academicas, ciencia abierta, canon de referencias</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-4 mb-6">
        <div className="glass rounded-xl p-5">
          <Users className="w-5 h-5 text-cyan-400 mb-2" />
          <p className="text-sm text-slate-400">Estudiantes UTAMV</p>
          <p className="text-2xl font-bold text-white">2,847</p>
        </div>
        <div className="glass rounded-xl p-5">
          <BookOpen className="w-5 h-5 text-cyan-400 mb-2" />
          <p className="text-sm text-slate-400">Cursos Activos</p>
          <p className="text-2xl font-bold text-white">64</p>
        </div>
        <div className="glass rounded-xl p-5">
          <Award className="w-5 h-5 text-cyan-400 mb-2" />
          <p className="text-sm text-slate-400">Credenciales Emitidas</p>
          <p className="text-2xl font-bold text-white">12,394</p>
        </div>
        <div className="glass rounded-xl p-5">
          <FileText className="w-5 h-5 text-cyan-400 mb-2" />
          <p className="text-sm text-slate-400">Publicaciones Open Science</p>
          <p className="text-2xl font-bold text-white">487</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* UTAMV Courses */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            Programas UTAMV
          </h2>
          <div className="space-y-3">
            {[
              { name: "Soberania Tecnologica 101", level: "Introductorio", enrolled: 423, status: "Activo", category: "Gobernanza Digital" },
              { name: "Desarrollo de Sistemas Atlas", level: "Intermedio", enrolled: 189, status: "Activo", category: "Ingenieria" },
              { name: "Etica de la IA y EOCT", level: "Avanzado", enrolled: 97, status: "Activo", category: "Etica" },
              { name: "Diseno de Identidades SSI", level: "Intermedio", enrolled: 234, status: "Activo", category: "Identidad" },
              { name: "Economia Federada", level: "Avanzado", enrolled: 156, status: "Activo", category: "Economia" },
              { name: "Gemelos Digitales Territoriales", level: "Intermedio", enrolled: 78, status: "Beta", category: "Infraestructura" },
            ].map((course, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
                <div>
                  <p className="text-sm font-medium text-white">{course.name}</p>
                  <p className="text-xs text-slate-500">{course.category} — {course.level}</p>
                </div>
                <div className="text-right">
                  <span className={`text-xs px-2 py-1 rounded-full ${course.status === 'Activo' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'}`}>
                    {course.status}
                  </span>
                  <p className="text-xs text-slate-500 mt-1">{course.enrolled} inscritos</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Open Science */}
        <div className="glass rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            Ciencia Abierta
          </h2>
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
              <h3 className="text-sm font-medium text-white mb-2">Registros Académicos</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="text-center p-2 rounded bg-slate-900/50">
                  <p className="text-lg font-bold text-white">156</p>
                  <p className="text-xs text-slate-500">DOIs Zenodo</p>
                </div>
                <div className="text-center p-2 rounded bg-slate-900/50">
                  <p className="text-lg font-bold text-white">89</p>
                  <p className="text-xs text-slate-500">Figshare</p>
                </div>
                <div className="text-center p-2 rounded bg-slate-900/50">
                  <p className="text-lg font-bold text-white">234</p>
                  <p className="text-xs text-slate-500">ORCID vinculados</p>
                </div>
                <div className="text-center p-2 rounded bg-slate-900/50">
                  <p className="text-lg font-bold text-white">8</p>
                  <p className="text-xs text-slate-500">ISNI institucionales</p>
                </div>
              </div>
            </div>
            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700/50">
              <h3 className="text-sm font-medium text-white mb-2">Canon de Referencias</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                El canon documental de Atlas Trascendence esta vinculado a repositorios de ciencia abierta
                con trazabilidad completa. Cada documento puede verificarse via DOI y su autoria via ORCID/ISNI.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
