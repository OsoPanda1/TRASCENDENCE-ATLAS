/**
 * AtlasDocs — Documentacion Civilizatoria
 */
import { BookOpen, Shield, Scale, Heart, FileText, Users, Globe, Cpu } from "lucide-react";

const DOCS = [
  {
    section: "Doctrina Fundamental",
    items: [
      { title: "Carta de Dignidad Humana", file: "HUMAN_DIGNITY_CHARTER.md", icon: Heart, desc: "Principios eticos vinculantes para toda implementacion Atlas" },
      { title: "Manifiesto de Soberania", file: "SOVEREIGNTY_MANIFESTO.md", icon: Shield, desc: "Declaracion de independencia tecnologica y anti-colonialismo digital" },
      { title: "Canon de Especificacion", file: "ATLAS_CANON.md", icon: BookOpen, desc: "Especificacion universal de Atlas Trascendence" },
      { title: "Carta de la Federacion", file: "FEDERATION_CHARTER.md", icon: Users, desc: "Contrato social de la red federada" },
    ],
  },
  {
    section: "Gobernanza y Etica",
    items: [
      { title: "Ethical Constraints", file: "ETHICAL_CONSTRAINTS.yaml", icon: Scale, desc: "Usos prohibidos y salvaguardas eticas parseables" },
      { title: "Siete Federaciones", file: "federations/README.md", icon: Globe, desc: "Modelo heptafederado: F1-F7" },
      { title: "Kernel Atlas", file: "kernel/README.md", icon: Cpu, desc: "Motor operativo, EOCT, human-in-the-loop" },
    ],
  },
  {
    section: "Legal y Compliance",
    items: [
      { title: "GDPR Compliance", file: "docs/legal-compliance/gdpr.md", icon: Scale, desc: "Alineacion con Reglamento General de Proteccion de Datos" },
      { title: "LFPDPPP Mexico", file: "docs/legal-compliance/lfpdppp.md", icon: Scale, desc: "Ley Federal de Proteccion de Datos Personales" },
      { title: "UNESCO AI Ethics", file: "docs/legal-compliance/unesco-ai-ethics.md", icon: Heart, desc: "Recomendacion sobre la Etica de la IA" },
    ],
  },
];

export default function AtlasDocs() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-slate-500/10">
            <BookOpen className="w-6 h-6 text-slate-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Documentacion Atlas Trascendence</h1>
            <p className="text-sm text-slate-400">Doctrina, arquitectura, legal y casos de estudio</p>
          </div>
        </div>
      </div>

      <div className="space-y-8">
        {DOCS.map((section) => (
          <div key={section.section}>
            <h2 className="text-lg font-semibold text-white mb-4">{section.section}</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {section.items.map((doc) => (
                <div key={doc.file} className="glass rounded-xl p-5 border border-slate-700/50 hover:border-slate-600 transition-colors">
                  <doc.icon className="w-5 h-5 text-atlas-400 mb-3" />
                  <h3 className="text-sm font-medium text-white mb-1">{doc.title}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed mb-3">{doc.desc}</p>
                  <code className="text-xs text-slate-500 bg-slate-800 px-2 py-1 rounded">{doc.file}</code>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Case Studies */}
      <div className="mt-10">
        <h2 className="text-lg font-semibold text-white mb-4">Casos de Estudio</h2>
        <div className="glass rounded-xl p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-lg bg-atlas-500/10">
              <FileText className="w-6 h-6 text-atlas-400" />
            </div>
            <div>
              <h3 className="text-sm font-medium text-white mb-1">RDM Digital — Primer Nodo Soberano Ejemplar</h3>
              <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
                Real del Monte, Hidalgo, Mexico, es el primer nodo Atlas Trascendence completamente operativo.
                Con 47 nodos territoriales, 3,847 sensores IoT, y una economia digital federada,
                RDM Digital demuestra que la soberania tecnologica es posible incluso en comunidades
                de menos de 15,000 habitantes. El nodo opera con 92% de infraestructura local,
                94% de datos en territorio, y un Sovereignty Score de 87.4.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
