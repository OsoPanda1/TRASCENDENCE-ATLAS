/**
 * App.tsx — Atlas Trascendence Frontend
 * Router principal con las 7 Federaciones y modulos operativos
 * Version: 2.0.0-trascendence
 */

import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/sonner";
import { Shield, Brain, Users, Building2, GraduationCap, Globe, Cpu, BookOpen, Activity } from "lucide-react";

// Pages
import Index from "@/pages/Index";
import F1Identity from "@/pages/federations/F1Identity";
import F2Governance from "@/pages/federations/F2Governance";
import F3Economy from "@/pages/federations/F3Economy";
import F4Cognition from "@/pages/federations/F4Cognition";
import F5Infrastructure from "@/pages/federations/F5Infrastructure";
import F6Education from "@/pages/federations/F6Education";
import F7XR from "@/pages/federations/F7XR";
import NexusGraph from "@/pages/nexus/NexusGraph";
import TelemetryDashboard from "@/pages/telemetry/TelemetryDashboard";
import SovereigntyMonitor from "@/pages/sovereignty/SovereigntyMonitor";
import IsabellaConsole from "@/pages/intelligence/IsabellaConsole";
import AtlasDocs from "@/pages/docs/AtlasDocs";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,
      retry: 2,
    },
  },
});

const FEDERATIONS = [
  { path: "/f1", label: "F1", name: "Identidad", icon: Users, color: "text-blue-400" },
  { path: "/f2", label: "F2", name: "Gobernanza", icon: Building2, color: "text-emerald-400" },
  { path: "/f3", label: "F3", name: "Economia", icon: Globe, color: "text-amber-400" },
  { path: "/f4", label: "F4", name: "Cognicion", icon: Brain, color: "text-purple-400" },
  { path: "/f5", label: "F5", name: "Infraestructura", icon: Cpu, color: "text-rose-400" },
  { path: "/f6", label: "F6", name: "Educacion", icon: GraduationCap, color: "text-cyan-400" },
  { path: "/f7", label: "F7", name: "XR", icon: Globe, color: "text-pink-400" },
];

function Navigation() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-[1800px] mx-auto px-4">
        <div className="flex items-center h-14 gap-1 overflow-x-auto">
          {/* Logo */}
          <NavLink to="/" className="flex items-center gap-2 mr-4 shrink-0">
            <Shield className="w-5 h-5 text-atlas-400" />
            <span className="font-bold text-sm text-white whitespace-nowrap">
              Atlas<span className="text-atlas-400">Trascendence</span>
            </span>
          </NavLink>

          {/* Federations */}
          <div className="flex items-center gap-0.5">
            {FEDERATIONS.map((fed) => (
              <NavLink
                key={fed.path}
                to={fed.path}
                className={({ isActive }) =>
                  `flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
                    isActive
                      ? "bg-slate-800 text-white"
                      : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                  }`
                }
                title={fed.name}
              >
                <fed.icon className={`w-3.5 h-3.5 ${fed.color}`} />
                <span className="hidden sm:inline">{fed.label}</span>
              </NavLink>
            ))}
          </div>

          <div className="w-px h-6 bg-slate-700 mx-2 shrink-0" />

          {/* Tools */}
          <NavLink
            to="/nexus"
            className={({ isActive }) =>
              `flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
                isActive ? "bg-slate-800 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800/50"
              }`
            }
          >
            <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden md:inline">Nexus</span>
          </NavLink>
          <NavLink
            to="/telemetry"
            className={({ isActive }) =>
              `flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
                isActive ? "bg-slate-800 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800/50"
              }`
            }
          >
            <Activity className="w-3.5 h-3.5 text-orange-400" />
            <span className="hidden md:inline">Telemetry</span>
          </NavLink>
          <NavLink
            to="/sovereignty"
            className={({ isActive }) =>
              `flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
                isActive ? "bg-slate-800 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800/50"
              }`
            }
          >
            <Shield className="w-3.5 h-3.5 text-sovereignty" />
            <span className="hidden md:inline">Soberania</span>
          </NavLink>
          <NavLink
            to="/isabella"
            className={({ isActive }) =>
              `flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
                isActive ? "bg-slate-800 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800/50"
              }`
            }
          >
            <Brain className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden md:inline">Isabella</span>
          </NavLink>
          <NavLink
            to="/docs"
            className={({ isActive }) =>
              `flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
                isActive ? "bg-slate-800 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800/50"
              }`
            }
          >
            <BookOpen className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden md:inline">Docs</span>
          </NavLink>
        </div>
      </div>
    </nav>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <BrowserRouter>
          <div className="min-h-screen bg-slate-950 text-slate-100">
            <Navigation />
            <main className="pt-14">
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/f1" element={<F1Identity />} />
                <Route path="/f2" element={<F2Governance />} />
                <Route path="/f3" element={<F3Economy />} />
                <Route path="/f4" element={<F4Cognition />} />
                <Route path="/f5" element={<F5Infrastructure />} />
                <Route path="/f6" element={<F6Education />} />
                <Route path="/f7" element={<F7XR />} />
                <Route path="/nexus" element={<NexusGraph />} />
                <Route path="/telemetry" element={<TelemetryDashboard />} />
                <Route path="/sovereignty" element={<SovereigntyMonitor />} />
                <Route path="/isabella" element={<IsabellaConsole />} />
                <Route path="/docs" element={<AtlasDocs />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
          </div>
        </BrowserRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
