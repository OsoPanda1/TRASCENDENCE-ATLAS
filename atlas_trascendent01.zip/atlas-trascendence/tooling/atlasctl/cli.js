#!/usr/bin/env node
/**
 * atlasctl — Atlas Trascendence CLI
 * Version: 2.0.0-trascendence
 */

const args = process.argv.slice(2);
const command = args[0];

const NODE_URL = process.env.ATLAS_NODE_URL || "http://localhost:3001";

async function fetchJSON(path) {
  const res = await fetch(`${NODE_URL}${path}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

const commands = {
  version: () => console.log("atlasctl v2.0.0-trascendence"),
  health: async () => console.log(JSON.stringify(await fetchJSON("/healthz"), null, 2)),
  "node:list": async () => console.log(JSON.stringify(await fetchJSON("/api/v1/nodes"), null, 2)),
  "citizen:list": async () => console.log(JSON.stringify(await fetchJSON("/api/v1/citizens"), null, 2)),
  "proposal:list": async () => console.log(JSON.stringify(await fetchJSON("/api/v1/proposals"), null, 2)),
  sovereignty: async () => console.log(JSON.stringify(await fetchJSON("/api/v1/sovereignty"), null, 2)),
  telemetry: async () => console.log(JSON.stringify(await fetchJSON("/api/v1/telemetry"), null, 2)),
  ledger: async () => console.log(JSON.stringify(await fetchJSON("/api/v1/ledger"), null, 2)),
  help: () => console.log(`
atlasctl — Atlas Trascendence CLI

Commands:
  version           Show version
  health            Check node health
  node:list         List registered nodes
  citizen:list      List citizens
  proposal:list     List proposals
  sovereignty       Get sovereignty metrics
  telemetry         Get telemetry data
  ledger            View recent ledger entries
  help              Show this help

Environment:
  ATLAS_NODE_URL    Atlas node endpoint (default: http://localhost:3001)
`),
};

const fn = commands[command] || commands.help;
fn().catch(err => { console.error(`Error: ${err.message}`); process.exit(1); });
