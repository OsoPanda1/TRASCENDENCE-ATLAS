# F2 Ledger
Registro de decisiones de gobernanza.