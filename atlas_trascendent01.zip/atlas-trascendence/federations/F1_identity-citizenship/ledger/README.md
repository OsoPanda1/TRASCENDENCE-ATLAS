# F1 Ledger
Registro inmutable de operaciones de identidad en BookPI/MSR.