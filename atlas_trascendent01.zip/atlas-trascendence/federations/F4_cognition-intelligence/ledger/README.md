# F4 Ledger
Registro de evaluaciones EOCT y decisiones de IA.