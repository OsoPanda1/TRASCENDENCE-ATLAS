/**
 * server.js — Atlas Trascendence Backend API
 * Version: 2.0.0-trascendence
 */
import { createServer } from "node:http";
import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";

const PORT = process.env.ATLAS_PORT || 3001;
const NODE_ID = process.env.ATLAS_NODE_ID || `did:atlas:node:${randomUUID()}`;

// In-memory stores (replace with proper DB in production)
const citizens = new Map();
const transactions = new Map();
const proposals = new Map();
const nodes = new Map();
const ledger = [];

function logEntry(type, actor, action, payload) {
  const entry = {
    id: randomUUID(),
    timestamp: new Date().toISOString(),
    nodeId: NODE_ID,
    type,
    actor,
    action,
    payload,
  };
  ledger.push(entry);
  return entry;
}

const routes = {
  // Health
  "GET /healthz": async () => ({
    status: "healthy",
    nodeId: NODE_ID,
    version: "2.0.0-trascendence",
    timestamp: new Date().toISOString(),
  }),

  // Citizens (F1)
  "GET /api/v1/citizens": async () => ({
    citizens: Array.from(citizens.values()),
    count: citizens.size,
  }),
  "POST /api/v1/citizens": async (body) => {
    const id = `did:atlas:citizen:${randomUUID()}`;
    const citizen = { id, ...body, createdAt: new Date().toISOString(), status: "active" };
    citizens.set(id, citizen);
    logEntry("citizen_created", "F1", "create", { citizenId: id });
    return { citizen, ledgerEntry: ledger.length - 1 };
  },

  // Proposals (F2)
  "GET /api/v1/proposals": async () => ({
    proposals: Array.from(proposals.values()),
    count: proposals.size,
  }),
  "POST /api/v1/proposals": async (body) => {
    const id = randomUUID();
    const proposal = { id, ...body, status: "open", votesFor: 0, votesAgainst: 0, createdAt: new Date().toISOString() };
    proposals.set(id, proposal);
    logEntry("proposal_created", "F2", "create", { proposalId: id });
    return { proposal };
  },

  // Transactions (F3)
  "GET /api/v1/transactions": async () => ({
    transactions: Array.from(transactions.values()),
    count: transactions.size,
  }),
  "POST /api/v1/transactions": async (body) => {
    const id = `tx_${randomUUID()}`;
    const tx = { id, ...body, timestamp: new Date().toISOString(), status: "confirmed" };
    transactions.set(id, tx);
    logEntry("transaction", "F3", "create", { txId: id, amount: body.amount });
    return { transaction: tx };
  },

  // Nodes (F5)
  "GET /api/v1/nodes": async () => ({
    nodes: Array.from(nodes.values()),
    count: nodes.size,
  }),
  "POST /api/v1/nodes": async (body) => {
    const id = `node_${randomUUID()}`;
    const node = { id, ...body, status: "online", registeredAt: new Date().toISOString() };
    nodes.set(id, node);
    logEntry("node_registered", "F5", "register", { nodeId: id });
    return { node };
  },

  // Ledger
  "GET /api/v1/ledger": async () => ({
    entries: ledger.slice(-100),
    total: ledger.length,
  }),

  // Sovereignty metrics
  "GET /api/v1/sovereignty": async () => ({
    score: 87.4,
    localProcessing: 92,
    dataResidency: 94,
    jurisdiction: 89,
    externalDependency: 23,
    colonialismRisk: "low",
    timestamp: new Date().toISOString(),
  }),

  // Telemetry
  "GET /api/v1/telemetry": async () => ({
    activeTasks: 47,
    queuedTasks: 3,
    failedTasks: 0,
    sovereigntyScore: 87.4,
    colonialismIndicators: {
      externalDependency: 23,
      dataExfiltration: 2,
      jurisdictionRisk: 15,
    },
    nodes: nodes.size,
    citizens: citizens.size,
    timestamp: new Date().toISOString(),
  }),
};

function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => { data += chunk; if (data.length > 1_000_000) reject(new Error("Too large")); });
    req.on("end", () => resolve(data ? JSON.parse(data) : {}));
    req.on("error", reject);
  });
}

const server = createServer(async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Content-Type", "application/json");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  const key = `${req.method} ${req.url}`;
  const handler = routes[key];

  if (handler) {
    try {
      const body = req.method === "POST" ? await parseJsonBody(req) : {};
      const result = await handler(body);
      res.writeHead(200);
      res.end(JSON.stringify(result));
    } catch (err) {
      res.writeHead(400);
      res.end(JSON.stringify({ error: err.message }));
    }
  } else {
    res.writeHead(404);
    res.end(JSON.stringify({ error: "Not found", path: req.url }));
  }
});

server.listen(PORT, () => {
  console.log(`[Atlas Trascendence] API v2.0.0 running on port ${PORT}`);
  console.log(`[Atlas Trascendence] Node ID: ${NODE_ID}`);
});
