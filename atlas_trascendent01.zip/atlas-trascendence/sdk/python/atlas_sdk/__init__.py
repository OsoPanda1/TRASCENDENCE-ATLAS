"""
Atlas Trascendence SDK — Python
Version: 2.0.0-trascendence
"""

import requests
from typing import Optional, Dict, Any

class AtlasClient:
    def __init__(self, node_url: str, api_key: Optional[str] = None, timeout: int = 30):
        self.node_url = node_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.headers = {"Content-Type": "application/json"}
        if api_key:
            self.headers["X-API-Key"] = api_key

    def _request(self, method: str, path: str, body: Optional[Dict] = None) -> Dict[str, Any]:
        url = f"{self.node_url}{path}"
        resp = requests.request(method, url, headers=self.headers, json=body, timeout=self.timeout)
        resp.raise_for_status()
        return resp.json()

    def health(self) -> Dict[str, Any]:
        return self._request("GET", "/healthz")

    def list_citizens(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/citizens")

    def create_citizen(self, body: Dict) -> Dict[str, Any]:
        return self._request("POST", "/api/v1/citizens", body)

    def list_proposals(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/proposals")

    def list_transactions(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/transactions")

    def list_nodes(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/nodes")

    def get_ledger(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/ledger")

    def get_sovereignty_metrics(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/sovereignty")

    def get_telemetry(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/telemetry")
