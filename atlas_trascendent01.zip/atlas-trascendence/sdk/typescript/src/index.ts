/**
 * Atlas Trascendence SDK — TypeScript
 * Version: 2.0.0-trascendence
 */

export interface AtlasConfig {
  nodeUrl: string;
  apiKey?: string;
  timeout?: number;
}

export class AtlasClient {
  private config: AtlasConfig;

  constructor(config: AtlasConfig) {
    this.config = { timeout: 30000, ...config };
  }

  private async request(path: string, method = "GET", body?: unknown): Promise<unknown> {
    const res = await fetch(`${this.config.nodeUrl}${path}`, {
      method,
      headers: {
        "Content-Type": "application/json",
        ...(this.config.apiKey ? { "X-API-Key": this.config.apiKey } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${await res.text()}`);
    return res.json();
  }

  async listCitizens() { return this.request("/api/v1/citizens"); }
  async createCitizen(body: unknown) { return this.request("/api/v1/citizens", "POST", body); }
  async listProposals() { return this.request("/api/v1/proposals"); }
  async createProposal(body: unknown) { return this.request("/api/v1/proposals", "POST", body); }
  async listTransactions() { return this.request("/api/v1/transactions"); }
  async createTransaction(body: unknown) { return this.request("/api/v1/transactions", "POST", body); }
  async listNodes() { return this.request("/api/v1/nodes"); }
  async registerNode(body: unknown) { return this.request("/api/v1/nodes", "POST", body); }
  async getLedger() { return this.request("/api/v1/ledger"); }
  async getSovereigntyMetrics() { return this.request("/api/v1/sovereignty"); }
  async getTelemetry() { return this.request("/api/v1/telemetry"); }
  async health() { return this.request("/healthz"); }
}

export default AtlasClient;
