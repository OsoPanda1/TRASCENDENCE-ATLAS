import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

export default defineConfig({
  plugins: [react()],
  root: "frontend",
  publicDir: "public",
  build: {
    outDir: "../dist",
    emptyOutDir: true,
    sourcemap: true,
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./frontend/src"),
      "@kernel": path.resolve(__dirname, "./kernel"),
      "@federations": path.resolve(__dirname, "./federations"),
      "@nexus": path.resolve(__dirname, "./nexus"),
      "@intelligence": path.resolve(__dirname, "./intelligence"),
    },
  },
  server: {
    port: 5173,
    proxy: {
      "/api": {
        target: "http://localhost:3001",
        changeOrigin: true,
      },
    },
  },
  define: {
    "import.meta.env.VITE_ATLAS_VERSION": JSON.stringify("2.0.0-trascendence"),
  },
});
