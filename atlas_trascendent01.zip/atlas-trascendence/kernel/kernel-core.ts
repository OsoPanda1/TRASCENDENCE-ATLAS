/**
 * kernel-core.ts — Atlas Trascendence Kernel
 * Nucleo operativo: scheduling, runtime, workflow, federated task orchestration
 * Version: 2.0.0-trascendence
 */

import type { PolicyDecision, Operation, Task, TaskId, TaskResult, Workflow, WorkflowId } from './types';
import { PolicyEvaluator } from './policy-evaluator';
import { GovernanceHook } from './governance-hook';
import { HumanLoopGate } from './human-loop-gate';
import { IsabellaAdapter } from './isabella-adapter';

// =============================================================================
// Types
// =============================================================================

export interface KernelConfig {
  maxConcurrentTasks: number;
  taskTimeoutMs: number;
  enableEOCT: boolean;
  enableHumanLoop: boolean;
  enableGovernanceLogging: boolean;
  federationMode: 'standalone' | 'federated' | 'hybrid';
  nodeId: string; // DID of this node
}

export interface Task {
  id?: string;
  type: string;
  federation?: string; // F1-F7
  payload: unknown;
  priority: 'critical' | 'high' | 'normal' | 'low';
  requiresHumanApproval?: boolean;
  ethicalSensitivity?: 'none' | 'low' | 'medium' | 'high' | 'critical';
  createdAt?: string;
}

export interface TaskResult {
  taskId: string;
  status: 'completed' | 'failed' | 'blocked' | 'pending_approval';
  output?: unknown;
  error?: string;
  policyDecision?: PolicyDecision;
  governanceEntry?: string; // ledger reference
  durationMs: number;
}

export interface Workflow {
  id?: string;
  name: string;
  tasks: Task[];
  federation?: string;
  parallel?: boolean;
  onFailure: 'abort' | 'continue' | 'retry';
}

export interface WorkflowResult {
  workflowId: string;
  status: 'completed' | 'failed' | 'partial';
  taskResults: TaskResult[];
  startedAt: string;
  completedAt: string;
}

// =============================================================================
// AtlasKernel — Main Implementation
// =============================================================================

export class AtlasKernel {
  private config: KernelConfig;
  private policyEvaluator: PolicyEvaluator;
  private governanceHook: GovernanceHook;
  private humanLoopGate: HumanLoopGate;
  private isabellaAdapter: IsabellaAdapter;
  
  private taskQueue: Map<string, Task> = new Map();
  private runningTasks: Map<string, AbortController> = new Map();
  private taskHistory: TaskResult[] = [];
  private workflowRegistry: Map<string, Workflow> = new Map();
  
  private metrics = {
    tasksTotal: 0,
    tasksCompleted: 0,
    tasksFailed: 0,
    tasksBlocked: 0,
    avgDurationMs: 0,
    byFederation: new Map<string, number>(),
  };

  constructor(config: Partial<KernelConfig> = {}) {
    this.config = {
      maxConcurrentTasks: 50,
      taskTimeoutMs: 300_000,
      enableEOCT: true,
      enableHumanLoop: true,
      enableGovernanceLogging: true,
      federationMode: 'hybrid',
      nodeId: `did:atlas:kernel:${crypto.randomUUID()}`,
      ...config,
    };

    this.policyEvaluator = new PolicyEvaluator();
    this.governanceHook = new GovernanceHook(this.config.nodeId);
    this.humanLoopGate = new HumanLoopGate();
    this.isabellaAdapter = new IsabellaAdapter();
  }

  // ==========================================================================
  // Task Management
  // ==========================================================================

  async schedule(task: Task): Promise<string> {
    const taskId = task.id || `task_${crypto.randomUUID()}`;
    const enrichedTask: Task = {
      ...task,
      id: taskId,
      createdAt: new Date().toISOString(),
    };

    // EOCT evaluation for ethically sensitive tasks
    if (this.config.enableEOCT && this.isEthicallySensitive(enrichedTask)) {
      const eoctResult = await this.isabellaAdapter.evaluateEOCT(enrichedTask);
      if (!eoctResult.approved) {
        const result: TaskResult = {
          taskId,
          status: 'blocked',
          error: `EOCT blocked: ${eoctResult.reason}`,
          policyDecision: { decision: 'deny', reason: eoctResult.reason, rule: 'EOCT-001' },
          durationMs: 0,
        };
        this.recordTaskResult(result);
        throw new AtlasKernelError(`Task blocked by EOCT: ${eoctResult.reason}`, result);
      }
    }

    // Policy evaluation
    const policyDecision = await this.policyEvaluator.evaluate({
      type: enrichedTask.type,
      federation: enrichedTask.federation,
      payload: enrichedTask.payload,
      ethicalSensitivity: enrichedTask.ethicalSensitivity,
    });

    if (policyDecision.decision === 'deny') {
      const result: TaskResult = {
        taskId,
        status: 'blocked',
        policyDecision,
        durationMs: 0,
      };
      this.recordTaskResult(result);
      throw new AtlasKernelError(`Task blocked by policy: ${policyDecision.reason}`, result);
    }

    // Human-in-the-Loop for critical operations
    if (this.config.enableHumanLoop && enrichedTask.requiresHumanApproval) {
      const approval = await this.humanLoopGate.requestApproval(enrichedTask);
      if (!approval.approved) {
        const result: TaskResult = {
          taskId,
          status: 'pending_approval',
          error: 'Waiting for human approval',
          durationMs: 0,
        };
        this.recordTaskResult(result);
        return taskId; // Task queued, awaiting approval
      }
    }

    // Queue and execute
    this.taskQueue.set(taskId, enrichedTask);
    this.metrics.tasksTotal++;
    
    // Execute asynchronously
    this.executeTask(taskId, enrichedTask).catch(console.error);
    
    return taskId;
  }

  async cancel(taskId: string): Promise<boolean> {
    const controller = this.runningTasks.get(taskId);
    if (controller) {
      controller.abort();
      this.runningTasks.delete(taskId);
      return true;
    }
    this.taskQueue.delete(taskId);
    return false;
  }

  async getTaskResult(taskId: string): Promise<TaskResult | undefined> {
    return this.taskHistory.find(r => r.taskId === taskId);
  }

  // ==========================================================================
  // Workflow Management
  // ==========================================================================

  async registerWorkflow(workflow: Workflow): Promise<string> {
    const workflowId = workflow.id || `wf_${crypto.randomUUID()}`;
    this.workflowRegistry.set(workflowId, { ...workflow, id: workflowId });
    return workflowId;
  }

  async executeWorkflow(workflowId: string): Promise<WorkflowResult> {
    const workflow = this.workflowRegistry.get(workflowId);
    if (!workflow) {
      throw new AtlasKernelError(`Workflow ${workflowId} not found`);
    }

    const startedAt = new Date().toISOString();
    const taskResults: TaskResult[] = [];

    if (workflow.parallel) {
      const promises = workflow.tasks.map(t => this.schedule(t).then(id => this.getTaskResult(id)));
      const results = await Promise.all(promises);
      taskResults.push(...results.filter((r): r is TaskResult => r !== undefined));
    } else {
      for (const task of workflow.tasks) {
        try {
          const taskId = await this.schedule(task);
          // Wait for completion with timeout
          const result = await this.waitForTask(taskId, this.config.taskTimeoutMs);
          taskResults.push(result);
          if (result.status === 'failed' && workflow.onFailure === 'abort') {
            break;
          }
        } catch (err) {
          const failResult: TaskResult = {
            taskId: task.id || 'unknown',
            status: 'failed',
            error: err instanceof Error ? err.message : String(err),
            durationMs: 0,
          };
          taskResults.push(failResult);
          if (workflow.onFailure === 'abort') break;
        }
      }
    }

    const allCompleted = taskResults.every(r => r.status === 'completed');
    const anyFailed = taskResults.some(r => r.status === 'failed' || r.status === 'blocked');

    const workflowResult: WorkflowResult = {
      workflowId,
      status: allCompleted ? 'completed' : anyFailed ? 'failed' : 'partial',
      taskResults,
      startedAt,
      completedAt: new Date().toISOString(),
    };

    // Log to governance ledger
    if (this.config.enableGovernanceLogging) {
      await this.governanceHook.recordWorkflowExecution(workflowResult);
    }

    return workflowResult;
  }

  // ==========================================================================
  // Governance
  // ==========================================================================

  async evaluatePolicy(operation: Operation): Promise<PolicyDecision> {
    return this.policyEvaluator.evaluate(operation);
  }

  async requestHumanApproval(operation: Operation): Promise<{ approved: boolean; signature?: string }> {
    return this.humanLoopGate.requestApproval({
      type: operation.type,
      payload: operation,
      priority: 'critical',
      requiresHumanApproval: true,
    });
  }

  // ==========================================================================
  // Metrics & Health
  // ==========================================================================

  getMetrics() {
    return {
      ...this.metrics,
      byFederation: Object.fromEntries(this.metrics.byFederation),
      activeTasks: this.runningTasks.size,
      queuedTasks: this.taskQueue.size,
      timestamp: new Date().toISOString(),
    };
  }

  healthCheck(): { status: 'healthy' | 'degraded' | 'critical'; details: Record<string, unknown> } {
    const active = this.runningTasks.size;
    const max = this.config.maxConcurrentTasks;
    const failureRate = this.metrics.tasksTotal > 0 
      ? this.metrics.tasksFailed / this.metrics.tasksTotal 
      : 0;

    if (failureRate > 0.5 || active > max * 0.95) {
      return {
        status: 'critical',
        details: { failureRate, activeTasks: active, maxTasks: max, metrics: this.getMetrics() },
      };
    }
    if (failureRate > 0.2 || active > max * 0.8) {
      return {
        status: 'degraded',
        details: { failureRate, activeTasks: active, maxTasks: max },
      };
    }
    return {
      status: 'healthy',
      details: { failureRate, activeTasks: active, maxTasks: max },
    };
  }

  // ==========================================================================
  // Private Methods
  // ==========================================================================

  private async executeTask(taskId: string, task: Task): Promise<void> {
    const controller = new AbortController();
    this.runningTasks.set(taskId, controller);
    const startTime = performance.now();

    try {
      // Federation-specific execution
      const result = await this.executeByFederation(task, controller.signal);
      
      const duration = Math.round(performance.now() - startTime);
      const taskResult: TaskResult = {
        taskId,
        status: 'completed',
        output: result,
        durationMs: duration,
      };

      // Governance logging
      if (this.config.enableGovernanceLogging) {
        taskResult.governanceEntry = await this.governanceHook.recordTaskCompletion(task, taskResult);
      }

      this.recordTaskResult(taskResult);
    } catch (err) {
      const duration = Math.round(performance.now() - startTime);
      const taskResult: TaskResult = {
        taskId,
        status: 'failed',
        error: err instanceof Error ? err.message : String(err),
        durationMs: duration,
      };
      this.recordTaskResult(taskResult);
    } finally {
      this.runningTasks.delete(taskId);
      this.taskQueue.delete(taskId);
    }
  }

  private async executeByFederation(task: Task, signal: AbortSignal): Promise<unknown> {
    // Route to appropriate federation handler
    switch (task.federation) {
      case 'F1':
        return this.executeF1(task, signal);
      case 'F2':
        return this.executeF2(task, signal);
      case 'F3':
        return this.executeF3(task, signal);
      case 'F4':
        return this.executeF4(task, signal);
      case 'F5':
        return this.executeF5(task, signal);
      case 'F6':
        return this.executeF6(task, signal);
      case 'F7':
        return this.executeF7(task, signal);
      default:
        return this.executeGeneric(task, signal);
    }
  }

  private async executeF1(task: Task, signal: AbortSignal): Promise<unknown> {
    // F1: Identity and Citizenship
    return { federation: 'F1', executed: true, taskType: task.type };
  }

  private async executeF2(task: Task, signal: AbortSignal): Promise<unknown> {
    // F2: Governance and Institutions
    return { federation: 'F2', executed: true, taskType: task.type };
  }

  private async executeF3(task: Task, signal: AbortSignal): Promise<unknown> {
    // F3: Economy and Finance
    return { federation: 'F3', executed: true, taskType: task.type };
  }

  private async executeF4(task: Task, signal: AbortSignal): Promise<unknown> {
    // F4: Cognition and Intelligence — Route to Isabella
    return this.isabellaAdapter.process(task);
  }

  private async executeF5(task: Task, signal: AbortSignal): Promise<unknown> {
    // F5: Infrastructure and Territory
    return { federation: 'F5', executed: true, taskType: task.type };
  }

  private async executeF6(task: Task, signal: AbortSignal): Promise<unknown> {
    // F6: Education and Knowledge
    return { federation: 'F6', executed: true, taskType: task.type };
  }

  private async executeF7(task: Task, signal: AbortSignal): Promise<unknown> {
    // F7: XR and Experiences
    return { federation: 'F7', executed: true, taskType: task.type };
  }

  private async executeGeneric(task: Task, signal: AbortSignal): Promise<unknown> {
    return { federation: 'generic', executed: true, taskType: task.type };
  }

  private recordTaskResult(result: TaskResult): void {
    this.taskHistory.push(result);
    if (result.status === 'completed') this.metrics.tasksCompleted++;
    if (result.status === 'failed') this.metrics.tasksFailed++;
    if (result.status === 'blocked') this.metrics.tasksBlocked++;

    // Update running average
    const total = this.metrics.tasksCompleted + this.metrics.tasksFailed + this.metrics.tasksBlocked;
    this.metrics.avgDurationMs = 
      (this.metrics.avgDurationMs * (total - 1) + result.durationMs) / total;

    // Trim history to prevent memory bloat
    if (this.taskHistory.length > 10_000) {
      this.taskHistory = this.taskHistory.slice(-5_000);
    }
  }

  private isEthicallySensitive(task: Task): boolean {
    return ['high', 'critical'].includes(task.ethicalSensitivity || 'none');
  }

  private async waitForTask(taskId: string, timeoutMs: number): Promise<TaskResult> {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const result = this.taskHistory.find(r => r.taskId === taskId);
      if (result) return result;
      await new Promise(r => setTimeout(r, 100));
    }
    return {
      taskId,
      status: 'failed',
      error: `Task timeout after ${timeoutMs}ms`,
      durationMs: timeoutMs,
    };
  }
}

// =============================================================================
// AtlasKernelError
// =============================================================================

export class AtlasKernelError extends Error {
  constructor(
    message: string,
    public readonly taskResult?: TaskResult,
    public readonly code: string = 'KERNEL_ERROR'
  ) {
    super(message);
    this.name = 'AtlasKernelError';
  }
}

// =============================================================================
// Types (re-exported)
// =============================================================================

export interface Operation {
  type: string;
  federation?: string;
  payload: unknown;
  ethicalSensitivity?: 'none' | 'low' | 'medium' | 'high' | 'critical';
}

export interface PolicyDecision {
  decision: 'allow' | 'deny' | 'conditional';
  reason: string;
  rule: string;
  conditions?: string[];
}

export interface GovernanceDecision {
  type: string;
  actor: string;
  action: string;
  timestamp: string;
  evidence?: unknown;
}

export type TaskId = string;
export type WorkflowId = string;
