/**
 * policy-evaluator.ts — Atlas Trascendence Policy Evaluator
 * Evalua todas las operaciones contra ETHICAL_CONSTRAINTS.yaml y politicas federativas
 * Version: 2.0.0-trascendence
 */

import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import YAML from 'yaml';
import type { Operation, PolicyDecision } from './kernel-core';

// =============================================================================
// Types
// =============================================================================

interface EthicalConstraint {
  id: string;
  category: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  trigger: string;
  action: string;
  legal_basis: string[];
  protected_characteristics?: string[];
}

interface OperationalConstraint {
  description: string;
  triggers: string[];
  requirements?: string[];
  [key: string]: unknown;
}

interface EthicalConstraintsDoc {
  version: string;
  enforcement_level: string;
  prohibited_uses: EthicalConstraint[];
  operational_constraints: Record<string, OperationalConstraint>;
  policy_engine_metadata: {
    schema_version: string;
    compatible_with: string[];
    priority_order: string;
    fail_closed: boolean;
  };
}

interface FederationPolicy {
  federation: string;
  allowedOperations: string[];
  deniedOperations: string[];
  requireApproval: string[];
  maxSensitivity: string;
}

// =============================================================================
// PolicyEvaluator
// =============================================================================

export class PolicyEvaluator {
  private constraints: EthicalConstraintsDoc | null = null;
  private federationPolicies: Map<string, FederationPolicy> = new Map();
  private constraintPath: string;

  constructor(constraintPath?: string) {
    this.constraintPath = constraintPath || resolve(process.cwd(), 'ETHICAL_CONSTRAINTS.yaml');
    this.loadConstraints();
    this.loadFederationPolicies();
  }

  // ==========================================================================
  // Main Evaluation
  // ==========================================================================

  async evaluate(operation: Operation): Promise<PolicyDecision> {
    // 1. Check prohibited uses (hard constraints)
    const prohibitedCheck = this.checkProhibited(operation);
    if (prohibitedCheck.decision === 'deny') {
      return prohibitedCheck;
    }

    // 2. Check federation-specific policies
    const federationCheck = this.checkFederationPolicy(operation);
    if (federationCheck.decision === 'deny') {
      return federationCheck;
    }

    // 3. Check operational constraints (human-in-the-loop, etc.)
    const operationalCheck = this.checkOperationalConstraints(operation);
    if (operationalCheck.decision === 'conditional') {
      return operationalCheck;
    }

    // 4. All checks passed
    return {
      decision: 'allow',
      reason: 'All policy checks passed',
      rule: 'DEFAULT_ALLOW',
    };
  }

  // ==========================================================================
  // Prohibited Uses Check
  // ==========================================================================

  private checkProhibited(operation: Operation): PolicyDecision {
    if (!this.constraints) {
      if (this.constraints?.policy_engine_metadata?.fail_closed) {
        return {
          decision: 'deny',
          reason: 'Constraints not loaded — fail-closed mode active',
          rule: 'FAIL_CLOSED',
        };
      }
      return { decision: 'allow', reason: 'No constraints loaded', rule: 'NO_CONSTRAINTS' };
    }

    for (const constraint of this.constraints.prohibited_uses) {
      if (this.matchesConstraint(operation, constraint)) {
        return {
          decision: 'deny',
          reason: `[${constraint.id}] ${constraint.category}: ${constraint.description}`,
          rule: constraint.id,
        };
      }
    }

    return { decision: 'allow', reason: 'No prohibited use matched', rule: 'PROHIBITED_CHECK_PASS' };
  }

  private matchesConstraint(operation: Operation, constraint: EthicalConstraint): boolean {
    const opType = operation.type.toLowerCase();
    const category = constraint.category.toLowerCase();

    // Pattern matching based on constraint category and operation type
    switch (category) {
      case 'vigilancia_masiva':
        return opType.includes('surveillance') || opType.includes('bulk') || opType.includes('mass_monitoring');
      
      case 'perfilamiento_discriminatorio':
        return opType.includes('profile') && this.hasProtectedCharacteristics(operation);
      
      case 'usos_militares_ofensivos':
        return opType.includes('military') || opType.includes('weapon') || opType.includes('offensive');
      
      case 'manipulacion_conductual':
        return opType.includes('manipulate') || opType.includes('dark_pattern') || opType.includes('nudge');
      
      case 'explotacion_laboral':
        return opType.includes('automate') && opType.includes('displace');
      
      case 'venta_datos_identidad':
        return opType.includes('sell') && opType.includes('identity');
      
      case 'extraccion_datos_no_consensuada':
        return opType.includes('harvest') || opType.includes('scrape');
      
      default:
        return false;
    }
  }

  private hasProtectedCharacteristics(operation: Operation): boolean {
    const payload = JSON.stringify(operation.payload).toLowerCase();
    const protectedChars = [
      'race', 'ethnicity', 'gender', 'sexual_orientation', 'religion',
      'national_origin', 'socioeconomic', 'disability', 'age',
    ];
    return protectedChars.some(char => payload.includes(char));
  }

  // ==========================================================================
  // Federation Policy Check
  // ==========================================================================

  private checkFederationPolicy(operation: Operation): PolicyDecision {
    if (!operation.federation) {
      return { decision: 'allow', reason: 'No federation specified', rule: 'NO_FEDERATION' };
    }

    const policy = this.federationPolicies.get(operation.federation);
    if (!policy) {
      return { decision: 'allow', reason: 'No policy for federation', rule: 'NO_FED_POLICY' };
    }

    const opType = operation.type;

    // Check denied operations
    if (policy.deniedOperations.some(d => opType.includes(d) || d.includes(opType))) {
      return {
        decision: 'deny',
        reason: `Operation '${opType}' is denied in federation ${operation.federation}`,
        rule: `FED_${operation.federation}_DENY`,
      };
    }

    // Check if approval is required
    if (policy.requireApproval.some(r => opType.includes(r) || r.includes(opType))) {
      return {
        decision: 'conditional',
        reason: `Operation '${opType}' requires approval in federation ${operation.federation}`,
        rule: `FED_${operation.federation}_APPROVAL_REQUIRED`,
        conditions: ['Human approval required'],
      };
    }

    // Check sensitivity level
    if (operation.ethicalSensitivity === 'critical' && policy.maxSensitivity !== 'critical') {
      return {
        decision: 'deny',
        reason: `Critical sensitivity operations not allowed in federation ${operation.federation}`,
        rule: `FED_${operation.federation}_SENSITIVITY`,
      };
    }

    return { decision: 'allow', reason: 'Federation policy check passed', rule: `FED_${operation.federation}_ALLOW` };
  }

  // ==========================================================================
  // Operational Constraints
  // ==========================================================================

  private checkOperationalConstraints(operation: Operation): PolicyDecision {
    if (!this.constraints?.operational_constraints) {
      return { decision: 'allow', reason: 'No operational constraints', rule: 'NO_OP_CONSTRAINTS' };
    }

    const op = this.constraints.operational_constraints;

    // Human-in-the-loop check
    if (op.human_in_the_loop && this.requiresHumanApproval(operation, op.human_in_the_loop)) {
      return {
        decision: 'conditional',
        reason: 'Operation requires human approval per Human-in-the-Loop policy',
        rule: 'HITL_REQUIRED',
        conditions: ['Requires IDNVIDA_VERIFIED_HUMAN signature'],
      };
    }

    // Data residency check
    if (op.data_residency && this.violatesDataResidency(operation)) {
      return {
        decision: 'deny',
        reason: 'Operation violates data residency requirements',
        rule: 'DATA_RESIDENCY',
      };
    }

    return { decision: 'allow', reason: 'Operational constraints satisfied', rule: 'OP_CHECK_PASS' };
  }

  private requiresHumanApproval(operation: Operation, hitlConfig: OperationalConstraint): boolean {
    const triggers = hitlConfig.triggers || [];
    const opStr = JSON.stringify(operation).toLowerCase();
    
    return triggers.some(trigger => {
      const t = trigger.toLowerCase();
      if (t.includes('derechos fundamentales')) return opStr.includes('rights');
      if (t.includes('servicios esenciales')) return opStr.includes('essential');
      if (t.includes('categorias especiales')) return this.hasProtectedCharacteristics(operation);
      if (t.includes('economico')) return opStr.includes('payment') || opStr.includes('transaction');
      return false;
    });
  }

  private violatesDataResidency(operation: Operation): boolean {
    const opStr = JSON.stringify(operation).toLowerCase();
    return opStr.includes('cross_border') && !opStr.includes('consent');
  }

  // ==========================================================================
  // Loading
  // ==========================================================================

  private loadConstraints(): void {
    try {
      const content = readFileSync(this.constraintPath, 'utf-8');
      this.constraints = YAML.parse(content) as EthicalConstraintsDoc;
      console.log(`[PolicyEvaluator] Loaded constraints v${this.constraints.version}`);
    } catch (err) {
      console.error(`[PolicyEvaluator] Failed to load constraints: ${err}`);
      this.constraints = null;
    }
  }

  private loadFederationPolicies(): void {
    // Default policies for F1-F7
    const defaultPolicies: FederationPolicy[] = [
      {
        federation: 'F1',
        allowedOperations: ['*'],
        deniedOperations: ['mass_export', 'bulk_delete'],
        requireApproval: ['revoke_citizenship', 'delete_identity'],
        maxSensitivity: 'critical',
      },
      {
        federation: 'F2',
        allowedOperations: ['*'],
        deniedOperations: ['bypass_vote', 'override_decision'],
        requireApproval: ['amend_charter', 'expel_node'],
        maxSensitivity: 'critical',
      },
      {
        federation: 'F3',
        allowedOperations: ['*'],
        deniedOperations: ['unauthorized_mint', 'unauthorized_transfer'],
        requireApproval: ['large_transfer', 'contract_deploy'],
        maxSensitivity: 'high',
      },
      {
        federation: 'F4',
        allowedOperations: ['inference', 'embedding', 'search', 'reasoning'],
        deniedOperations: ['unsupervised_training', 'unauthorized_model_export'],
        requireApproval: ['deploy_model', 'fine_tune', 'batch_inference_personal'],
        maxSensitivity: 'high',
      },
      {
        federation: 'F5',
        allowedOperations: ['*'],
        deniedOperations: ['shutdown_critical_infrastructure'],
        requireApproval: ['deploy_physical_node', 'change_topology'],
        maxSensitivity: 'high',
      },
      {
        federation: 'F6',
        allowedOperations: ['*'],
        deniedOperations: ['forge_credential', 'unauthorized_access_records'],
        requireApproval: ['issue_degree', 'accredit_institution'],
        maxSensitivity: 'high',
      },
      {
        federation: 'F7',
        allowedOperations: ['*'],
        deniedOperations: ['unauthorized_xr_capture', 'privacy_violation_xr'],
        requireApproval: ['deploy_xr_space', 'capture_biometric'],
        maxSensitivity: 'medium',
      },
    ];

    for (const policy of defaultPolicies) {
      this.federationPolicies.set(policy.federation, policy);
    }
  }

  // ==========================================================================
  // Hot Reload
  // ==========================================================================

  reloadConstraints(): void {
    this.loadConstraints();
  }

  getLoadedVersion(): string | null {
    return this.constraints?.version || null;
  }
}

export default PolicyEvaluator;
