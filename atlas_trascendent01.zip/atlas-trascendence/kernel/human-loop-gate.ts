/**
 * human-loop-gate.ts — Atlas Trascendence Human-in-the-Loop Gate
 * Fuerza intervencion humana en decisiones criticas que afectan derechos fundamentales
 * Version: 2.0.0-trascendence
 */

import { createHash, randomUUID } from 'node:crypto';
import type { Task } from './kernel-core';

// =============================================================================
// Types
// =============================================================================

interface HumanApprovalRequest {
  id: string;
  taskId: string;
  taskType: string;
  federation: string;
  description: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  requestedAt: string;
  expiresAt: string;
  status: 'pending' | 'approved' | 'rejected' | 'expired';
  approverDid?: string;
  approverSignature?: string;
  decidedAt?: string;
  reason?: string;
}

interface ApprovalConfig {
  defaultTimeoutMs: number;
  requireMultipleApprovers: boolean;
  minApprovers: number;
  approverCredential: string;
  approvalMethod: 'cryptographic_signature' | 'biometric' | 'mfa';
  maxPendingRequests: number;
}

interface Approver {
  did: string;
  credential: string;
  role: string;
  active: boolean;
}

// =============================================================================
// HumanLoopGate
// =============================================================================

export class HumanLoopGate {
  private config: ApprovalConfig;
  private pendingRequests: Map<string, HumanApprovalRequest> = new Map();
  private approvedRequests: Map<string, HumanApprovalRequest> = new Map();
  private approvers: Map<string, Approver> = new Map();

  constructor(config?: Partial<ApprovalConfig>) {
    this.config = {
      defaultTimeoutMs: 24 * 60 * 60 * 1000, // 24 hours
      requireMultipleApprovers: false,
      minApprovers: 1,
      approverCredential: 'IDNVIDA_VERIFIED_HUMAN',
      approvalMethod: 'cryptographic_signature',
      maxPendingRequests: 100,
      ...config,
    };
  }

  // ==========================================================================
  // Core Methods
  // ==========================================================================

  async requestApproval(task: Task): Promise<{ approved: boolean; signature?: string; requestId?: string }> {
    // Check if gate is at capacity
    if (this.pendingRequests.size >= this.config.maxPendingRequests) {
      throw new HumanLoopGateError('Approval gate at capacity. Cannot queue more requests.');
    }

    const requestId = `hlg_${randomUUID()}`;
    const riskLevel = this.assessRisk(task);

    const request: HumanApprovalRequest = {
      id: requestId,
      taskId: task.id || 'unknown',
      taskType: task.type,
      federation: task.federation || 'unspecified',
      description: this.generateDescription(task),
      riskLevel,
      requestedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + this.config.defaultTimeoutMs).toISOString(),
      status: 'pending',
    };

    this.pendingRequests.set(requestId, request);

    // Auto-approve low risk in non-production (configurable)
    if (riskLevel === 'low' && process.env.ATLAS_ENV === 'development') {
      request.status = 'approved';
      request.approverDid = 'auto_dev_mode';
      request.decidedAt = new Date().toISOString();
      this.pendingRequests.delete(requestId);
      this.approvedRequests.set(requestId, request);
      return { approved: true, signature: 'dev_auto_approved', requestId };
    }

    // In a real implementation, this would:
    // 1. Send notification to authorized approvers
    // 2. Wait for response via webhook/API
    // 3. Verify cryptographic signature
    // For now, we simulate the async nature

    return { approved: false, requestId };
  }

  async approve(requestId: string, approverDid: string, signature: string, reason?: string): Promise<boolean> {
    const request = this.pendingRequests.get(requestId);
    if (!request) {
      throw new HumanLoopGateError(`Approval request ${requestId} not found or already processed`);
    }

    // Check expiry
    if (new Date() > new Date(request.expiresAt)) {
      request.status = 'expired';
      this.pendingRequests.delete(requestId);
      throw new HumanLoopGateError(`Approval request ${requestId} has expired`);
    }

    // Verify approver
    if (!this.isAuthorizedApprover(approverDid)) {
      throw new HumanLoopGateError(`Approver ${approverDid} is not authorized`);
    }

    // Verify signature
    if (!this.verifySignature(requestId, approverDid, signature)) {
      throw new HumanLoopGateError('Invalid approval signature');
    }

    // Approve
    request.status = 'approved';
    request.approverDid = approverDid;
    request.approverSignature = signature;
    request.decidedAt = new Date().toISOString();
    request.reason = reason;

    this.pendingRequests.delete(requestId);
    this.approvedRequests.set(requestId, request);

    return true;
  }

  async reject(requestId: string, approverDid: string, signature: string, reason: string): Promise<boolean> {
    const request = this.pendingRequests.get(requestId);
    if (!request) {
      throw new HumanLoopGateError(`Approval request ${requestId} not found`);
    }

    if (!this.isAuthorizedApprover(approverDid)) {
      throw new HumanLoopGateError(`Approver ${approverDid} is not authorized`);
    }

    request.status = 'rejected';
    request.approverDid = approverDid;
    request.approverSignature = signature;
    request.decidedAt = new Date().toISOString();
    request.reason = reason;

    this.pendingRequests.delete(requestId);
    this.approvedRequests.set(requestId, request);

    return true;
  }

  // ==========================================================================
  // Approver Management
  // ==========================================================================

  registerApprover(did: string, credential: string, role: string = 'operator'): void {
    this.approvers.set(did, {
      did,
      credential,
      role,
      active: true,
    });
  }

  revokeApprover(did: string): boolean {
    const approver = this.approvers.get(did);
    if (approver) {
      approver.active = false;
      return true;
    }
    return false;
  }

  getApprovers(): Approver[] {
    return Array.from(this.approvers.values()).filter(a => a.active);
  }

  // ==========================================================================
  // Query Methods
  // ==========================================================================

  getPendingRequests(): HumanApprovalRequest[] {
    this.cleanupExpired();
    return Array.from(this.pendingRequests.values());
  }

  getRequest(requestId: string): HumanApprovalRequest | undefined {
    return this.pendingRequests.get(requestId) || this.approvedRequests.get(requestId);
  }

  getStats(): {
    pending: number;
    approved: number;
    rejected: number;
    expired: number;
    averageDecisionTimeMs: number;
  } {
    const all = Array.from(this.approvedRequests.values());
    const approved = all.filter(r => r.status === 'approved');
    const rejected = all.filter(r => r.status === 'rejected');
    const expired = all.filter(r => r.status === 'expired');

    const decisionTimes = all
      .filter(r => r.decidedAt && r.requestedAt)
      .map(r => new Date(r.decidedAt!).getTime() - new Date(r.requestedAt).getTime());

    const avgTime = decisionTimes.length > 0
      ? decisionTimes.reduce((a, b) => a + b, 0) / decisionTimes.length
      : 0;

    return {
      pending: this.pendingRequests.size,
      approved: approved.length,
      rejected: rejected.length,
      expired: expired.length,
      averageDecisionTimeMs: Math.round(avgTime),
    };
  }

  // ==========================================================================
  // Private Methods
  // ==========================================================================

  private assessRisk(task: Task): 'low' | 'medium' | 'high' | 'critical' {
    const sensitivity = task.ethicalSensitivity || 'none';
    const type = task.type.toLowerCase();

    if (sensitivity === 'critical') return 'critical';
    if (sensitivity === 'high') return 'high';

    const criticalOps = ['delete', 'revoke', 'expel', 'transfer_large', 'deploy'];
    if (criticalOps.some(op => type.includes(op))) return 'high';

    const mediumOps = ['update', 'modify', 'approve', 'issue'];
    if (mediumOps.some(op => type.includes(op))) return 'medium';

    return 'low';
  }

  private generateDescription(task: Task): string {
    return `Task "${task.type}" in federation ${task.federation || 'N/A'} ` +
           `with ${task.ethicalSensitivity || 'no'} ethical sensitivity. ` +
           `Priority: ${task.priority}. ` +
           `Requires human review before execution.`;
  }

  private isAuthorizedApprover(did: string): boolean {
    const approver = this.approvers.get(did);
    return approver !== undefined && approver.active;
  }

  private verifySignature(requestId: string, did: string, signature: string): boolean {
    // In production: verify with DID resolver + cryptographic verification
    // For now: check signature format and length
    if (!signature || signature.length < 32) return false;
    
    const expected = createHash('sha256')
      .update(`${requestId}:${did}:ATLAS_APPROVAL`)
      .digest('hex');
    
    // In dev mode, accept any well-formed signature
    if (process.env.ATLAS_ENV === 'development') return true;
    
    return signature === expected;
  }

  private cleanupExpired(): void {
    const now = new Date();
    for (const [id, request] of this.pendingRequests) {
      if (now > new Date(request.expiresAt)) {
        request.status = 'expired';
        this.pendingRequests.delete(id);
        this.approvedRequests.set(id, request);
      }
    }
  }
}

// =============================================================================
// HumanLoopGateError
// =============================================================================

export class HumanLoopGateError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'HumanLoopGateError';
  }
}

export default HumanLoopGate;
