/**
 * isabella-adapter.ts — Atlas Trascendence Isabella Adapter
 * Puente entre el Kernel y el sistema de inteligencia Isabella (F4)
 * Version: 2.0.0-trascendence
 */

import type { Task } from './kernel-core';

// =============================================================================
// Types
// =============================================================================

interface EOCTResult {
  approved: boolean;
  reason: string;
  confidence: number; // 0-1
  ethicalDimensions: {
    dignity: number;
    autonomy: number;
    fairness: number;
    transparency: number;
    accountability: number;
  };
  alternatives?: string[];
  humanReviewRecommended: boolean;
}

interface IsabellaConfig {
  endpoint?: string;
  modelId?: string;
  enableExplanations: boolean;
  enableMemory: boolean;
  maxTokens: number;
  temperature: number;
}

interface MemoryEntry {
  id: string;
  timestamp: string;
  content: string;
  embedding?: number[];
  federation?: string;
  tags: string[];
}

interface ExplainabilityReport {
  operation: string;
  decision: string;
  factors: { name: string; weight: number; description: string }[];
  counterfactuals: string[];
  confidence: number;
  limitations: string[];
}

// =============================================================================
// IsabellaAdapter
// =============================================================================

export class IsabellaAdapter {
  private config: IsabellaConfig;
  private memory: Map<string, MemoryEntry> = new Map();
  private explanationCache: Map<string, ExplainabilityReport> = new Map();

  constructor(config?: Partial<IsabellaConfig>) {
    this.config = {
      endpoint: process.env.ISABELLA_ENDPOINT || 'http://localhost:8000',
      modelId: process.env.ISABELLA_MODEL || 'isabella-kernel-v2',
      enableExplanations: true,
      enableMemory: true,
      maxTokens: 4096,
      temperature: 0.1,
      ...config,
    };
  }

  // ==========================================================================
  // EOCT — Ethical Operational Cognitive Tree
  // ==========================================================================

  async evaluateEOCT(task: Task): Promise<EOCTResult> {
    // The EOCT evaluates operations across 5 ethical dimensions
    const dimensions = await this.evaluateEthicalDimensions(task);
    
    const minScore = Math.min(
      dimensions.dignity,
      dimensions.autonomy,
      dimensions.fairness,
      dimensions.transparency,
      dimensions.accountability
    );

    const approved = minScore >= 0.3; // Threshold for approval
    const confidence = (dimensions.dignity + dimensions.autonomy + dimensions.fairness + 
                       dimensions.transparency + dimensions.accountability) / 5;

    const result: EOCTResult = {
      approved,
      reason: approved 
        ? 'Operation passes all ethical dimensions'
        : `Operation fails ethical dimension(s): ${this.getFailedDimensions(dimensions)}`,
      confidence,
      ethicalDimensions: dimensions,
      humanReviewRecommended: minScore < 0.7 || task.ethicalSensitivity === 'critical',
    };

    // Store in memory for learning
    if (this.config.enableMemory) {
      await this.storeMemory({
        id: `eoct_${task.id || Date.now()}`,
        timestamp: new Date().toISOString(),
        content: `EOCT evaluation for ${task.type}: ${approved ? 'APPROVED' : 'DENIED'}`,
        federation: task.federation,
        tags: ['eoct', task.federation || 'general', approved ? 'approved' : 'denied'],
      });
    }

    return result;
  }

  // ==========================================================================
  // Task Processing
  // ==========================================================================

  async process(task: Task): Promise<unknown> {
    // Route to Isabella engine for F4 tasks
    const enrichedPayload = await this.enrichWithContext(task);
    
    // Generate explanation if enabled
    if (this.config.enableExplanations) {
      const explanation = await this.explainDecision(task, enrichedPayload);
      this.explanationCache.set(task.id || 'unknown', explanation);
    }

    return {
      federation: 'F4',
      processed: true,
      taskType: task.type,
      enrichedContext: enrichedPayload,
      modelUsed: this.config.modelId,
      timestamp: new Date().toISOString(),
    };
  }

  // ==========================================================================
  // Explainability
  // ==========================================================================

  async explainDecision(task: Task, decision: unknown): Promise<ExplainabilityReport> {
    const factors = this.extractFactors(task, decision);
    
    return {
      operation: task.type,
      decision: JSON.stringify(decision),
      factors,
      counterfactuals: this.generateCounterfactuals(task),
      confidence: 0.85,
      limitations: [
        'Explanation based on available context; may not capture all implicit factors',
        'Model confidence varies with input complexity',
        'Cultural context may affect interpretation of fairness',
      ],
    };
  }

  getExplanation(taskId: string): ExplainabilityReport | undefined {
    return this.explanationCache.get(taskId);
  }

  // ==========================================================================
  // Memory System
  // ==========================================================================

  async storeMemory(entry: MemoryEntry): Promise<void> {
    this.memory.set(entry.id, entry);
  }

  async retrieveRelevant(query: string, federation?: string, limit: number = 5): Promise<MemoryEntry[]> {
    // Simple keyword-based retrieval (in production, use vector similarity)
    const queryTerms = query.toLowerCase().split(' ');
    const entries = Array.from(this.memory.values())
      .filter(e => !federation || e.federation === federation)
      .map(e => ({
        entry: e,
        score: queryTerms.filter(term => 
          e.content.toLowerCase().includes(term) || 
          e.tags.some(t => t.toLowerCase().includes(term))
        ).length,
      }))
      .filter(({ score }) => score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
      .map(({ entry }) => entry);

    return entries;
  }

  // ==========================================================================
  // Health & Status
  // ==========================================================================

  healthCheck(): { status: 'healthy' | 'degraded' | 'unavailable'; details: Record<string, unknown> } {
    const memorySize = this.memory.size;
    const cacheSize = this.explanationCache.size;

    return {
      status: 'healthy',
      details: {
        modelId: this.config.modelId,
        memoryEntries: memorySize,
        cachedExplanations: cacheSize,
        explanationsEnabled: this.config.enableExplanations,
        memoryEnabled: this.config.enableMemory,
      },
    };
  }

  // ==========================================================================
  // Private Methods
  // ==========================================================================

  private async evaluateEthicalDimensions(task: Task): Promise<EOCTResult['ethicalDimensions']> {
    const payload = JSON.stringify(task.payload).toLowerCase();
    const type = task.type.toLowerCase();
    const sensitivity = task.ethicalSensitivity || 'none';

    // Dignity: Does the operation respect human dignity?
    let dignity = 0.8;
    if (payload.includes('surveillance') || payload.includes('monitor')) dignity -= 0.4;
    if (payload.includes('profile') && this.hasSensitiveData(payload)) dignity -= 0.3;
    if (sensitivity === 'critical') dignity -= 0.2;

    // Autonomy: Does it preserve user agency?
    let autonomy = 0.8;
    if (payload.includes('automatic') && !payload.includes('consent')) autonomy -= 0.3;
    if (type.includes('decide') || type.includes('determine')) autonomy -= 0.2;
    if (payload.includes('opt_in') || payload.includes('consent')) autonomy += 0.1;

    // Fairness: Is it unbiased?
    let fairness = 0.8;
    if (this.hasSensitiveData(payload)) fairness -= 0.2;
    if (payload.includes('exclude') || payload.includes('filter')) fairness -= 0.2;

    // Transparency: Is it explainable?
    let transparency = 0.9;
    if (type.includes('blackbox') || type.includes('opaque')) transparency -= 0.5;
    if (sensitivity === 'high' || sensitivity === 'critical') transparency -= 0.1;

    // Accountability: Can responsibility be assigned?
    let accountability = 0.9;
    if (!task.federation) accountability -= 0.2;
    if (payload.includes('anonymous') && sensitivity !== 'none') accountability -= 0.3;

    return {
      dignity: Math.max(0, Math.min(1, dignity)),
      autonomy: Math.max(0, Math.min(1, autonomy)),
      fairness: Math.max(0, Math.min(1, fairness)),
      transparency: Math.max(0, Math.min(1, transparency)),
      accountability: Math.max(0, Math.min(1, accountability)),
    };
  }

  private getFailedDimensions(dimensions: EOCTResult['ethicalDimensions']): string {
    const failed: string[] = [];
    if (dimensions.dignity < 0.3) failed.push('dignity');
    if (dimensions.autonomy < 0.3) failed.push('autonomy');
    if (dimensions.fairness < 0.3) failed.push('fairness');
    if (dimensions.transparency < 0.3) failed.push('transparency');
    if (dimensions.accountability < 0.3) failed.push('accountability');
    return failed.join(', ');
  }

  private hasSensitiveData(payload: string): boolean {
    const sensitiveTerms = ['race', 'gender', 'religion', 'health', 'biometric', 'political'];
    return sensitiveTerms.some(term => payload.includes(term));
  }

  private async enrichWithContext(task: Task): Promise<Record<string, unknown>> {
    const relevantMemory = await this.retrieveRelevant(
      task.type,
      task.federation,
      3
    );

    return {
      originalPayload: task.payload,
      relevantContext: relevantMemory.map(m => m.content),
      federation: task.federation,
      ethicalSensitivity: task.ethicalSensitivity,
      timestamp: new Date().toISOString(),
    };
  }

  private extractFactors(task: Task, decision: unknown): { name: string; weight: number; description: string }[] {
    return [
      {
        name: 'Task Type',
        weight: 0.3,
        description: `Operation type: ${task.type}`,
      },
      {
        name: 'Federation Context',
        weight: 0.2,
        description: `Executed within federation: ${task.federation || 'none'}`,
      },
      {
        name: 'Ethical Sensitivity',
        weight: 0.3,
        description: `Sensitivity level: ${task.ethicalSensitivity || 'none'}`,
      },
      {
        name: 'Historical Context',
        weight: 0.2,
        description: 'Based on similar past operations and their outcomes',
      },
    ];
  }

  private generateCounterfactuals(task: Task): string[] {
    return [
      `What if the operation was executed with lower ethical sensitivity?`,
      `What if a different federation handled this operation?`,
      `What if human approval was required before execution?`,
      `What if the operation was split into smaller, less sensitive sub-operations?`,
    ];
  }
}

export default IsabellaAdapter;
