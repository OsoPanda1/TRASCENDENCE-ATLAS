/**
 * governance-hook.ts — Atlas Trascendence Governance Hook
 * Registra todas las decisiones criticas en el ledger inmutable (BookPI/MSR)
 * Version: 2.0.0-trascendence
 */

import { createHash, randomUUID } from 'node:crypto';
import type { Task, TaskResult, WorkflowResult } from './kernel-core';

// =============================================================================
// Types
// =============================================================================

interface LedgerEntry {
  id: string;
  timestamp: string;
  nodeId: string;
  type: 'task_completion' | 'workflow_execution' | 'policy_decision' | 'human_approval' | 'ethics_violation' | 'sovereignty_event';
  actor: string;
  action: string;
  payload: Record<string, unknown>;
  hash: string;
  previousHash: string | null;
  signature: string;
}

interface LedgerConfig {
  nodeId: string;
  storageType: 'memory' | 'file' | 'supabase';
  filePath?: string;
  supabaseUrl?: string;
  supabaseKey?: string;
}

// =============================================================================
// GovernanceHook
// =============================================================================

export class GovernanceHook {
  private config: LedgerConfig;
  private ledger: LedgerEntry[] = [];
  private lastHash: string | null = null;

  constructor(nodeId: string, config?: Partial<LedgerConfig>) {
    this.config = {
      nodeId,
      storageType: 'memory',
      ...config,
    };
  }

  // ==========================================================================
  // Recording Methods
  // ==========================================================================

  async recordTaskCompletion(task: Task, result: TaskResult): Promise<string> {
    return this.appendEntry({
      type: 'task_completion',
      actor: task.federation || 'kernel',
      action: `task_${result.status}`,
      payload: {
        taskType: task.type,
        taskPayload: this.sanitizePayload(task.payload),
        resultStatus: result.status,
        resultOutput: result.output ? this.sanitizePayload(result.output) : undefined,
        resultError: result.error,
        durationMs: result.durationMs,
        policyDecision: result.policyDecision,
      },
    });
  }

  async recordWorkflowExecution(result: WorkflowResult): Promise<string> {
    return this.appendEntry({
      type: 'workflow_execution',
      actor: 'workflow_engine',
      action: `workflow_${result.status}`,
      payload: {
        workflowId: result.workflowId,
        status: result.status,
        taskCount: result.taskResults.length,
        completedCount: result.taskResults.filter(r => r.status === 'completed').length,
        failedCount: result.taskResults.filter(r => r.status === 'failed').length,
        startedAt: result.startedAt,
        completedAt: result.completedAt,
      },
    });
  }

  async recordPolicyDecision(operation: string, decision: string, reason: string): Promise<string> {
    return this.appendEntry({
      type: 'policy_decision',
      actor: 'policy_evaluator',
      action: `policy_${decision}`,
      payload: { operation, decision, reason },
    });
  }

  async recordHumanApproval(operationId: string, approverDid: string, approved: boolean): Promise<string> {
    return this.appendEntry({
      type: 'human_approval',
      actor: approverDid,
      action: approved ? 'approved' : 'rejected',
      payload: { operationId, approverDid, approved, timestamp: new Date().toISOString() },
    });
  }

  async recordEthicsViolation(violationId: string, details: Record<string, unknown>): Promise<string> {
    return this.appendEntry({
      type: 'ethics_violation',
      actor: 'ethics_monitor',
      action: 'violation_detected',
      payload: { violationId, details, severity: details.severity },
    });
  }

  async recordSovereigntyEvent(eventType: string, metrics: Record<string, unknown>): Promise<string> {
    return this.appendEntry({
      type: 'sovereignty_event',
      actor: 'sovereignty_monitor',
      action: eventType,
      payload: { metrics, timestamp: new Date().toISOString() },
    });
  }

  // ==========================================================================
  // Query Methods
  // ==========================================================================

  query(filters: {
    type?: string;
    actor?: string;
    from?: string;
    to?: string;
    limit?: number;
  }): LedgerEntry[] {
    let results = [...this.ledger];

    if (filters.type) {
      results = results.filter(e => e.type === filters.type);
    }
    if (filters.actor) {
      results = results.filter(e => e.actor === filters.actor);
    }
    if (filters.from) {
      results = results.filter(e => e.timestamp >= filters.from!);
    }
    if (filters.to) {
      results = results.filter(e => e.timestamp <= filters.to!);
    }
    if (filters.limit) {
      results = results.slice(-filters.limit);
    }

    return results;
  }

  verifyChain(): { valid: boolean; brokenAt?: number; error?: string } {
    for (let i = 1; i < this.ledger.length; i++) {
      const current = this.ledger[i];
      const previous = this.ledger[i - 1];

      if (current.previousHash !== previous.hash) {
        return { valid: false, brokenAt: i, error: `Hash mismatch at entry ${i}` };
      }

      const recalculatedHash = this.calculateHash({
        ...current,
        hash: '', // exclude hash from calculation
      });

      if (recalculatedHash !== current.hash) {
        return { valid: false, brokenAt: i, error: `Invalid hash at entry ${i}` };
      }
    }

    return { valid: true };
  }

  getLedgerSize(): number {
    return this.ledger.length;
  }

  exportToJSON(): string {
    return JSON.stringify({
      nodeId: this.config.nodeId,
      exportedAt: new Date().toISOString(),
      entryCount: this.ledger.length,
      entries: this.ledger,
    }, null, 2);
  }

  // ==========================================================================
  // Private Methods
  // ==========================================================================

  private async appendEntry(partial: Omit<LedgerEntry, 'id' | 'timestamp' | 'nodeId' | 'hash' | 'previousHash' | 'signature'>): Promise<string> {
    const entry: LedgerEntry = {
      id: randomUUID(),
      timestamp: new Date().toISOString(),
      nodeId: this.config.nodeId,
      ...partial,
      previousHash: this.lastHash,
      hash: '',
      signature: '',
    };

    entry.hash = this.calculateHash(entry);
    entry.signature = this.signEntry(entry);

    this.ledger.push(entry);
    this.lastHash = entry.hash;

    // Persist if needed
    if (this.config.storageType === 'file' && this.config.filePath) {
      await this.persistToFile();
    }

    return entry.id;
  }

  private calculateHash(entry: Omit<LedgerEntry, 'hash'>): string {
    const data = JSON.stringify({
      id: entry.id,
      timestamp: entry.timestamp,
      nodeId: entry.nodeId,
      type: entry.type,
      actor: entry.actor,
      action: entry.action,
      payload: entry.payload,
      previousHash: entry.previousHash,
    });
    return createHash('sha3-256').update(data).digest('hex');
  }

  private signEntry(entry: LedgerEntry): string {
    // In production, this would use the node's private key
    // For now, we create a deterministic signature
    const data = `${entry.hash}:${this.config.nodeId}`;
    return createHash('sha3-256').update(data).digest('hex');
  }

  private sanitizePayload(payload: unknown): unknown {
    if (typeof payload !== 'object' || payload === null) return payload;
    
    const sensitiveKeys = ['password', 'secret', 'token', 'key', 'private', 'credential'];
    const sanitized = { ...payload as Record<string, unknown> };
    
    for (const key of Object.keys(sanitized)) {
      if (sensitiveKeys.some(sk => key.toLowerCase().includes(sk))) {
        sanitized[key] = '[REDACTED]';
      }
    }
    
    return sanitized;
  }

  private async persistToFile(): Promise<void> {
    // Implementation for file persistence
    // Would use fs.writeFile in real implementation
  }
}

export default GovernanceHook;
