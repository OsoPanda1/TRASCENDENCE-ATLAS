import { config } from "../config.js";
import { reconcilePids, ReconciliationReport } from "../pidReconciler.js";

/**
 * Exit codes for the process
 */
enum ExitCode {
  SUCCESS = 0,
  VALIDATION_FAILED = 1,
  RUNTIME_ERROR = 2,
  TIMEOUT = 3,
  RETRY_EXHAUSTED = 4,
}

/**
 * Log levels for structured logging
 */
type LogLevel = "info" | "error" | "warn" | "debug";

/**
 * Structured log entry
 */
interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  jobId: string;
  runId: string;
  payload?: unknown;
}

/**
 * Normalized error for logging
 */
interface NormalizedError {
  name: string;
  message: string;
  stack?: string;
  cause?: unknown;
}

/**
 * Alert payload sent to monitoring/observability system
 */
interface AlertPayload {
  severity: "critical" | "error" | "warning" | "info";
  source: "pid-reconciliation-job";
  code: string;
  message: string;
  context?: unknown;
}

/**
 * Secondary restart / retry configuration
 */
interface RetryConfig {
  maxAttempts: number;
  baseDelayMs: number;
  maxDelayMs: number;
}

/**
 * Timeout configuration
 */
const RECONCILIATION_TIMEOUT_MS = 30_000; // 30s, ajustable según SLA
const RETRY_CONFIG: RetryConfig = {
  maxAttempts: 3,
  baseDelayMs: 2_000,
  maxDelayMs: 30_000,
};

const EXIT = ExitCode;

/**
 * Job-level identifiers for tracing
 */
const JOB_ID = process.env.PID_RECONCILIATION_JOB_ID ?? "pid-reconciliation";
const RUN_ID =
  process.env.PID_RECONCILIATION_RUN_ID ??
  `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

/**
 * Structured logger (puede ser reemplazado por Pino / Winston / etc.)
 */
const emit = (level: LogLevel, message: string, payload?: unknown): void => {
  const entry: LogEntry = {
    timestamp: new Date().toISOString(),
    level,
    message,
    jobId: JOB_ID,
    runId: RUN_ID,
    ...(payload !== undefined && { payload }),
  };

  const output = JSON.stringify(entry);

  if (level === "error") {
    console.error(output);
  } else {
    console.log(output);
  }
};

/**
 * Normaliza cualquier error a una forma serializable
 */
const normalizeError = (error: unknown): NormalizedError => {
  if (error instanceof Error) {
    return {
      name: error.name || "Error",
      message: error.message || "Unknown error",
      stack: error.stack,
    };
  }

  return {
    name: "NonErrorThrowable",
    message: "Thrown value is not an Error instance",
    cause: error,
  };
};

/**
 * Envía una alerta al sistema de paneles/observabilidad.
 * Actualmente loguea como 'error', pero está aislado para conectar con:
 * - Prometheus (pushgateway),
 * - Sentry,
 * - Loki,
 * - CLEI chain, etc.
 */
const sendAlert = async (alert: AlertPayload): Promise<void> => {
  emit("error", "ALERT_EMIT", alert);

  // Ejemplo de integración futura:
  // const endpoint = process.env.ALERT_ENDPOINT;
  // if (!endpoint) return;
  //
  // await fetch(endpoint, {
  //   method: "POST",
  //   headers: { "Content-Type": "application/json" },
  //   body: JSON.stringify({ ...alert, jobId: JOB_ID, runId: RUN_ID }),
  // });
};

/**
 * Asigna exitCode de forma centralizada
 */
const setExitCode = (code: ExitCode): void => {
  process.exitCode = code;
};

/**
 * Ejecuta una promesa con timeout duro.
 * Si se excede, rechaza con Error('Timeout: ...').
 */
const withTimeout = <T>(
  promise: Promise<T>,
  timeoutMs: number,
  label = "operation",
): Promise<T> => {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => {
      const error = new Error(`Timeout: ${label} exceeded ${timeoutMs}ms`);
      reject(error);
    }, timeoutMs);

    promise
      .then((value) => {
        clearTimeout(timer);
        resolve(value);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
};

/**
 * Calcula backoff exponencial con jitter para el protocolo de rearranque secundario.
 */
const computeBackoffDelay = (attempt: number, cfg: RetryConfig): number => {
  const exp = Math.min(attempt, 10);
  const base = cfg.baseDelayMs * 2 ** (exp - 1);
  const capped = Math.min(base, cfg.maxDelayMs);
  const jitter = Math.random() * 0.4 + 0.8; // 0.8x–1.2x
  return Math.round(capped * jitter);
};

/**
 * Determina si un error parece transitorio o permanente.
 * Ajusta la heurística según los tipos de error que pueda emitir reconcilePids.
 */
const isTransientError = (error: NormalizedError): boolean => {
  const msg = error.message.toLowerCase();
  return (
    msg.includes("network") ||
    msg.includes("timeout") ||
    msg.includes("connection") ||
    msg.includes("rate limit") ||
    msg.includes("temporarily")
  );
};

/**
 * Protocolo de rearranque secundario:
 * - Reintenta la reconciliación con backoff ante fallos transitorios.
 * - No reintenta si:
 *   - el reporte indica fallo de validación definitivo, o
 *   - el error parece permanente.
 */
const runReconciliationWithRetry = async (): Promise<ReconciliationReport> => {
  let lastError: unknown;

  for (let attempt = 1; attempt <= RETRY_CONFIG.maxAttempts; attempt += 1) {
    const context = {
      attempt,
      maxAttempts: RETRY_CONFIG.maxAttempts,
      jobId: JOB_ID,
      runId: RUN_ID,
    };

    emit("info", "PID reconciliation attempt started", context);

    try {
      const report = await withTimeout(
        reconcilePids(config),
        RECONCILIATION_TIMEOUT_MS,
        `PID reconciliation attempt ${attempt}`,
      );

      emit("info", "PID reconciliation attempt completed", {
        ...context,
        report,
      });

      if (report.passed) {
        setExitCode(EXIT.SUCCESS);
        return report;
      }

      // Falla de validación: consideramos no reintentar (fallo permanente)
      emit("warn", "PID reconciliation validation failed", {
        ...context,
        report,
      });

      await sendAlert({
        severity: "warning",
        source: "pid-reconciliation-job",
        code: "PID_RECONCILIATION_VALIDATION_FAILED",
        message: "PID reconciliation validation failed",
        context: { ...context, report },
      });

      setExitCode(EXIT.VALIDATION_FAILED);
      return report;
    } catch (error) {
      lastError = error;
      const normalized = normalizeError(error);

      emit("error", "PID reconciliation attempt failed", {
        ...context,
        error: normalized,
      });

      // Timeout explícito: no tiene sentido seguir reintentando
      if (normalized.message.includes("Timeout:")) {
        await sendAlert({
          severity: "critical",
          source: "pid-reconciliation-job",
          code: "PID_RECONCILIATION_TIMEOUT",
          message: normalized.message,
          context,
        });
        setExitCode(EXIT.TIMEOUT);
        throw error;
      }

      // Errores permanentes (no transitorios) → no reintentar
      if (!isTransientError(normalized)) {
        await sendAlert({
          severity: "error",
          source: "pid-reconciliation-job",
          code: "PID_RECONCILIATION_PERMANENT_FAILURE",
          message: normalized.message,
          context: { ...context, error: normalized },
        });
        setExitCode(EXIT.RUNTIME_ERROR);
        throw error;
      }

      // Errores transitorios: reintentar si aún hay intentos restantes
      if (attempt < RETRY_CONFIG.maxAttempts) {
        const delay = computeBackoffDelay(attempt, RETRY_CONFIG);

        emit("warn", "Scheduling PID reconciliation retry", {
          ...context,
          delayMs: delay,
        });

        await sendAlert({
          severity: "error",
          source: "pid-reconciliation-job",
          code: "PID_RECONCILIATION_RETRY",
          message: "PID reconciliation failed, scheduling retry",
          context: { ...context, delayMs: delay, error: normalized },
        });

        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }

  // Si agotamos los intentos:
  const normalized = normalizeError(lastError);

  await sendAlert({
    severity: "critical",
    source: "pid-reconciliation-job",
    code: "PID_RECONCILIATION_RETRY_EXHAUSTED",
    message: "PID reconciliation exhausted all retry attempts",
    context: { error: normalized, ...RETRY_CONFIG, jobId: JOB_ID, runId: RUN_ID },
  });

  setExitCode(EXIT.RETRY_EXHAUSTED);
  throw lastError ?? new Error("PID reconciliation failed with no error detail");
};

/**
 * Entrada principal del job, con:
 * - logging estructurado,
 * - rearranque secundario,
 * - timeout,
 * - alertas integradas,
 * - exit codes consistentes.
 */
async function main(): Promise<void> {
  emit("info", "PID reconciliation job started", {
    jobId: JOB_ID,
    runId: RUN_ID,
  });

  try {
    await runReconciliationWithRetry();
  } catch (error) {
    const normalized = normalizeError(error);

    emit("error", "PID reconciliation job failed", {
      error: normalized,
      jobId: JOB_ID,
      runId: RUN_ID,
    });

    if (process.exitCode === undefined) {
      setExitCode(EXIT.RUNTIME_ERROR);
    }
  } finally {
    if (process.exitCode === undefined) {
      setExitCode(EXIT.RUNTIME_ERROR);
    }

    emit("info", "PID reconciliation job finished", {
      exitCode: process.exitCode,
      jobId: JOB_ID,
      runId: RUN_ID,
    });
  }
}

void main();
