import { createHash, randomUUID } from 'node:crypto';
import canon from '../../data/civilizational-compiler/canon-v1.json' with { type: 'json' };
import sourceRepos from '../../data/civilizational-compiler/source-repos.json' with { type: 'json' };

const ecosystemKeywords = [
  'tamv',
  'mdx4',
  'md-x4',
  'atlas',
  'isabella',
  'bookpi',
  'soberania',
  'soberanía',
  'territorial',
  'federada',
  'federated',
  'knowledge',
  'memoria',
];

const ontologyHints = {
  Entity: ['actor', 'persona', 'institucion', 'institución', 'entidad', 'identity'],
  Process: ['pipeline', 'proceso', 'weaver', 'ingest', 'normalizacion', 'normalización', 'workflow'],
  Protocol: ['protocol', 'protocolo', 'api', 'endpoint', 'handshake'],
  Policy: ['policy', 'politica', 'política', 'constitution', 'canon', 'invariant'],
  Infrastructure: ['kernel', 'infra', 'backend', 'frontend', 'web', 'gateway', 'service'],
  Memory: ['atlas', 'bookpi', 'ledger', 'memoria', 'lineage', 'provenance'],
  Governance: ['governance', 'gobernanza', 'tribunal', 'guardian', 'review'],
  Territory: ['territorio', 'territorial', 'rdm', 'pueblo', 'omniverso', 'xr'],
};

const now = () => new Date().toISOString();

function stableId(input) {
  return createHash('sha256').update(JSON.stringify(input)).digest('hex').slice(0, 16);
}

function textForArtifact(artifact = {}) {
  return [artifact.id, artifact.name, artifact.title, artifact.description, artifact.purpose, artifact.domain, artifact.url]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();
}

function clamp(value) {
  return Math.max(0, Math.min(1, Number(value.toFixed(3))));
}

function evaluateIdentity(artifact) {
  const text = textForArtifact(artifact);
  const hits = ecosystemKeywords.filter((keyword) => text.includes(keyword));
  const sourceMatch = sourceRepos.repositories.find((repo) => text.includes(repo.name));
  const confidence = clamp((hits.length / 5) + (sourceMatch ? 0.35 : 0));
  return {
    guardian: 'identity',
    verdict: confidence >= 0.35 ? 'APPROVE' : 'REVIEW',
    belongs: confidence >= 0.35,
    confidence,
    node: sourceMatch?.target_module ?? artifact.node ?? 'atlas/civilizational-compiler',
    evidence: [...hits, sourceMatch?.name].filter(Boolean),
  };
}

function evaluateOntology(artifact) {
  const text = textForArtifact(artifact);
  const explicit = canon.ontology_types.includes(artifact.ontology) ? artifact.ontology : undefined;
  const inferred = explicit ?? Object.entries(ontologyHints).find(([, hints]) => hints.some((hint) => text.includes(hint)))?.[0];
  return {
    guardian: 'ontology',
    verdict: inferred ? 'APPROVE' : 'REJECT',
    type: inferred ?? null,
    domain: artifact.domain ?? 'Civilizational Compiler',
    subdomain: artifact.subdomain ?? (inferred ? `${inferred.toLowerCase()}-integration` : null),
  };
}

function evaluateSemantics(artifact, ontologyResult) {
  const relations = new Set(artifact.relations ?? []);
  const text = textForArtifact(artifact);
  for (const repo of sourceRepos.repositories) {
    if (text.includes(repo.name) || repo.role.toLowerCase().includes(ontologyResult.type?.toLowerCase() ?? '')) {
      relations.add(repo.target_module);
    }
  }
  relations.add('canon-compilador-civilizatorio-v1');
  if (ontologyResult.type) relations.add(`ontology:${ontologyResult.type}`);

  return {
    guardian: 'semantics',
    verdict: relations.size >= 2 ? 'APPROVE' : 'REVIEW',
    orphan: relations.size < 2,
    relations: [...relations],
    duplicateRisk: false,
  };
}

function evaluateRisk(artifact) {
  const text = textForArtifact(artifact);
  const warnings = [];
  if (text.includes('secret') || text.includes('credential')) warnings.push('possible-secret-material');
  if (text.includes('centralized') || text.includes('centralizado')) warnings.push('centralization-risk');
  if (!artifact.tests && artifact.kind === 'code') warnings.push('missing-tests');
  const riskLevel = warnings.length > 1 ? 'HIGH' : warnings.length === 1 ? 'MEDIUM' : 'LOW';
  return {
    guardian: 'risk',
    verdict: riskLevel === 'HIGH' ? 'REVIEW' : 'APPROVE',
    riskLevel,
    warnings,
  };
}

function evaluateConstitution(artifact) {
  const declaredViolations = Array.isArray(artifact.violations) ? artifact.violations : [];
  const violations = declaredViolations.filter((violation) => canon.constitutional_invariants.includes(violation));
  if (!artifact.provenance && !artifact.url && !artifact.source) {
    violations.push('provenance_required');
  }
  return {
    guardian: 'constitution',
    verdict: violations.length > 0 ? 'REJECT' : 'APPROVE',
    violations: [...new Set(violations)],
    invariants: canon.constitutional_invariants,
  };
}

function baseMetrics(graph = {}) {
  return {
    coherence: Number(graph.coherence ?? 0.72),
    traceability: Number(graph.traceability ?? 0.66),
    coverage: Number(graph.coverage ?? 0.61),
    reuse: Number(graph.reuse ?? 0.58),
    contradictions: Number(graph.contradictions ?? 0.08),
    fragmentation: Number(graph.fragmentation ?? 0.18),
    debt: Number(graph.debt ?? 0.22),
  };
}

function fitness(metrics) {
  const weights = canon.fitness_weights;
  return clamp(
    weights.coherence * metrics.coherence
    + weights.traceability * metrics.traceability
    + weights.coverage * metrics.coverage
    + weights.reuse * metrics.reuse
    - weights.contradictions * metrics.contradictions
    - weights.fragmentation * metrics.fragmentation
    - weights.debt * metrics.debt,
  );
}

function simulateArtifact(artifact, graph) {
  const before = baseMetrics(graph);
  const hasProvenance = Boolean(artifact.provenance || artifact.url || artifact.source);
  const relationCount = Array.isArray(artifact.relations) ? artifact.relations.length : 0;
  const after = {
    coherence: clamp(before.coherence + (artifact.purpose ? 0.035 : -0.02)),
    traceability: clamp(before.traceability + (hasProvenance ? 0.045 : -0.08)),
    coverage: clamp(before.coverage + 0.025),
    reuse: clamp(before.reuse + Math.min(0.04, relationCount * 0.01)),
    contradictions: clamp(before.contradictions + (artifact.contradiction ? 0.08 : -0.01)),
    fragmentation: clamp(before.fragmentation + (relationCount > 0 ? -0.02 : 0.04)),
    debt: clamp(before.debt + (artifact.tests || artifact.kind !== 'code' ? -0.015 : 0.03)),
  };
  const beforeFitness = fitness(before);
  const afterFitness = fitness(after);
  return {
    guardian: 'simulation',
    verdict: afterFitness > beforeFitness ? 'APPROVE' : 'REVIEW',
    before,
    after,
    fitness_before: beforeFitness,
    fitness_after: afterFitness,
    fitness_delta: clamp(afterFitness - beforeFitness),
  };
}

function decidePromotion(evaluations, requestedState = 'REVIEW') {
  const constitution = evaluations.find((item) => item.guardian === 'constitution');
  const simulation = evaluations.find((item) => item.guardian === 'simulation');
  const rejected = evaluations.some((item) => item.verdict === 'REJECT');
  const requestedIndex = canon.promotion_states.indexOf(requestedState);
  const safeRequestedState = requestedIndex >= 0 ? requestedState : 'REVIEW';
  let state = 'REVIEW';
  if (constitution?.verdict === 'REJECT' || rejected) state = 'DRAFT';
  else if (simulation?.fitness_delta > 0.02 && ['APPROVED', 'CANONICAL', 'HISTORICAL'].includes(safeRequestedState)) state = 'APPROVED';
  else if (simulation?.fitness_delta > 0) state = safeRequestedState === 'DRAFT' ? 'REVIEW' : safeRequestedState;

  return {
    guardian: 'promotion',
    verdict: state === 'DRAFT' && constitution?.verdict === 'REJECT' ? 'REJECT' : 'APPROVE',
    state,
    requestedState: safeRequestedState,
    canonicalDirectPromotionBlocked: safeRequestedState === 'CANONICAL' && state !== 'CANONICAL',
  };
}

function evaluateArtifact(artifact = {}, graph = {}) {
  const normalized = {
    id: artifact.id ?? stableId(artifact),
    received_at: now(),
    ...artifact,
  };
  const identity = evaluateIdentity(normalized);
  const ontology = evaluateOntology(normalized);
  const semantics = evaluateSemantics(normalized, ontology);
  const risk = evaluateRisk(normalized);
  const constitution = evaluateConstitution(normalized);
  const simulation = simulateArtifact({ ...normalized, relations: semantics.relations }, graph);
  const promotion = decidePromotion([identity, ontology, semantics, risk, constitution, simulation], normalized.requestedState);
  const verdict = constitution.verdict === 'REJECT' || ontology.verdict === 'REJECT' ? 'REJECT' : promotion.state === 'APPROVED' ? 'APPROVE' : 'REVIEW';

  return {
    id: normalized.id,
    event: verdict === 'REJECT' ? 'artifact_rejected' : verdict === 'APPROVE' ? 'artifact_approved' : 'artifact_in_review',
    timestamp: now(),
    artifact: normalized,
    verdict,
    evaluations: [identity, ontology, semantics, risk, constitution, simulation, promotion],
    telemetry: {
      event_id: randomUUID(),
      fitness_delta: simulation.fitness_delta,
      constitutional_violations: constitution.violations.length,
      promotion_state: promotion.state,
    },
  };
}

function buildGraph() {
  const repoNodes = sourceRepos.repositories.map((repo) => ({
    id: `repo:${repo.name}`,
    type: 'Repo',
    label: repo.name,
    url: repo.url,
    priority: repo.priority,
  }));
  const moduleNodes = sourceRepos.repositories.map((repo) => ({
    id: `module:${repo.target_module}`,
    type: 'Module',
    label: repo.target_module,
    ontology: repo.ontology,
  }));
  const edges = sourceRepos.repositories.flatMap((repo) => [
    { from: `repo:${repo.name}`, to: `module:${repo.target_module}`, type: 'implements' },
    { from: `module:${repo.target_module}`, to: 'policy:canon-compilador-civilizatorio-v1', type: 'governed_by' },
  ]);
  return {
    generated_at: now(),
    nodes: [
      { id: 'policy:canon-compilador-civilizatorio-v1', type: 'Policy', label: canon.title, status: canon.status },
      { id: 'evidence:source-repos', type: 'Evidence', label: 'Manifiesto repos OsoPanda1' },
      ...repoNodes,
      ...moduleNodes,
    ],
    edges,
    orphan_nodes: [],
  };
}

function buildLineage(artifactId) {
  const source = sourceRepos.repositories.find((repo) => repo.name === artifactId || `repo:${repo.name}` === artifactId);
  return {
    artifact: artifactId,
    generated_at: now(),
    provenance: source ? [source.url, 'data/civilizational-compiler/source-repos.json', 'docs/civilizational-compiler/ABSORPTION_PLAN_OSOPANDA_REPOS.md'] : ['data/civilizational-compiler/canon-v1.json'],
    decisions: [
      { event: 'artifact_ingested', state: 'REVIEW', guardian: 'identity', timestamp: '2026-06-11T00:00:00Z' },
      { event: 'canon_applied', state: 'REVIEW', guardian: 'constitution', timestamp: '2026-06-11T00:00:00Z' },
    ],
    source,
  };
}

export function createCivilizationalCompiler() {
  const decisions = [];
  const currentFitness = fitness(baseMetrics());

  return {
    canon,
    sourceRepos,
    getConstitution: () => ({
      canon: canon.id,
      status: canon.status,
      mutability: canon.mutability,
      invariants: canon.constitutional_invariants,
      principles: canon.principles,
      guardians: canon.guardians,
    }),
    getFitness: () => ({
      civilizational_fitness: currentFitness,
      metrics: baseMetrics(),
      weights: canon.fitness_weights,
      observability: {
        coherence_score: baseMetrics().coherence,
        ontology_coverage: baseMetrics().coverage,
        semantic_connectivity: 1 - baseMetrics().fragmentation,
        contradiction_count: baseMetrics().contradictions,
        orphan_nodes: 0,
        provenance_score: baseMetrics().traceability,
        constitutional_violations: 0,
        promotion_rate: decisions.filter((item) => item.telemetry.promotion_state === 'APPROVED').length,
        rejection_rate: decisions.filter((item) => item.verdict === 'REJECT').length,
        canonical_stability: 1,
      },
    }),
    getGraph: buildGraph,
    getLineage: buildLineage,
    evaluate: (artifact, graph) => evaluateArtifact(artifact, graph),
    ingest: (artifact) => {
      const decision = evaluateArtifact(artifact);
      decisions.push(decision);
      return decision;
    },
    simulate: (artifact, graph) => simulateArtifact(artifact, graph),
    review: (payload) => {
      const event = {
        event: 'human_review_recorded',
        id: randomUUID(),
        timestamp: now(),
        artifact: payload.artifact,
        reviewer: payload.reviewer ?? 'committee',
        decision: payload.decision ?? 'REVIEW',
        evidence: payload.evidence ?? [],
      };
      decisions.push({ verdict: event.decision, telemetry: { promotion_state: event.decision }, ...event });
      return event;
    },
    promote: (payload) => {
      const evaluation = evaluateArtifact({ ...payload.artifact, requestedState: payload.requestedState ?? 'APPROVED' });
      decisions.push(evaluation);
      return evaluation;
    },
    freeze: (payload) => {
      const event = {
        event: 'artifact_frozen',
        id: randomUUID(),
        timestamp: now(),
        artifact: payload.artifact,
        state: payload.state ?? 'CANONICAL',
        note: 'Frozen by extension; history remains preserved.',
      };
      decisions.push({ verdict: 'APPROVE', telemetry: { promotion_state: event.state }, ...event });
      return event;
    },
  };
}
