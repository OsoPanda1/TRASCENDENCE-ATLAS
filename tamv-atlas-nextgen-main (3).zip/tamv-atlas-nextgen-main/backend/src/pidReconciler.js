const ORCID_REGEX = /^(\d{4}-){3}\d{3}[\dX]$/; // formato ORCID estándar [web:91][web:94]

const DOI_PREFIX_REGEX = /^10\.\d{4,9}$/; // patrón recomendado para prefijos DOI [web:96][web:99]

interface PidFormatInput {
  isni?: string | null;
  orcid?: string | null;
  zenodoRecord?: string | number | null;
  doiPrefix?: string | null;
}

interface PidFormatValidation {
  isni: boolean;
  orcid: boolean;
  zenodoRecord: boolean;
  doiPrefix: boolean;
}

interface OnlineStatusOk {
  reachable: true;
  status: number;
}

interface OnlineStatusError {
  reachable: false;
  error: string;
  status?: number;
}

type OnlineStatus = OnlineStatusOk | OnlineStatusError;

interface OnlineResult {
  orcid: OnlineStatus;
  zenodo: OnlineStatus;
}

interface PidReconciliationConfig {
  pids: {
    isni?: string | null;
    orcid?: string | null;
    zenodoRecord?: string | number | null;
    doiPrefix?: string | null;
    reconcileTimeoutMs?: number;
  };
}

interface ReconciliationReport {
  checkedAt: string;
  formatValidation: PidFormatValidation;
  online: OnlineResult;
  passed: boolean;
}

/**
 * Validación estricta de formato de PIDs (no reachability).
 */
export function validatePidFormat({
  isni,
  orcid,
  zenodoRecord,
  doiPrefix,
}: PidFormatInput): PidFormatValidation {
  const isniStr = String(isni ?? "").replace(/\s+/g, "").replace(/-/g, "");

  return {
    // ISNI: 16 caracteres (dígitos) + posible dígito de control — aquí solo longitud y no vacío.
    isni: isniStr.length >= 8 && /^[0-9Xx]+$/.test(isniStr),
    // ORCID: 0000-0000-0000-0000 con dígito final que puede ser X [web:94]
    orcid: typeof orcid === "string" && ORCID_REGEX.test(orcid.trim()),
    // Zenodo record ID: entero positivo
    zenodoRecord: /^\d+$/.test(String(zenodoRecord ?? "").trim()),
    // DOI prefix: 10.NNNN... (4–9 dígitos) [web:96][web:99]
    doiPrefix: typeof doiPrefix === "string" && DOI_PREFIX_REGEX.test(doiPrefix.trim()),
  };
}

/**
 * Fetch con timeout duro. Separa AbortError de otros errores. [web:97][web:100]
 */
async function fetchWithTimeout(
  url: string,
  timeoutMs: number,
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { accept: "application/json" },
    });
    return response;
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new Error(`Timeout after ${timeoutMs}ms for ${url}`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function toOnlineStatusOk(response: Response): OnlineStatusOk {
  return {
    reachable: response.ok,
    status: response.status,
  };
}

function toOnlineStatusError(reason: unknown): OnlineStatusError {
  if (reason instanceof Error) {
    return { reachable: false, error: reason.message };
  }
  return { reachable: false, error: String(reason) };
}

/**
 * Reconciliación de PIDs:
 * - valida formato local,
 * - verifica reachability de ORCID y Zenodo,
 * - considera passed solo si:
 *   - todos los formatos son válidos,
 *   - ORCID y Zenodo responden OK.
 */
export async function reconcilePids(
  config: PidReconciliationConfig,
): Promise<ReconciliationReport> {
  const timeoutMs = config.pids.reconcileTimeoutMs ?? 7_000;

  const formatValidation = validatePidFormat({
    isni: config.pids.isni,
    orcid: config.pids.orcid,
    zenodoRecord: config.pids.zenodoRecord,
    doiPrefix: config.pids.doiPrefix,
  });

  const orcidId = config.pids.orcid?.trim();
  const zenodoId = String(config.pids.zenodoRecord ?? "").trim();

  const [orcidResult, zenodoResult] = await Promise.allSettled([
    orcidId
      ? fetchWithTimeout(
          `https://pub.orcid.org/v3.0/${orcidId}/person`,
          timeoutMs,
        )
      : Promise.reject(new Error("Missing ORCID id")),
    zenodoId
      ? fetchWithTimeout(
          `https://zenodo.org/api/records/${zenodoId}`,
          timeoutMs,
        )
      : Promise.reject(new Error("Missing Zenodo record id")),
  ]);

  const online: OnlineResult = {
    orcid:
      orcidResult.status === "fulfilled"
        ? toOnlineStatusOk(orcidResult.value)
        : toOnlineStatusError(orcidResult.reason),
    zenodo:
      zenodoResult.status === "fulfilled"
        ? toOnlineStatusOk(zenodoResult.value)
        : toOnlineStatusError(zenodoResult.reason),
  };

  const formatsOk = Object.values(formatValidation).every(Boolean);
  const orcidReachable = online.orcid.reachable === true;
  const zenodoReachable = online.zenodo.reachable === true;

  const passed = formatsOk && orcidReachable && zenodoReachable;

  return {
    checkedAt: new Date().toISOString(),
    formatValidation,
    online,
    passed,
  };
}
