import { WikiBreadcrumb, WikiCard, WikiCode, WikiH1, WikiH2, WikiP, WikiTable, WikiTag } from "@/components/WikiComponents";

const sourceRows = [
  ["kernel-tamv", "Kernel operativo y constitucional", "Infrastructure", "super importante"],
  ["tamv-core-atlas", "Memoria Atlas, lineage y contratos", "Memory", "alta"],
  ["oso-data-weaver", "Normalización, proveniencia y conectores", "Process", "alta"],
  ["ecosistema-nextgen-tamv", "Servicios NextGen y producto", "Process", "alta"],
  ["tamv-onmiverso", "Territorio, XR y semántica omniverso", "Territory", "alta"],
  ["tamvweb-fb822252", "Interfaz web y documentación complementaria", "Infrastructure", "complemento"],
];

export default function CanonV1() {
  return (
    <div>
      <WikiBreadcrumb section="compilador-civilizatorio" page="canon-v1" />
      <WikiH1>Compilador Civilizatorio · Canon v1.0</WikiH1>
      <WikiP>
        El Atlas integra el Canon del Compilador Civilizatorio como constitución computable: no trata los repositorios como
        carpetas aisladas, sino como artefactos que deben demostrar identidad, propósito, ontología, semántica,
        invariantes, memoria y fitness ecosistémico antes de promoverse.
      </WikiP>

      <div className="flex flex-wrap mb-6">
        <WikiTag>CANÓNICO</WikiTag>
        <WikiTag>CONGELADO</WikiTag>
        <WikiTag>TAMV / MDX4 / Atlas</WikiTag>
        <WikiTag>BookPI</WikiTag>
      </div>

      <WikiCard title="Axioma de absorción" accent="orange">
        Un ecosistema no es un conjunto de repositorios. Es una identidad persistente capaz de absorber, interpretar,
        validar, preservar y expandir conocimiento sin perder coherencia. Por eso cada incorporación entra por tribunal
        de guardianías y queda registrada con proveniencia.
      </WikiCard>

      <WikiH2>Cadena de arquitectura</WikiH2>
      <WikiCode>{`CANON
  ↓
Guardianías
  ↓
Motor de Evaluación
  ↓
Motor Ontológico
  ↓
Motor Semántico
  ↓
Motor de Fitness
  ↓
Motor de Promoción
  ↓
Atlas`}</WikiCode>

      <WikiH2>Guardianías activadas</WikiH2>
      <WikiTable
        headers={["Guardianía", "Pregunta", "Resultado computable"]}
        rows={[
          ["Identidad", "¿Pertenece al ecosistema?", "belongs, confidence, node"],
          ["Ontología", "¿Qué es?", "type, domain, subdomain"],
          ["Semántica", "¿Con qué se relaciona?", "relations, orphan, duplicateRisk"],
          ["Riesgo", "¿Qué puede romper?", "riskLevel, warnings"],
          ["Constitución", "¿Viola invariantes?", "APPROVE / REJECT"],
          ["Simulación", "¿Mejora G1 sobre G0?", "fitness_before, fitness_after, fitness_delta"],
          ["Promoción", "¿Qué estado merece?", "DRAFT, REVIEW, APPROVED, CANONICAL"],
        ]}
      />

      <WikiH2>Repos fuente de absorción</WikiH2>
      <WikiTable headers={["Repositorio", "Rol", "Ontología", "Prioridad"]} rows={sourceRows} />

      <WikiH2>API operacional</WikiH2>
      <WikiCard accent="cyan">
        <ul className="space-y-2">
          <li><strong>GET</strong> /v1/civilizational-compiler/constitution</li>
          <li><strong>GET</strong> /v1/civilizational-compiler/fitness</li>
          <li><strong>GET</strong> /v1/civilizational-compiler/graph</li>
          <li><strong>GET</strong> /v1/civilizational-compiler/lineage/:artifact</li>
          <li><strong>POST</strong> /v1/civilizational-compiler/ingest | evaluate | simulate | review | promote | freeze</li>
        </ul>
      </WikiCard>

      <WikiH2>Estado de importación física</WikiH2>
      <WikiP>
        El entorno bloqueó la clonación directa de GitHub con <code>CONNECT tunnel failed, response 403</code>. Aun así,
        el Atlas queda completado con canon congelado, manifiesto de absorción, grafo de destino, API y evaluación
        constitucional. La importación física por subtree puede reintentarse cuando el túnel GitHub esté disponible.
      </WikiP>
    </div>
  );
}
