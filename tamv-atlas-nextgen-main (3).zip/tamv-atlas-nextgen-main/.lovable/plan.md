# Plan de Integración — TAMV ATLAS Producción

Tarea muy extensa. La dividiré en 6 fases, todas implementadas en este ciclo, salvo que la fase 4 (Playwright e2e) se entrega como suite ejecutable pero su ejecución completa queda fuera del runtime de Lovable (se corre en CI).

## Fase 1 — Ingesta canónica del zip + Korimakodex (Atlas)
- Extraer `tamvonline-eco-main.zip` y `kernel_canonico_isabella_villasenor_ai.md` desde uploads (no se copian al repo; se procesan en `/tmp`).
- Nueva edge function `atlas-canon-upload`: parsea MD/MDX/JSON/YAML, calcula hashes SHA-256, deduplica vs `canon_entities`, crea relaciones y versiona en `entity_versions`. Registra `bookpi_events` con `trace_id`.
- Seed inicial: registra el zip como `federation=tamvonline-eco` con sus 6 módulos (M01–M06) como `canon_entities` tipo `module`, más documentos maestros como `entities` tipo `doc`.

## Fase 2 — Núcleo canónico Isabella desde Korimakodex
- Parsear `kernel_canonico_isabella_villasenor_ai.md` (es texto plano, lo leo directo desde uploads).
- Reescribir en DB (`INSERT ... ON CONFLICT`):
  - `isabella_canon` (versión nueva, firmada PQC, `locked=true`).
  - `isabella_identity` (identidad canónica completa).
  - `isabella_pillars` (pilares del Korimakodex, reemplaza seed previo si difiere).
  - `isabella_functions`, `isabella_policies`, `isabella_blueprint` enriquecidos.
- Cada cambio firma con PQC y ancla a `clei_audit`.

## Fase 3 — Ingesta masiva OsoPanda1 (229 repos)
- Nueva edge function `github-org-sync`:
  - Pagina `GET /users/OsoPanda1/repos?per_page=100` (3 páginas).
  - Upsert en `github_repos`, dispara `atlas-ingest-batch` con `parallelism=5`, `max_retries=3`, backoff exponencial ante 403/429/5xx.
  - Respeta `X-RateLimit-Remaining`, usa `If-None-Match` (ETag) para no re-descargar.
- UI: botón "Sincronizar OsoPanda1" en `/atlas` y card con KPIs (repos totales, scaneados, pendientes, errores).

## Fase 4 — PQC real en runtime + pgvector + Playwright
**4a. PQC runtime crítico**
- Refactor `_shared/pqc.ts`: si `@noble/post-quantum` no disponible, usar Ed25519 (`@noble/curves`) y marcar `is_pqc_ready=false`. Anclar todo en `clei_audit`.
- Aplicado obligatoriamente en: `isabella-canon-load`, `isabella-policy-engine` (firma decisión), `utamv-issue-certificate`, `kyc-service` (firma verdict).
- Endpoint `pqc-verify` que cualquier cliente puede usar para validar firma + cadena.

**4b. pgvector + embeddings**
- Migración: `CREATE EXTENSION vector`, columna `embedding vector(1536)` en `isabella_memory`, `canon_entities` (nullable), `wiki_articles` si existe.
- Índices HNSW `vector_cosine_ops`.
- Edge function `embeddings-index`: usa Lovable AI (`google/gemini-embedding-001` truncado a 1536 dims) para re-embedder en background.
- RPC `match_isabella_memory` y `match_canon_entities`.
- UI: buscador semántico en `/atlas` (input + lista de top-10 con score) y memoria semántica integrada en `isabella-chat`.

**4c. Playwright e2e/seguridad**
- Carpeta `tests/e2e/` con `playwright.config.ts`.
- Specs:
  - `isabella-rate-limit.spec.ts` (50 req → 429).
  - `prompt-injection.spec.ts` (payloads conocidos → bloqueo).
  - `clei-chain.spec.ts` (verifica prev_hash secuencial vía Supabase REST).
  - `pii-redact.spec.ts` (CURP/RFC/email/secrets → redacted).
  - `utamv-certificate.spec.ts` (emisión + verificación firma).
- Workflow `.github/workflows/e2e.yml`.

## Fase 5 — Panel de auditoría y cumplimiento
- Nueva ruta `/atlas/audit`:
  - Tabla paginada `clei_audit` + `mdx_audit_log` con filtros (usuario, módulo, fecha, decisión).
  - Métricas: integridad cadena (verificación cliente-side recalculando hash), eventos por hora, top políticas activadas.
  - Export CSV/JSON.
  - Card "Cumplimiento": % runs sin violaciones, latencia p50/p95 de policy-engine.
- Sidebar: enlace en sección Atlas (solo admin).

## Detalles técnicos clave
- Todo via `supabase.functions.invoke()`, ningún path `/api/...`.
- Zod en todas las funciones nuevas. CORS via `npm:@supabase/supabase-js@2/cors`.
- Rate-limit con `_shared/security.ts` existente.
- Migraciones: 3 en total (pgvector + audit_index + canon_extensions).
- `.lovable/memory/index.md` actualizado con nuevo % global (~85% esperado).

## Exclusiones explícitas
- Ejecución real de Playwright (queda para CI).
- Stripe Issuing / CATTLEYA (sigue pendiente por aprobación externa).
- Re-embedding masivo de los 229 repos (sólo entidades nuevas; backfill se programa por cron opcional).

## Aprobación
Confirma y procedo a implementar las 5 fases en bloque (≈18 archivos nuevos, 3 migraciones, 4 ediciones de UI).