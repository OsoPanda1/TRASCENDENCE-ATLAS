# CANON COMPILADOR CIVILIZATORIO v1.0

**Estado:** CANÓNICO  
**Mutabilidad:** CONGELADA  
**Ámbito:** Ecosistemas soberanos de conocimiento (TAMV / MDX4 / Atlas / Isabella / BookPI)  
**Fecha de cristalización:** 2026-06-11

## 0. Naturaleza

Un ecosistema no es un conjunto de repositorios. Es una identidad persistente capaz de absorber, interpretar, validar, preservar y expandir conocimiento sin perder coherencia.

Un Compilador Civilizatorio no es un generador de código. Es un sistema que decide qué conocimiento merece existir como parte permanente del ecosistema.

## I. Principios fundamentales

1. **Identidad:** todo artefacto debe responder primero si pertenece al ecosistema.
2. **Propósito:** toda incorporación debe justificar para qué existe.
3. **Ontología:** todo artefacto debe clasificarse como entidad, proceso, protocolo, política, infraestructura, memoria, gobernanza o territorio.
4. **Semántica:** todo artefacto debe relacionarse con el grafo vivo del ecosistema.
5. **Invariantes:** memoria verificable, trazabilidad, gobernanza auditable, identidad federada, soberanía del conocimiento y proveniencia explícita no pueden violarse.
6. **Generación:** la generación ocurre solo después de la legitimación.
7. **Fitness ecosistémico:** la decisión se toma sobre el delta entre el ecosistema antes y después de incorporar un artefacto.
8. **Promoción:** promover únicamente cuando aumenta coherencia, trazabilidad, reutilización y cobertura; disminuye fragmentación y contradicción; y respeta invariantes constitucionales.
9. **Memoria:** toda aceptación, rechazo, promoción o degradación debe registrarse con historial, proveniencia y evidencia.
10. **Ciencia abierta:** todo conocimiento validado debe poder rastrearse a repositorios, DOI, publicaciones, versiones, autores y evidencia.
11. **Cristalización:** existen estados fluido, experimental, validado, canónico e histórico.
12. **Congelamiento:** el conocimiento estable se congela para preservar continuidad; evoluciona por extensión, no por borrado.
13. **Conservación:** una inteligencia civilizatoria debe conservar memoria, identidad y continuidad, no solo optimizar.

## II. Definición operativa

El Compilador Civilizatorio transforma conocimiento en realidad operativa mediante identidad, legitimación, memoria, gobernanza y preservación. Su función no es producir software; su función es decidir qué conocimiento merece convertirse en parte permanente del ecosistema.

## III. Arquitectura

```text
CANON
  ↓
Guardianías
  ↓
Motor de Evaluación
  ↓
Motor Ontológico
  ↓
Motor Semántico
  ↓
Motor de Fitness
  ↓
Motor de Promoción
  ↓
Atlas
```

- **Canon:** constitución computable.
- **Guardianías:** módulos especializados de evaluación.
- **Motores:** componentes que transforman estado y métricas.
- **Atlas:** grafo vivo del ecosistema y memoria estructurada.

## IV. Guardianías del ecosistema

| Guardianía | Responsabilidad | Salida esperada |
|---|---|---|
| Identidad | Determinar pertenencia al ecosistema. | `belongs`, `confidence`, `node` |
| Ontología | Clasificar tipo, dominio y subdominio. | `type`, `domain`, `subdomain` |
| Semántica | Conectar artefactos al Knowledge Graph y detectar islas. | `relations`, `orphan`, `duplicates` |
| Riesgo | Evaluar dependencias críticas, seguridad, deuda y contradicciones. | `riskLevel`, `warnings` |
| Constitución | Rechazar violaciones de invariantes. | `verdict`, `violations` |
| Simulación | Calcular `Fitness(G1) - Fitness(G0)`. | `delta`, `before`, `after` |
| Promoción | Decidir estado de ciclo de vida. | `state`, `allowedTransitions` |

La Constitución domina el tribunal: una sola violación constitucional produce rechazo, aunque las métricas técnicas mejoren.

## V. Grafo ecosistémico y fitness

Atlas representa el ecosistema como un grafo de nodos `Node`, `Module`, `Repo`, `Doc`, `API`, `Type`, `Policy`, `Evidence` y `Actor`.

Aristas principales:

- `Repo -> Module` (`implements`)
- `Module -> Node` (`deployed_on`)
- `Doc -> Module` (`describes`)
- `Doc -> Evidence` (`cites`)
- `Policy -> Module` (`governs`)
- `Type -> API` (`used_in`)
- `Repo -> Evidence` (`derived_from`)

La función de fitness combina coherencia, trazabilidad, cobertura y reutilización, y penaliza contradicciones, fragmentación y deuda.

```text
Fitness(G) = wc·Coherencia(G) + wt·Trazabilidad(G) + wcov·Cobertura(G)
           + wr·Reutilización(G) - wcontr·Contradicciones(G)
           - wf·Fragmentación(G) - wd·Deuda(G)
```

## VI. API mínima del compilador

| Método | Endpoint | Propósito |
|---|---|---|
| `POST` | `/v1/civilizational-compiler/ingest` | Enviar artefacto y registrar decisión inicial. |
| `POST` | `/v1/civilizational-compiler/evaluate` | Ejecutar guardianías completas. |
| `POST` | `/v1/civilizational-compiler/simulate` | Calcular impacto de fitness sin promover. |
| `POST` | `/v1/civilizational-compiler/review` | Registrar revisión humana o de comité. |
| `POST` | `/v1/civilizational-compiler/promote` | Solicitar promoción con consenso. |
| `POST` | `/v1/civilizational-compiler/freeze` | Congelar artefacto canónico o histórico. |
| `GET` | `/v1/civilizational-compiler/fitness` | Ver fitness actual. |
| `GET` | `/v1/civilizational-compiler/graph` | Consultar Atlas y sus islas. |
| `GET` | `/v1/civilizational-compiler/constitution` | Ver invariantes vigentes. |
| `GET` | `/v1/civilizational-compiler/lineage/{artifact}` | Consultar genealogía y proveniencia. |

## VII. Repositorios fuente de la absorción

| Repo | Rol canónico | Tipo ontológico | Prioridad |
|---|---|---|---|
| `kernel-tamv` | Kernel operativo y constitucional del compilador. | Infrastructure | super importante |
| `tamv-core-atlas` | Núcleo Atlas, memoria estructurada y contratos internos. | Memory | alta |
| `oso-data-weaver` | Normalización, proveniencia y conectores de datos. | Process | alta |
| `ecosistema-nextgen-tamv` | Capa producto/servicios NextGen. | Process | alta |
| `tamv-onmiverso` | Omniverso narrativo, XR y semántico. | Territory | alta |
| `tamvweb-fb822252` | Complemento web y material documental previo. | Infrastructure | complemento |

> Nota operativa: el entorno bloqueó `git clone` hacia GitHub con `CONNECT tunnel failed, response 403`. Por eso esta versión cristaliza el canon, manifiesto, API y grafo de absorción; la importación física por subtree queda lista para reintento cuando el túnel esté disponible.

## VIII. Cierre

El Canon ya existe y queda congelado. Define qué es ecosistema, conocimiento legítimo, memoria, soberanía y fitness civilizatorio. Lo implementado aquí convierte esos principios en decisiones computables, auditables y observables dentro del Atlas.
