# Plan de absorción de repos OsoPanda1 hacia Atlas único

## Objetivo

Absorber, fusionar y completar el Atlas TAMV como un solo proyecto sin perder trazabilidad documental, funcional ni constitucional.

## Reglas de absorción

1. Ningún repo se copia como ruido: cada artefacto debe tener propósito, ontología y proveniencia.
2. `kernel-tamv` tiene prioridad de lectura sobre cualquier definición incompatible de kernel, invariantes o guardián constitucional.
3. Todo repo entra inicialmente en `REVIEW`; nada salta directamente a `CANONICAL`.
4. La decisión final se registra en BookPI/Atlas como memoria verificable.
5. Cualquier violación de soberanía de datos, dignidad por diseño o proveniencia explícita bloquea la promoción.

## Mapa de destino

| Fuente | Destino lógico | Qué se absorbe primero |
|---|---|---|
| `kernel-tamv` | `backend/src/civilizationalCompiler.js`, `data/civilizational-compiler/` | Invariantes, guardianías, ciclo de promoción, fitness. |
| `tamv-core-atlas` | `data/civilizational-compiler/atlas-graph.json`, wiki Atlas | Tipos, nodos, memoria, lineage. |
| `oso-data-weaver` | scripts de ingesta/consolidación | Normalizadores, extractores, conectores y reglas de proveniencia. |
| `ecosistema-nextgen-tamv` | frontend/wiki/backend APIs | Servicios y módulos producto con trazabilidad. |
| `tamv-onmiverso` | módulos XR/territorio/semántica | Relaciones territoriales y narrativas XR. |
| `tamvweb-fb822252` | UI/UX y documentación web | Páginas, componentes y contenido que completen la experiencia. |

## Estado actual del entorno

El comando de clonación fue ejecutado contra los seis repositorios solicitados, pero el túnel HTTP hacia GitHub devolvió `CONNECT tunnel failed, response 403`. La absorción física queda representada como manifiesto verificable y lista para reintento mediante `scripts/unify_osopanda_repos.sh` o `git subtree` cuando la red permita acceso.

## Resultado integrado en esta entrega

- Canon congelado como documento humano y JSON computable.
- Manifiesto de repos fuente con rol, prioridad, tipo ontológico y módulo destino.
- Motor backend para constitución, evaluación, simulación, promoción, fitness, grafo y lineage.
- Página wiki que vuelve visible el Compilador Civilizatorio dentro del Atlas.
