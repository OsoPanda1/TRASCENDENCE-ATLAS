export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      access_requests: {
        Row: {
          created_at: string
          id: string
          reason: string | null
          requested_role: Database["public"]["Enums"]["app_role"]
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          reason?: string | null
          requested_role: Database["public"]["Enums"]["app_role"]
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          reason?: string | null
          requested_role?: Database["public"]["Enums"]["app_role"]
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      akae_jobs: {
        Row: {
          created_at: string
          created_by: string | null
          entities_created: number | null
          error: string | null
          files_done: number | null
          files_total: number | null
          finished_at: string | null
          id: string
          payload: Json | null
          relations_created: number | null
          source_ref: string
          source_type: string
          status: string
          trace_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          entities_created?: number | null
          error?: string | null
          files_done?: number | null
          files_total?: number | null
          finished_at?: string | null
          id?: string
          payload?: Json | null
          relations_created?: number | null
          source_ref: string
          source_type: string
          status?: string
          trace_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          entities_created?: number | null
          error?: string | null
          files_done?: number | null
          files_total?: number | null
          finished_at?: string | null
          id?: string
          payload?: Json | null
          relations_created?: number | null
          source_ref?: string
          source_type?: string
          status?: string
          trace_id?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      article_versions: {
        Row: {
          article_id: string
          created_at: string
          edit_reason: string | null
          edited_by: string | null
          id: string
          new_body: string | null
          previous_body: string | null
        }
        Insert: {
          article_id: string
          created_at?: string
          edit_reason?: string | null
          edited_by?: string | null
          id?: string
          new_body?: string | null
          previous_body?: string | null
        }
        Update: {
          article_id?: string
          created_at?: string
          edit_reason?: string | null
          edited_by?: string | null
          id?: string
          new_body?: string | null
          previous_body?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "article_versions_article_id_fkey"
            columns: ["article_id"]
            isOneToOne: false
            referencedRelation: "wiki_articles"
            referencedColumns: ["id"]
          },
        ]
      }
      assembly_artifacts: {
        Row: {
          content: string
          created_at: string
          entity_canonical_ids: string[]
          format: string
          hash: string
          id: string
          target: string
          trace_id: string
        }
        Insert: {
          content: string
          created_at?: string
          entity_canonical_ids?: string[]
          format?: string
          hash: string
          id?: string
          target: string
          trace_id: string
        }
        Update: {
          content?: string
          created_at?: string
          entity_canonical_ids?: string[]
          format?: string
          hash?: string
          id?: string
          target?: string
          trace_id?: string
        }
        Relationships: []
      }
      atlas_shell_commands: {
        Row: {
          args: Json | null
          command: string
          created_at: string
          duration_ms: number | null
          id: string
          result: Json | null
          status: string
          user_id: string | null
        }
        Insert: {
          args?: Json | null
          command: string
          created_at?: string
          duration_ms?: number | null
          id?: string
          result?: Json | null
          status?: string
          user_id?: string | null
        }
        Update: {
          args?: Json | null
          command?: string
          created_at?: string
          duration_ms?: number | null
          id?: string
          result?: Json | null
          status?: string
          user_id?: string | null
        }
        Relationships: []
      }
      audit_export_runs: {
        Row: {
          content_hash: string
          created_at: string
          export_type: string
          filters: Json
          format: string
          id: string
          requested_by: string | null
          schema_version: string
          signature: string
          signing_key_id: string
          total_events: number
          trace_id: string
        }
        Insert: {
          content_hash: string
          created_at?: string
          export_type: string
          filters?: Json
          format: string
          id?: string
          requested_by?: string | null
          schema_version?: string
          signature: string
          signing_key_id: string
          total_events?: number
          trace_id: string
        }
        Update: {
          content_hash?: string
          created_at?: string
          export_type?: string
          filters?: Json
          format?: string
          id?: string
          requested_by?: string | null
          schema_version?: string
          signature?: string
          signing_key_id?: string
          total_events?: number
          trace_id?: string
        }
        Relationships: []
      }
      audit_metrics: {
        Row: {
          actor: string | null
          actual: number | null
          axis: string | null
          event_type: string | null
          federation_id: string | null
          id: string
          measured_at: string
          objetivo: number | null
          payload: Json | null
          source: string
        }
        Insert: {
          actor?: string | null
          actual?: number | null
          axis?: string | null
          event_type?: string | null
          federation_id?: string | null
          id?: string
          measured_at?: string
          objetivo?: number | null
          payload?: Json | null
          source?: string
        }
        Update: {
          actor?: string | null
          actual?: number | null
          axis?: string | null
          event_type?: string | null
          federation_id?: string | null
          id?: string
          measured_at?: string
          objetivo?: number | null
          payload?: Json | null
          source?: string
        }
        Relationships: []
      }
      bookpi_events: {
        Row: {
          actor_id: string | null
          created_at: string
          entity_canonical_ids: string[]
          event_type: string
          hash: string
          id: string
          payload: Json
          source: string
          trace_id: string
        }
        Insert: {
          actor_id?: string | null
          created_at?: string
          entity_canonical_ids?: string[]
          event_type: string
          hash: string
          id?: string
          payload?: Json
          source: string
          trace_id: string
        }
        Update: {
          actor_id?: string | null
          created_at?: string
          entity_canonical_ids?: string[]
          event_type?: string
          hash?: string
          id?: string
          payload?: Json
          source?: string
          trace_id?: string
        }
        Relationships: []
      }
      canon_entities: {
        Row: {
          canonical: boolean
          canonical_id: string
          created_at: string
          dependencies: string[]
          description: string | null
          domain_v2: string | null
          embedded_at: string | null
          embedding_dirty: boolean
          embedding_indexed_at: string | null
          embedding_model: string | null
          embedding_version: number
          federation: string
          hash: string
          id: string
          metadata: Json
          previous_hash: string | null
          risk_level: string | null
          score_confianza: number | null
          score_integridad: number | null
          source_refs: string[]
          subdomain: string | null
          title: string
          type: string
          updated_at: string
          vector_embedding: string | null
          version: number
        }
        Insert: {
          canonical?: boolean
          canonical_id: string
          created_at?: string
          dependencies?: string[]
          description?: string | null
          domain_v2?: string | null
          embedded_at?: string | null
          embedding_dirty?: boolean
          embedding_indexed_at?: string | null
          embedding_model?: string | null
          embedding_version?: number
          federation?: string
          hash: string
          id?: string
          metadata?: Json
          previous_hash?: string | null
          risk_level?: string | null
          score_confianza?: number | null
          score_integridad?: number | null
          source_refs?: string[]
          subdomain?: string | null
          title: string
          type: string
          updated_at?: string
          vector_embedding?: string | null
          version?: number
        }
        Update: {
          canonical?: boolean
          canonical_id?: string
          created_at?: string
          dependencies?: string[]
          description?: string | null
          domain_v2?: string | null
          embedded_at?: string | null
          embedding_dirty?: boolean
          embedding_indexed_at?: string | null
          embedding_model?: string | null
          embedding_version?: number
          federation?: string
          hash?: string
          id?: string
          metadata?: Json
          previous_hash?: string | null
          risk_level?: string | null
          score_confianza?: number | null
          score_integridad?: number | null
          source_refs?: string[]
          subdomain?: string | null
          title?: string
          type?: string
          updated_at?: string
          vector_embedding?: string | null
          version?: number
        }
        Relationships: []
      }
      canon_relations: {
        Row: {
          created_at: string
          id: string
          metadata: Json
          relation_type: string
          source_canonical_id: string
          target_canonical_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          metadata?: Json
          relation_type: string
          source_canonical_id: string
          target_canonical_id: string
        }
        Update: {
          created_at?: string
          id?: string
          metadata?: Json
          relation_type?: string
          source_canonical_id?: string
          target_canonical_id?: string
        }
        Relationships: []
      }
      clei_audit: {
        Row: {
          actor_id: string | null
          created_at: string
          event_type: string
          hash: string
          id: string
          payload: Json
          prev_hash: string | null
          sequence: number
          signature: string
          signing_key_id: string
        }
        Insert: {
          actor_id?: string | null
          created_at?: string
          event_type: string
          hash: string
          id?: string
          payload?: Json
          prev_hash?: string | null
          sequence?: number
          signature: string
          signing_key_id: string
        }
        Update: {
          actor_id?: string | null
          created_at?: string
          event_type?: string
          hash?: string
          id?: string
          payload?: Json
          prev_hash?: string | null
          sequence?: number
          signature?: string
          signing_key_id?: string
        }
        Relationships: []
      }
      compliance_runs: {
        Row: {
          blocked_runs: number
          clean_runs: number
          created_at: string
          id: string
          latency_p50_ms: number | null
          latency_p95_ms: number | null
          metadata: Json
          module: string
          total_runs: number
          window_end: string
          window_start: string
        }
        Insert: {
          blocked_runs?: number
          clean_runs?: number
          created_at?: string
          id?: string
          latency_p50_ms?: number | null
          latency_p95_ms?: number | null
          metadata?: Json
          module: string
          total_runs?: number
          window_end?: string
          window_start?: string
        }
        Update: {
          blocked_runs?: number
          clean_runs?: number
          created_at?: string
          id?: string
          latency_p50_ms?: number | null
          latency_p95_ms?: number | null
          metadata?: Json
          module?: string
          total_runs?: number
          window_end?: string
          window_start?: string
        }
        Relationships: []
      }
      embedding_reindex_runs: {
        Row: {
          batch_size: number
          error: string | null
          failed: number
          finished_at: string | null
          id: string
          mode: string
          processed: number
          started_at: string
          status: string
          table_name: string
          total_candidates: number
          trace_id: string
        }
        Insert: {
          batch_size?: number
          error?: string | null
          failed?: number
          finished_at?: string | null
          id?: string
          mode?: string
          processed?: number
          started_at?: string
          status?: string
          table_name?: string
          total_candidates?: number
          trace_id: string
        }
        Update: {
          batch_size?: number
          error?: string | null
          failed?: number
          finished_at?: string | null
          id?: string
          mode?: string
          processed?: number
          started_at?: string
          status?: string
          table_name?: string
          total_candidates?: number
          trace_id?: string
        }
        Relationships: []
      }
      entity_versions: {
        Row: {
          canonical_id: string
          changed_at: string
          description: string | null
          hash: string
          id: string
          metadata: Json
          previous_hash: string | null
          title: string | null
          version: number
        }
        Insert: {
          canonical_id: string
          changed_at?: string
          description?: string | null
          hash: string
          id?: string
          metadata?: Json
          previous_hash?: string | null
          title?: string | null
          version: number
        }
        Update: {
          canonical_id?: string
          changed_at?: string
          description?: string | null
          hash?: string
          id?: string
          metadata?: Json
          previous_hash?: string | null
          title?: string | null
          version?: number
        }
        Relationships: []
      }
      federations: {
        Row: {
          color_token: string
          conceptual_pct: number
          description: string
          id: string
          level: number
          name: string
          nodes_declared: number
          production_pct: number
          updated_at: string
          wiring_pct: number
        }
        Insert: {
          color_token: string
          conceptual_pct?: number
          description: string
          id: string
          level: number
          name: string
          nodes_declared?: number
          production_pct?: number
          updated_at?: string
          wiring_pct?: number
        }
        Update: {
          color_token?: string
          conceptual_pct?: number
          description?: string
          id?: string
          level?: number
          name?: string
          nodes_declared?: number
          production_pct?: number
          updated_at?: string
          wiring_pct?: number
        }
        Relationships: []
      }
      github_repos: {
        Row: {
          description: string | null
          federation_id: string | null
          forks: number
          full_name: string
          id: string
          language: string | null
          name: string
          open_issues: number
          owner: string
          pushed_at: string | null
          stars: number
          synced_at: string
        }
        Insert: {
          description?: string | null
          federation_id?: string | null
          forks?: number
          full_name: string
          id?: string
          language?: string | null
          name: string
          open_issues?: number
          owner: string
          pushed_at?: string | null
          stars?: number
          synced_at?: string
        }
        Update: {
          description?: string | null
          federation_id?: string | null
          forks?: number
          full_name?: string
          id?: string
          language?: string | null
          name?: string
          open_issues?: number
          owner?: string
          pushed_at?: string | null
          stars?: number
          synced_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "github_repos_federation_id_fkey"
            columns: ["federation_id"]
            isOneToOne: false
            referencedRelation: "federations"
            referencedColumns: ["id"]
          },
        ]
      }
      identity_profiles: {
        Row: {
          created_at: string
          did: string | null
          display_name: string
          doi_prefix: string | null
          github_handle: string | null
          id: string
          isni: string | null
          jsonld: Json | null
          orcid: string | null
          trust_score: number
          type: string
          updated_at: string
          zenodo_record: string | null
        }
        Insert: {
          created_at?: string
          did?: string | null
          display_name: string
          doi_prefix?: string | null
          github_handle?: string | null
          id?: string
          isni?: string | null
          jsonld?: Json | null
          orcid?: string | null
          trust_score?: number
          type: string
          updated_at?: string
          zenodo_record?: string | null
        }
        Update: {
          created_at?: string
          did?: string | null
          display_name?: string
          doi_prefix?: string | null
          github_handle?: string | null
          id?: string
          isni?: string | null
          jsonld?: Json | null
          orcid?: string | null
          trust_score?: number
          type?: string
          updated_at?: string
          zenodo_record?: string | null
        }
        Relationships: []
      }
      ingestion_runs: {
        Row: {
          batch_id: string | null
          entities_created: number
          error: string | null
          federation: string | null
          files_scanned: number
          finished_at: string | null
          id: string
          last_error_at: string | null
          relations_created: number
          repo_url: string
          retries: number
          skipped: number
          started_at: string
          started_by: string | null
          status: string
          trace_id: string
        }
        Insert: {
          batch_id?: string | null
          entities_created?: number
          error?: string | null
          federation?: string | null
          files_scanned?: number
          finished_at?: string | null
          id?: string
          last_error_at?: string | null
          relations_created?: number
          repo_url: string
          retries?: number
          skipped?: number
          started_at?: string
          started_by?: string | null
          status?: string
          trace_id: string
        }
        Update: {
          batch_id?: string | null
          entities_created?: number
          error?: string | null
          federation?: string | null
          files_scanned?: number
          finished_at?: string | null
          id?: string
          last_error_at?: string | null
          relations_created?: number
          repo_url?: string
          retries?: number
          skipped?: number
          started_at?: string
          started_by?: string | null
          status?: string
          trace_id?: string
        }
        Relationships: []
      }
      isabella_agent_registry: {
        Row: {
          capabilities: Json
          code: string
          created_at: string
          description: string
          enabled: boolean
          id: string
          name: string
          ordering: number
          role: string
          trigger_keywords: Json
        }
        Insert: {
          capabilities?: Json
          code: string
          created_at?: string
          description: string
          enabled?: boolean
          id?: string
          name: string
          ordering?: number
          role: string
          trigger_keywords?: Json
        }
        Update: {
          capabilities?: Json
          code?: string
          created_at?: string
          description?: string
          enabled?: boolean
          id?: string
          name?: string
          ordering?: number
          role?: string
          trigger_keywords?: Json
        }
        Relationships: []
      }
      isabella_blueprint: {
        Row: {
          auth_required: boolean
          created_at: string
          description: string
          endpoint: string
          id: string
          method: string
          request_schema: Json
          response_schema: Json
          version: string
        }
        Insert: {
          auth_required?: boolean
          created_at?: string
          description: string
          endpoint: string
          id?: string
          method?: string
          request_schema?: Json
          response_schema?: Json
          version?: string
        }
        Update: {
          auth_required?: boolean
          created_at?: string
          description?: string
          endpoint?: string
          id?: string
          method?: string
          request_schema?: Json
          response_schema?: Json
          version?: string
        }
        Relationships: []
      }
      isabella_canon: {
        Row: {
          content_md: string
          created_at: string
          hash: string
          id: string
          locked: boolean
          signature: string | null
          signing_key_id: string | null
          title: string
          updated_at: string
          version: string
        }
        Insert: {
          content_md: string
          created_at?: string
          hash: string
          id?: string
          locked?: boolean
          signature?: string | null
          signing_key_id?: string | null
          title: string
          updated_at?: string
          version: string
        }
        Update: {
          content_md?: string
          created_at?: string
          hash?: string
          id?: string
          locked?: boolean
          signature?: string | null
          signing_key_id?: string | null
          title?: string
          updated_at?: string
          version?: string
        }
        Relationships: []
      }
      isabella_emotions: {
        Row: {
          arousal: number
          context: string | null
          created_at: string
          dominance: number
          id: string
          session_id: string | null
          source: string
          user_id: string
          valence: number
        }
        Insert: {
          arousal?: number
          context?: string | null
          created_at?: string
          dominance?: number
          id?: string
          session_id?: string | null
          source?: string
          user_id: string
          valence?: number
        }
        Update: {
          arousal?: number
          context?: string | null
          created_at?: string
          dominance?: number
          id?: string
          session_id?: string | null
          source?: string
          user_id?: string
          valence?: number
        }
        Relationships: [
          {
            foreignKeyName: "isabella_emotions_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "isabella_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      isabella_ethical_decisions: {
        Row: {
          created_at: string
          decision: string
          id: string
          payload_hash: string
          reason: string
          session_id: string | null
          triggered_module: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          decision: string
          id?: string
          payload_hash: string
          reason: string
          session_id?: string | null
          triggered_module?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          decision?: string
          id?: string
          payload_hash?: string
          reason?: string
          session_id?: string | null
          triggered_module?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "isabella_ethical_decisions_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "isabella_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      isabella_functions: {
        Row: {
          category: string
          code: string
          created_at: string
          description: string
          enabled: boolean
          id: string
          inputs: Json
          name: string
          outputs: Json
        }
        Insert: {
          category: string
          code: string
          created_at?: string
          description: string
          enabled?: boolean
          id?: string
          inputs?: Json
          name: string
          outputs?: Json
        }
        Update: {
          category?: string
          code?: string
          created_at?: string
          description?: string
          enabled?: boolean
          id?: string
          inputs?: Json
          name?: string
          outputs?: Json
        }
        Relationships: []
      }
      isabella_identity: {
        Row: {
          alias: string | null
          canonical_name: string
          created_at: string
          domain: string
          guiding_principle: string
          hash: string
          id: string
          metadata: Json
          nature: string
          role: string
          short_definition: string
          signature: string | null
          technical_definition: string
          updated_at: string
        }
        Insert: {
          alias?: string | null
          canonical_name: string
          created_at?: string
          domain: string
          guiding_principle: string
          hash: string
          id?: string
          metadata?: Json
          nature: string
          role: string
          short_definition: string
          signature?: string | null
          technical_definition: string
          updated_at?: string
        }
        Update: {
          alias?: string | null
          canonical_name?: string
          created_at?: string
          domain?: string
          guiding_principle?: string
          hash?: string
          id?: string
          metadata?: Json
          nature?: string
          role?: string
          short_definition?: string
          signature?: string | null
          technical_definition?: string
          updated_at?: string
        }
        Relationships: []
      }
      isabella_memory: {
        Row: {
          content: string
          created_at: string
          embedding: Json | null
          embedding_model: string | null
          expires_at: string | null
          hash: string
          id: string
          importance: number
          key: string
          scope: string
          user_id: string
          vector_embedding: string | null
        }
        Insert: {
          content: string
          created_at?: string
          embedding?: Json | null
          embedding_model?: string | null
          expires_at?: string | null
          hash: string
          id?: string
          importance?: number
          key: string
          scope?: string
          user_id: string
          vector_embedding?: string | null
        }
        Update: {
          content?: string
          created_at?: string
          embedding?: Json | null
          embedding_model?: string | null
          expires_at?: string | null
          hash?: string
          id?: string
          importance?: number
          key?: string
          scope?: string
          user_id?: string
          vector_embedding?: string | null
        }
        Relationships: []
      }
      isabella_messages: {
        Row: {
          content: string
          created_at: string
          ethical_flag: string | null
          id: string
          latency_ms: number | null
          metadata: Json
          module_invoked: string | null
          role: string
          session_id: string
          tokens_in: number | null
          tokens_out: number | null
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          ethical_flag?: string | null
          id?: string
          latency_ms?: number | null
          metadata?: Json
          module_invoked?: string | null
          role: string
          session_id: string
          tokens_in?: number | null
          tokens_out?: number | null
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          ethical_flag?: string | null
          id?: string
          latency_ms?: number | null
          metadata?: Json
          module_invoked?: string | null
          role?: string
          session_id?: string
          tokens_in?: number | null
          tokens_out?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "isabella_messages_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "isabella_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      isabella_module_runs: {
        Row: {
          created_at: string
          decision: string
          hash: string
          id: string
          input: Json
          latency_ms: number | null
          module_code: string
          output: Json
          reason: string | null
          session_id: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          decision?: string
          hash: string
          id?: string
          input?: Json
          latency_ms?: number | null
          module_code: string
          output?: Json
          reason?: string | null
          session_id?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          decision?: string
          hash?: string
          id?: string
          input?: Json
          latency_ms?: number | null
          module_code?: string
          output?: Json
          reason?: string | null
          session_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "isabella_module_runs_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "isabella_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      isabella_pillars: {
        Row: {
          code: string
          created_at: string
          description: string
          enforcement_level: string
          id: string
          name: string
          ordering: number
        }
        Insert: {
          code: string
          created_at?: string
          description: string
          enforcement_level?: string
          id?: string
          name: string
          ordering?: number
        }
        Update: {
          code?: string
          created_at?: string
          description?: string
          enforcement_level?: string
          id?: string
          name?: string
          ordering?: number
        }
        Relationships: []
      }
      isabella_policies: {
        Row: {
          category: string
          code: string
          created_at: string
          decision: string
          description: string
          enabled: boolean
          hash: string
          id: string
          name: string
          pattern: string | null
          priority: number
          signature: string | null
          updated_at: string
        }
        Insert: {
          category?: string
          code: string
          created_at?: string
          decision?: string
          description: string
          enabled?: boolean
          hash: string
          id?: string
          name: string
          pattern?: string | null
          priority?: number
          signature?: string | null
          updated_at?: string
        }
        Update: {
          category?: string
          code?: string
          created_at?: string
          decision?: string
          description?: string
          enabled?: boolean
          hash?: string
          id?: string
          name?: string
          pattern?: string | null
          priority?: number
          signature?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      isabella_sessions: {
        Row: {
          closed_at: string | null
          created_at: string
          id: string
          metadata: Json
          opened_at: string
          persona_mode: string
          status: string
          thread_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          closed_at?: string | null
          created_at?: string
          id?: string
          metadata?: Json
          opened_at?: string
          persona_mode?: string
          status?: string
          thread_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          closed_at?: string | null
          created_at?: string
          id?: string
          metadata?: Json
          opened_at?: string
          persona_mode?: string
          status?: string
          thread_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      isni_credentials: {
        Row: {
          created_at: string
          expires_at: string | null
          holder_entity_id: string
          id: string
          issued_at: string
          issuer_did: string
          payload: Json
          signature: string
          status: string
          vc_id: string
          vc_type: string
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          holder_entity_id: string
          id?: string
          issued_at?: string
          issuer_did: string
          payload: Json
          signature: string
          status?: string
          vc_id: string
          vc_type: string
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          holder_entity_id?: string
          id?: string
          issued_at?: string
          issuer_did?: string
          payload?: Json
          signature?: string
          status?: string
          vc_id?: string
          vc_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "isni_credentials_holder_entity_id_fkey"
            columns: ["holder_entity_id"]
            isOneToOne: false
            referencedRelation: "isni_entities"
            referencedColumns: ["id"]
          },
        ]
      }
      isni_entities: {
        Row: {
          created_at: string
          display_name: string
          entity_type: string
          id: string
          identifiers: Json
          is_public: boolean
          isni: string
          metadata: Json
          owner_id: string | null
          trust_score: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_name: string
          entity_type: string
          id?: string
          identifiers?: Json
          is_public?: boolean
          isni: string
          metadata?: Json
          owner_id?: string | null
          trust_score?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_name?: string
          entity_type?: string
          id?: string
          identifiers?: Json
          is_public?: boolean
          isni?: string
          metadata?: Json
          owner_id?: string | null
          trust_score?: number
          updated_at?: string
        }
        Relationships: []
      }
      kyc_records: {
        Row: {
          created_at: string
          document_hash: string
          document_type: string
          expires_at: string | null
          id: string
          jurisdiction: string
          metadata: Json
          rejection_reason: string | null
          status: string
          updated_at: string
          user_id: string
          verified_at: string | null
          verifier: string | null
        }
        Insert: {
          created_at?: string
          document_hash: string
          document_type: string
          expires_at?: string | null
          id?: string
          jurisdiction?: string
          metadata?: Json
          rejection_reason?: string | null
          status?: string
          updated_at?: string
          user_id: string
          verified_at?: string | null
          verifier?: string | null
        }
        Update: {
          created_at?: string
          document_hash?: string
          document_type?: string
          expires_at?: string | null
          id?: string
          jurisdiction?: string
          metadata?: Json
          rejection_reason?: string | null
          status?: string
          updated_at?: string
          user_id?: string
          verified_at?: string | null
          verifier?: string | null
        }
        Relationships: []
      }
      kyc_verifications: {
        Row: {
          created_at: string
          id: string
          kyc_id: string
          notes: string | null
          payload_hash: string
          provider: string
          result: string
          reviewer: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          kyc_id: string
          notes?: string | null
          payload_hash: string
          provider?: string
          result: string
          reviewer?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          kyc_id?: string
          notes?: string | null
          payload_hash?: string
          provider?: string
          result?: string
          reviewer?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "kyc_verifications_kyc_id_fkey"
            columns: ["kyc_id"]
            isOneToOne: false
            referencedRelation: "kyc_records"
            referencedColumns: ["id"]
          },
        ]
      }
      mdx_audit_log: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          domain: string
          hash: string
          id: string
          payload: Json
          result: Json
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          domain: string
          hash: string
          id?: string
          payload?: Json
          result?: Json
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          domain?: string
          hash?: string
          id?: string
          payload?: Json
          result?: Json
        }
        Relationships: []
      }
      mdx_modules: {
        Row: {
          created_at: string
          description: string | null
          federation: string
          id: string
          last_heartbeat: string
          metrics: Json
          module_code: string
          name: string
          status: string
          updated_at: string
          version: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          federation: string
          id?: string
          last_heartbeat?: string
          metrics?: Json
          module_code: string
          name: string
          status?: string
          updated_at?: string
          version?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          federation?: string
          id?: string
          last_heartbeat?: string
          metrics?: Json
          module_code?: string
          name?: string
          status?: string
          updated_at?: string
          version?: string
        }
        Relationships: []
      }
      org_sync_runs: {
        Row: {
          error: string | null
          failed_repos: number
          finished_at: string | null
          id: string
          new_repos: number
          owner: string
          rate_limit_remaining: number | null
          started_at: string
          started_by: string | null
          status: string
          total_repos: number
          trace_id: string
          updated_repos: number
        }
        Insert: {
          error?: string | null
          failed_repos?: number
          finished_at?: string | null
          id?: string
          new_repos?: number
          owner: string
          rate_limit_remaining?: number | null
          started_at?: string
          started_by?: string | null
          status?: string
          total_repos?: number
          trace_id: string
          updated_repos?: number
        }
        Update: {
          error?: string | null
          failed_repos?: number
          finished_at?: string | null
          id?: string
          new_repos?: number
          owner?: string
          rate_limit_remaining?: number | null
          started_at?: string
          started_by?: string | null
          status?: string
          total_repos?: number
          trace_id?: string
          updated_repos?: number
        }
        Relationships: []
      }
      pqc_keys: {
        Row: {
          algorithm: string
          created_at: string
          entity_id: string | null
          id: string
          is_pqc_ready: boolean
          key_id: string
          owner_id: string | null
          public_key_b64: string
          rotated_at: string | null
          status: string
        }
        Insert: {
          algorithm?: string
          created_at?: string
          entity_id?: string | null
          id?: string
          is_pqc_ready?: boolean
          key_id: string
          owner_id?: string | null
          public_key_b64: string
          rotated_at?: string | null
          status?: string
        }
        Update: {
          algorithm?: string
          created_at?: string
          entity_id?: string | null
          id?: string
          is_pqc_ready?: boolean
          key_id?: string
          owner_id?: string | null
          public_key_b64?: string
          rotated_at?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "pqc_keys_entity_id_fkey"
            columns: ["entity_id"]
            isOneToOne: false
            referencedRelation: "isni_entities"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          did_tamv: string | null
          display_name: string | null
          id: string
          locale: string
          orcid: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          did_tamv?: string | null
          display_name?: string | null
          id: string
          locale?: string
          orcid?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          did_tamv?: string | null
          display_name?: string | null
          id?: string
          locale?: string
          orcid?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      rate_limits: {
        Row: {
          bucket: string
          count: number
          id: string
          user_id: string | null
          window_start: string
        }
        Insert: {
          bucket: string
          count?: number
          id?: string
          user_id?: string | null
          window_start?: string
        }
        Update: {
          bucket?: string
          count?: number
          id?: string
          user_id?: string | null
          window_start?: string
        }
        Relationships: []
      }
      roadmap_phases: {
        Row: {
          actual: number
          eta: string | null
          fase: string
          id: string
          index_order: number
          milestone: string
          target: number
        }
        Insert: {
          actual?: number
          eta?: string | null
          fase: string
          id?: string
          index_order?: number
          milestone: string
          target?: number
        }
        Update: {
          actual?: number
          eta?: string | null
          fase?: string
          id?: string
          index_order?: number
          milestone?: string
          target?: number
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          granted_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          granted_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          granted_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      utamv_assessments: {
        Row: {
          course_id: string
          created_at: string
          id: string
          kind: string
          passing_score: number
          payload: Json
          title: string
        }
        Insert: {
          course_id: string
          created_at?: string
          id?: string
          kind?: string
          passing_score?: number
          payload?: Json
          title: string
        }
        Update: {
          course_id?: string
          created_at?: string
          id?: string
          kind?: string
          passing_score?: number
          payload?: Json
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "utamv_assessments_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "utamv_courses"
            referencedColumns: ["id"]
          },
        ]
      }
      utamv_campus_zones: {
        Row: {
          code: string
          description: string | null
          id: string
          metadata: Json
          name: string
          ordering: number
          scene_url: string | null
          zone_type: string
        }
        Insert: {
          code: string
          description?: string | null
          id?: string
          metadata?: Json
          name: string
          ordering?: number
          scene_url?: string | null
          zone_type?: string
        }
        Update: {
          code?: string
          description?: string | null
          id?: string
          metadata?: Json
          name?: string
          ordering?: number
          scene_url?: string | null
          zone_type?: string
        }
        Relationships: []
      }
      utamv_certificates: {
        Row: {
          certificate_code: string
          course_id: string
          hash: string
          id: string
          issued_at: string
          payload: Json
          signature: string | null
          signing_key_id: string | null
          user_id: string
        }
        Insert: {
          certificate_code: string
          course_id: string
          hash: string
          id?: string
          issued_at?: string
          payload?: Json
          signature?: string | null
          signing_key_id?: string | null
          user_id: string
        }
        Update: {
          certificate_code?: string
          course_id?: string
          hash?: string
          id?: string
          issued_at?: string
          payload?: Json
          signature?: string | null
          signing_key_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      utamv_courses: {
        Row: {
          code: string
          created_at: string
          credits: number
          faculty: string | null
          id: string
          is_published: boolean
          learning_outcomes: string[]
          level: string
          prerequisites: string[]
          summary: string | null
          syllabus: Json
          title: string
          track: string | null
          updated_at: string
          xr_assets: Json
        }
        Insert: {
          code: string
          created_at?: string
          credits?: number
          faculty?: string | null
          id?: string
          is_published?: boolean
          learning_outcomes?: string[]
          level?: string
          prerequisites?: string[]
          summary?: string | null
          syllabus?: Json
          title: string
          track?: string | null
          updated_at?: string
          xr_assets?: Json
        }
        Update: {
          code?: string
          created_at?: string
          credits?: number
          faculty?: string | null
          id?: string
          is_published?: boolean
          learning_outcomes?: string[]
          level?: string
          prerequisites?: string[]
          summary?: string | null
          syllabus?: Json
          title?: string
          track?: string | null
          updated_at?: string
          xr_assets?: Json
        }
        Relationships: []
      }
      utamv_enrollments: {
        Row: {
          completed_at: string | null
          course_id: string
          created_at: string
          id: string
          progress: number
          updated_at: string
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          course_id: string
          created_at?: string
          id?: string
          progress?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          completed_at?: string | null
          course_id?: string
          created_at?: string
          id?: string
          progress?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "utamv_enrollments_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "utamv_courses"
            referencedColumns: ["id"]
          },
        ]
      }
      utamv_faculties: {
        Row: {
          code: string
          color_token: string | null
          created_at: string
          description: string | null
          id: string
          name: string
          ordering: number
        }
        Insert: {
          code: string
          color_token?: string | null
          created_at?: string
          description?: string | null
          id?: string
          name: string
          ordering?: number
        }
        Update: {
          code?: string
          color_token?: string | null
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          ordering?: number
        }
        Relationships: []
      }
      utamv_lessons: {
        Row: {
          content_md: string
          course_id: string
          created_at: string
          duration_minutes: number
          id: string
          is_published: boolean
          ordering: number
          resources: Json
          title: string
        }
        Insert: {
          content_md?: string
          course_id: string
          created_at?: string
          duration_minutes?: number
          id?: string
          is_published?: boolean
          ordering?: number
          resources?: Json
          title: string
        }
        Update: {
          content_md?: string
          course_id?: string
          created_at?: string
          duration_minutes?: number
          id?: string
          is_published?: boolean
          ordering?: number
          resources?: Json
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "utamv_lessons_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "utamv_courses"
            referencedColumns: ["id"]
          },
        ]
      }
      utamv_tracks: {
        Row: {
          code: string
          course_codes: string[]
          created_at: string
          description: string | null
          duration_weeks: number
          faculty_code: string
          id: string
          name: string
        }
        Insert: {
          code: string
          course_codes?: string[]
          created_at?: string
          description?: string | null
          duration_weeks?: number
          faculty_code: string
          id?: string
          name: string
        }
        Update: {
          code?: string
          course_codes?: string[]
          created_at?: string
          description?: string | null
          duration_weeks?: number
          faculty_code?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      wiki_articles: {
        Row: {
          access_level: Database["public"]["Enums"]["app_role"]
          content_md: string
          created_at: string
          depth: Database["public"]["Enums"]["article_depth"]
          id: string
          is_critical: boolean
          module_id: string
          read_minutes: number
          search_tsv: unknown
          slug: string
          source_doc: string | null
          status: Database["public"]["Enums"]["article_status"]
          summary: string
          tags: string[]
          title: string
          updated_at: string
          view_count: number
        }
        Insert: {
          access_level?: Database["public"]["Enums"]["app_role"]
          content_md?: string
          created_at?: string
          depth?: Database["public"]["Enums"]["article_depth"]
          id?: string
          is_critical?: boolean
          module_id: string
          read_minutes?: number
          search_tsv?: unknown
          slug: string
          source_doc?: string | null
          status?: Database["public"]["Enums"]["article_status"]
          summary?: string
          tags?: string[]
          title: string
          updated_at?: string
          view_count?: number
        }
        Update: {
          access_level?: Database["public"]["Enums"]["app_role"]
          content_md?: string
          created_at?: string
          depth?: Database["public"]["Enums"]["article_depth"]
          id?: string
          is_critical?: boolean
          module_id?: string
          read_minutes?: number
          search_tsv?: unknown
          slug?: string
          source_doc?: string | null
          status?: Database["public"]["Enums"]["article_status"]
          summary?: string
          tags?: string[]
          title?: string
          updated_at?: string
          view_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "wiki_articles_module_id_fkey"
            columns: ["module_id"]
            isOneToOne: false
            referencedRelation: "wiki_modules"
            referencedColumns: ["id"]
          },
        ]
      }
      wiki_modules: {
        Row: {
          created_at: string
          description: string | null
          federation_id: string | null
          id: string
          index_order: number
          level: number
          slug: string
          title: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          federation_id?: string | null
          id: string
          index_order?: number
          level: number
          slug: string
          title: string
        }
        Update: {
          created_at?: string
          description?: string | null
          federation_id?: string | null
          id?: string
          index_order?: number
          level?: number
          slug?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "wiki_modules_federation_id_fkey"
            columns: ["federation_id"]
            isOneToOne: false
            referencedRelation: "federations"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_min_role: {
        Args: {
          _min: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      match_canon_entities: {
        Args: {
          filter_federation?: string
          match_count?: number
          min_similarity?: number
          query_embedding: string
        }
        Returns: {
          canonical_id: string
          description: string
          federation: string
          similarity: number
          title: string
          type: string
        }[]
      }
      match_isabella_memory: {
        Args: {
          match_count?: number
          match_user_id: string
          min_similarity?: number
          query_embedding: string
        }
        Returns: {
          content: string
          id: string
          importance: number
          key: string
          scope: string
          similarity: number
        }[]
      }
      show_limit: { Args: never; Returns: number }
      show_trgm: { Args: { "": string }; Returns: string[] }
    }
    Enums: {
      app_role:
        | "ciudadano"
        | "dev"
        | "empresario"
        | "academia"
        | "gobierno"
        | "admin"
      article_depth:
        | "intro"
        | "tecnico"
        | "constitucional"
        | "filosofico"
        | "juridico"
        | "operativo"
      article_status: "draft" | "review" | "published" | "archived"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "ciudadano",
        "dev",
        "empresario",
        "academia",
        "gobierno",
        "admin",
      ],
      article_depth: [
        "intro",
        "tecnico",
        "constitucional",
        "filosofico",
        "juridico",
        "operativo",
      ],
      article_status: ["draft", "review", "published", "archived"],
    },
  },
} as const
