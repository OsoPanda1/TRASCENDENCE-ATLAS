import crypto from "crypto";
import type {
  BookPiEntry,
  DreamSpace,
  GuardianSignal,
  LedgerEntry,
  MembershipTier,
  MsrEvent,
  ProtocolDecisionPath,
  ProtocolExecution,
  UserProfile,
} from "./types";

type IsoTime = string;
type EntityId = string;
type Hash = string;

/**
 * CANONICAL IDENTITY
 * cid: prefijo soberano + tipo
 */
type CanonicalId = string;

type KernelCommand =
  | CreateUserCommand
  | AssignMembershipCommand
  | ExecuteProtocolCommand
  | CreateDreamSpaceCommand
  | PostLedgerCommand;

type KernelEvent =
  | UserCreatedEvent
  | MembershipAssignedEvent
  | ProtocolCollapsedEvent
  | GuardianTriggeredEvent
  | DreamSpaceCreatedEvent
  | LedgerPostedEvent
  | NarrativeWrittenEvent;

interface KernelMetadata {
  eventId: EntityId;
  timestamp: IsoTime;
  version: number;
  checksum: Hash;
  actorId: string;
  // canal/federación para trazabilidad
  channel?: string;
  federation?: string;
}

/**
 * Envelope canónico de evento
 */
interface EventEnvelope<T extends KernelEvent> {
  meta: KernelMetadata;
  data: T;
}

/**
 * Epistemic footprint muy básico para el Kernel (MVP):
 * se podría ir alimentando con AKAE-TRUST más adelante.
 */
interface EpistemicFootprint {
  certaintyScore: number; // 0..1
  evidenceCount: number;
}

/**
 * Commands
 */
interface CreateUserCommand {
  type: "CreateUser";
  handle: string;
  displayName: string;
}

interface AssignMembershipCommand {
  type: "AssignMembership";
  userId: CanonicalId;
  tier: MembershipTier;
}

interface ExecuteProtocolCommand {
  type: "ExecuteProtocol";
  protocolId: CanonicalId;
  actorId: CanonicalId;
  paths: ProtocolDecisionPath[];
}

interface CreateDreamSpaceCommand {
  type: "CreateDreamSpace";
  ownerId: CanonicalId;
  name: string;
  isPublic: boolean;
}

interface PostLedgerCommand {
  type: "PostLedger";
  userId: CanonicalId;
  amount: number;
  reason: string;
}

/**
 * Events
 */
interface UserCreatedEvent {
  type: "UserCreated";
  user: UserProfile & {
    cid: CanonicalId;
  };
}

interface MembershipAssignedEvent {
  type: "MembershipAssigned";
  userId: CanonicalId;
  tier: MembershipTier;
}

interface ProtocolCollapsedEvent {
  type: "ProtocolCollapsed";
  execution: ProtocolExecution;
  epistemic: EpistemicFootprint;
}

interface GuardianTriggeredEvent {
  type: "GuardianTriggered";
  signal: GuardianSignal;
}

interface DreamSpaceCreatedEvent {
  type: "DreamSpaceCreated";
  dreamSpace: DreamSpace & {
    cid: CanonicalId;
  };
}

interface LedgerPostedEvent {
  type: "LedgerPosted";
  entry: LedgerEntry & {
    cid: CanonicalId;
  };
}

interface NarrativeWrittenEvent {
  type: "NarrativeWritten";
  entry: BookPiEntry & {
    cid: CanonicalId;
  };
}

/**
 * Kernel State
 */
interface KernelState {
  users: Record<CanonicalId, UserProfile & { cid: CanonicalId }>;
  dreamSpaces: Record<CanonicalId, DreamSpace & { cid: CanonicalId }>;
  ledger: (LedgerEntry & { cid: CanonicalId })[];
  guardianSignals: GuardianSignal[];
  narratives: (BookPiEntry & { cid: CanonicalId })[];
  protocolExecutions: ProtocolExecution[];
}

const initialState = (): KernelState => ({
  users: {},
  dreamSpaces: {},
  ledger: [],
  guardianSignals: [],
  narratives: [],
  protocolExecutions: [],
});

const nowIso = (): IsoTime => new Date().toISOString();

/**
 * Generador de IDs soberanos tipo atlas:kernel:user:0000...
 */
const cid = (namespace: string): CanonicalId =>
  `atlas:kernel:${namespace}:${crypto.randomUUID().replace(/-/g, "")}`;

/**
 * Hash fuerte del evento (contenido)
 */
const checksum = (obj: unknown): Hash =>
  crypto.createHash("sha512").update(JSON.stringify(obj)).digest("hex");

/**
 * Event Store simple en memoria
 * (después puedes perfilar a nivel AKAE-OBSERVABILITY)
 */
class EventStore {
  private readonly stream: EventEnvelope<KernelEvent>[] = [];

  append<T extends KernelEvent>(
    event: T,
    actorId: string,
    opts: { channel?: string; federation?: string } = {},
  ): EventEnvelope<T> {
    const envelope: EventEnvelope<T> = {
      meta: {
        eventId: cid("evt"),
        timestamp: nowIso(),
        version: this.stream.length + 1,
        checksum: checksum(event),
        actorId,
        channel: opts.channel,
        federation: opts.federation,
      },
      data: event,
    };
    this.stream.push(envelope);
    return envelope;
  }

  all(): EventEnvelope<KernelEvent>[] {
    return [...this.stream];
  }

  reset(events: EventEnvelope<KernelEvent>[] = []): void {
    this.stream.length = 0;
    this.stream.push(...events);
  }

  verifyIntegrity(): boolean {
    return this.stream.every((event) => checksum(event.data) === event.meta.checksum);
  }
}

/**
 * Pure reducer del estado del Kernel
 */
function reduce(state: KernelState, event: KernelEvent): KernelState {
  switch (event.type) {
    case "UserCreated":
      return {
        ...state,
        users: { ...state.users, [event.user.cid]: event.user },
      };

    case "MembershipAssigned": {
      const user = state.users[event.userId];
      if (!user) return state;
      if (user.memberships.includes(event.tier)) return state;
      return {
        ...state,
        users: {
          ...state.users,
          [event.userId]: { ...user, memberships: [...user.memberships, event.tier] },
        },
      };
    }

    case "DreamSpaceCreated":
      return {
        ...state,
        dreamSpaces: { ...state.dreamSpaces, [event.dreamSpace.cid]: event.dreamSpace },
      };

    case "LedgerPosted":
      return { ...state, ledger: [...state.ledger, event.entry] };

    case "GuardianTriggered":
      return { ...state, guardianSignals: [...state.guardianSignals, event.signal] };

    case "NarrativeWritten":
      return { ...state, narratives: [...state.narratives, event.entry] };

    case "ProtocolCollapsed":
      return {
        ...state,
        protocolExecutions: [...state.protocolExecutions, event.execution],
      };

    default:
      return state;
  }
}

/**
 * Protocolo de colapso con un poco más de claridad.
 * Nota: la heurística de ranking sigue siendo simple, pero aislada.
 */
class ProtocolVM {
  static collapse(protocolId: CanonicalId, paths: ProtocolDecisionPath[]): ProtocolExecution {
    if (!paths.length) throw new Error("No protocol paths");

    // Score compuesto sencillo: valor - penalización ética
    const scoreOf = (p: ProtocolDecisionPath) => p.score - p.ethicalRisk * 2;

    const ranked = [...paths].sort((a, b) => scoreOf(b) - scoreOf(a));

    return {
      protocolId,
      phase: "active",
      selectedPath: ranked[0],
      evaluatedPaths: ranked,
      collapsedAt: nowIso(),
    };
  }

  /**
   * Epistemic footprint mínimo: cuántos caminos se evaluaron
   * y cuánta "claridad" hubo en la elección.
   */
  static epistemicFootprint(paths: ProtocolDecisionPath[]): EpistemicFootprint {
    if (!paths.length) {
      return { certaintyScore: 0, evidenceCount: 0 };
    }
    const sorted = [...paths].sort((a, b) => b.score - a.score);
    const top = sorted[0];
    const second = sorted[1];
    const delta = second ? Math.abs(top.score - second.score) : top.score;
    const certaintyScore = Math.max(0, Math.min(1, delta)); // normaliza un poco

    return {
      certaintyScore,
      evidenceCount: paths.length,
    };
  }
}

/**
 * AtlasKernel — VM de dominio básico alineada con GENESIS
 */
export class AtlasKernel {
  private readonly store = new EventStore();
  private state: KernelState = initialState();

  // API de dominio

  createUser(handle: string, displayName: string): UserProfile & { cid: CanonicalId } {
    const [event] = this.dispatch({ type: "CreateUser", handle, displayName }, "system");
    return (event as UserCreatedEvent).user;
  }

  assignMembership(userId: CanonicalId, tier: MembershipTier): UserProfile & { cid: CanonicalId } {
    this.requireUser(userId);
    this.dispatch({ type: "AssignMembership", userId, tier }, "system");
    return this.state.users[userId];
  }

  executeProtocol(
    protocolId: CanonicalId,
    actorId: CanonicalId,
    paths: ProtocolDecisionPath[],
  ): ProtocolExecution {
    const events = this.dispatch({ type: "ExecuteProtocol", protocolId, actorId, paths }, actorId);
    const collapsed = events.find(
      (event): event is ProtocolCollapsedEvent => event.type === "ProtocolCollapsed",
    );
    if (!collapsed) throw new Error("Protocol execution did not collapse");
    return collapsed.execution;
  }

  createDreamSpace(
    ownerId: CanonicalId,
    name: string,
    isPublic: boolean,
  ): DreamSpace & { cid: CanonicalId } {
    this.requireUser(ownerId);
    const [event] = this.dispatch({ type: "CreateDreamSpace", ownerId, name, isPublic }, ownerId);
    return (event as DreamSpaceCreatedEvent).dreamSpace;
  }

  postLedger(userId: CanonicalId, amount: number, reason: string): LedgerEntry & { cid: CanonicalId } {
    this.requireUser(userId);
    const [event] = this.dispatch({ type: "PostLedger", userId, amount, reason }, userId);
    return (event as LedgerPostedEvent).entry;
  }

  // Infra de eventos

  dispatch(command: KernelCommand, actorId = "system"): KernelEvent[] {
    const events = this.decide(command);
    for (const event of events) {
      this.store.append(event, actorId);
      this.state = reduce(this.state, event);
    }
    return events;
  }

  eventLog(): EventEnvelope<KernelEvent>[] {
    return this.store.all();
  }

  verify(): boolean {
    return this.store.verifyIntegrity();
  }

  replay(events: EventEnvelope<KernelEvent>[]): void {
    this.state = initialState();
    this.store.reset(events);
    for (const event of events) {
      this.state = reduce(this.state, event.data);
    }
  }

  snapshot() {
    const msrEvents: MsrEvent[] = this.store.all().map((envelope) => ({
      id: envelope.meta.eventId,
      type: `kernel.${envelope.data.type}`,
      actorId: envelope.meta.actorId,
      timestamp: envelope.meta.timestamp,
      payload: envelope.data as unknown as Record<string, unknown>,
    }));

    return {
      users: Object.values(this.state.users),
      msrEvents,
      bookPi: [...this.state.narratives],
      guardianSignals: [...this.state.guardianSignals],
      dreamSpaces: Object.values(this.state.dreamSpaces),
      ledger: [...this.state.ledger],
      protocolExecutions: [...this.state.protocolExecutions],
    };
  }

  // Privadas

  private requireUser(userId: CanonicalId): UserProfile & { cid: CanonicalId } {
    const user = this.state.users[userId];
    if (!user) throw new Error(`User ${userId} not found`);
    return user;
  }

  private decide(command: KernelCommand): KernelEvent[] {
    switch (command.type) {
      case "CreateUser": {
        const userCid = cid("user");
        const user: UserProfile & { cid: CanonicalId } = {
          id: userCid,
          cid: userCid,
          handle: command.handle,
          displayName: command.displayName,
          roles: ["citizen"],
          memberships: ["free"],
          createdAt: nowIso(),
        };
        return [{ type: "UserCreated", user }];
      }

      case "AssignMembership":
        return [
          {
            type: "MembershipAssigned",
            userId: command.userId,
            tier: command.tier,
          },
        ];

      case "CreateDreamSpace": {
        const dsCid = cid("dreamspace");
        const dreamSpace: DreamSpace & { cid: CanonicalId } = {
          id: dsCid,
          cid: dsCid,
          ownerId: command.ownerId,
          name: command.name,
          isPublic: command.isPublic,
          participants: [command.ownerId],
        };
        return [{ type: "DreamSpaceCreated", dreamSpace }];
      }

      case "PostLedger": {
        const ledgerCid = cid("ledger");
        const entry: LedgerEntry & { cid: CanonicalId } = {
          id: ledgerCid,
          cid: ledgerCid,
          userId: command.userId,
          amount: command.amount,
          reason: command.reason,
          kind: command.amount >= 0 ? "credit" : "debit",
          createdAt: nowIso(),
        };
        return [{ type: "LedgerPosted", entry }];
      }

      case "ExecuteProtocol": {
        const execution = ProtocolVM.collapse(command.protocolId, command.paths);
        const epistemic = ProtocolVM.epistemicFootprint(command.paths);

        const events: KernelEvent[] = [
          {
            type: "ProtocolCollapsed",
            execution,
            epistemic,
          },
        ];

        if (execution.selectedPath.ethicalRisk > 0.4) {
          events.push({
            type: "GuardianTriggered",
            signal: {
              id: cid("guardian"),
              protocolId: command.protocolId,
              severity: execution.selectedPath.ethicalRisk > 0.75 ? "high" : "medium",
              summary: "Risk above civil baseline; route to EOCT/Guardian review.",
              generatedAt: nowIso(),
            },
          });
        }

        events.push({
          type: "NarrativeWritten",
          entry: {
            id: cid("bookpi"),
            cid: cid("bookpi"),
            eventId: command.protocolId,
            title: `Protocol ${command.protocolId} collapse narrative`,
            narrative: execution.selectedPath.description,
            createdAt: nowIso(),
          },
        });

        return events;
      }
    }
  }
}
