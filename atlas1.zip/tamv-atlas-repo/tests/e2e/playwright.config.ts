import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: ".",
  timeout: 30_000,
  retries: 1,
  reporter: [["list"], ["html", { open: "never" }]],
  use: {
    baseURL: process.env.E2E_BASE_URL ?? "http://localhost:8080",
    extraHTTPHeaders: {
      apikey: process.env.SUPABASE_ANON_KEY ?? "",
    },
    trace: "retain-on-failure",
  },
});
