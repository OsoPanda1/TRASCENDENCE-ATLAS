import { test, expect, request } from "@playwright/test";

test("CLEI chain prev_hash continuity", async () => {
  test.skip(!process.env.SUPABASE_URL || !process.env.SUPABASE_ANON_KEY, "Missing env");
  const ctx = await request.newContext();
  const r = await ctx.get(
    `${process.env.SUPABASE_URL}/rest/v1/clei_audit?select=sequence,prev_hash,hash&order=sequence.asc&limit=200`,
    { headers: { apikey: process.env.SUPABASE_ANON_KEY!, Authorization: `Bearer ${process.env.SUPABASE_ANON_KEY!}` } },
  );
  const rows = await r.json();
  let prev: string | null = null;
  for (const e of rows) {
    if (prev !== null) expect(e.prev_hash).toBe(prev);
    prev = e.hash;
  }
});
