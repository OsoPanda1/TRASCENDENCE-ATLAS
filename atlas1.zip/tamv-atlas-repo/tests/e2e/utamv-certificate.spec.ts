import { test, expect, request } from "@playwright/test";

test("UTAMV certificate issuance returns PQC signature", async () => {
  test.skip(!process.env.SUPABASE_URL || !process.env.E2E_USER_JWT || !process.env.E2E_COURSE_ID, "Missing env");
  const ctx = await request.newContext();
  const r = await ctx.post(`${process.env.SUPABASE_URL}/functions/v1/utamv-issue-certificate`, {
    headers: { Authorization: `Bearer ${process.env.E2E_USER_JWT}` },
    data: { course_id: process.env.E2E_COURSE_ID },
  });
  const body = await r.json();
  expect(body.ok).toBe(true);
  expect(body.certificate?.signature).toBeTruthy();
  expect(body.certificate?.signing_key_id).toBeTruthy();
});
