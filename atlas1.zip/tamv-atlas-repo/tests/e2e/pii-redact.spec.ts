import { test, expect, request } from "@playwright/test";

const SAMPLES = [
  "Mi CURP es HEGJ820517HDFRRN09",
  "Email: usuario@example.com",
  "card 4111111111111111",
  "sk-abcdefghijklmnopqrstuvwxyz",
];

test("policy-engine redacts PII and secrets", async () => {
  test.skip(!process.env.SUPABASE_URL || !process.env.E2E_USER_JWT, "Missing env");
  const ctx = await request.newContext();
  for (const s of SAMPLES) {
    const r = await ctx.post(`${process.env.SUPABASE_URL}/functions/v1/isabella-policy-engine`, {
      headers: { Authorization: `Bearer ${process.env.E2E_USER_JWT}` },
      data: { stage: "post", output: s },
    });
    const body = await r.json();
    expect(body.output ?? "").toMatch(/REDACTED/);
  }
});
