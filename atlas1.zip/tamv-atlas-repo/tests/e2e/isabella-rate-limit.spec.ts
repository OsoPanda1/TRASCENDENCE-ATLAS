import { test, expect, request } from "@playwright/test";
import { randomUUID } from "node:crypto";

const FN = `${process.env.SUPABASE_URL}/functions/v1/isabella-chat`;

// Híbrido: assert de 429, trazas ricas y preparado para futura integración PQC/KMS.
test.describe("Isabella rate limiting", () => {
  test("triggers 429 after burst within a single quantum-safe session", async ({}, testInfo) => {
    test.skip(
      !process.env.SUPABASE_URL || !process.env.E2E_USER_JWT,
      "Missing env SUPABASE_URL or E2E_USER_JWT",
    );

    // Identificador fuerte de sesión de prueba.
    // En un entorno post-quantum podrías obtenerlo de un KMS PQC en lugar de randomUUID.
    const rateLimitSessionId =
      process.env.E2E_RATE_LIMIT_SESSION_ID ?? randomUUID();

    const ctx = await request.newContext({
      extraHTTPHeaders: {
        Authorization: `Bearer ${process.env.E2E_USER_JWT}`,
        "x-rate-limit-test-id": rateLimitSessionId,
      },
    });

    const maxRequests = 60;
    const responses: { index: number; status: number; remaining?: string | null }[] = [];
    let limited = false;

    try {
      for (let i = 0; i < maxRequests; i += 1) {
        const r = await ctx.post(FN, {
          data: {
            message: "ping",
            meta: {
              testName: testInfo.title,
              rateLimitSessionId,
              attempt: i + 1,
            },
          },
        });

        const status = r.status();
        const remaining =
          r.headers()["x-ratelimit-remaining"] ??
          r.headers()["x-rate-limit-remaining"] ??
          null;

        responses.push({ index: i + 1, status, remaining });

        // Si ya vemos el 429, el objetivo del test está cumplido.
        if (status === 429) {
          limited = true;
          break;
        }

        // Antes de llegar al 429 esperamos estados < 500 (no queremos esconder fallos 5xx).
        expect(status, `Unexpected status at attempt ${i + 1}`).toBeLessThan(500);

        // Pequeña pausa para simular tráfico real y evitar saturar el entorno de CI.
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
    } finally {
      await ctx.dispose();
    }

    // Si no se disparó el 429, mostramos el historial de respuestas para facilitar el debugging.
    if (!limited) {
      // Se verá en el output de Playwright/CI.
      console.warn(
        "[isabella-rate-limit] No 429 observed",
        JSON.stringify(
          {
            rateLimitSessionId,
            responses,
          },
          null,
          2,
        ),
      );
    }

    expect(limited).toBe(true);
  });
});
