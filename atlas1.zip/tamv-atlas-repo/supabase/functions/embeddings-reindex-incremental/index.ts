// Incremental pgvector reindex for canon_entities.
// Picks rows where embedding_dirty=true, re-embeds in batches via Lovable AI Gateway,
// updates vector_embedding + clears the dirty flag, and logs the run.
import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { z } from "npm:zod@3";

const BodySchema = z.object({
  batch_size: z.number().int().min(1).max(64).default(16),
  max_batches: z.number().int().min(1).max(20).default(4),
  mode: z.enum(["incremental", "full"]).default("incremental"),
});

const AI_KEY = Deno.env.get("LOVABLE_API_KEY")!;
const MODEL = "google/gemini-embedding-001";

async function embed(texts: string[]): Promise<number[][]> {
  const r = await fetch("https://ai.gateway.lovable.dev/v1/embeddings", {
    method: "POST",
    headers: { Authorization: `Bearer ${AI_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: MODEL, input: texts, dimensions: 1536 }),
  });
  if (!r.ok) throw new Error(`embeddings ${r.status}: ${(await r.text()).slice(0, 200)}`);
  const data = await r.json();
  return data.data.map((d: { embedding: number[] }) => d.embedding);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = BodySchema.parse(await req.json().catch(() => ({})));
    const supa = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const trace_id = `reindex_${crypto.randomUUID()}`;

    // count candidates
    let countQuery = supa.from("canon_entities").select("canonical_id", { count: "exact", head: true });
    if (body.mode === "incremental") countQuery = countQuery.eq("embedding_dirty", true);
    const { count } = await countQuery;

    const { data: runRow, error: runErr } = await supa.from("embedding_reindex_runs").insert({
      trace_id, mode: body.mode, batch_size: body.batch_size, total_candidates: count ?? 0, status: "running",
    }).select("id").single();
    if (runErr) throw new Error(runErr.message);
    const runId = runRow.id;

    let processed = 0, failed = 0;
    for (let b = 0; b < body.max_batches; b++) {
      let q = supa.from("canon_entities")
        .select("canonical_id, title, description, content")
        .order("updated_at", { ascending: true })
        .limit(body.batch_size);
      if (body.mode === "incremental") q = q.eq("embedding_dirty", true);
      const { data: rows, error } = await q;
      if (error) throw new Error(error.message);
      if (!rows || rows.length === 0) break;

      const texts = rows.map((r) => `${r.title ?? ""}\n${r.description ?? ""}\n${(r.content ?? "").slice(0, 4000)}`.slice(0, 8000));
      try {
        const vecs = await embed(texts);
        for (let i = 0; i < rows.length; i++) {
          const { error: uerr } = await supa.from("canon_entities").update({
            vector_embedding: vecs[i] as unknown as string,
            embedding_model: MODEL,
            embedded_at: new Date().toISOString(),
            embedding_dirty: false,
            embedding_indexed_at: new Date().toISOString(),
          }).eq("canonical_id", rows[i].canonical_id);
          if (uerr) { failed++; console.error("[reindex] update:", uerr.message); } else processed++;
        }
      } catch (e) {
        failed += rows.length;
        console.error("[reindex] batch embed failed:", e);
      }

      await supa.from("embedding_reindex_runs").update({ processed, failed }).eq("id", runId);
      if (rows.length < body.batch_size) break;
    }

    await supa.from("embedding_reindex_runs").update({
      status: "completed", processed, failed, finished_at: new Date().toISOString(),
    }).eq("id", runId);

    return new Response(JSON.stringify({ ok: true, trace_id, processed, failed, total_candidates: count ?? 0 }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: e instanceof Error ? e.message : String(e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
