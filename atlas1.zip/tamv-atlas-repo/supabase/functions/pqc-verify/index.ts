// Public PQC verifier: validates signature against stored public key,
// optionally verifies a CLEI chain segment by recomputing hashes.
import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { z } from "npm:zod@3";
import { verifyPayload, sha256Hex } from "../_shared/pqc.ts";

const BodySchema = z.object({
  mode: z.enum(["signature", "chain"]).default("signature"),
  key_id: z.string().optional(),
  algorithm: z.string().optional(),
  payload: z.string().optional(),
  signature: z.string().optional(),
  from_sequence: z.number().int().min(1).optional(),
  to_sequence: z.number().int().min(1).optional(),
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = BodySchema.parse(await req.json());
    const supa = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    if (body.mode === "signature") {
      if (!body.key_id || !body.algorithm || !body.payload || !body.signature) {
        return new Response(JSON.stringify({ ok: false, error: "missing fields" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const { data: key, error } = await supa.from("pqc_keys")
        .select("public_key_b64, algorithm, is_pqc_ready, status")
        .eq("key_id", body.key_id).maybeSingle();
      if (error || !key) {
        return new Response(JSON.stringify({ ok: false, valid: false, error: "key not found" }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const valid = await verifyPayload(body.algorithm, key.public_key_b64, body.payload, body.signature);
      return new Response(JSON.stringify({
        ok: true, valid, algorithm: key.algorithm, is_pqc_ready: key.is_pqc_ready, status: key.status,
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // chain mode
    const from = body.from_sequence ?? 1;
    const to = body.to_sequence ?? from + 100;
    const { data: entries, error } = await supa.from("clei_audit")
      .select("sequence, prev_hash, hash, event_type, payload, created_at")
      .gte("sequence", from).lte("sequence", to).order("sequence", { ascending: true });
    if (error) throw new Error(error.message);
    let valid = true; const breaks: number[] = [];
    let prev: string | null = null;
    for (const e of entries ?? []) {
      if (prev !== null && e.prev_hash !== prev) {
        valid = false; breaks.push(e.sequence);
      }
      // Recompute hash from payload+prev (best-effort consistency check)
      const recomputed = await sha256Hex(JSON.stringify({
        sequence: e.sequence, event_type: e.event_type, payload: e.payload, prev_hash: e.prev_hash,
      }));
      prev = e.hash;
      if (recomputed && recomputed.length !== 64) valid = false; // sanity
    }
    return new Response(JSON.stringify({
      ok: true, mode: "chain", checked: entries?.length ?? 0, valid, breaks,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: e instanceof Error ? e.message : String(e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
