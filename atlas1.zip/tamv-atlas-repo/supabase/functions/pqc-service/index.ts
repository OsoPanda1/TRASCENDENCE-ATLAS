// PQC Service — keygen / sign / verify + CLEI append
// PQC bridge: ML-DSA-65 (real PQC) with Ed25519-bridge fallback.

import { corsHeaders, sha256 } from "../_shared/ai-gateway.ts";
import { adminClient, getUserFromReq, isAdmin } from "../_shared/auth.ts";
import { generateKeyPair, signPayload, verifyPayload, sha256Hex } from "../_shared/pqc.ts";

// In-memory key cache (private keys never persisted to DB).
// In a real production deployment these go to a KMS/HSM (Supabase Vault, AWS KMS, etc.).
const PRIVATE_KEY_CACHE: Record<string, { algorithm: string; privateKeyB64: string }> = {};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const user = await getUserFromReq(req);
    if (!user) return json({ error: "unauthorized" }, 401);
    const sb = adminClient();
    const body = await req.json();
    const intent: string = body.intent;

    if (intent === "keygen") {
      const { entity_id } = body;
      const kp = await generateKeyPair();
      const { data, error } = await sb.from("pqc_keys").insert({
        entity_id: entity_id ?? null,
        owner_id: user.id,
        algorithm: kp.algorithm,
        is_pqc_ready: kp.is_pqc_ready,
        public_key_b64: kp.publicKeyB64,
        key_id: kp.keyId,
        status: "active",
      }).select().single();
      if (error) throw error;
      PRIVATE_KEY_CACHE[kp.keyId] = { algorithm: kp.algorithm, privateKeyB64: kp.privateKeyB64 };
      return json({
        ok: true, key: data,
        warning: kp.is_pqc_ready ? null : "PQC library unavailable in runtime; using Ed25519 bridge. Set is_pqc_ready=true when ML-DSA library is enabled.",
      });
    }

    if (intent === "sign") {
      const { key_id, payload } = body;
      if (!key_id || !payload) return json({ error: "missing_fields" }, 400);
      const cached = PRIVATE_KEY_CACHE[key_id];
      if (!cached) return json({ error: "private_key_not_in_session_cache" }, 404);
      const signature = await signPayload(cached.algorithm, cached.privateKeyB64, JSON.stringify(payload));
      const hash = await sha256Hex(JSON.stringify(payload));
      // Append to CLEI chain
      const { data: last } = await sb.from("clei_audit").select("hash").order("sequence", { ascending: false }).limit(1).maybeSingle();
      const prev_hash = last?.hash ?? null;
      const chainHash = await sha256Hex((prev_hash ?? "") + hash + signature);
      await sb.from("clei_audit").insert({
        event_type: "pqc.sign", actor_id: user.id,
        payload: { key_id, payload_hash: hash },
        hash: chainHash, prev_hash, signature, signing_key_id: key_id,
      });
      return json({ ok: true, signature, hash, chain_hash: chainHash, algorithm: cached.algorithm });
    }

    if (intent === "verify") {
      const { key_id, payload, signature } = body;
      const { data: key } = await sb.from("pqc_keys").select("algorithm, public_key_b64").eq("key_id", key_id).maybeSingle();
      if (!key) return json({ error: "key_not_found" }, 404);
      const valid = await verifyPayload(key.algorithm, key.public_key_b64, JSON.stringify(payload), signature);
      return json({ ok: true, valid, algorithm: key.algorithm });
    }

    if (intent === "list_keys") {
      const { data } = await sb.from("pqc_keys").select("*").eq("owner_id", user.id).order("created_at", { ascending: false });
      return json({ keys: data ?? [] });
    }

    if (intent === "issue_isni_credential") {
      if (!(await isAdmin(user.id))) return json({ error: "forbidden" }, 403);
      const { holder_entity_id, vc_type, key_id, claims } = body;
      const cached = PRIVATE_KEY_CACHE[key_id];
      if (!cached) return json({ error: "private_key_not_in_session_cache" }, 404);
      const vc_id = `urn:tamv:vc:${crypto.randomUUID()}`;
      const vcPayload = {
        "@context": ["https://www.w3.org/2018/credentials/v1", "https://tamv.online/contexts/isni-v1"],
        type: ["VerifiableCredential", vc_type ?? "ISNICredential"],
        id: vc_id,
        issuer: `did:tamv:issuer:${user.id}`,
        issuanceDate: new Date().toISOString(),
        credentialSubject: { id: holder_entity_id, ...claims },
      };
      const signature = await signPayload(cached.algorithm, cached.privateKeyB64, JSON.stringify(vcPayload));
      const { data, error } = await sb.from("isni_credentials").insert({
        vc_id, holder_entity_id, issuer_did: vcPayload.issuer,
        vc_type: vc_type ?? "ISNICredential",
        payload: vcPayload, signature, status: "active",
      }).select().single();
      if (error) throw error;
      const hash = await sha256Hex(JSON.stringify(vcPayload));
      const { data: last } = await sb.from("clei_audit").select("hash").order("sequence", { ascending: false }).limit(1).maybeSingle();
      const prev_hash = last?.hash ?? null;
      const chainHash = await sha256Hex((prev_hash ?? "") + hash + signature);
      await sb.from("clei_audit").insert({
        event_type: "isni.credential.issued", actor_id: user.id,
        payload: { vc_id, holder_entity_id }, hash: chainHash, prev_hash,
        signature, signing_key_id: key_id,
      });
      return json({ ok: true, credential: data });
    }

    return json({ error: "unknown_intent" }, 400);
  } catch (e) {
    console.error("[pqc-service]", e);
    return json({ error: e instanceof Error ? e.message : "internal" }, 500);
  }
});

function json(b: any, s = 200) {
  return new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
