// Signed audit export: dumps clei_audit / mdx_audit_log / isabella_policies events
// as JSON or CSV, signs the canonical payload (PQC w/ Ed25519 fallback),
// persists the verifiable run in audit_export_runs and returns content + signature.
import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { z } from "npm:zod@3";
import { generateKeyPair, signPayload, sha256Hex } from "../_shared/pqc.ts";
import { getUserFromReq, adminClient } from "../_shared/auth.ts";

const SCHEMA_VERSION = "v1";

const BodySchema = z.object({
  export_type: z.enum(["clei", "mdx", "policies"]).default("clei"),
  format: z.enum(["json", "csv"]).default("json"),
  limit: z.number().int().min(1).max(5000).default(1000),
  since: z.string().datetime().optional(),
  until: z.string().datetime().optional(),
});

function toCsv(rows: Record<string, unknown>[]): string {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  const escape = (v: unknown) => {
    if (v === null || v === undefined) return "";
    const s = typeof v === "string" ? v : JSON.stringify(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [headers.join(","), ...rows.map((r) => headers.map((h) => escape(r[h])).join(","))].join("\n");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const user = await getUserFromReq(req);
    if (!user) return new Response(JSON.stringify({ ok: false, error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const supa = adminClient();
    const { data: roleRow } = await supa.from("user_roles").select("role").eq("user_id", user.id);
    const roles = (roleRow ?? []).map((r) => r.role);
    if (!roles.includes("admin") && !roles.includes("gobierno")) {
      return new Response(JSON.stringify({ ok: false, error: "forbidden: requires admin|gobierno" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = BodySchema.parse(await req.json().catch(() => ({})));
    const trace_id = `export_${crypto.randomUUID()}`;

    const table = body.export_type === "clei" ? "clei_audit" : body.export_type === "mdx" ? "mdx_audit_log" : "isabella_policies";
    let q = supa.from(table).select("*").order("created_at", { ascending: true }).limit(body.limit);
    if (body.since) q = q.gte("created_at", body.since);
    if (body.until) q = q.lte("created_at", body.until);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);

    const payload = {
      schema_version: SCHEMA_VERSION,
      export_type: body.export_type,
      trace_id,
      generated_at: new Date().toISOString(),
      total_events: rows?.length ?? 0,
      filters: { since: body.since ?? null, until: body.until ?? null, limit: body.limit },
      events: rows ?? [],
    };

    // Canonical payload for signing: stable JSON of payload (without signature itself)
    const canonical = JSON.stringify(payload);
    const content_hash = await sha256Hex(canonical);

    const kp = await generateKeyPair();
    const signature = await signPayload(kp.algorithm, kp.privateKeyB64, canonical);

    // Register the public key for verification (one-shot ephemeral signing key)
    await supa.from("pqc_keys").insert({
      algorithm: kp.algorithm, is_pqc_ready: kp.is_pqc_ready,
      public_key_b64: kp.publicKeyB64, key_id: kp.keyId, status: "active",
    });

    await supa.from("audit_export_runs").insert({
      trace_id, export_type: body.export_type, format: body.format,
      schema_version: SCHEMA_VERSION, total_events: payload.total_events,
      content_hash, signature, signing_key_id: kp.keyId, requested_by: user.id,
      filters: payload.filters,
    });

    const content = body.format === "csv" ? toCsv(rows ?? []) : canonical;

    return new Response(JSON.stringify({
      ok: true, trace_id, schema_version: SCHEMA_VERSION, format: body.format,
      total_events: payload.total_events, content_hash, signature,
      signing_key_id: kp.keyId, algorithm: kp.algorithm, is_pqc_ready: kp.is_pqc_ready,
      content,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: e instanceof Error ? e.message : String(e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
