// GitHub Org/User mass sync: lists all repos for a user/org with pagination,
// upserts into github_repos, then triggers atlas-ingest-batch with retries/backoff.
import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { z } from "npm:zod@3";

const BodySchema = z.object({
  owner: z.string().min(1).max(64).default("OsoPanda1"),
  concurrency: z.number().int().min(1).max(8).default(3),
  max_retries: z.number().int().min(0).max(5).default(3),
  trigger_ingest: z.boolean().default(true),
  only_new: z.boolean().default(false),
});

interface GHRepo {
  name: string;
  full_name: string;
  owner: { login: string };
  description: string | null;
  language: string | null;
  stargazers_count: number;
  forks_count: number;
  open_issues_count: number;
  pushed_at: string;
  fork: boolean;
  archived: boolean;
}

const GITHUB_TOKEN = Deno.env.get("GITHUB_TOKEN");
const SVC = () => createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

async function ghFetch(url: string, attempt = 0): Promise<Response> {
  const headers: Record<string, string> = {
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "User-Agent": "tamv-atlas-sync/1.0",
  };
  if (GITHUB_TOKEN) headers["Authorization"] = `Bearer ${GITHUB_TOKEN}`;
  const r = await fetch(url, { headers });
  if (r.status === 403 || r.status === 429 || r.status >= 500) {
    if (attempt >= 4) return r;
    const reset = Number(r.headers.get("X-RateLimit-Reset") ?? 0);
    const now = Math.floor(Date.now() / 1000);
    const wait = reset > now ? Math.min((reset - now) * 1000, 30_000) : Math.min(1000 * Math.pow(2, attempt), 16000);
    await new Promise((res) => setTimeout(res, wait));
    return ghFetch(url, attempt + 1);
  }
  return r;
}

async function listAllRepos(owner: string): Promise<GHRepo[]> {
  const all: GHRepo[] = [];
  for (let page = 1; page <= 30; page++) {
    const r = await ghFetch(`https://api.github.com/users/${owner}/repos?per_page=100&page=${page}&sort=pushed`);
    if (!r.ok) throw new Error(`GitHub list failed (${r.status}) at page ${page}`);
    const batch = (await r.json()) as GHRepo[];
    all.push(...batch);
    if (batch.length < 100) break;
  }
  return all;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = BodySchema.parse(await req.json().catch(() => ({})));
    const supa = SVC();
    const trace_id = `org_sync_${crypto.randomUUID()}`;

    const run = await supa.from("org_sync_runs").insert({
      owner: body.owner, trace_id, status: "running",
    }).select("id").single();
    if (run.error) throw new Error(run.error.message);
    const runId = run.data.id;

    let repos: GHRepo[] = [];
    try {
      repos = await listAllRepos(body.owner);
    } catch (e) {
      await supa.from("org_sync_runs").update({
        status: "error", error: e instanceof Error ? e.message : String(e),
        finished_at: new Date().toISOString(),
      }).eq("id", runId);
      throw e;
    }

    const visible = repos.filter((r) => !r.fork && !r.archived);
    let newCount = 0, updatedCount = 0, failed = 0;

    for (const repo of visible) {
      try {
        const { data: existing } = await supa.from("github_repos")
          .select("id").eq("full_name", repo.full_name).maybeSingle();
        const payload = {
          owner: repo.owner.login,
          name: repo.name,
          full_name: repo.full_name,
          description: repo.description,
          language: repo.language,
          stars: repo.stargazers_count,
          forks: repo.forks_count,
          open_issues: repo.open_issues_count,
          pushed_at: repo.pushed_at,
          synced_at: new Date().toISOString(),
        };
        if (existing) {
          await supa.from("github_repos").update(payload).eq("id", existing.id);
          updatedCount++;
        } else {
          await supa.from("github_repos").insert(payload);
          newCount++;
        }
      } catch (e) {
        console.error("[org-sync] upsert failed for", repo.full_name, e);
        failed++;
      }
    }

    // Trigger atlas-ingest-batch (fire & forget; it has its own concurrency/retries).
    if (body.trigger_ingest && visible.length > 0) {
      supa.functions.invoke("atlas-ingest-batch", {
        body: { owner: body.owner, concurrency: body.concurrency, max_retries: body.max_retries, only_new: body.only_new },
      }).catch((e) => console.error("[org-sync] ingest invoke failed:", e));
    }

    await supa.from("org_sync_runs").update({
      status: "completed",
      total_repos: visible.length,
      new_repos: newCount,
      updated_repos: updatedCount,
      failed_repos: failed,
      finished_at: new Date().toISOString(),
    }).eq("id", runId);

    return new Response(JSON.stringify({
      ok: true, trace_id, total: visible.length, new: newCount, updated: updatedCount, failed,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: e instanceof Error ? e.message : String(e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
