import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { createClient } from "npm:@supabase/supabase-js@2";
import { z } from "npm:zod@3";
import { sha256, checkRateLimit } from "../_shared/security.ts";

const Body = z.object({
  op: z.enum(["read", "write", "list"]),
  scope: z.enum(["short", "long", "episodic"]).default("short"),
  key: z.string().max(200).optional(),
  content: z.string().max(10000).optional(),
  importance: z.number().min(0).max(1).optional(),
  limit: z.number().min(1).max(100).default(20).optional(),
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) return json({ error: "Unauthorized" }, 401);
    const supa = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: auth } },
    });
    const { data: claims } = await supa.auth.getClaims(auth.replace("Bearer ", ""));
    if (!claims?.claims) return json({ error: "Unauthorized" }, 401);
    const userId = claims.claims.sub as string;
    if (!(await checkRateLimit(userId, "memory", 120))) return json({ error: "Rate limited" }, 429);

    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) return json({ error: parsed.error.flatten() }, 400);
    const { op, scope, key, content, importance, limit } = parsed.data;

    if (op === "write") {
      if (!content) return json({ error: "content required" }, 400);
      const h = await sha256(content);
      const expires_at = scope === "short" ? new Date(Date.now() + 24 * 3600 * 1000).toISOString() : null;
      const { data, error } = await supa.from("isabella_memory").upsert({
        user_id: userId, scope, key: key ?? h.slice(0, 12), content, hash: h, importance: importance ?? 0.5, expires_at,
      }, { onConflict: "user_id,scope,hash" }).select().maybeSingle();
      if (error) return json({ error: error.message }, 400);
      return json({ entry: data });
    }
    if (op === "read" && key) {
      const { data } = await supa.from("isabella_memory").select("*").eq("user_id", userId).eq("scope", scope).eq("key", key).limit(1);
      return json({ entries: data ?? [] });
    }
    const { data } = await supa.from("isabella_memory").select("*").eq("user_id", userId).eq("scope", scope)
      .order("importance", { ascending: false }).order("created_at", { ascending: false }).limit(limit ?? 20);
    return json({ entries: data ?? [] });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});

function json(b: unknown, s = 200) {
  return new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
