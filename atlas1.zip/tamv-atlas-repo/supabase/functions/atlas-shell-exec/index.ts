// Atlas Shell — server-side execution of high-level Atlas commands with audit.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

async function getUser(req: Request) {
  const auth = req.headers.get("Authorization");
  if (!auth) return null;
  const sb = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: auth } },
  });
  const { data } = await sb.auth.getUser();
  return data.user;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const t0 = Date.now();
  const user = await getUser(req);
  if (!user) return new Response(JSON.stringify({ error: "unauthorized" }),
    { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  const svc = createClient(SUPABASE_URL, SERVICE_KEY);
  const { data: hasRole } = await svc.rpc("has_min_role", { _user_id: user.id, _min: "gobierno" });
  if (!hasRole) return new Response(JSON.stringify({ error: "forbidden: requires gobierno+" }),
    { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  const { command, args = {} } = await req.json();
  let result: any = {};
  let status = "ok";

  try {
    switch (command) {
      case "status": {
        const [e, r, j] = await Promise.all([
          svc.from("canon_entities").select("id", { count: "exact", head: true }),
          svc.from("canon_relations").select("id", { count: "exact", head: true }),
          svc.from("akae_jobs").select("id", { count: "exact", head: true }).eq("status", "running"),
        ]);
        result = { entities: e.count, relations: r.count, jobs_running: j.count };
        break;
      }
      case "search": {
        const q = String(args.q ?? "").trim();
        if (!q) throw new Error("q required");
        const { data } = await svc.from("canon_entities")
          .select("canonical_id,title,domain_v2,risk_level,score_confianza")
          .or(`title.ilike.%${q}%,description.ilike.%${q}%`).limit(25);
        result = { matches: data ?? [] };
        break;
      }
      case "node": {
        const id = String(args.id ?? "");
        const { data } = await svc.from("canon_entities").select("*").eq("canonical_id", id).maybeSingle();
        result = { node: data };
        break;
      }
      case "ingest": {
        const url = String(args.url ?? "");
        if (!url) throw new Error("url required");
        const r = await fetch(`${SUPABASE_URL}/functions/v1/atlas-ingest`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${SERVICE_KEY}` },
          body: JSON.stringify({ repo_url: url }),
        });
        result = await r.json();
        break;
      }
      default:
        throw new Error(`unknown command: ${command}`);
    }
  } catch (e) {
    status = "error";
    result = { error: (e as Error).message };
  }

  await svc.from("atlas_shell_commands").insert({
    user_id: user.id, command, args, result, status, duration_ms: Date.now() - t0,
  });

  return new Response(JSON.stringify({ status, result }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } });
});
