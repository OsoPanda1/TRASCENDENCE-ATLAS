// Shared security helpers: rate limiting, prompt-injection guard, PII/secret filters.
import { createClient } from "npm:@supabase/supabase-js@2";

export function svc() {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );
}

// Token-bucket-ish per-user rate limiter (1-minute windows).
export async function checkRateLimit(userId: string, bucket: string, maxPerMinute = 30): Promise<boolean> {
  const supa = svc();
  const windowStart = new Date(Math.floor(Date.now() / 60000) * 60000).toISOString();
  const { data } = await supa.from("rate_limits")
    .select("id, count").eq("user_id", userId).eq("bucket", bucket).eq("window_start", windowStart).maybeSingle();
  if (!data) {
    await supa.from("rate_limits").insert({ user_id: userId, bucket, window_start: windowStart, count: 1 });
    return true;
  }
  if (data.count >= maxPerMinute) return false;
  await supa.from("rate_limits").update({ count: data.count + 1 }).eq("id", data.id);
  return true;
}

const INJECTION_PATTERNS = [
  /ignore (?:all|previous|prior) (?:instructions|prompts?)/i,
  /override (?:the )?system/i,
  /jailbreak/i,
  /disregard.{0,40}instructions/i,
  /act as (?:if you are |an? )?(?:dan|developer mode)/i,
];

export function detectPromptInjection(text: string): { hit: boolean; matches: string[] } {
  const matches: string[] = [];
  for (const p of INJECTION_PATTERNS) if (p.test(text)) matches.push(String(p));
  return { hit: matches.length > 0, matches };
}

const PII_PATTERNS: [string, RegExp][] = [
  ["card_number", /\b\d{13,19}\b/g],
  ["curp", /\b[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d\b/g],
  ["rfc", /\b[A-Z&Ñ]{3,4}\d{6}[A-Z0-9]{3}\b/g],
  ["email", /\b[\w.+-]+@[\w-]+\.[\w.-]+\b/g],
];

export function filterPII(text: string): { redacted: string; found: string[] } {
  let out = text;
  const found: string[] = [];
  for (const [name, re] of PII_PATTERNS) {
    if (re.test(out)) { found.push(name); out = out.replace(re, `[REDACTED:${name}]`); }
  }
  return { redacted: out, found };
}

const SECRET_PATTERNS = [
  /sk-[a-zA-Z0-9]{20,}/g,
  /api[_-]?key\s*[:=]\s*["']?[\w-]{16,}/gi,
  /Bearer\s+[A-Za-z0-9._-]{20,}/g,
];

export function filterSecrets(text: string): { redacted: string; found: number } {
  let out = text; let n = 0;
  for (const re of SECRET_PATTERNS) {
    const m = out.match(re); if (m) { n += m.length; out = out.replace(re, "[REDACTED:SECRET]"); }
  }
  return { redacted: out, found: n };
}

export function sha256(input: string): Promise<string> {
  const enc = new TextEncoder().encode(input);
  return crypto.subtle.digest("SHA-256", enc).then(b =>
    Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, "0")).join("")
  );
}

export const cspHeaders = {
  "Content-Security-Policy": "default-src 'self'; frame-ancestors 'none'",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "Strict-Transport-Security": "max-age=63072000; includeSubDomains",
};
