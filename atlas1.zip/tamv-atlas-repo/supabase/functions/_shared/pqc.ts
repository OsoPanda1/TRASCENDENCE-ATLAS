// PQC bridge: tries ML-DSA-65 via @noble/post-quantum; falls back to Ed25519 (browser-compatible WebCrypto).
// We DO NOT pretend Ed25519 is PQC: returns `is_pqc_ready: false` when fallback is used.

export interface PQCKeyPair {
  algorithm: "ML-DSA-65" | "Ed25519-bridge";
  is_pqc_ready: boolean;
  publicKeyB64: string;
  privateKeyB64: string;
  keyId: string;
}

function b64encode(bytes: Uint8Array): string {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s);
}
function b64decode(s: string): Uint8Array {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function keyIdOf(pub: Uint8Array): Promise<string> {
  const d = await crypto.subtle.digest("SHA-256", pub);
  return "kid_" + b64encode(new Uint8Array(d)).slice(0, 16);
}

export async function generateKeyPair(): Promise<PQCKeyPair> {
  // Try ML-DSA-65
  try {
    const mod: any = await import("npm:@noble/post-quantum@0.2.1/ml-dsa.js");
    const ml = mod.ml_dsa65;
    const seed = crypto.getRandomValues(new Uint8Array(32));
    const { publicKey, secretKey } = ml.keygen(seed);
    return {
      algorithm: "ML-DSA-65",
      is_pqc_ready: true,
      publicKeyB64: b64encode(publicKey),
      privateKeyB64: b64encode(secretKey),
      keyId: await keyIdOf(publicKey),
    };
  } catch (e) {
    console.warn("[pqc] ML-DSA unavailable, falling back to Ed25519:", e instanceof Error ? e.message : e);
  }

  // Fallback Ed25519
  const kp = await crypto.subtle.generateKey({ name: "Ed25519" } as any, true, ["sign", "verify"]);
  const pubRaw = new Uint8Array(await crypto.subtle.exportKey("raw", (kp as CryptoKeyPair).publicKey));
  const privPkcs8 = new Uint8Array(await crypto.subtle.exportKey("pkcs8", (kp as CryptoKeyPair).privateKey));
  return {
    algorithm: "Ed25519-bridge",
    is_pqc_ready: false,
    publicKeyB64: b64encode(pubRaw),
    privateKeyB64: b64encode(privPkcs8),
    keyId: await keyIdOf(pubRaw),
  };
}

export async function signPayload(algorithm: string, privateKeyB64: string, payload: string): Promise<string> {
  const msg = new TextEncoder().encode(payload);
  if (algorithm === "ML-DSA-65") {
    const mod: any = await import("npm:@noble/post-quantum@0.2.1/ml-dsa.js");
    const sk = b64decode(privateKeyB64);
    const sig = mod.ml_dsa65.sign(sk, msg);
    return b64encode(sig);
  }
  // Ed25519
  const sk = await crypto.subtle.importKey(
    "pkcs8", b64decode(privateKeyB64), { name: "Ed25519" } as any, false, ["sign"],
  );
  const sig = new Uint8Array(await crypto.subtle.sign("Ed25519", sk, msg));
  return b64encode(sig);
}

export async function verifyPayload(algorithm: string, publicKeyB64: string, payload: string, signatureB64: string): Promise<boolean> {
  const msg = new TextEncoder().encode(payload);
  const sig = b64decode(signatureB64);
  if (algorithm === "ML-DSA-65") {
    const mod: any = await import("npm:@noble/post-quantum@0.2.1/ml-dsa.js");
    return mod.ml_dsa65.verify(b64decode(publicKeyB64), msg, sig);
  }
  const pk = await crypto.subtle.importKey(
    "raw", b64decode(publicKeyB64), { name: "Ed25519" } as any, false, ["verify"],
  );
  return await crypto.subtle.verify("Ed25519", pk, sig, msg);
}

export async function sha256Hex(s: string): Promise<string> {
  const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return Array.from(new Uint8Array(d)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
