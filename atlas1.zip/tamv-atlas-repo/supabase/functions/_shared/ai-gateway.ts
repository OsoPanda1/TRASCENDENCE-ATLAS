// Shared Lovable AI Gateway helper for Isabella modules
export const LOVABLE_AIG_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";

export interface AIGCallOptions {
  model?: string;
  system?: string;
  messages: Array<{ role: "system" | "user" | "assistant"; content: string }>;
  jsonMode?: boolean;
  temperature?: number;
}

export async function callLovableAI(opts: AIGCallOptions): Promise<{
  content: string;
  parsed?: any;
  tokens_in?: number;
  tokens_out?: number;
  latency_ms: number;
}> {
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) throw new Error("LOVABLE_API_KEY missing");

  const body: Record<string, unknown> = {
    model: opts.model ?? "google/gemini-3-flash-preview",
    messages: opts.system
      ? [{ role: "system", content: opts.system }, ...opts.messages]
      : opts.messages,
  };
  if (opts.jsonMode) body.response_format = { type: "json_object" };
  if (opts.temperature !== undefined) body.temperature = opts.temperature;

  const t0 = Date.now();
  const res = await fetch(LOVABLE_AIG_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "tamv-isabella",
    },
    body: JSON.stringify(body),
  });
  const latency_ms = Date.now() - t0;

  if (res.status === 429) throw new Error("rate_limit");
  if (res.status === 402) throw new Error("credits_exhausted");
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`gateway_error_${res.status}: ${txt.slice(0, 200)}`);
  }

  const data = await res.json();
  const content: string = data.choices?.[0]?.message?.content ?? "";
  let parsed: any = undefined;
  if (opts.jsonMode) {
    try { parsed = JSON.parse(content); } catch { /* ignore */ }
  }
  return {
    content,
    parsed,
    tokens_in: data.usage?.prompt_tokens,
    tokens_out: data.usage?.completion_tokens,
    latency_ms,
  };
}

export async function sha256(input: string): Promise<string> {
  const buf = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};
