// KYC Service — submit / status / verify (admin)
import { corsHeaders, sha256 } from "../_shared/ai-gateway.ts";
import { adminClient, getUserFromReq, isAdmin } from "../_shared/auth.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const user = await getUserFromReq(req);
    if (!user) return json({ error: "unauthorized" }, 401);

    const body = await req.json();
    const intent: string = body.intent;
    const sb = adminClient();

    if (intent === "submit") {
      const { document_type, document_payload, jurisdiction = "MX", metadata = {} } = body;
      if (!document_type || !document_payload) return json({ error: "missing_fields" }, 400);
      const document_hash = await sha256(String(document_payload));
      const { data, error } = await sb.from("kyc_records").upsert({
        user_id: user.id, status: "pending", document_hash, document_type,
        jurisdiction, metadata,
      }, { onConflict: "user_id" }).select().single();
      if (error) throw error;
      await sb.from("kyc_verifications").insert({
        kyc_id: data.id, user_id: user.id, provider: "manual",
        payload_hash: document_hash, result: "submitted",
      });
      return json({ ok: true, record: data });
    }

    if (intent === "status") {
      const { data } = await sb.from("kyc_records").select("*").eq("user_id", user.id).maybeSingle();
      return json({ record: data });
    }

    if (intent === "verify") {
      if (!(await isAdmin(user.id))) return json({ error: "forbidden" }, 403);
      const { kyc_id, decision, notes } = body;
      if (!kyc_id || !["verified", "rejected"].includes(decision)) return json({ error: "invalid" }, 400);
      const update: any = { status: decision, verifier: user.id };
      if (decision === "verified") update.verified_at = new Date().toISOString();
      if (decision === "rejected") update.rejection_reason = notes ?? "Not specified";
      const { data, error } = await sb.from("kyc_records").update(update).eq("id", kyc_id).select().single();
      if (error) throw error;
      await sb.from("kyc_verifications").insert({
        kyc_id, user_id: data.user_id, provider: "admin_review",
        payload_hash: await sha256(JSON.stringify({ kyc_id, decision })),
        result: decision, reviewer: user.id, notes,
      });
      return json({ ok: true, record: data });
    }

    if (intent === "list_pending") {
      if (!(await isAdmin(user.id))) return json({ error: "forbidden" }, 403);
      const { data } = await sb.from("kyc_records")
        .select("*").in("status", ["pending", "in_review"]).order("created_at", { ascending: false });
      return json({ records: data ?? [] });
    }

    return json({ error: "unknown_intent" }, 400);
  } catch (e) {
    console.error("[kyc-service]", e);
    return json({ error: e instanceof Error ? e.message : "internal" }, 500);
  }
});

function json(b: any, s = 200) {
  return new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
