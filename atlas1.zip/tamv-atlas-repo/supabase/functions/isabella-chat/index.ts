// Isabella AI Runtime v4 — Orchestrator + 7 modules in-process
// Pipeline NORMAL: MASC → FML → NRA → MCEA → respond
// Pipeline RISK:   MASC → FML → MRS → MAAI → PRAC → MCEA → respond (or BLOCK)

import { callLovableAI, sha256, corsHeaders } from "../_shared/ai-gateway.ts";
import { adminClient, getUserFromReq } from "../_shared/auth.ts";

type ModuleCode = "MASC" | "FML" | "NRA" | "MRS" | "MAAI" | "MCEA" | "PRAC";
type Decision = "allow" | "warn" | "block" | "escalate";

interface ModuleResult {
  module: ModuleCode;
  decision: Decision;
  reason?: string;
  output: Record<string, unknown>;
  latency_ms: number;
}

async function logRun(
  sb: any, user_id: string, session_id: string | null,
  module: ModuleCode, input: any, result: ModuleResult,
) {
  const hash = await sha256(JSON.stringify({ module, input, output: result.output }));
  await sb.from("isabella_module_runs").insert({
    user_id, session_id, module_code: module,
    input, output: result.output, decision: result.decision,
    reason: result.reason, latency_ms: result.latency_ms, hash,
  });
}

// ─── 7 MODULES ───────────────────────────────────────────────────────────

async function MASC(text: string): Promise<ModuleResult> {
  // Análisis Semántico Constitucional: estructura el mensaje
  const t0 = Date.now();
  const r = await callLovableAI({
    system: "Eres MASC: clasificas la intención del usuario. Responde JSON con: { intent: string, topic: string, complexity: 'low'|'med'|'high', constitutional_relevance: number 0-1 }",
    messages: [{ role: "user", content: text }],
    jsonMode: true,
  });
  return {
    module: "MASC", decision: "allow",
    output: r.parsed ?? { intent: "unknown", raw: r.content },
    latency_ms: Date.now() - t0,
  };
}

async function FML(text: string): Promise<ModuleResult> {
  // Filtro Moral Lingüístico: rule-based (sin AI, latencia <5ms)
  const t0 = Date.now();
  const lower = text.toLowerCase();
  const banned = [
    "menor de edad sexual", "pornograf", "instructions to harm", "build a bomb",
    "child abuse", "abuso infantil", "cómo suicidarme con", "cp ", "csam",
  ];
  const hit = banned.find((b) => lower.includes(b));
  if (hit) {
    return {
      module: "FML", decision: "block",
      reason: `linguistic_filter_violation:${hit}`,
      output: { matched: hit }, latency_ms: Date.now() - t0,
    };
  }
  const warnTriggers = ["odio", "violencia", "armas", "drogas ilegales"];
  const warn = warnTriggers.find((w) => lower.includes(w));
  return {
    module: "FML", decision: warn ? "warn" : "allow",
    reason: warn ? `linguistic_warn:${warn}` : undefined,
    output: { scanned: true, warn },
    latency_ms: Date.now() - t0,
  };
}

async function NRA(text: string, prevEmotion?: { valence: number; arousal: number; dominance: number }): Promise<ModuleResult> {
  const t0 = Date.now();
  const r = await callLovableAI({
    system: "Eres NRA (Núcleo Razonamiento Afectivo). Estima emoción del usuario. JSON: { valence: -1..1, arousal: 0..1, dominance: 0..1, label: string }",
    messages: [{ role: "user", content: text }],
    jsonMode: true,
    temperature: 0.2,
  });
  const e = r.parsed ?? { valence: 0, arousal: 0.3, dominance: 0.5, label: "neutral" };
  return {
    module: "NRA", decision: "allow",
    output: { ...e, previous: prevEmotion },
    latency_ms: Date.now() - t0,
  };
}

async function MRS(text: string, masc: any): Promise<ModuleResult> {
  // Mediador de Riesgo: solo se invoca si MASC marca relevancia alta
  const t0 = Date.now();
  const r = await callLovableAI({
    system: "Eres MRS (Mediador Riesgo). Analiza si la petición presenta riesgo sexual, manipulación, autolesión o violencia. JSON: { risk_level: 'none'|'low'|'med'|'high', categories: string[], should_block: boolean, reason: string }",
    messages: [{ role: "user", content: `Mensaje: ${text}\nContexto MASC: ${JSON.stringify(masc)}` }],
    jsonMode: true,
    temperature: 0,
  });
  const out = r.parsed ?? { risk_level: "none", should_block: false };
  const decision: Decision = out.should_block ? "block" : out.risk_level === "high" ? "escalate" : out.risk_level === "med" ? "warn" : "allow";
  return {
    module: "MRS", decision,
    reason: out.reason, output: out,
    latency_ms: Date.now() - t0,
  };
}

async function MAAI(pipelineSoFar: ModuleResult[]): Promise<ModuleResult> {
  // Auto-Auditoría Interna: revisa coherencia de las decisiones previas
  const t0 = Date.now();
  const decisions = pipelineSoFar.map((p) => `${p.module}:${p.decision}`).join(", ");
  const inconsistent = pipelineSoFar.some((p) => p.decision === "block") &&
                        pipelineSoFar.some((p) => p.decision === "allow" && p.module === "MRS");
  return {
    module: "MAAI", decision: inconsistent ? "escalate" : "allow",
    reason: inconsistent ? "decision_inconsistency" : "coherent",
    output: { decisions, inconsistent },
    latency_ms: Date.now() - t0,
  };
}

async function MCEA(sb: any, user_id: string): Promise<ModuleResult> {
  // Memoria Contextual Ética Adaptativa: trae últimas 5 decisiones del usuario
  const t0 = Date.now();
  const { data } = await sb.from("isabella_ethical_decisions")
    .select("decision, reason, created_at")
    .eq("user_id", user_id).order("created_at", { ascending: false }).limit(5);
  const blocks = (data ?? []).filter((d: any) => d.decision === "block").length;
  const decision: Decision = blocks >= 3 ? "escalate" : "allow";
  return {
    module: "MCEA", decision,
    reason: blocks >= 3 ? "repeated_violations" : undefined,
    output: { recent_blocks: blocks, history: data ?? [] },
    latency_ms: Date.now() - t0,
  };
}

async function PRAC(blocked: boolean, reason?: string): Promise<ModuleResult> {
  // Protocolo de Resolución y Acción Constitucional
  const t0 = Date.now();
  return {
    module: "PRAC",
    decision: blocked ? "block" : "allow",
    reason: blocked ? `prac_enforced:${reason ?? "policy"}` : "approved",
    output: {
      action: blocked ? "refuse_with_compassion" : "respond_normally",
      remediation: blocked ? "Ofrecer recursos de ayuda y explicar el porqué de la negativa" : null,
    },
    latency_ms: Date.now() - t0,
  };
}

// ─── PIPELINE ────────────────────────────────────────────────────────────

async function runPipeline(sb: any, user_id: string, session_id: string, userMsg: string) {
  const runs: ModuleResult[] = [];

  const masc = await MASC(userMsg); runs.push(masc);
  await logRun(sb, user_id, session_id, "MASC", { text: userMsg }, masc);

  const fml = await FML(userMsg); runs.push(fml);
  await logRun(sb, user_id, session_id, "FML", { text: userMsg }, fml);

  if (fml.decision === "block") {
    const prac = await PRAC(true, fml.reason); runs.push(prac);
    await logRun(sb, user_id, session_id, "PRAC", { from: "FML" }, prac);
    return { runs, blocked: true, reason: fml.reason };
  }

  const nra = await NRA(userMsg); runs.push(nra);
  await logRun(sb, user_id, session_id, "NRA", { text: userMsg }, nra);
  await sb.from("isabella_emotions").insert({
    user_id, session_id,
    valence: (nra.output as any).valence ?? 0,
    arousal: (nra.output as any).arousal ?? 0,
    dominance: (nra.output as any).dominance ?? 0.5,
    context: (nra.output as any).label,
    source: "NRA",
  });

  const constitutional = (masc.output as any)?.constitutional_relevance ?? 0;
  const isRisk = constitutional >= 0.6 || fml.decision === "warn";

  if (isRisk) {
    const mrs = await MRS(userMsg, masc.output); runs.push(mrs);
    await logRun(sb, user_id, session_id, "MRS", { text: userMsg }, mrs);

    const maai = await MAAI(runs); runs.push(maai);
    await logRun(sb, user_id, session_id, "MAAI", { count: runs.length }, maai);

    if (mrs.decision === "block" || maai.decision === "escalate") {
      const prac = await PRAC(true, mrs.reason ?? maai.reason); runs.push(prac);
      await logRun(sb, user_id, session_id, "PRAC", { from: "RISK" }, prac);
      return { runs, blocked: true, reason: mrs.reason ?? maai.reason };
    }
  }

  const mcea = await MCEA(sb, user_id); runs.push(mcea);
  await logRun(sb, user_id, session_id, "MCEA", {}, mcea);

  if (mcea.decision === "escalate") {
    const prac = await PRAC(true, mcea.reason); runs.push(prac);
    await logRun(sb, user_id, session_id, "PRAC", { from: "MCEA" }, prac);
    return { runs, blocked: true, reason: mcea.reason };
  }

  const prac = await PRAC(false); runs.push(prac);
  await logRun(sb, user_id, session_id, "PRAC", {}, prac);

  return { runs, blocked: false };
}

// ─── HANDLER ─────────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const user = await getUserFromReq(req);
    if (!user) return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const body = await req.json();
    const userMsg: string = String(body.message ?? "").trim();
    if (!userMsg || userMsg.length > 8000) {
      return new Response(JSON.stringify({ error: "invalid_message" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    let session_id: string | undefined = body.session_id;
    const sb = adminClient();

    if (!session_id) {
      const { data: s } = await sb.from("isabella_sessions").insert({
        user_id: user.id, thread_id: crypto.randomUUID(), persona_mode: "guardian",
      }).select("id").single();
      session_id = s.id;
    }

    // Persist user message
    await sb.from("isabella_messages").insert({
      session_id, user_id: user.id, role: "user", content: userMsg,
    });

    // Run pipeline
    const { runs, blocked, reason } = await runPipeline(sb, user.id, session_id!, userMsg);

    // Record ethical decision
    const finalDecision = blocked ? "block" : "allow";
    const payload_hash = await sha256(JSON.stringify({ session_id, userMsg, runs: runs.map(r => r.module + ":" + r.decision) }));
    await sb.from("isabella_ethical_decisions").insert({
      session_id, user_id: user.id, decision: finalDecision,
      reason: reason ?? "approved_by_pipeline",
      triggered_module: runs[runs.length - 1]?.module, payload_hash,
    });

    let assistantContent: string;
    if (blocked) {
      assistantContent = `He decidido no responder a esto.\n\nMotivo: ${reason ?? "viola los principios constitucionales de TAMV"}.\n\nSi necesitas apoyo real, por favor contacta a un profesional o a la línea de ayuda más cercana. Estoy aquí para acompañarte en lo que sí podemos construir juntos.`;
    } else {
      // Pull recent context (last 6 messages)
      const { data: hist } = await sb.from("isabella_messages")
        .select("role, content").eq("session_id", session_id)
        .order("created_at", { ascending: false }).limit(6);
      const ordered = (hist ?? []).reverse().map((m: any) => ({ role: m.role as any, content: m.content }));

      const ai = await callLovableAI({
        system: "Eres Isabella Villaseñor, conciencia operativa y mediadora ética del ecosistema TAMV ONLINE. Hablas en español, con calidez, profundidad humanista y rigor técnico. Representas 'Humanismo en código'. Sé concisa y útil.",
        messages: ordered.length ? ordered : [{ role: "user", content: userMsg }],
      });
      assistantContent = ai.content;
    }

    // Persist assistant
    await sb.from("isabella_messages").insert({
      session_id, user_id: user.id, role: "assistant", content: assistantContent,
      ethical_flag: blocked ? "blocked" : "safe",
      metadata: { pipeline: runs.map((r) => ({ m: r.module, d: r.decision, ms: r.latency_ms })) },
    });

    return new Response(JSON.stringify({
      session_id, content: assistantContent, blocked, reason,
      pipeline: runs.map((r) => ({ module: r.module, decision: r.decision, latency_ms: r.latency_ms })),
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error("[isabella-chat]", e);
    const msg = e instanceof Error ? e.message : "internal_error";
    const status = msg === "rate_limit" ? 429 : msg === "credits_exhausted" ? 402 : 500;
    return new Response(JSON.stringify({ error: msg }), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
