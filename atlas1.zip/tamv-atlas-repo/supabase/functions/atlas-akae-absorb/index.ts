// AKAE — Atlas Knowledge Absorption Engine
// Absorbs heterogeneous payloads (file list + raw content) into canon_entities + canon_relations
// with deterministic scoring and full audit trail.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

interface AbsorbFile {
  path: string;
  content: string;
  source: string; // e.g. "upload://kernel-tamv-main.zip"
}

interface AbsorbRequest {
  source_label: string;
  source_type: "zip" | "git" | "upload" | "text";
  files: AbsorbFile[];
  default_domain?: string;
  default_risk?: "PUBLIC" | "INTERNAL" | "CROWN_JEWEL";
}

async function sha256(t: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t));
  return Array.from(new Uint8Array(buf)).map(x => x.toString(16).padStart(2, "0")).join("");
}

function classify(path: string, content: string) {
  const p = path.toLowerCase();
  let type = "artifact";
  if (/readme/i.test(p)) type = "readme";
  else if (/\.(md|mdx)$/.test(p)) type = "document";
  else if (/package\.json$/.test(p)) type = "manifest";
  else if (/tsconfig\.json$/.test(p)) type = "config";
  else if (/docker-?compose|kustomization|deployment\.yaml$/.test(p)) type = "topology";
  else if (/\.(ya?ml|toml|json)$/.test(p)) type = "config";
  else if (/\.(ts|tsx|js|jsx|py|rs|go|sql)$/.test(p)) type = "code";

  const haystack = (p + " " + content.slice(0, 4000)).toLowerCase();
  let domain = "infra";
  if (/isabella|cogniti|reason|llm|ai\b/.test(haystack)) domain = "cognitivo";
  else if (/utamv|campus|course|academ|lesson/.test(haystack)) domain = "educativo";
  else if (/odoo|wallet|tcep|economy|stripe|credit/.test(haystack)) domain = "economico";
  else if (/xr|metaverse|three|webxr/.test(haystack)) domain = "xr";
  else if (/atlas|kernel|canon|federation|isni/.test(haystack)) domain = "canon";
  else if (/turismo|territor|ciudad|urban|mineral del monte/.test(haystack)) domain = "urbano";
  return { type, domain };
}

function extractTitle(path: string, content: string): string {
  const h1 = content.match(/^#\s+(.+)$/m);
  if (h1) return h1[1].trim().slice(0, 200);
  return (path.split("/").pop() ?? path).slice(0, 200);
}

function scoreConfianza(source_type: string, hasFrontmatter: boolean, size: number): number {
  let s = 0.5;
  if (source_type === "git") s += 0.2;
  if (hasFrontmatter) s += 0.15;
  if (size > 200 && size < 200_000) s += 0.1;
  return Math.min(1, s);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const supa = createClient(SUPABASE_URL, SERVICE_KEY);

  try {
    const body = (await req.json()) as AbsorbRequest;
    if (!body?.files?.length) throw new Error("files[] required");

    const trace_id = `akae-${Date.now().toString(36)}-${crypto.randomUUID().slice(0, 8)}`;
    const { data: job } = await supa.from("akae_jobs").insert({
      source_type: body.source_type,
      source_ref: body.source_label,
      status: "running",
      files_total: body.files.length,
      trace_id,
    }).select("id").single();

    const containerCanon = `tamv://akae/${encodeURIComponent(body.source_label)}`;
    await supa.from("canon_entities").upsert({
      canonical_id: containerCanon,
      type: "corpus",
      federation: "atlas",
      domain_v2: "canon",
      subdomain: body.source_label,
      title: body.source_label,
      description: `AKAE corpus container: ${body.source_label}`,
      hash: await sha256(containerCanon),
      score_integridad: 1.0,
      score_confianza: 0.9,
      risk_level: body.default_risk ?? "INTERNAL",
      metadata: { trace_id, source_type: body.source_type },
    }, { onConflict: "canonical_id" });

    let entities = 0, relations = 0, skipped = 0;
    const relRows: any[] = [];

    for (const f of body.files) {
      const content = (f.content ?? "").slice(0, 120_000);
      const canonical_id = `tamv://akae/${encodeURIComponent(body.source_label)}#${f.path}`;
      const hash = await sha256(content);

      const { data: existing } = await supa.from("canon_entities")
        .select("hash, version").eq("canonical_id", canonical_id).maybeSingle();
      if (existing?.hash === hash) { skipped++; continue; }

      const { type, domain } = classify(f.path, content);
      const title = extractTitle(f.path, content);
      const description = content.replace(/```[\s\S]*?```/g, "")
        .replace(/[*_`>#-]/g, " ").replace(/\s+/g, " ").trim().slice(0, 400);
      const hasFM = /^---\n/.test(content);
      const conf = scoreConfianza(body.source_type, hasFM, content.length);

      await supa.from("canon_entities").upsert({
        canonical_id,
        type,
        federation: body.default_domain ?? "atlas",
        domain_v2: domain,
        subdomain: body.source_label,
        title,
        description,
        hash,
        previous_hash: existing?.hash ?? null,
        version: (existing?.version ?? 0) + 1,
        score_integridad: 1.0,
        score_confianza: conf,
        risk_level: body.default_risk ?? "PUBLIC",
        source_refs: [f.source],
        metadata: { path: f.path, trace_id, akae_version: "1.0" },
        updated_at: new Date().toISOString(),
      }, { onConflict: "canonical_id" });

      relRows.push({
        source_canonical_id: containerCanon,
        target_canonical_id: canonical_id,
        relation_type: "CONTAINS",
      });
      entities++;
    }

    if (relRows.length) {
      await supa.from("canon_relations").upsert(relRows, {
        onConflict: "source_canonical_id,target_canonical_id,relation_type",
      });
      relations = relRows.length;
    }

    await supa.from("bookpi_events").insert({
      event_type: "AKAE_ABSORB",
      entity_canonical_ids: [containerCanon],
      source: body.source_label,
      trace_id,
      hash: await sha256(`${containerCanon}:${entities}:${skipped}`),
      payload: { entities, relations, skipped, files: body.files.length },
    });

    await supa.from("akae_jobs").update({
      status: "done",
      files_done: body.files.length,
      entities_created: entities,
      relations_created: relations,
      finished_at: new Date().toISOString(),
    }).eq("id", job?.id);

    return new Response(JSON.stringify({
      ok: true, trace_id, entities, relations, skipped, container: containerCanon,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: (e as Error).message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
