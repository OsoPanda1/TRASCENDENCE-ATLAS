// Embeddings indexer: re-embeds canon_entities or isabella_memory rows
// using Lovable AI Gateway (google/gemini-embedding-001 → 1536 dims).
import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { z } from "npm:zod@3";

const BodySchema = z.object({
  target: z.enum(["canon_entities", "isabella_memory"]),
  batch_size: z.number().int().min(1).max(100).default(20),
  query_text: z.string().min(1).max(8000).optional(),  // when present → embed-on-demand, no DB write
});

const AI_KEY = Deno.env.get("LOVABLE_API_KEY")!;
const MODEL = "google/gemini-embedding-001";

async function embed(texts: string[]): Promise<number[][]> {
  const r = await fetch("https://ai.gateway.lovable.dev/v1/embeddings", {
    method: "POST",
    headers: { "Authorization": `Bearer ${AI_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: MODEL, input: texts, dimensions: 1536 }),
  });
  if (!r.ok) {
    const t = await r.text();
    throw new Error(`embeddings ${r.status}: ${t.slice(0, 200)}`);
  }
  const data = await r.json();
  return data.data.map((d: { embedding: number[] }) => d.embedding);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = BodySchema.parse(await req.json().catch(() => ({ target: "canon_entities" })));
    const supa = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    if (body.query_text) {
      const [vec] = await embed([body.query_text]);
      return new Response(JSON.stringify({ ok: true, embedding: vec, dims: vec.length }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let processed = 0, failed = 0;
    if (body.target === "canon_entities") {
      const { data: rows, error } = await supa.from("canon_entities")
        .select("canonical_id, title, description")
        .is("vector_embedding", null)
        .limit(body.batch_size);
      if (error) throw new Error(error.message);
      if (rows && rows.length) {
        const texts = rows.map((r) => `${r.title}\n${r.description ?? ""}`.slice(0, 8000));
        try {
          const vecs = await embed(texts);
          for (let i = 0; i < rows.length; i++) {
            const { error: uerr } = await supa.from("canon_entities").update({
              vector_embedding: vecs[i] as unknown as string,
              embedding_model: MODEL,
              embedded_at: new Date().toISOString(),
            }).eq("canonical_id", rows[i].canonical_id);
            if (uerr) { failed++; console.error("[emb] update failed:", uerr.message); }
            else processed++;
          }
        } catch (e) { failed += rows.length; console.error("[emb] batch failed:", e); }
      }
    } else {
      const { data: rows, error } = await supa.from("isabella_memory")
        .select("id, content")
        .is("vector_embedding", null)
        .limit(body.batch_size);
      if (error) throw new Error(error.message);
      if (rows && rows.length) {
        const texts = rows.map((r) => (r.content ?? "").slice(0, 8000));
        try {
          const vecs = await embed(texts);
          for (let i = 0; i < rows.length; i++) {
            const { error: uerr } = await supa.from("isabella_memory").update({
              vector_embedding: vecs[i] as unknown as string,
              embedding_model: MODEL,
            }).eq("id", rows[i].id);
            if (uerr) failed++; else processed++;
          }
        } catch (e) { failed += rows.length; console.error("[emb] batch failed:", e); }
      }
    }

    return new Response(JSON.stringify({ ok: true, target: body.target, processed, failed }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: e instanceof Error ? e.message : String(e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
