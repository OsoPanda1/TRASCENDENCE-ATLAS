import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { createClient } from "npm:@supabase/supabase-js@2";
import { z } from "npm:zod@3";
import { sha256 } from "../_shared/security.ts";

const Body = z.object({ course_id: z.string().uuid(), score: z.number().min(0).max(1).default(1) });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) return json({ error: "Unauthorized" }, 401);
    const userClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: auth } },
    });
    const { data: claims } = await userClient.auth.getClaims(auth.replace("Bearer ", ""));
    if (!claims?.claims) return json({ error: "Unauthorized" }, 401);
    const userId = claims.claims.sub as string;

    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) return json({ error: parsed.error.flatten() }, 400);

    const svc = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: enr } = await svc.from("utamv_enrollments")
      .select("id,progress").eq("user_id", userId).eq("course_id", parsed.data.course_id).maybeSingle();
    if (!enr || (enr.progress ?? 0) < parsed.data.score) return json({ error: "Course not completed" }, 400);

    const certificate_code = `UTAMV-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    const payload = {
      certificate_code, user_id: userId, course_id: parsed.data.course_id, score: parsed.data.score,
      issued_at: new Date().toISOString(), issuer: "UTAMV — Universidad Tecnológica Meta Virtual",
    };
    const hash = await sha256(JSON.stringify(payload));

    const { data: cert, error } = await svc.from("utamv_certificates").insert({
      user_id: userId, course_id: parsed.data.course_id, certificate_code, payload, hash,
    }).select().maybeSingle();
    if (error) return json({ error: error.message }, 400);

    return json({ certificate: cert });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});

function json(b: unknown, s = 200) {
  return new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
