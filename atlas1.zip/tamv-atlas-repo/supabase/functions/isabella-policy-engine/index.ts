import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { createClient } from "npm:@supabase/supabase-js@2";
import { z } from "npm:zod@3";
import { detectPromptInjection, filterPII, filterSecrets, checkRateLimit, svc } from "../_shared/security.ts";

const Body = z.object({
  text: z.string().min(1).max(20000),
  stage: z.enum(["pre", "post"]).default("pre"),
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) return json({ error: "Unauthorized" }, 401);
    const supa = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: auth } },
    });
    const { data: claims } = await supa.auth.getClaims(auth.replace("Bearer ", ""));
    if (!claims?.claims) return json({ error: "Unauthorized" }, 401);
    const userId = claims.claims.sub as string;
    if (!(await checkRateLimit(userId, "policy", 60))) return json({ error: "Rate limited" }, 429);

    const parsed = Body.safeParse(await req.json());
    if (!parsed.success) return json({ error: parsed.error.flatten() }, 400);
    const { text, stage } = parsed.data;

    const matches: Array<{ code: string; decision: string; category: string }> = [];

    // Load enabled policies sorted by priority.
    const { data: policies } = await svc().from("isabella_policies")
      .select("code,decision,pattern,category,priority").eq("enabled", true).order("priority", { ascending: true });

    let finalDecision = "allow";
    let redacted = text;

    for (const p of policies ?? []) {
      if (!p.pattern) continue;
      try {
        const re = new RegExp(p.pattern, "i");
        if (re.test(redacted)) {
          matches.push({ code: p.code, decision: p.decision, category: p.category });
          if (p.decision === "deny" || p.decision === "escalate") { finalDecision = p.decision; break; }
          if (p.decision === "filter") {
            redacted = filterSecrets(filterPII(redacted).redacted).redacted;
          }
        }
      } catch { /* ignore bad regex */ }
    }

    // Heuristic prompt-injection check for pre-stage
    if (stage === "pre") {
      const pi = detectPromptInjection(text);
      if (pi.hit) { matches.push({ code: "heuristic_injection", decision: "deny", category: "injection" }); finalDecision = "deny"; }
    }

    return json({ decision: finalDecision, matched: matches, redacted });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});

function json(b: unknown, s = 200) {
  return new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
