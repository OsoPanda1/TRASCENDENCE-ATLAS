-- AKAE extensions
ALTER TABLE public.canon_entities
  ADD COLUMN IF NOT EXISTS score_integridad numeric DEFAULT 1.0,
  ADD COLUMN IF NOT EXISTS score_confianza numeric DEFAULT 0.5,
  ADD COLUMN IF NOT EXISTS domain_v2 text,
  ADD COLUMN IF NOT EXISTS subdomain text,
  ADD COLUMN IF NOT EXISTS risk_level text DEFAULT 'PUBLIC';

CREATE INDEX IF NOT EXISTS idx_canon_entities_domain_v2 ON public.canon_entities(domain_v2);
CREATE INDEX IF NOT EXISTS idx_canon_entities_risk_level ON public.canon_entities(risk_level);

-- AKAE jobs queue
CREATE TABLE IF NOT EXISTS public.akae_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_type text NOT NULL,
  source_ref text NOT NULL,
  status text NOT NULL DEFAULT 'queued',
  files_total int DEFAULT 0,
  files_done int DEFAULT 0,
  entities_created int DEFAULT 0,
  relations_created int DEFAULT 0,
  error text,
  payload jsonb DEFAULT '{}'::jsonb,
  trace_id text,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);
GRANT SELECT ON public.akae_jobs TO authenticated;
GRANT ALL ON public.akae_jobs TO service_role;
ALTER TABLE public.akae_jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "akae_jobs gobierno read" ON public.akae_jobs FOR SELECT TO authenticated
  USING (public.has_min_role(auth.uid(), 'gobierno'));
CREATE TRIGGER trg_akae_jobs_updated BEFORE UPDATE ON public.akae_jobs
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Atlas Shell command audit log
CREATE TABLE IF NOT EXISTS public.atlas_shell_commands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  command text NOT NULL,
  args jsonb DEFAULT '{}'::jsonb,
  result jsonb DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'ok',
  duration_ms int,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.atlas_shell_commands TO authenticated;
GRANT ALL ON public.atlas_shell_commands TO service_role;
ALTER TABLE public.atlas_shell_commands ENABLE ROW LEVEL SECURITY;
CREATE POLICY "shell read own or gobierno" ON public.atlas_shell_commands FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_min_role(auth.uid(), 'gobierno'));