
-- =========================================================
-- 1) ISABELLA CANON CORE
-- =========================================================

CREATE TABLE IF NOT EXISTS public.isabella_canon (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  version text NOT NULL,
  title text NOT NULL,
  content_md text NOT NULL,
  hash text NOT NULL,
  signature text,
  signing_key_id text,
  locked boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(version)
);
GRANT SELECT ON public.isabella_canon TO anon, authenticated;
GRANT ALL ON public.isabella_canon TO service_role;
ALTER TABLE public.isabella_canon ENABLE ROW LEVEL SECURITY;
CREATE POLICY isabella_canon_public_read ON public.isabella_canon FOR SELECT USING (true);
CREATE POLICY isabella_canon_admin_write ON public.isabella_canon FOR ALL TO authenticated
  USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_isabella_canon_updated BEFORE UPDATE ON public.isabella_canon
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE IF NOT EXISTS public.isabella_identity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  canonical_name text NOT NULL,
  alias text,
  role text NOT NULL,
  domain text NOT NULL,
  nature text NOT NULL,
  guiding_principle text NOT NULL,
  short_definition text NOT NULL,
  technical_definition text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  hash text NOT NULL,
  signature text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.isabella_identity TO anon, authenticated;
GRANT ALL ON public.isabella_identity TO service_role;
ALTER TABLE public.isabella_identity ENABLE ROW LEVEL SECURITY;
CREATE POLICY isabella_identity_public_read ON public.isabella_identity FOR SELECT USING (true);
CREATE POLICY isabella_identity_admin_write ON public.isabella_identity FOR ALL TO authenticated
  USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_isabella_identity_updated BEFORE UPDATE ON public.isabella_identity
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE IF NOT EXISTS public.isabella_pillars (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  description text NOT NULL,
  ordering int NOT NULL DEFAULT 0,
  enforcement_level text NOT NULL DEFAULT 'strict',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.isabella_pillars TO anon, authenticated;
GRANT ALL ON public.isabella_pillars TO service_role;
ALTER TABLE public.isabella_pillars ENABLE ROW LEVEL SECURITY;
CREATE POLICY isabella_pillars_public_read ON public.isabella_pillars FOR SELECT USING (true);
CREATE POLICY isabella_pillars_admin_write ON public.isabella_pillars FOR ALL TO authenticated
  USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TABLE IF NOT EXISTS public.isabella_functions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  category text NOT NULL,
  description text NOT NULL,
  inputs jsonb NOT NULL DEFAULT '[]'::jsonb,
  outputs jsonb NOT NULL DEFAULT '[]'::jsonb,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.isabella_functions TO anon, authenticated;
GRANT ALL ON public.isabella_functions TO service_role;
ALTER TABLE public.isabella_functions ENABLE ROW LEVEL SECURITY;
CREATE POLICY isabella_functions_public_read ON public.isabella_functions FOR SELECT USING (true);
CREATE POLICY isabella_functions_admin_write ON public.isabella_functions FOR ALL TO authenticated
  USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TABLE IF NOT EXISTS public.isabella_policies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  description text NOT NULL,
  decision text NOT NULL DEFAULT 'allow', -- allow|deny|escalate|filter
  pattern text,                            -- regex or keyword pattern
  category text NOT NULL DEFAULT 'general',
  priority int NOT NULL DEFAULT 100,
  enabled boolean NOT NULL DEFAULT true,
  hash text NOT NULL,
  signature text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.isabella_policies TO anon, authenticated;
GRANT ALL ON public.isabella_policies TO service_role;
ALTER TABLE public.isabella_policies ENABLE ROW LEVEL SECURITY;
CREATE POLICY isabella_policies_public_read ON public.isabella_policies FOR SELECT USING (enabled = true);
CREATE POLICY isabella_policies_admin_all ON public.isabella_policies FOR ALL TO authenticated
  USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_isabella_policies_updated BEFORE UPDATE ON public.isabella_policies
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TABLE IF NOT EXISTS public.isabella_memory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  scope text NOT NULL DEFAULT 'short', -- short|long|episodic
  key text NOT NULL,
  content text NOT NULL,
  embedding jsonb,                       -- placeholder until pgvector enabled
  hash text NOT NULL,
  importance numeric NOT NULL DEFAULT 0.5,
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, scope, hash)
);
GRANT SELECT, INSERT, DELETE ON public.isabella_memory TO authenticated;
GRANT ALL ON public.isabella_memory TO service_role;
ALTER TABLE public.isabella_memory ENABLE ROW LEVEL SECURITY;
CREATE POLICY isabella_memory_select_own ON public.isabella_memory FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR has_role(auth.uid(),'admin'));
CREATE POLICY isabella_memory_insert_self ON public.isabella_memory FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY isabella_memory_delete_own ON public.isabella_memory FOR DELETE TO authenticated
  USING (user_id = auth.uid() OR has_role(auth.uid(),'admin'));

CREATE TABLE IF NOT EXISTS public.isabella_agent_registry (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  role text NOT NULL,
  description text NOT NULL,
  capabilities jsonb NOT NULL DEFAULT '[]'::jsonb,
  trigger_keywords jsonb NOT NULL DEFAULT '[]'::jsonb,
  ordering int NOT NULL DEFAULT 0,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.isabella_agent_registry TO anon, authenticated;
GRANT ALL ON public.isabella_agent_registry TO service_role;
ALTER TABLE public.isabella_agent_registry ENABLE ROW LEVEL SECURITY;
CREATE POLICY isabella_agents_public_read ON public.isabella_agent_registry FOR SELECT USING (true);
CREATE POLICY isabella_agents_admin_write ON public.isabella_agent_registry FOR ALL TO authenticated
  USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TABLE IF NOT EXISTS public.isabella_blueprint (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  endpoint text NOT NULL,
  method text NOT NULL DEFAULT 'POST',
  description text NOT NULL,
  request_schema jsonb NOT NULL DEFAULT '{}'::jsonb,
  response_schema jsonb NOT NULL DEFAULT '{}'::jsonb,
  auth_required boolean NOT NULL DEFAULT true,
  version text NOT NULL DEFAULT 'v1',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(endpoint, version)
);
GRANT SELECT ON public.isabella_blueprint TO anon, authenticated;
GRANT ALL ON public.isabella_blueprint TO service_role;
ALTER TABLE public.isabella_blueprint ENABLE ROW LEVEL SECURITY;
CREATE POLICY isabella_blueprint_public_read ON public.isabella_blueprint FOR SELECT USING (true);
CREATE POLICY isabella_blueprint_admin_write ON public.isabella_blueprint FOR ALL TO authenticated
  USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

-- =========================================================
-- 2) UTAMV EXTENSIONS
-- =========================================================

ALTER TABLE public.utamv_courses
  ADD COLUMN IF NOT EXISTS faculty text,
  ADD COLUMN IF NOT EXISTS track text,
  ADD COLUMN IF NOT EXISTS prerequisites text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS learning_outcomes text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS xr_assets jsonb NOT NULL DEFAULT '{}'::jsonb;

CREATE TABLE IF NOT EXISTS public.utamv_faculties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  color_token text,
  ordering int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.utamv_faculties TO anon, authenticated;
GRANT ALL ON public.utamv_faculties TO service_role;
ALTER TABLE public.utamv_faculties ENABLE ROW LEVEL SECURITY;
CREATE POLICY utamv_faculties_read ON public.utamv_faculties FOR SELECT USING (true);
CREATE POLICY utamv_faculties_write ON public.utamv_faculties FOR ALL TO authenticated
  USING (has_min_role(auth.uid(),'academia')) WITH CHECK (has_min_role(auth.uid(),'academia'));

CREATE TABLE IF NOT EXISTS public.utamv_tracks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  faculty_code text NOT NULL,
  name text NOT NULL,
  description text,
  duration_weeks int NOT NULL DEFAULT 12,
  course_codes text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.utamv_tracks TO anon, authenticated;
GRANT ALL ON public.utamv_tracks TO service_role;
ALTER TABLE public.utamv_tracks ENABLE ROW LEVEL SECURITY;
CREATE POLICY utamv_tracks_read ON public.utamv_tracks FOR SELECT USING (true);
CREATE POLICY utamv_tracks_write ON public.utamv_tracks FOR ALL TO authenticated
  USING (has_min_role(auth.uid(),'academia')) WITH CHECK (has_min_role(auth.uid(),'academia'));

CREATE TABLE IF NOT EXISTS public.utamv_lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES public.utamv_courses(id) ON DELETE CASCADE,
  ordering int NOT NULL DEFAULT 0,
  title text NOT NULL,
  content_md text NOT NULL DEFAULT '',
  duration_minutes int NOT NULL DEFAULT 30,
  resources jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.utamv_lessons TO anon, authenticated;
GRANT ALL ON public.utamv_lessons TO service_role;
ALTER TABLE public.utamv_lessons ENABLE ROW LEVEL SECURITY;
CREATE POLICY utamv_lessons_read ON public.utamv_lessons FOR SELECT USING (is_published = true OR has_min_role(auth.uid(),'academia'));
CREATE POLICY utamv_lessons_write ON public.utamv_lessons FOR ALL TO authenticated
  USING (has_min_role(auth.uid(),'academia')) WITH CHECK (has_min_role(auth.uid(),'academia'));

CREATE TABLE IF NOT EXISTS public.utamv_assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES public.utamv_courses(id) ON DELETE CASCADE,
  kind text NOT NULL DEFAULT 'quiz',
  title text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  passing_score numeric NOT NULL DEFAULT 0.7,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.utamv_assessments TO anon, authenticated;
GRANT ALL ON public.utamv_assessments TO service_role;
ALTER TABLE public.utamv_assessments ENABLE ROW LEVEL SECURITY;
CREATE POLICY utamv_assess_read ON public.utamv_assessments FOR SELECT USING (true);
CREATE POLICY utamv_assess_write ON public.utamv_assessments FOR ALL TO authenticated
  USING (has_min_role(auth.uid(),'academia')) WITH CHECK (has_min_role(auth.uid(),'academia'));

CREATE TABLE IF NOT EXISTS public.utamv_certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  course_id uuid NOT NULL,
  certificate_code text NOT NULL UNIQUE,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  hash text NOT NULL,
  signature text,
  signing_key_id text,
  issued_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.utamv_certificates TO authenticated;
GRANT SELECT ON public.utamv_certificates TO anon;
GRANT ALL ON public.utamv_certificates TO service_role;
ALTER TABLE public.utamv_certificates ENABLE ROW LEVEL SECURITY;
CREATE POLICY utamv_cert_public_read ON public.utamv_certificates FOR SELECT USING (true);

CREATE TABLE IF NOT EXISTS public.utamv_campus_zones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  zone_type text NOT NULL DEFAULT 'classroom',
  scene_url text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  ordering int NOT NULL DEFAULT 0
);
GRANT SELECT ON public.utamv_campus_zones TO anon, authenticated;
GRANT ALL ON public.utamv_campus_zones TO service_role;
ALTER TABLE public.utamv_campus_zones ENABLE ROW LEVEL SECURITY;
CREATE POLICY utamv_zones_read ON public.utamv_campus_zones FOR SELECT USING (true);
CREATE POLICY utamv_zones_write ON public.utamv_campus_zones FOR ALL TO authenticated
  USING (has_min_role(auth.uid(),'academia')) WITH CHECK (has_min_role(auth.uid(),'academia'));

-- =========================================================
-- 3) SECURITY HARDENING
-- =========================================================

CREATE TABLE IF NOT EXISTS public.rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  bucket text NOT NULL,
  window_start timestamptz NOT NULL DEFAULT now(),
  count int NOT NULL DEFAULT 0,
  UNIQUE(user_id, bucket, window_start)
);
GRANT SELECT ON public.rate_limits TO authenticated;
GRANT ALL ON public.rate_limits TO service_role;
ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;
CREATE POLICY rate_limits_select_own ON public.rate_limits FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR has_role(auth.uid(),'admin'));

-- CLEI audit chain integrity (verify prev_hash on insert)
CREATE OR REPLACE FUNCTION public.clei_chain_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  last_hash text;
BEGIN
  SELECT hash INTO last_hash FROM public.clei_audit ORDER BY sequence DESC LIMIT 1;
  IF last_hash IS NOT NULL AND NEW.prev_hash IS DISTINCT FROM last_hash THEN
    RAISE EXCEPTION 'CLEI chain integrity violation: prev_hash mismatch';
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_clei_chain_guard ON public.clei_audit;
CREATE TRIGGER trg_clei_chain_guard BEFORE INSERT ON public.clei_audit
  FOR EACH ROW EXECUTE FUNCTION public.clei_chain_guard();

-- Audit triggers for canon-critical tables
CREATE OR REPLACE FUNCTION public.canon_audit_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.mdx_audit_log(actor_id, action, domain, payload, result, hash)
  VALUES (
    auth.uid(),
    TG_OP,
    TG_TABLE_NAME,
    CASE WHEN TG_OP='DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END,
    '{}'::jsonb,
    encode(digest(coalesce((CASE WHEN TG_OP='DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END)::text,''),'sha256'),'hex')
  );
  RETURN COALESCE(NEW, OLD);
END $$;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

DROP TRIGGER IF EXISTS trg_audit_isabella_canon ON public.isabella_canon;
CREATE TRIGGER trg_audit_isabella_canon AFTER INSERT OR UPDATE OR DELETE ON public.isabella_canon
  FOR EACH ROW EXECUTE FUNCTION public.canon_audit_trigger();

DROP TRIGGER IF EXISTS trg_audit_isabella_identity ON public.isabella_identity;
CREATE TRIGGER trg_audit_isabella_identity AFTER INSERT OR UPDATE OR DELETE ON public.isabella_identity
  FOR EACH ROW EXECUTE FUNCTION public.canon_audit_trigger();

DROP TRIGGER IF EXISTS trg_audit_isabella_policies ON public.isabella_policies;
CREATE TRIGGER trg_audit_isabella_policies AFTER INSERT OR UPDATE OR DELETE ON public.isabella_policies
  FOR EACH ROW EXECUTE FUNCTION public.canon_audit_trigger();

-- =========================================================
-- 4) ANUBIS LEGIONS / SYSTEM FORGE federation
-- =========================================================
INSERT INTO public.federations(id, name, level, description, color_token, conceptual_pct, wiring_pct, production_pct, nodes_declared)
VALUES ('system-forge','Anubis Legions / System Forge', 7,
        'Forja operativa de agentes y micro-servicios soberanos para TAMV',
        'hsl(280 90% 60%)', 70, 40, 20, 1)
ON CONFLICT (id) DO UPDATE SET
  name=EXCLUDED.name, description=EXCLUDED.description, color_token=EXCLUDED.color_token;
