
CREATE OR REPLACE FUNCTION public.canon_audit_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  INSERT INTO public.mdx_audit_log(actor_id, action, domain, payload, result, hash)
  VALUES (
    auth.uid(),
    TG_OP,
    TG_TABLE_NAME,
    CASE WHEN TG_OP='DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END,
    '{}'::jsonb,
    encode(extensions.digest(coalesce((CASE WHEN TG_OP='DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END)::text,''),'sha256'),'hex')
  );
  RETURN COALESCE(NEW, OLD);
END $$;
