
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

ALTER TABLE public.isabella_memory ADD COLUMN IF NOT EXISTS vector_embedding vector(1536);
ALTER TABLE public.isabella_memory ADD COLUMN IF NOT EXISTS embedding_model text DEFAULT 'google/gemini-embedding-001';
CREATE INDEX IF NOT EXISTS isabella_memory_vec_idx
  ON public.isabella_memory USING hnsw (vector_embedding vector_cosine_ops);

ALTER TABLE public.canon_entities ADD COLUMN IF NOT EXISTS vector_embedding vector(1536);
ALTER TABLE public.canon_entities ADD COLUMN IF NOT EXISTS embedding_model text;
ALTER TABLE public.canon_entities ADD COLUMN IF NOT EXISTS embedded_at timestamptz;
CREATE INDEX IF NOT EXISTS canon_entities_vec_idx
  ON public.canon_entities USING hnsw (vector_embedding vector_cosine_ops);
CREATE INDEX IF NOT EXISTS canon_entities_title_trgm_idx
  ON public.canon_entities USING gin (title gin_trgm_ops);

CREATE OR REPLACE FUNCTION public.match_isabella_memory(
  query_embedding vector(1536),
  match_user_id uuid,
  match_count int DEFAULT 5,
  min_similarity float DEFAULT 0.6
)
RETURNS TABLE (id uuid, scope text, key text, content text, importance numeric, similarity float)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT m.id, m.scope, m.key, m.content, m.importance,
         1 - (m.vector_embedding <=> query_embedding) AS similarity
  FROM public.isabella_memory m
  WHERE m.user_id = match_user_id
    AND m.vector_embedding IS NOT NULL
    AND (m.expires_at IS NULL OR m.expires_at > now())
    AND 1 - (m.vector_embedding <=> query_embedding) >= min_similarity
  ORDER BY m.vector_embedding <=> query_embedding
  LIMIT match_count;
$$;

CREATE OR REPLACE FUNCTION public.match_canon_entities(
  query_embedding vector(1536),
  match_count int DEFAULT 10,
  filter_federation text DEFAULT NULL,
  min_similarity float DEFAULT 0.5
)
RETURNS TABLE (canonical_id text, type text, federation text, title text, description text, similarity float)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT e.canonical_id, e.type, e.federation, e.title, e.description,
         1 - (e.vector_embedding <=> query_embedding) AS similarity
  FROM public.canon_entities e
  WHERE e.vector_embedding IS NOT NULL
    AND (filter_federation IS NULL OR e.federation = filter_federation)
    AND 1 - (e.vector_embedding <=> query_embedding) >= min_similarity
  ORDER BY e.vector_embedding <=> query_embedding
  LIMIT match_count;
$$;

GRANT EXECUTE ON FUNCTION public.match_isabella_memory(vector, uuid, int, float) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.match_canon_entities(vector, int, text, float) TO anon, authenticated, service_role;

CREATE TABLE IF NOT EXISTS public.compliance_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module text NOT NULL,
  total_runs int NOT NULL DEFAULT 0,
  clean_runs int NOT NULL DEFAULT 0,
  blocked_runs int NOT NULL DEFAULT 0,
  latency_p50_ms int,
  latency_p95_ms int,
  window_start timestamptz NOT NULL DEFAULT now(),
  window_end timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.compliance_runs TO anon, authenticated;
GRANT ALL ON public.compliance_runs TO service_role;
ALTER TABLE public.compliance_runs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS compliance_runs_public_read ON public.compliance_runs;
CREATE POLICY compliance_runs_public_read ON public.compliance_runs FOR SELECT USING (true);

CREATE TABLE IF NOT EXISTS public.org_sync_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner text NOT NULL,
  total_repos int NOT NULL DEFAULT 0,
  new_repos int NOT NULL DEFAULT 0,
  updated_repos int NOT NULL DEFAULT 0,
  failed_repos int NOT NULL DEFAULT 0,
  rate_limit_remaining int,
  status text NOT NULL DEFAULT 'running',
  trace_id text NOT NULL,
  started_by uuid,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  error text
);
GRANT SELECT ON public.org_sync_runs TO anon, authenticated;
GRANT ALL ON public.org_sync_runs TO service_role;
ALTER TABLE public.org_sync_runs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS org_sync_runs_public_read ON public.org_sync_runs;
CREATE POLICY org_sync_runs_public_read ON public.org_sync_runs FOR SELECT USING (true);

CREATE INDEX IF NOT EXISTS clei_audit_created_at_idx ON public.clei_audit (created_at DESC);
CREATE INDEX IF NOT EXISTS clei_audit_event_type_idx ON public.clei_audit (event_type);
CREATE INDEX IF NOT EXISTS mdx_audit_created_at_idx ON public.mdx_audit_log (created_at DESC);
CREATE INDEX IF NOT EXISTS mdx_audit_domain_idx ON public.mdx_audit_log (domain);
CREATE INDEX IF NOT EXISTS isabella_module_runs_created_idx ON public.isabella_module_runs (created_at DESC);
CREATE INDEX IF NOT EXISTS canon_entities_federation_idx ON public.canon_entities (federation);
CREATE INDEX IF NOT EXISTS canon_entities_type_idx ON public.canon_entities (type);
