
-- 1. Embedding dirty flags on canon_entities
ALTER TABLE public.canon_entities
  ADD COLUMN IF NOT EXISTS embedding_dirty boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS embedding_version integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS embedding_indexed_at timestamptz;

CREATE INDEX IF NOT EXISTS canon_entities_embedding_dirty_idx
  ON public.canon_entities (embedding_dirty) WHERE embedding_dirty = true;

CREATE OR REPLACE FUNCTION public.mark_canon_embedding_dirty()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    NEW.embedding_dirty := true;
    RETURN NEW;
  END IF;
  IF NEW.title IS DISTINCT FROM OLD.title
     OR NEW.description IS DISTINCT FROM OLD.description
     OR NEW.content IS DISTINCT FROM OLD.content THEN
    NEW.embedding_dirty := true;
    NEW.embedding_version := COALESCE(OLD.embedding_version, 0) + 1;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_canon_embedding_dirty ON public.canon_entities;
CREATE TRIGGER trg_canon_embedding_dirty
BEFORE INSERT OR UPDATE ON public.canon_entities
FOR EACH ROW EXECUTE FUNCTION public.mark_canon_embedding_dirty();

-- 2. Reindex runs
CREATE TABLE IF NOT EXISTS public.embedding_reindex_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trace_id text NOT NULL,
  mode text NOT NULL DEFAULT 'incremental',
  table_name text NOT NULL DEFAULT 'canon_entities',
  batch_size integer NOT NULL DEFAULT 32,
  total_candidates integer NOT NULL DEFAULT 0,
  processed integer NOT NULL DEFAULT 0,
  failed integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'running',
  error text,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);
GRANT SELECT ON public.embedding_reindex_runs TO authenticated;
GRANT ALL ON public.embedding_reindex_runs TO service_role;
ALTER TABLE public.embedding_reindex_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins read reindex runs" ON public.embedding_reindex_runs
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- 3. Audit export runs (signed)
CREATE TABLE IF NOT EXISTS public.audit_export_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trace_id text NOT NULL,
  export_type text NOT NULL,
  format text NOT NULL,
  schema_version text NOT NULL DEFAULT 'v1',
  total_events integer NOT NULL DEFAULT 0,
  content_hash text NOT NULL,
  signature text NOT NULL,
  signing_key_id text NOT NULL,
  requested_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  filters jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.audit_export_runs TO authenticated;
GRANT ALL ON public.audit_export_runs TO service_role;
ALTER TABLE public.audit_export_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins/gobierno read exports" ON public.audit_export_runs
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'gobierno'));
