
-- =========================================================
-- MÓDULO A: Isabella AI Runtime v4
-- =========================================================

-- A.1 Sessions
CREATE TABLE public.isabella_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  thread_id text NOT NULL,
  persona_mode text NOT NULL DEFAULT 'guardian',
  status text NOT NULL DEFAULT 'open',
  opened_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.isabella_sessions TO authenticated;
GRANT ALL ON public.isabella_sessions TO service_role;
ALTER TABLE public.isabella_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "isabella_sessions_select_own" ON public.isabella_sessions FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "isabella_sessions_insert_self" ON public.isabella_sessions FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "isabella_sessions_update_own" ON public.isabella_sessions FOR UPDATE TO authenticated
  USING (user_id = auth.uid());
CREATE INDEX idx_isabella_sessions_user ON public.isabella_sessions(user_id, opened_at DESC);

-- A.2 Messages
CREATE TABLE public.isabella_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.isabella_sessions(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  role text NOT NULL CHECK (role IN ('user','assistant','system','tool')),
  content text NOT NULL,
  module_invoked text,
  latency_ms integer,
  tokens_in integer,
  tokens_out integer,
  ethical_flag text DEFAULT 'safe',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.isabella_messages TO authenticated;
GRANT ALL ON public.isabella_messages TO service_role;
ALTER TABLE public.isabella_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "isabella_messages_select_own" ON public.isabella_messages FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE INDEX idx_isabella_messages_session ON public.isabella_messages(session_id, created_at);

-- A.3 Module runs
CREATE TABLE public.isabella_module_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid REFERENCES public.isabella_sessions(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  module_code text NOT NULL CHECK (module_code IN ('MASC','FML','NRA','MRS','MAAI','MCEA','PRAC')),
  input jsonb NOT NULL DEFAULT '{}'::jsonb,
  output jsonb NOT NULL DEFAULT '{}'::jsonb,
  decision text NOT NULL DEFAULT 'allow',
  reason text,
  latency_ms integer,
  hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.isabella_module_runs TO authenticated;
GRANT ALL ON public.isabella_module_runs TO service_role;
ALTER TABLE public.isabella_module_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "isabella_module_runs_select_own" ON public.isabella_module_runs FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE INDEX idx_isabella_module_runs_user ON public.isabella_module_runs(user_id, created_at DESC);

-- A.4 Emotions
CREATE TABLE public.isabella_emotions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  session_id uuid REFERENCES public.isabella_sessions(id) ON DELETE SET NULL,
  valence numeric NOT NULL DEFAULT 0,    -- -1 .. 1
  arousal numeric NOT NULL DEFAULT 0,    -- 0 .. 1
  dominance numeric NOT NULL DEFAULT 0.5,-- 0 .. 1
  context text,
  source text NOT NULL DEFAULT 'NRA',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.isabella_emotions TO authenticated;
GRANT ALL ON public.isabella_emotions TO service_role;
ALTER TABLE public.isabella_emotions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "isabella_emotions_select_own" ON public.isabella_emotions FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE INDEX idx_isabella_emotions_user ON public.isabella_emotions(user_id, created_at DESC);

-- A.5 Ethical decisions
CREATE TABLE public.isabella_ethical_decisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid REFERENCES public.isabella_sessions(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  decision text NOT NULL CHECK (decision IN ('allow','warn','block','escalate')),
  reason text NOT NULL,
  triggered_module text,
  payload_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.isabella_ethical_decisions TO authenticated;
GRANT ALL ON public.isabella_ethical_decisions TO service_role;
ALTER TABLE public.isabella_ethical_decisions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "isabella_eth_select_own" ON public.isabella_ethical_decisions FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- =========================================================
-- MÓDULO B: Hardening (KYC + PQC + CLEI)
-- =========================================================

-- B.1 KYC records
CREATE TABLE public.kyc_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','in_review','verified','rejected','expired')),
  document_hash text NOT NULL,
  document_type text NOT NULL,
  jurisdiction text NOT NULL DEFAULT 'MX',
  verifier text,
  verified_at timestamptz,
  rejection_reason text,
  expires_at timestamptz,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.kyc_records TO authenticated;
GRANT ALL ON public.kyc_records TO service_role;
ALTER TABLE public.kyc_records ENABLE ROW LEVEL SECURITY;
CREATE POLICY "kyc_select_own" ON public.kyc_records FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "kyc_insert_self" ON public.kyc_records FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "kyc_update_admin" ON public.kyc_records FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- B.2 KYC verifications
CREATE TABLE public.kyc_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kyc_id uuid NOT NULL REFERENCES public.kyc_records(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  provider text NOT NULL DEFAULT 'manual',
  payload_hash text NOT NULL,
  result text NOT NULL,
  reviewer uuid,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.kyc_verifications TO authenticated;
GRANT ALL ON public.kyc_verifications TO service_role;
ALTER TABLE public.kyc_verifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "kyc_ver_select_own" ON public.kyc_verifications FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- B.3 PQC keys
CREATE TABLE public.pqc_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_id uuid REFERENCES public.isni_entities(id) ON DELETE CASCADE,
  owner_id uuid,
  algorithm text NOT NULL DEFAULT 'ML-DSA-65',
  is_pqc_ready boolean NOT NULL DEFAULT false,
  public_key_b64 text NOT NULL,
  key_id text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','rotated','revoked')),
  rotated_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.pqc_keys TO anon, authenticated;
GRANT ALL ON public.pqc_keys TO service_role;
ALTER TABLE public.pqc_keys ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pqc_keys_public_read" ON public.pqc_keys FOR SELECT USING (true);

-- B.4 CLEI audit chain
CREATE TABLE public.clei_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sequence bigserial NOT NULL,
  event_type text NOT NULL,
  actor_id uuid,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  hash text NOT NULL UNIQUE,
  prev_hash text,
  signature text NOT NULL,
  signing_key_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.clei_audit TO anon, authenticated;
GRANT ALL ON public.clei_audit TO service_role;
ALTER TABLE public.clei_audit ENABLE ROW LEVEL SECURITY;
CREATE POLICY "clei_audit_public_read" ON public.clei_audit FOR SELECT USING (true);
CREATE INDEX idx_clei_audit_seq ON public.clei_audit(sequence);

-- Touch triggers
CREATE TRIGGER trg_isabella_sessions_touch BEFORE UPDATE ON public.isabella_sessions
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_kyc_records_touch BEFORE UPDATE ON public.kyc_records
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
