import { Link } from "@tanstack/react-router";
import { useI18n, type Lang } from "@/lib/i18n";
import { RealmontenseBadge } from "@/components/RealmontenseBadge";
import type { ReactNode } from "react";

function LangSwitch() {
  const { lang, setLang } = useI18n();
  const opt = (l: Lang, label: string) => (
    <button
      onClick={() => setLang(l)}
      className={`mono text-[10px] tracking-[0.2em] px-2 py-1 rounded-sm transition ${
        lang === l ? "text-primary text-glow" : "text-muted-foreground hover:text-foreground"
      }`}
      aria-pressed={lang === l}
    >
      {label}
    </button>
  );
  return (
    <div className="flex items-center gap-1 hairline rounded-sm px-1">
      {opt("es", "ES")}
      <span className="text-muted-foreground/40">·</span>
      {opt("en", "EN")}
    </div>
  );
}

function NavLink({ to, children }: { to: string; children: ReactNode }) {
  return (
    <Link
      to={to}
      className="mono text-[11px] tracking-[0.18em] uppercase text-muted-foreground hover:text-foreground transition relative py-1"
      activeProps={{ className: "mono text-[11px] tracking-[0.18em] uppercase text-primary text-glow py-1" }}
    >
      {children}
    </Link>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const { t } = useI18n();
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-background/60 border-b border-border">
        <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between gap-6">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="relative w-7 h-7">
              <div className="absolute inset-0 rounded-full border border-primary/60" style={{ animation: "orbit 18s linear infinite" }}>
                <span className="absolute -top-[3px] left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_12px_var(--glow)]" />
              </div>
              <div className="absolute inset-1.5 rounded-full bg-primary/20 border border-primary/40" />
            </div>
            <div className="leading-none">
              <div className="font-display text-base tracking-wide">ATLAS <span className="text-primary">TRASCENDENCE</span></div>
              <div className="mono text-[9px] tracking-[0.25em] uppercase text-muted-foreground mt-0.5">TAMV · ONLINE</div>
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-7">
            <NavLink to="/">{t("nav.manifest")}</NavLink>
            <NavLink to="/federations">{t("nav.federations")}</NavLink>
            <NavLink to="/doctrine">{t("nav.doctrine")}</NavLink>
            <NavLink to="/genesis">{t("nav.genesis")}</NavLink>
            <NavLink to="/kernel">{t("nav.kernel")}</NavLink>
            <NavLink to="/atlas">{t("nav.atlas")}</NavLink>
          </nav>
          <LangSwitch />
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-border mt-24">
        <div className="mx-auto max-w-7xl px-6 py-10 flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
          <div>
            <div className="font-display text-lg">ATLAS TRASCENDENCE</div>
            <div className="mono text-[10px] tracking-[0.22em] uppercase text-muted-foreground mt-1">
              {t("brand.origin")}
            </div>
            <div className="mt-3"><RealmontenseBadge /></div>
          </div>
          <div className="mono text-[10px] tracking-[0.18em] uppercase text-muted-foreground max-w-md md:text-right">
            {t("footer.tag")}
          </div>
        </div>
      </footer>
    </div>
  );
}
