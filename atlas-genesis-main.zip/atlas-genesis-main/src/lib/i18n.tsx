import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "es" | "en";

type Dict = Record<string, { es: string; en: string }>;

export const dict: Dict = {
  "nav.manifest": { es: "Manifiesto", en: "Manifest" },
  "nav.federations": { es: "Federaciones", en: "Federations" },
  "nav.doctrine": { es: "Doctrina", en: "Doctrine" },
  "nav.genesis": { es: "GENESIS", en: "GENESIS" },
  "nav.kernel": { es: "Kernel", en: "Kernel" },
  "nav.atlas": { es: "Atlas", en: "Atlas" },
  "brand.tag": { es: "Metasistema civilizatorio heptafederado", en: "Heptafederated civilizational metasystem" },
  "brand.origin": { es: "Originado en LATAM · by TAMV ONLINE", en: "Originated in LATAM · by TAMV ONLINE" },
  "hero.kicker": { es: "ATLAS TRASCENDENCE", en: "ATLAS TRASCENDENCE" },
  "hero.title": { es: "Preservando todo aquello que la humanidad considera digno de ser recordado.", en: "Preserving everything humanity deems worthy of being remembered." },
  "hero.lede": {
    es: "No es una aplicación. No es una plataforma. Es una infraestructura para la memoria, la identidad y la evolución de la humanidad en la era digital.",
    en: "Not an application. Not a platform. An infrastructure for memory, identity and evolution of humanity in the digital era."
  },
  "hero.cta": { es: "Explorar las 7 federaciones", en: "Explore the 7 federations" },
  "hero.cta2": { es: "Leer GENESIS TAMVPRINT", en: "Read GENESIS TAMVPRINT" },
  "section.federations": { es: "Las Siete Federaciones", en: "The Seven Federations" },
  "section.federations.lede": {
    es: "Cada federación es autónoma en ejecución, pero todas obedecen una misma doctrina estructural.",
    en: "Each federation is autonomous in execution, yet all obey one structural doctrine."
  },
  "section.doctrine": { es: "Doctrina Axiomática", en: "Axiomatic Doctrine" },
  "section.doctrine.lede": { es: "Principios no negociables que ninguna implementación puede violar.", en: "Non-negotiable principles no implementation may violate." },
  "section.genesis": { es: "GENESIS TAMVPRINT", en: "GENESIS TAMVPRINT" },
  "section.genesis.lede": { es: "Arquitectura fundacional híbrida · Plano · Roadmap · Whitepaper · Manifiesto · Blueprint", en: "Hybrid foundational architecture · Blueprint · Roadmap · Whitepaper · Manifest · Plan" },
  "kernel.title": { es: "Atlas Kernel", en: "Atlas Kernel" },
  "kernel.sub": { es: "El grafo civilizatorio · entidades, relaciones, eventos", en: "The civilizational graph · entities, relations, events" },
  "footer.tag": { es: "Construido no solo para funcionar — sino para trascender.", en: "Built not only to function — but to transcend." },
  "back": { es: "Volver", en: "Back" },
  "explore": { es: "Explorar federación", en: "Explore federation" },
};

const Ctx = createContext<{ lang: Lang; setLang: (l: Lang) => void; t: (k: keyof typeof dict) => string }>({
  lang: "es",
  setLang: () => {},
  t: (k) => k as string,
});

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("es");
  useEffect(() => {
    const saved = typeof window !== "undefined" ? (localStorage.getItem("atlas.lang") as Lang | null) : null;
    if (saved === "es" || saved === "en") setLangState(saved);
  }, []);
  const setLang = (l: Lang) => {
    setLangState(l);
    if (typeof window !== "undefined") localStorage.setItem("atlas.lang", l);
  };
  const t = (k: keyof typeof dict) => dict[k]?.[lang] ?? (k as string);
  return <Ctx.Provider value={{ lang, setLang, t }}>{children}</Ctx.Provider>;
}

export const useI18n = () => useContext(Ctx);
